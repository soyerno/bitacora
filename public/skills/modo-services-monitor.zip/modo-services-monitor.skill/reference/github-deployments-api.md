# GitHub Deployments API · source-of-truth de versiones desplegadas

GitHub registra cada deploy via Deployments API. Para cualquier repo `playsistemico/*` con workflows que llaman a `gh api` o `actions/deploy*`, este endpoint da el SHA + branch + timestamp del último deploy por env.

## Endpoint

```bash
gh api "repos/playsistemico/<repo>/deployments?environment=<env>&per_page=1" \
  --jq '.[] | {sha: .sha[:7], ref, created_at, env: .environment}'
```

**Environments comunes en MODO**: `develop · qa · preprod · production`.

## Sample output

```json
{
  "sha": "34cdfab",
  "ref": "main",
  "created_at": "2026-05-20T20:30:49Z",
  "env": "production"
}
```

## Status check (¿el deploy fue exitoso?)

```bash
deploy_id=$(gh api "repos/playsistemico/<repo>/deployments?environment=production&per_page=1" --jq '.[].id')
gh api "repos/playsistemico/<repo>/deployments/${deploy_id}/statuses?per_page=1" \
  --jq '.[] | {state, description, created_at}'
```

Estados posibles: `success · failure · in_progress · pending · queued · error · inactive`.

Si el último deployment está en `failure`, lo que está corriendo es el penúltimo `success`. Para apps en prod este edge case importa — ajustar query a `?per_page=10 | first(.[] | select(.state=="success"))` si necesitás "qué está REALMENTE corriendo".

## Patterns reusables

### Pattern A · Versiones cross-env para 1 repo

```bash
for env in develop qa preprod production; do
  data=$(gh api "repos/playsistemico/<repo>/deployments?environment=${env}&per_page=1" --jq '.[0]')
  sha=$(echo "$data" | jq -r '.sha[:7]')
  ref=$(echo "$data" | jq -r '.ref')
  printf "%-12s %s @ %s\n" "$env" "$sha" "$ref"
done
```

### Pattern B · Workspace × env grid (este skill)

Walk `~/Documents/Proyectos/modo` → discover `playsistemico/*` repos via `git remote` → parallel fetch deployments per env → render Markdown table. Ver `scripts/check-versions.sh`.

### Pattern C · Drift detection (prod ↔ preprod)

```bash
prod_sha=$(gh api "repos/playsistemico/<repo>/deployments?environment=production&per_page=1" --jq '.[].sha')
prep_sha=$(gh api "repos/playsistemico/<repo>/deployments?environment=preprod&per_page=1" --jq '.[].sha')
if [[ "$prod_sha" != "$prep_sha" ]]; then
  ahead=$(gh api "repos/playsistemico/<repo>/compare/${prod_sha}...${prep_sha}" --jq '.ahead_by')
  echo "preprod ahead de prod por $ahead commits"
fi
```

## Limitaciones

- **Deployment events vs. lo que CORRE realmente** — un workflow puede crear el deployment record pero el pod puede haber sido rolled-back manualmente sin actualizar GH. Para "what's actually running RIGHT NOW", probar `/api/version` del runtime o consultar k8s directo.
- **Repos sin Deployments API uso** — algunos repos MODO no llaman a `gh api deployments` desde sus workflows (usan ArgoCD u otro). Para esos, este endpoint devuelve `[]`. Ver `check-versions.sh` para handling de `null`.
- **Rate limit GitHub API** — 5000 req/h con PAT. 25 repos × 4 envs = 100 req → OK. Si el workspace crece >50 repos, paginar o paralelizar con `wait` y mostrar progreso.

## Endpoint relacionado

- `repos/<owner>/<repo>/releases/latest` — si el repo tiene GitHub Releases con tags semver, devuelve `tag_name + published_at`. Útil para libs versionadas (`@playsistemico/modo-ui-lib-web@1.32.1`) pero no para servicios deployables.
- `repos/<owner>/<repo>/commits?sha=<branch>&per_page=1` — último commit en una branch específica. Útil para detectar drift PR ↔ deploy.
