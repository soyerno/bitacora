# Bash portability rules · macOS bash 3.2

macOS ships bash 3.2 (2007). Cualquier script `#!/usr/bin/env bash` que asume bash 4+ va a romper en máquinas dev MODO sin fix. La skill `modo-services-monitor` corrió en estos traps. Documento canónico para no repetirlos.

## Variable interpolation con `set -u`

**Anti-pattern**:
```bash
set -u
reason="ok"
echo "_$reason_"   # Bash lee $reason_ como nombre completo → "unbound variable"
```

**Pattern**:
```bash
set -u
reason="ok"
echo "_${reason}_"   # Las braces delimitan el nombre exacto
```

**Regla**: si el char inmediatamente después de `$varname` es válido como identifier (`[A-Za-z0-9_]`), usar braces. Sin braces, bash extiende la lectura del nombre.

**Caso canónico**: `render.sh` línea 83 cazado en smoke verbose 2026-05-25.

## Asociative arrays no existen en bash 3.2

**Anti-pattern**:
```bash
declare -A seen=()
seen[$key]=1
[[ -n "${seen[$key]:-}" ]] && continue
```
Error: `declare: -A: invalid option`.

**Pattern**:
```bash
SEEN_LIST=""
for x in "${items[@]}"; do
  case " $SEEN_LIST " in
    *" $x "*) continue ;;
  esac
  SEEN_LIST="$SEEN_LIST $x"
done
```

Flat string + `case` con espacios delimitadores. Funciona en bash 3.2, 4.x, 5.x.

**Caso canónico**: dedupe de repos en `check-versions.sh` (un repo cloneado en varios paths).

## `local` dentro de loops

Si declarás `local var1 var2 var3` sin asignación y el loop hace `var1=value` después, en bash 3.2 puede imprimir `var1=value` en stdout en algunas configuraciones de shell. Workaround:

```bash
setopt local_options typeset_silent 2>/dev/null  # zsh-only
# En bash, asignar en la declaración:
local var1="" var2="" var3=""
```

Ver memoria `feedback_zsh_local_pollution.md` para el caso canónico (motd-status.sh).

## Detectar bash version

```bash
if (( BASH_VERSINFO[0] < 4 )); then
  echo "bash 3.2 fallback" >&2
fi
```

Si el script REQUIERE bash 4+, agregar shebang explícito y verificación temprana — no asumir.

## Otros traps típicos

- `mapfile` / `readarray` — bash 4+. Usar `while IFS= read -r line` en 3.2.
- `**` glob expansion — necesita `shopt -s globstar` (bash 4+). Usar `find` directo.
- `${var,,}` lowercase / `${var^^}` uppercase — bash 4+. Usar `tr` en 3.2.
- `wait -n` (single-process wait) — bash 4.3+. Usar `wait` plano y manejar todos.
