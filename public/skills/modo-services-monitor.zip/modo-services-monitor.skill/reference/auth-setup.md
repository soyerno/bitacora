# Auth setup · status.modo.com.ar

`status.modo.com.ar` está protegido por Auth0 (tenant `playdigital-develop` para dev / `portal-modo-prod` para prod). Toda ruta `/api/*` excepto `/api/health` exige Cookie de sesión o Bearer JWT.

La skill `modo-services-monitor` soporta tres caminos para conseguir credenciales (más sencillo → más robusto).

## Opción A · Pasar cookie del browser (rápido, 5 min)

Tras login interactivo en https://status.modo.com.ar:

1. Abrir DevTools → Application → Cookies → `https://status.modo.com.ar`.
2. Copiar **todas** las cookies relevantes (`appSession`, `auth0.*`, JWT cookie si aparece) en formato `key1=val1; key2=val2; ...`.
3. Guardar en `~/.config/modo-services-monitor.env`:

   ```bash
   mkdir -p ~/.config
   cat > ~/.config/modo-services-monitor.env <<'EOF'
   MODO_STATUS_COOKIE="appSession=eyJhbGc...; auth0.is.authenticated=true; ..."
   EOF
   chmod 600 ~/.config/modo-services-monitor.env
   ```

4. Test:

   ```bash
   bash ~/.claude/skills/modo-services-monitor/scripts/check-modo.sh | jq .ok
   # → true
   ```

**Limitación**: la session cookie expira (típicamente 8-24h). Hay que repetir el paste cuando vuelve a fallar (`auth-failed` en el output del skill).

## Opción B · Extraer JWT directo (más estable)

Si el front del status-page usa JWT en lugar de session cookie:

1. Network tab → request a `/api/services` → headers → copiar `Authorization: Bearer <token>`.
2. Guardar:

   ```bash
   cat > ~/.config/modo-services-monitor.env <<'EOF'
   MODO_STATUS_JWT="eyJhbGciOiJSUzI1NiIs..."
   EOF
   chmod 600 ~/.config/modo-services-monitor.env
   ```

JWTs típicamente expiran cada 1h pero suelen tener refresh tokens. Pasta el JWT más reciente cuando expire.

## Opción C · Auth0 client_credentials (machine-to-machine)

Camino canónico — no requiere navegador y no expira hasta TTL de Auth0 (1h con refresh automático). **Requiere ticket Cyber para conseguir CLIENT_ID + CLIENT_SECRET** vía el [Jira Service Management de MODO](https://play-sistemico.atlassian.net/servicedesk/customer/portals).

Pedido tipo (template del skill `modo-jsm-ticket`):

> **Asunto**: Acceso M2M Auth0 para `status.modo.com.ar` (CLI dev tooling)
>
> **Justificación**: Personal CLI tool (`modo-services-monitor`) que necesita read-only access a `GET /api/last-incidents` + `/api/services` para mostrar status panel desde Claude Code. Sin escrituras, sin acceso a banks / users / subscriptions.
>
> **Scope solicitado**: `read:incidents read:services`
>
> **Audience**: `https://status.modo.com.ar/api`

Una vez aprobado, agregar al `~/.config/modo-services-monitor.env`:

```bash
AUTH0_DOMAIN="playdigital-develop.auth0.com"
AUTH0_CLIENT_ID="..."
AUTH0_CLIENT_SECRET="..."
AUTH0_AUDIENCE="https://status.modo.com.ar/api"
```

> **TODO V1.1**: agregar `scripts/refresh-token.sh` que haga el POST a `/oauth/token` con `grant_type=client_credentials` y persista el JWT con TTL. La skill lo invocará auto cuando detecte `auth-failed`.

## Verificar acceso

```bash
# Probar capa 2 directamente
bash ~/.claude/skills/modo-services-monitor/scripts/check-modo.sh | jq .

# Output esperado en success:
# {
#   "ok": true,
#   "reason": "ok",
#   "incidents": [...],
#   "services": [...]
# }

# Output esperado sin auth:
# {"ok": false, "reason": "no-auth", "hint": "..."}
```

## Higiene

- Permisos `600` siempre en `~/.config/modo-services-monitor.env`.
- Nunca commitear el archivo (debería estar en `.gitignore` global; verificar con `git check-ignore`).
- Nunca imprimir el JWT en stdout / logs / decks. Si el user pide ver el token, decir "está en `~/.config/modo-services-monitor.env`" sin mostrarlo.
- Rotación: si sospechás que el token leakeó (lo pegaste por error en chat, screenshot, etc.) → revocar en Auth0 admin + abrir ticket Cyber.
