# Perf patterns · modo-services-monitor

Aprendizajes de la sesión V1.2 (2026-05-26) sobre cómo hacer que el verbose mode no tarde 22s.

## Lección 1 · gh REST en loop = anti-pattern para datos bulk

V1.1 ejecutaba `gh api repos/.../deployments?environment=<env>&per_page=1` por cada repo × cada env. Con 25 repos × 4 envs = **100 invocaciones gh CLI**. Cada invocación:

- ~300ms de startup (node process).
- Auth handshake (cookie/token check).
- 1 round-trip HTTP.

Aun paralelizando: el OS limita procesos concurrentes + GitHub rate-limita conexiones desde la misma IP. Resultado: ~22s end-to-end.

## Lección 2 · gh GraphQL con aliases = la fix

GitHub GraphQL acepta queries con múltiples aliases en una sola call:

```graphql
query {
  r0: repository(owner: "playsistemico", name: "modo-landing") {
    name
    production: deployments(environments: ["production"], first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }
    preprod:    deployments(environments: ["preprod"],    first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }
    qa:         deployments(environments: ["qa"],         first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }
    develop:    deployments(environments: ["develop"],    first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }
  }
  r1: repository(owner: "playsistemico", name: "promos-hub-site") { ... }
  ...
}
```

**1 gh call · 1 round-trip · ~3-6s para 30 repos × 4 envs**. 6x speedup vs REST loop.

### Cómo construir la query desde bash

```bash
{
  echo "query {"
  for i in "${!REPO_NAMES[@]}"; do
    n="${REPO_NAMES[$i]}"
    echo "  r${i}: repository(owner: \"playsistemico\", name: \"${n}\") {"
    echo "    name"
    for env in $ENVS; do
      echo "    ${env}: deployments(environments: [\"${env}\"], first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }"
    done
    echo "  }"
  done
  echo "}"
} > "$QUERY_FILE"

gh api graphql -F query=@"$QUERY_FILE" > "$RESP_FILE"
```

Aliases `r0`, `r1`, ... evitan colisión con nombres de repo que tengan hyphens (no son IDs GraphQL válidos sin escapar).

## Lección 3 · gh exit ≠ 0 no implica "no data"

Si un repo aliasado no existe (archived, private, typo), GitHub devuelve `errors: [...]` pero el campo `data` sigue poblado para los demás. gh CLI sale con código no-cero igual.

**Anti-pattern**:
```bash
if ! gh api graphql -F query=@q.graphql > resp.json 2>/dev/null; then
  echo "ERROR"; exit 1
fi
```

**Correct**:
```bash
gh api graphql -F query=@q.graphql > resp.json 2>/dev/null || true
if ! jq -e '.data' resp.json >/dev/null 2>&1; then
  echo "ERROR — no data field"; exit 1
fi
# Proceed: data has the accessible repos
```

## Lección 4 · Capas con TTLs distintos

| Capa | TTL | Razón |
|---|---|---|
| 1 · externos | 5min | Statuspages cambian rápido durante un incident |
| 2 · MODO interno | sin cache | Canal oficial de incidents debe ser fresco |
| 3 · versiones | 10min | Deploys MODO son raros, capa más lenta de fetchear |

Forzar refresh: `MSM_FORCE_REFRESH=1 bash check-versions.sh`.

## Lección 5 · Orquestador único `gather-all.sh`

Antes: la skill llamaba 3 scripts secuencialmente o en paralelo bash inline. Difícil mantener cache logic en cada call site.

Después: `gather-all.sh` centraliza:
- Lectura de TTLs.
- Disparo paralelo de las 3 capas (skipping si cache válido).
- Output `EXT=... MODO=... VERSIONS=...` para `eval`.

Path canónico:
```bash
eval "$(bash gather-all.sh verbose)"
MSM_MODO_JSON="$MODO" MSM_VERSIONS_JSON="$VERSIONS" bash render.sh verbose "$EXT"
```

## Lección 6 · El gh CLI startup es el costo fijo

Hasta con la mejor paralelización, gh CLI tarda ~300ms a abrir. Si tenés que hacer ≥4 calls, evaluá si podés combinar todo en una sola GraphQL. Pattern aplicable a cualquier dataset bulk de GitHub: deployments, PRs, issues, workflows, branches.
