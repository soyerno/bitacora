#!/usr/bin/env bash
# modo-services-monitor — status.modo.com.ar internal incidents fetch
# Auth-aware: uses Bearer JWT or Cookie if available.
# Output: JSON to stdout with shape:
#   {"ok": <bool>, "reason": "<str>", "incidents": [...], "services": [...]}
#
# Auth sources (first match wins):
#   1. $MODO_STATUS_JWT       env var
#   2. $MODO_STATUS_COOKIE    env var (paste-from-browser cookie string)
#   3. ~/.config/modo-services-monitor.env  (MODO_STATUS_JWT= / MODO_STATUS_COOKIE=)
#
# If no auth, returns {"ok": false, "reason": "no-auth"} and exits 0 (best-effort).

set -u

BASE="${MODO_STATUS_BASE:-https://status.modo.com.ar}"
TIMEOUT="${MSM_TIMEOUT:-6}"
CFG="${HOME}/.config/modo-services-monitor.env"

# Load creds file if env not set
if [[ -z "${MODO_STATUS_JWT:-}" && -z "${MODO_STATUS_COOKIE:-}" && -r "$CFG" ]]; then
  # shellcheck disable=SC1090
  set -a; source "$CFG"; set +a
fi

# Pick auth header
AUTH_HEADER=""
if [[ -n "${MODO_STATUS_JWT:-}" ]]; then
  AUTH_HEADER="Authorization: Bearer ${MODO_STATUS_JWT}"
elif [[ -n "${MODO_STATUS_COOKIE:-}" ]]; then
  AUTH_HEADER="Cookie: ${MODO_STATUS_COOKIE}"
else
  printf '{"ok":false,"reason":"no-auth","hint":"set MODO_STATUS_JWT or MODO_STATUS_COOKIE; see reference/auth-setup.md"}\n'
  exit 0
fi

# Probe an authenticated endpoint to validate creds (use /api/services as a cheap call)
http_code=$(curl -sI -L --max-time "$TIMEOUT" -o /dev/null -w "%{http_code}" \
  -H "$AUTH_HEADER" "$BASE/api/services" 2>/dev/null)

if [[ "$http_code" != "200" ]]; then
  printf '{"ok":false,"reason":"auth-failed","http_code":"%s"}\n' "$http_code"
  exit 0
fi

# Fetch incidents + services in parallel
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

(curl -sL --max-time "$TIMEOUT" -H "$AUTH_HEADER" "$BASE/api/last-incidents" > "$tmp/incidents.json" 2>/dev/null) &
(curl -sL --max-time "$TIMEOUT" -H "$AUTH_HEADER" "$BASE/api/services"        > "$tmp/services.json"  2>/dev/null) &
wait

# Validate JSON; default to empty arrays on parse failure
inc=$(jq -c '.' "$tmp/incidents.json" 2>/dev/null || echo 'null')
svc=$(jq -c '.' "$tmp/services.json"  2>/dev/null || echo 'null')
[[ "$inc" == "null" || -z "$inc" ]] && inc='[]'
[[ "$svc" == "null" || -z "$svc" ]] && svc='[]'

# Normalize: incidents may be wrapped — try common shapes
inc_arr=$(printf '%s' "$inc" | jq -c 'if type=="array" then . elif .incidents then .incidents elif .data then .data else [] end' 2>/dev/null || echo '[]')
svc_arr=$(printf '%s' "$svc" | jq -c 'if type=="array" then . elif .services then .services elif .data then .data else [] end' 2>/dev/null || echo '[]')

printf '{"ok":true,"reason":"ok","incidents":%s,"services":%s}\n' "$inc_arr" "$svc_arr"
