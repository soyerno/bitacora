#!/usr/bin/env bash
# modo-services-monitor — single-shot orchestrator.
# Fires the 3 layers in parallel respecting cache TTLs and waits.
# Prints the 3 output paths so the caller can pipe them to render.sh.
#
# Usage:
#   bash gather-all.sh           # compact (capa 1 + 2)
#   bash gather-all.sh verbose   # + capa 3 (versiones)
#
# Output (stdout):
#   EXT=<path>
#   MODO=<path>
#   VERSIONS=<path>   # only in verbose mode
#
# Cache TTLs (override via env):
#   MSM_EXT_TTL=300         (5min)  — capa 1
#   MSM_VERSIONS_TTL=600    (10min) — capa 3
# Capa 2 (MODO interno) no se cachea — fetch siempre que haya auth.

set -u

MODE="${1:-compact}"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
EXT_CACHE="${MSM_EXT_CACHE:-${HOME}/.cache/motd-status/status.json}"
MODO_OUT="${MSM_MODO_JSON:-/tmp/msm-modo.json}"
VERSIONS_OUT="${MSM_VERSIONS_JSON:-/tmp/msm-versions.json}"
EXT_TTL="${MSM_EXT_TTL:-300}"

mkdir -p "$(dirname "$EXT_CACHE")"

stale() {
  local f="$1" ttl="$2"
  [[ -f "$f" ]] || return 0
  local age
  age=$(( $(date +%s) - $(stat -f %m "$f" 2>/dev/null || stat -c %Y "$f" 2>/dev/null || echo 0) ))
  [[ $age -ge $ttl ]]
}

pids=()

# Capa 1 — externos (cache 5min)
if stale "$EXT_CACHE" "$EXT_TTL"; then
  bash "$SKILL_DIR/scripts/check-external.sh" "$EXT_CACHE" >/dev/null 2>&1 &
  pids+=($!)
fi

# Capa 2 — MODO interno (no cache, capa fail-soft)
bash "$SKILL_DIR/scripts/check-modo.sh" > "$MODO_OUT" 2>/dev/null &
pids+=($!)

# Capa 3 — versions (cache 10min, solo verbose)
if [[ "$MODE" == "verbose" || "$MODE" == "detailed" ]]; then
  bash "$SKILL_DIR/scripts/check-versions.sh" "$VERSIONS_OUT" >/dev/null 2>&1 &
  pids+=($!)
fi

for p in "${pids[@]}"; do wait "$p" 2>/dev/null || true; done

echo "EXT=$EXT_CACHE"
echo "MODO=$MODO_OUT"
[[ "$MODE" == "verbose" || "$MODE" == "detailed" ]] && echo "VERSIONS=$VERSIONS_OUT"
