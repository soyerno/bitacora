#!/usr/bin/env bash
# modo-services-monitor — render combined snapshot as Markdown table + TLDR
# Reads:
#   - MOTD cache:    ~/.cache/motd-status/status.json   (preferred for capa 1)
#   - External:      stdin or first arg (JSON from check-external.sh)
#   - MODO API:      $MSM_MODO_JSON       (check-modo.sh output, optional)
#   - Versions:      $MSM_VERSIONS_JSON   (check-versions.sh output, optional)
#   - Catalog:       data/services-catalog.json (always loaded)
#
# Modes (env var MSM_MODE or first non-path arg):
#   "compact"  (default) — grid + TLDR if degraded
#   "verbose"            — grid + TLDR + per-service WHAT + IMPACT + versions
#
# Output: Markdown to stdout.

set -u

# First non-mode arg is the external snapshot path
MODE="${MSM_MODE:-compact}"
EXT_SRC=""
for arg in "$@"; do
  case "$arg" in
    compact|verbose|detailed) MODE="$arg" ;;
    *) [[ -z "$EXT_SRC" ]] && EXT_SRC="$arg" ;;
  esac
done
[[ -z "$EXT_SRC" ]] && EXT_SRC="${HOME}/.cache/motd-status/status.json"
[[ "$MODE" == "detailed" ]] && MODE="verbose"

MODO_SRC="${MSM_MODO_JSON:-}"
VERS_SRC="${MSM_VERSIONS_JSON:-}"
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CATALOG="${MSM_CATALOG:-${SCRIPT_DIR}/../data/services-catalog.json}"

if [[ ! -s "$EXT_SRC" ]]; then
  echo "**no data** — ejecutá \`bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh ~/.cache/motd-status/status.json\` primero, o \`motd-refresh\` desde la terminal."
  exit 0
fi

emoji_for() {
  case "$1" in
    none|ok|operational)  printf "🟢" ;;
    minor)                printf "🟡" ;;
    major)                printf "🟠" ;;
    critical|down)        printf "🔴" ;;
    maintenance)          printf "🔵" ;;
    *)                    printf "⚪" ;;
  esac
}

# Emit Markdown table 3 cols × N rows
emit_grid() {
  local rows
  rows=$(jq -r '.services[] | "\(.indicator)\t\(.name)\t\(.label)"' "$EXT_SRC" 2>/dev/null)
  [[ -z "$rows" ]] && { echo "_(cache vacío)_"; return; }

  echo "**Servicios externos + MODO público**"
  echo
  echo "| Servicio | Servicio | Servicio |"
  echo "|---|---|---|"

  local cells=()
  while IFS=$'\t' read -r ind name lab; do
    local emoji
    emoji=$(emoji_for "$ind")
    cells+=("$emoji $name")
  done <<< "$rows"

  local n=${#cells[@]} i=0
  while [[ $i -lt $n ]]; do
    local a="${cells[$i]:-}" b="${cells[$((i+1))]:-}" c="${cells[$((i+2))]:-}"
    echo "| $a | $b | $c |"
    i=$((i+3))
  done
  echo
}

# TLDR — only emit if any degraded service
emit_tldr_external() {
  local bad
  bad=$(jq -r '.services[] | select(.indicator!="none" and .indicator!="ok" and .indicator!="operational") | "- \(.indicator | ascii_upcase): **\(.name)** — \(.label)"' "$EXT_SRC" 2>/dev/null)
  if [[ -n "$bad" ]]; then
    echo "**TLDR · externos**"
    echo
    echo "$bad"
    echo
  fi
}

emit_modo() {
  [[ -z "$MODO_SRC" || ! -s "$MODO_SRC" ]] && return

  local ok reason
  ok=$(jq -r '.ok // false' "$MODO_SRC" 2>/dev/null)
  reason=$(jq -r '.reason // "?"' "$MODO_SRC" 2>/dev/null)

  if [[ "$ok" != "true" ]]; then
    echo "**status.modo.com.ar** — _${reason}_ (ver \`reference/auth-setup.md\` para wire-up auth)"
    echo
    return
  fi

  local inc_count svc_count
  inc_count=$(jq '.incidents | length' "$MODO_SRC" 2>/dev/null)
  svc_count=$(jq '.services  | length' "$MODO_SRC" 2>/dev/null)

  echo "**status.modo.com.ar** — $svc_count servicios catalogados · $inc_count incidents recientes"
  echo

  # Open incidents (no end date / not resolved)
  local open_inc
  open_inc=$(jq -r '.incidents[] | select((.endedAt // .resolvedAt // .closedAt) == null) | "- **\(.title // .name // "incident")** — \(.severity // .status // "?") · \(.startedAt // .createdAt // "?")"' "$MODO_SRC" 2>/dev/null)

  if [[ -n "$open_inc" ]]; then
    echo "**TLDR · MODO incidents abiertos**"
    echo
    echo "$open_inc"
    echo
  fi
}

ts=$(jq -r '.ts // 0' "$EXT_SRC" 2>/dev/null)
now=$(date +%s)
age=$((now - ts))
if   [[ $age -lt 60   ]]; then age_str="${age}s ago"
elif [[ $age -lt 3600 ]]; then age_str="$((age/60))m ago"
elif [[ $age -lt 86400 ]]; then age_str="$((age/3600))h ago"
else                           age_str="$((age/86400))d ago"
fi

# ---------------------------------------------------------------------------
# Verbose mode helpers
# ---------------------------------------------------------------------------

# Emit per-service detail: WHAT + IMPACT EN MODO, joined with current indicator
emit_service_detail() {
  [[ ! -r "$CATALOG" ]] && { echo "_(catalog file missing at $CATALOG)_"; return; }

  echo "### Detalle por servicio"
  echo

  local rows
  rows=$(jq -r '.services[] | "\(.key)\t\(.indicator)\t\(.name)\t\(.label)"' "$EXT_SRC" 2>/dev/null)
  [[ -z "$rows" ]] && return

  while IFS=$'\t' read -r key ind name lab; do
    local emoji crit what impact
    emoji=$(emoji_for "$ind")
    what=$(jq -r --arg k "$key" '.services[$k].what // "—"' "$CATALOG" 2>/dev/null)
    impact=$(jq -r --arg k "$key" '.services[$k].impact_modo // "Sin descripción de impacto."' "$CATALOG" 2>/dev/null)
    crit=$(jq -r --arg k "$key" '.services[$k].criticality // "—"' "$CATALOG" 2>/dev/null)

    echo "**${emoji} ${name}** · _criticality: ${crit}_ · status: \`${lab}\`"
    echo
    echo "- **Qué es**: ${what}"
    echo "- **Impacto en MODO si cae**: ${impact}"
    echo
  done <<< "$rows"
}

# Emit versions table — repos × envs grid
emit_versions() {
  [[ -z "$VERS_SRC" || ! -s "$VERS_SRC" ]] && return

  local err
  err=$(jq -r '.error // empty' "$VERS_SRC" 2>/dev/null)
  if [[ -n "$err" ]]; then
    echo "### Versiones desplegadas"
    echo
    echo "_no disponible — $err_"
    echo
    return
  fi

  local n
  n=$(jq '.repos | length' "$VERS_SRC" 2>/dev/null)
  [[ "$n" == "0" || -z "$n" ]] && return

  # Detect envs present in the data (union across repos)
  local envs
  envs=$(jq -r '[.repos[].envs | keys[]] | unique | .[]' "$VERS_SRC" 2>/dev/null \
         | tr '\n' ' ' | sed 's/ $//')
  [[ -z "$envs" ]] && return

  echo "### Versiones desplegadas (workspace × env)"
  echo
  echo "_Última deployment registrada por GitHub Deployments API. SHA + branch + fecha._"
  echo

  # Header
  local hdr="| Repo |"
  local sep="|---|"
  for e in $envs; do
    hdr+=" ${e} |"
    sep+="---|"
  done
  echo "$hdr"
  echo "$sep"

  # Rows — one per repo
  local repos_json
  repos_json=$(jq -c '.repos[]' "$VERS_SRC" 2>/dev/null)
  while IFS= read -r row; do
    [[ -z "$row" ]] && continue
    local rname
    rname=$(printf '%s' "$row" | jq -r '.repo')
    local line="| **${rname}** |"
    for e in $envs; do
      local sha ref created cell
      sha=$(printf '%s' "$row" | jq -r --arg e "$e" '.envs[$e].sha // empty')
      ref=$(printf '%s' "$row" | jq -r --arg e "$e" '.envs[$e].ref // empty')
      created=$(printf '%s' "$row" | jq -r --arg e "$e" '.envs[$e].created_at // empty')
      if [[ -z "$sha" ]]; then
        cell="—"
      else
        local date_short="${created:0:10}"
        cell="\`${sha}\` ${ref} · ${date_short}"
      fi
      line+=" ${cell} |"
    done
    echo "$line"
  done <<< "$repos_json"
  echo
}

# Emit repo-level functional descriptions (from catalog)
emit_repo_catalog() {
  [[ ! -r "$CATALOG" ]] && return

  local repos_in_catalog
  repos_in_catalog=$(jq -r '.repos_to_track | keys[]' "$CATALOG" 2>/dev/null)
  [[ -z "$repos_in_catalog" ]] && return

  echo "### Catálogo de repos MODO trackeados"
  echo

  while IFS= read -r r; do
    [[ -z "$r" ]] && continue
    local desc team
    desc=$(jq -r --arg r "$r" '.repos_to_track[$r].describe // "—"' "$CATALOG")
    team=$(jq -r --arg r "$r" '.repos_to_track[$r].owner_team // "—"' "$CATALOG")
    echo "- **${r}** · _${team}_ — ${desc}"
  done <<< "$repos_in_catalog"
  echo
}

# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------

echo "_snapshot cacheado · $age_str · modo: \`${MODE}\` · refresh: \`motd-refresh\`_"
echo
emit_grid
emit_tldr_external
emit_modo

if [[ "$MODE" == "verbose" ]]; then
  emit_service_detail
  emit_versions
  emit_repo_catalog
fi
