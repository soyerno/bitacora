#!/usr/bin/env bash
# modo-services-monitor — fetch last deployment per env for MODO repos.
# Single GraphQL call (gh api graphql) for ALL repos × ALL envs at once.
# Before: N gh REST calls × 4 envs → 68+ subprocesses, ~22s.
# After:  1 gh GraphQL call → ~3.5s end-to-end. 6x faster.
#
# Auth: relies on `gh auth status` — no extra config needed.
# Cache: respects $MSM_VERSIONS_TTL (default 600s = 10min).
#
# Output: JSON to stdout (or $1).
#   { "ts": <unix>, "repos": [ {"repo": ..., "path": ..., "envs": {...}} ] }

set -u

WORKSPACE="${MSM_WORKSPACE:-${HOME}/Documents/Proyectos/modo}"
OUT="${1:-/dev/stdout}"
ENVS="${MSM_ENVS:-production preprod qa develop}"
MAX_REPOS="${MSM_MAX_REPOS:-30}"
CACHE_TTL="${MSM_VERSIONS_TTL:-600}"

if [[ "$OUT" != "/dev/stdout" ]] && [[ -f "$OUT" ]]; then
  age=$(( $(date +%s) - $(stat -f %m "$OUT" 2>/dev/null || stat -c %Y "$OUT" 2>/dev/null || echo 0) ))
  if [[ $age -lt $CACHE_TTL ]] && [[ "${MSM_FORCE_REFRESH:-0}" != "1" ]]; then
    exit 0
  fi
fi

if ! command -v gh >/dev/null 2>&1; then
  echo '{"ts":0,"repos":[],"error":"gh CLI not in PATH"}' > "$OUT"; exit 0
fi
if ! gh auth status >/dev/null 2>&1; then
  echo '{"ts":0,"repos":[],"error":"gh not authenticated"}' > "$OUT"; exit 0
fi
if ! command -v jq >/dev/null 2>&1; then
  echo '{"ts":0,"repos":[],"error":"jq not in PATH"}' > "$OUT"; exit 0
fi

# Discover playsistemico repos in workspace (dedupe by repo name)
REPO_PATHS=()
REPO_NAMES=()
SEEN=""
while IFS= read -r gitdir; do
  repo_root="$(dirname "$gitdir")"
  remote="$(git -C "$repo_root" remote get-url origin 2>/dev/null)"
  [[ "$remote" == *playsistemico/* ]] || continue
  name="${remote##*playsistemico/}"
  name="${name%.git}"
  case " $SEEN " in *" $name "*) continue ;; esac
  SEEN="$SEEN $name"
  REPO_PATHS+=("$repo_root")
  REPO_NAMES+=("$name")
  [[ ${#REPO_NAMES[@]} -ge $MAX_REPOS ]] && break
done < <(find "$WORKSPACE" -maxdepth 4 -name ".git" -type d 2>/dev/null)

if [[ ${#REPO_NAMES[@]} -eq 0 ]]; then
  echo '{"ts":'"$(date +%s)"',"repos":[],"error":"no playsistemico repos in workspace"}' > "$OUT"; exit 0
fi

# Build single GraphQL query with one alias per repo
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
QUERY_FILE="$tmp/query.graphql"

{
  echo "query {"
  for i in "${!REPO_NAMES[@]}"; do
    n="${REPO_NAMES[$i]}"
    echo "  r${i}: repository(owner: \"playsistemico\", name: \"${n}\") {"
    echo "    name"
    for env in $ENVS; do
      echo "    ${env}: deployments(environments: [\"${env}\"], first: 1, orderBy: {field: CREATED_AT, direction: DESC}) { nodes { commitOid ref { name } createdAt } }"
    done
    echo "  }"
  done
  echo "}"
} > "$QUERY_FILE"

RESP_FILE="$tmp/resp.json"
# gh exits non-zero on partial errors (repo not found) but `data` still has
# the accessible repos. Capture body, ignore exit, validate JSON.
gh api graphql -F query=@"$QUERY_FILE" > "$RESP_FILE" 2>/dev/null || true
if ! jq -e '.data' "$RESP_FILE" >/dev/null 2>&1; then
  echo '{"ts":'"$(date +%s)"',"repos":[],"error":"gh graphql returned no data"}' > "$OUT"; exit 0
fi

# Build paths map
PATHS_TSV="$tmp/paths.tsv"
for i in "${!REPO_NAMES[@]}"; do
  printf '%s\t%s\n' "${REPO_NAMES[$i]}" "${REPO_PATHS[$i]}"
done > "$PATHS_TSV"

# Use jq to reshape GraphQL response → {ts, repos: [...]}
NOW=$(date +%s)
ENVS_ARR=$(printf '%s\n' $ENVS | jq -R . | jq -sc .)

jq -n --slurpfile resp "$RESP_FILE" \
      --rawfile paths "$PATHS_TSV" \
      --argjson envs "$ENVS_ARR" \
      --argjson ts "$NOW" '
  ($paths | split("\n") | map(select(length>0) | split("\t")) | map({(.[0]): .[1]}) | add) as $pathmap
  | $resp[0].data
  | to_entries
  | map(.value)
  | map(select(. != null))
  | map(
      . as $r
      | {
          repo: $r.name,
          path: ($pathmap[$r.name] // ""),
          envs: ($envs | map({
            (.): (
              ($r[.].nodes[0]) as $d
              | if $d == null then null
                else {sha: ($d.commitOid[0:7]), ref: $d.ref.name, created_at: $d.createdAt}
                end
            )
          }) | add)
        }
    )
  | {ts: $ts, repos: .}
' > "$OUT"
