#!/usr/bin/env bash
# modo-services-monitor — external + MODO public HTTP probes
# Replicates the MOTD service status monitor in a portable bash script.
# Output: JSON to stdout (or to $1 if provided).
#
# Tunables:
#   MSM_TIMEOUT   per-request curl timeout (default 4s)
#
# Exit code:
#   0 always (best-effort). Service-level status conveyed in JSON.

set -u

TIMEOUT="${MSM_TIMEOUT:-4}"
OUT="${1:-/dev/stdout}"

SERVICES=(
  "github|GitHub|https://www.githubstatus.com/api/v2/status.json|statuspage"
  "claude|Claude|https://status.claude.com/api/v2/status.json|statuspage"
  "openai|OpenAI|https://status.openai.com/api/v2/status.json|statuspage"
  "datadog|Datadog|https://status.datadoghq.com/api/v2/status.json|statuspage"
  "cloudflare|Cloudflare|https://www.cloudflarestatus.com/api/v2/status.json|statuspage"
  "gcloud|Google Cloud|https://status.cloud.google.com/incidents.json|gcloud"
  "npm|npm|https://status.npmjs.org/api/v2/status.json|statuspage"
  "vercel|Vercel|https://www.vercel-status.com/api/v2/status.json|statuspage"
  "modo_landing|MODO Landing|https://modo.com.ar/|http"
  "modo_promos|MODO Promos|https://modo.com.ar/promos|http"
  "modo_merchants|MODO Merchants|https://merchants.playdigital.com.ar/|http"
  "modo_developers|MODO Developers|https://developers.modo.com.ar/|http"
  "modo_status_page|MODO Status Page|https://status.modo.com.ar/api/health|http"
)

check_one() {
  local key="$1" name="$2" url="$3" kind="$4"
  local indicator="?" label="unknown"
  local resp="" code="" n=""

  case "$kind" in
    statuspage)
      resp=$(curl -sL --max-time "$TIMEOUT" "$url" 2>/dev/null)
      if [[ -n "$resp" ]]; then
        indicator=$(printf '%s' "$resp" | jq -r '.status.indicator // "?"' 2>/dev/null)
        label=$(printf '%s' "$resp" | jq -r '.status.description // "unknown"' 2>/dev/null)
        [[ -z "$indicator" || "$indicator" == "null" ]] && indicator="?"
        [[ -z "$label" || "$label" == "null" ]] && label="unknown"
      else
        indicator="down"; label="no response"
      fi
      ;;
    gcloud)
      n=$(curl -sL --max-time "$TIMEOUT" "$url" 2>/dev/null \
          | jq 'map(select(.end == null or .end == "")) | length' 2>/dev/null)
      if [[ "$n" == "0" ]]; then
        indicator="none"; label="All Systems Operational"
      elif [[ -n "$n" && "$n" != "null" ]]; then
        indicator="minor"; label="$n active incident(s)"
      else
        indicator="?"; label="unreachable"
      fi
      ;;
    http)
      code=$(curl -sI -L --max-time "$TIMEOUT" -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
      case "$code" in
        2*|3*) indicator="none";     label="HTTP $code" ;;
        4*)    indicator="none";     label="HTTP $code" ;;
        5*)    indicator="major";    label="HTTP $code" ;;
        000)   indicator="critical"; label="no response" ;;
        *)     indicator="?";        label="HTTP $code" ;;
      esac
      ;;
  esac

  # Escape label for JSON
  local label_esc
  label_esc=$(printf '%s' "$label" | sed 's/\\/\\\\/g; s/"/\\"/g')
  printf '{"key":"%s","name":"%s","indicator":"%s","label":"%s","source":"external"}' \
    "$key" "$name" "$indicator" "$label_esc"
}

# Parallel fetch via background processes + temp dir
part_dir=$(mktemp -d)
trap 'rm -rf "$part_dir"' EXIT

i=0
for svc in "${SERVICES[@]}"; do
  IFS='|' read -r key name url kind <<< "$svc"
  (check_one "$key" "$name" "$url" "$kind" > "$part_dir/$i.json") &
  i=$((i+1))
done
wait

now=$(date +%s)
{
  printf '{"ts":%d,"services":[' "$now"
  first=1
  for part in "$part_dir"/*.json; do
    [[ -s "$part" ]] || continue
    [[ $first -eq 1 ]] && first=0 || printf ','
    cat "$part"
  done
  printf ']}\n'
} > "$OUT"
