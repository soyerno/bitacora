# modo-services-monitor

Service-status panel para MODO desde Claude Code. Responde "¿cómo están los servicios?" sin abrir terminal ni navegar al status-page oficial.

## Qué hace

- **Capa 1 (anon)**: pull paralelo a 8 statuspages externos (GitHub · Claude · OpenAI · Datadog · Cloudflare · GCP · npm · Vercel) + 5 HTTP probes MODO (modo.com.ar · /promos · merchants · developers · status).
- **Capa 2 (opt-in, auth)**: fetch a `status.modo.com.ar/api/last-incidents` + `/api/services` cuando hay JWT/cookie. Cruza con la fuente canónica MODO.
- Renderea grid Markdown 3×N + TLDR solo si hay degradación (🟡🟠🔴) o incidents abiertos.

## Install

```bash
# Ya viene como skill local en ~/.claude/skills/modo-services-monitor/
# Auto-invocable. No requiere setup.

# Opcional — capa 2 MODO interna:
echo 'MODO_STATUS_JWT=eyJhbGc...' > ~/.config/modo-services-monitor.env
chmod 600 ~/.config/modo-services-monitor.env
```

Ver `reference/auth-setup.md` para cómo extraer el JWT/cookie desde el browser.

## Uso desde Claude Code

```
> como estan los servicios
> /services-status
> hay algún incident hoy
> está MODO up
```

Cualquiera de esos triggers invoca la skill. Output: grid + TLDR.

## Uso desde terminal

```bash
# Path canónico V1.2+ — orquestador único, caches respetados
eval "$(bash ~/.claude/skills/modo-services-monitor/scripts/gather-all.sh verbose)"
MSM_MODO_JSON="$MODO" MSM_VERSIONS_JSON="$VERSIONS" \
  bash ~/.claude/skills/modo-services-monitor/scripts/render.sh verbose "$EXT"
```

Para compact mode omitir `verbose` en ambas llamadas.

## Comparación con `~/.config/motd-status.sh`

| | MOTD (`motd-status.sh`) | Skill `modo-services-monitor` |
|---|---|---|
| Triggered by | Cada terminal abierta | Comando del user en Claude Code |
| Output | Terminal ANSI (3×4 grid coloreado) | Markdown table 3×N + TLDR |
| Cache | `~/.cache/motd-status/status.json` | Mismo cache (reusa) |
| Capa 2 MODO interna | No | Sí (opt-in) |
| Refresh | `motd-refresh` desde shell | Auto al expirar cache (5min) |

Los dos comparten el cache, así que la skill se beneficia gratis del polling que ya hace el MOTD al abrir terminales.

## Archivos

```
~/.claude/skills/modo-services-monitor/
├── SKILL.md                       # Metadata + reglas duras (14)
├── README.md                      # Este archivo
├── scripts/
│   ├── gather-all.sh              # Orquestador único 3 capas (V1.2+)
│   ├── check-external.sh          # 13 endpoints públicos (capa 1)
│   ├── check-modo.sh              # status.modo.com.ar/api/* (capa 2, auth)
│   ├── check-versions.sh          # gh GraphQL bulk · capa 3 · cache 10min
│   └── render.sh                  # Markdown grid + TLDR + verbose
├── data/
│   └── services-catalog.json      # WHAT/IMPACT por servicio
└── reference/
    ├── auth-setup.md              # Cómo conseguir JWT/cookie
    ├── bash-portability-rules.md  # set -u + bash 3.2 traps
    └── github-deployments-api.md  # Pattern API (REST + GraphQL)
```

## Changelog

- **2026-05-26** — **V1.2** ship. GraphQL bulk fetch capa 3 (1 call vs N×4 REST), cache 10min versiones, orquestador `scripts/gather-all.sh`, tolerancia a partial fail (gh exit≠0 ≠ no data). Cold de capa 3: 22s → 6s. Warm verbose end-to-end: <100ms. 4 reglas nuevas en SKILL.md (11-14).
- **2026-05-25** — **V1.1** ship. Agregado capa 3 (versiones desplegadas vía gh Deployments API), modo verbose con per-service WHAT/IMPACT, bash 3.2 compat dedupe, fix `set -u` interpolation.
- **2026-05-25** — **V1.0** ship inicial. Capa 1 (8 statuspages + 5 HTTP probes MODO) + capa 2 opt-in (`status.modo.com.ar/api`). PR #44 a erno-modo bitácora.

## Roadmap

- V1.3 — Auth0 m2m (si Cyber aprueba CLIENT_ID + SECRET vía JSM)
- V1.4 — Hook visual al MOTD del shell
- V1.5 — Watch mode `--watch 30s`
- V1.6 — Drift detection prod ↔ preprod en verbose

## Source-of-truth

- `playsistemico/status-page` — status page interna MODO, Remix + Prisma + Auth0
- `~/.config/motd-status.sh` — MOTD del shell que polea los mismos endpoints
- Memoria asociada: `reference_motd_status_monitor.md`, `reference_modo_services_monitor.md`
