---
name: modo-services-monitor
description: 'Service-status panel para MODO + ecosistema externo. Auto-invocable cuando el user pregunta "cómo están los servicios", "están todos los servicios up", "status de servicios", "service status", "qué versión está en prod", "qué hay desplegado en preprod", "/services-status", "/motd-status" o pide ver el panel del MOTD. Tres capas: (1) statuspages externos + MODO público vía MOTD cache; (2) `status.modo.com.ar/api/last-incidents` con JWT opt-in; (3) versiones desplegadas por env vía GitHub Deployments API cruzando con repos del workspace. Soporta modo compact (default) y verbose (detalle por servicio + impacto en MODO + tabla de versiones). Renderea Markdown grid 3×N + TLDR solo si hay degradación (🟡🟠🔴).'
---

# modo-services-monitor

Skill MODO para responder rápido "¿cómo están los servicios?" desde cualquier proyecto sin abrir la terminal ni navegar a status.modo.com.ar.

## Cuándo se invoca

**Manual / explícito**:
- `/services-status`, `/motd-status`
- "como están los servicios"
- "está todo up"
- "hay algún incident"
- "service status"
- "muéstrame el estatus" / "muéstrame con detalle"
- "qué versión está en prod"
- "qué hay desplegado en preprod"
- "qué versión tiene `<repo>` en `<env>`"

**Implícito**:
- User reporta un bug raro y se sospecha incident externo (Cloudflare, GitHub, npm caído).
- User pregunta por uptime de modo.com.ar / promos / merchants / developers.
- User pide cruzar con incidents internos del status-page oficial MODO.
- User pregunta por estado de un repo MODO o el último deploy de un env.

**Detección de modo**:
- Verbose si el user dice "con detalle", "completo", "verbose", "todo", "qué impacto tiene", "y las versiones", "y qué está deployado".
- Compact otherwise.

## Tres capas de data

### Capa 1 · Externos + MODO público (always-on, anon)

Read `~/.cache/motd-status/status.json` (cache del MOTD del shell). Si no existe o tiene >5min, correr:

```bash
bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh ~/.cache/motd-status/status.json
```

Polea 13 endpoints:

| Categoría | Servicios |
|---|---|
| AI/dev infra | GitHub · Claude · OpenAI · Datadog · Cloudflare · GCP · npm · Vercel |
| MODO público | modo.com.ar · /promos · merchants.playdigital.com.ar · developers.modo.com.ar · status.modo.com.ar |

Sin auth. Pull paralelo, ~800ms.

### Capa 2 · status.modo.com.ar interno (opt-in, auth)

Fuente canónica MODO: `playsistemico/status-page` (Remix + Prisma + Auth0) servida en https://status.modo.com.ar. Modela Service · Bank · Flow · Incident · Squad · Subscription.

APIs relevantes (autenticadas con Cookie o JWT Auth0):
- `GET /api/last-incidents` → incidents recientes con severidad
- `GET /api/services` → catálogo de servicios MODO
- `GET /api/banks` → bancos asociados
- `GET /api/flows` → flujos críticos
- `GET /api/incidents.filter` → filter ad-hoc

**Auth setup** — ver `reference/auth-setup.md`. Resumen: setear `MODO_STATUS_JWT` o `MODO_STATUS_COOKIE` en env o en `~/.config/modo-services-monitor.env`.

Sin auth → la skill ignora capa 2 silenciosamente (no rompe la respuesta).

### Capa 3 · Versiones desplegadas (workspace + gh GraphQL)

Para cada repo `playsistemico/*` cloneado en `~/Documents/Proyectos/modo/` (recursivo, max 4 niveles), arma **una sola** `gh api graphql` con un alias por repo × env (`production · preprod · qa · develop`). Devuelve `{sha, ref, created_at}` del último deployment registrado por env.

**Discovery**: walk `find $WORKSPACE -maxdepth 4 -name ".git" -type d`, extrae `origin` remote, filtra por `playsistemico/`. Dedupe por repo name (un repo cloneado en varios paths cuenta una vez).

**Auth**: usa `gh auth status` — no extra config.

**Cache**: `$MSM_VERSIONS_TTL` (default 600s = 10min). El script no re-fetch si el archivo de salida es más nuevo que el TTL. Forzar refresh con `MSM_FORCE_REFRESH=1`.

**Cuando emitir**: solo en modo `verbose`. En modo `compact` no se ejecuta. Capa 3 históricamente latente (~22s con REST loop), desde V1.2 usa GraphQL bulk → 1 sola call al API, 3-6x más rápido.

**Tolerancia a partial fail**: si un repo del workspace no existe en GitHub o no tiene acceso, gh exit≠0 pero `data` viene poblado para los demás. El script ignora el exit code y valida `.data` con `jq -e` antes de reshapeo.

## Modos de render

| Modo | Trigger | Contenido |
|---|---|---|
| `compact` (default) | "cómo están los servicios", "/services-status" | Grid 3×N + TLDR si hay degradación |
| `verbose` | "muéstrame con detalle", "verbose", "completo", "qué versión hay en prod", "y las versiones" | Compact + per-service WHAT/IMPACT + tabla versiones × envs + catálogo repos |

`render.sh` acepta el modo como arg (`verbose|compact|detailed`) o env var `MSM_MODE`.

## Workflow estándar

Desde V1.2 hay un orquestador único `gather-all.sh` que dispara las 3 capas en paralelo respetando cache TTLs (5min externos · 10min versiones · sin cache MODO interno). Es el path canónico — no llamar scripts individuales.

### Compact mode

```bash
eval "$(bash ~/.claude/skills/modo-services-monitor/scripts/gather-all.sh)"
MSM_MODO_JSON="$MODO" bash ~/.claude/skills/modo-services-monitor/scripts/render.sh compact "$EXT"
```

### Verbose mode (con versiones)

```bash
eval "$(bash ~/.claude/skills/modo-services-monitor/scripts/gather-all.sh verbose)"
MSM_MODO_JSON="$MODO" MSM_VERSIONS_JSON="$VERSIONS" \
  bash ~/.claude/skills/modo-services-monitor/scripts/render.sh verbose "$EXT"
```

Output: grid + TLDR + per-service WHAT/IMPACT + tabla versiones × envs + catálogo repos.

### Perf medido (M1 / red residencial · 2026-05-26)

| Modo | Cold (todos los cachés frescos) | Warm (caches válidos) |
|---|---|---|
| compact | ~3-5s | <100ms |
| verbose | ~6-30s (varía con GitHub GraphQL) | <100ms |

Cold de capa 3 era ~22s en V1.1 (N×4 REST calls). Desde V1.2 usa **1 sola `gh api graphql`** aliasada (repo × env en un payload) → 3-6x speedup. Cache 10min hace que dentro de la misma ventana cualquier re-render sea instantáneo.

### Forzar refresh

```bash
MSM_FORCE_REFRESH=1 bash ~/.claude/skills/modo-services-monitor/scripts/check-versions.sh /tmp/msm-versions.json
```

O borrar el archivo: `rm /tmp/msm-versions.json ~/.cache/motd-status/status.json`.

## Reglas duras

1. **No spam de probes** — si `~/.cache/motd-status/status.json` tiene <5min de antigüedad (`MSM_TTL`), no re-correr `check-external.sh`. Read directo.
2. **TLDR solo si hay degradación** — todo verde → solo grid + age. Nunca explicar lo obvio.
3. **MODO Merchants HTTP 404 root es esperado** — no flaggearlo como down. El host responde, simplemente no hay `/`. Indicator queda `none`.
4. **Capa 2 nunca rompe la respuesta** — si auth falla, mostrar grid de capa 1 + nota "_status.modo.com.ar — auth no configurada_" y seguir.
5. **Capa 3 solo en verbose** — `check-versions.sh` toma 3-5s contra el workspace completo. No bloqueante en compact.
6. **No exponer JWT/cookie** — `MODO_STATUS_JWT` y `MODO_STATUS_COOKIE` nunca se loguean ni se imprimen. Si el user pide ver el JWT, decir "está en `~/.config/modo-services-monitor.env`" sin imprimirlo.
7. **Statuspages indicator vocabulary**: `none | minor | major | critical | maintenance`. Mapping a emoji en `render.sh`.
8. **Bash `set -u` + var interpolation ambigua** — usar `${var}` siempre que el char siguiente sea válido como identifier (`_`, letra, dígito). Bash 3.2 toma el char trailing como parte del nombre de la var → `unbound variable` o expansion incorrecta. Caso canónico cazado: `_$reason_` → bash leyó `$reason_`. Fix: `_${reason}_`.
9. **Bash 3.2 (macOS default) no soporta `declare -A`** — para dedupe de listas usar string flat + `case " $list " in *" $x "*) continue ;; esac`. No assumir bash 4+.
10. **Workspace discovery** — `find $WORKSPACE -maxdepth 4 -name ".git" -type d` + `git remote get-url origin` + grep `playsistemico/`. Dedupe por repo name, NO por path (un repo cloneado 2x cuenta una sola vez).
11. **Bulk fetch obligatorio para capa 3** — no loopear `gh api repos/.../deployments` por repo×env. Construir una sola `gh api graphql` con un alias por repo (`r0`, `r1`, ...) y un sub-alias por env (`production`, `preprod`, `qa`, `develop`). N×M REST calls (~22s) → 1 GraphQL call (~3-6s). Caso canónico V1.2 2026-05-26.
12. **gh exit non-zero ≠ no data** — `gh api graphql` puede salir con error si UN alias no resuelve (repo privado, archived, typo), pero el `data` viene poblado para todos los demás. Capturar el body, ignorar el exit code, validar con `jq -e '.data'` antes de procesar.
13. **Cache TTLs por capa** — capa 1 externos: 5min (`MSM_EXT_TTL`). Capa 2 MODO interno: sin cache (canal oficial de incidents debe ser fresco). Capa 3 versiones: 10min (`MSM_VERSIONS_TTL`). Refresh manual: `MSM_FORCE_REFRESH=1` o borrar el archivo.
14. **Orquestar siempre con `gather-all.sh`** — no llamar `check-*.sh` individualmente desde la skill. El orquestador respeta cache TTLs, dispara las 3 capas en paralelo, y expone `EXT/MODO/VERSIONS` vía `eval` para que el render los consuma.

## Glosario de indicadores

| Emoji | Indicator | Significado |
|---|---|---|
| 🟢 | `none` / `ok` / `operational` | OK |
| 🟡 | `minor` | Minor outage / degraded |
| 🟠 | `major` | Major outage |
| 🔴 | `critical` / `down` | Down / critical |
| 🔵 | `maintenance` | Mantenimiento programado |
| ⚪ | `?` | Unknown / unreachable |

## Roadmap

- **V1.0** ship — Capa 1 (externos + MODO público) + Capa 2 opt-in via JWT/cookie.
- **V1.1** ship — Capa 3 (versiones desplegadas vía gh Deployments REST), modo verbose, catálogo de servicios, bash 3.2 compat.
- **V1.2** ship 2026-05-26 — GraphQL bulk fetch capa 3 (1 call vs N×4), cache 10min versiones, orquestador `gather-all.sh`, tolerancia a partial fail. 6x perf cold, ~300x warm.
- V1.3 — Auth0 client_credentials flow (machine-to-machine) si Cyber aprueba CLIENT_ID + SECRET para CLI use.
- V1.4 — Hook al MOTD del shell: el render del skill comparte el mismo formato que `motd_status_render`.
- V1.5 — Watch mode: `--watch 30s` para polling continuo (útil durante incident response).
- V1.6 — Drift detection automática prod ↔ preprod en verbose (highlight cuando difieren).

## Comparación con status-page oficial

| | `playsistemico/status-page` | `modo-services-monitor` (esta skill) |
|---|---|---|
| Escala | Sistema MODO completo · 30+ services · banks · flows · SLA · newsletters | Snapshot rápido · 13 endpoints clave |
| Persistencia | Postgres + Prisma + Auth0 | Cache local JSON · ephemeral |
| Audiencia | SREs MODO · admin curated incidents | Desarrolladores individuales · self-service |
| Auth | Auth0 obligatorio · Cookie o JWT | Auth opcional (capa 2) |
| Acceso | https://status.modo.com.ar (login) | Claude Code en cualquier proyecto |

Esta skill **NO reemplaza** al status-page oficial. Es complemento dev-facing: cruza statuspages externos (no cubiertos por el portal) con la lista oficial de MODO via API.
