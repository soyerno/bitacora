#!/usr/bin/env bash
# Helpers comunes para los scripts del skill modo-jsm-ticket.
# Resuelve auth (API token), define BASE, JSM_BASE y emite jsm_get / jsm_post.

set -euo pipefail

BASE="https://play-sistemico.atlassian.net"
JSM_BASE="$BASE/rest/servicedeskapi"

EMAIL_FILE="${EMAIL_FILE:-$HOME/.atlassian/email}"
TOKEN_FILE="${TOKEN_FILE:-$HOME/.atlassian/jsm-token}"

require_auth() {
  if [[ -n "${ATLASSIAN_EMAIL:-}" && -n "${ATLASSIAN_TOKEN:-}" ]]; then
    return 0
  fi
  if [[ -r "$EMAIL_FILE" && -r "$TOKEN_FILE" ]]; then
    ATLASSIAN_EMAIL="$(cat "$EMAIL_FILE")"
    ATLASSIAN_TOKEN="$(cat "$TOKEN_FILE")"
    export ATLASSIAN_EMAIL ATLASSIAN_TOKEN
    return 0
  fi
  echo "ERROR: faltan credenciales." >&2
  echo "Opciones:" >&2
  echo "  1. export ATLASSIAN_EMAIL=... ATLASSIAN_TOKEN=..." >&2
  echo "  2. echo TU_EMAIL > $EMAIL_FILE && echo TU_TOKEN > $TOKEN_FILE && chmod 600 $EMAIL_FILE $TOKEN_FILE" >&2
  echo "Token: https://id.atlassian.com/manage-profile/security/api-tokens" >&2
  return 1
}

jsm_get() {
  local path="$1"; shift || true
  require_auth
  curl -sS \
    -u "$ATLASSIAN_EMAIL:$ATLASSIAN_TOKEN" \
    -H "Accept: application/json" \
    -H "X-ExperimentalApi: opt-in" \
    "$JSM_BASE$path" "$@"
}

jsm_post() {
  local path="$1"; shift || true
  local data="${1:-}"; shift || true
  require_auth
  curl -sS -X POST \
    -u "$ATLASSIAN_EMAIL:$ATLASSIAN_TOKEN" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -H "X-ExperimentalApi: opt-in" \
    --data "$data" \
    "$JSM_BASE$path" "$@"
}

# Acepta JSON desde stdin si --stdin viene como flag
jsm_post_stdin() {
  local path="$1"; shift || true
  require_auth
  curl -sS -X POST \
    -u "$ATLASSIAN_EMAIL:$ATLASSIAN_TOKEN" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -H "X-ExperimentalApi: opt-in" \
    --data @- \
    "$JSM_BASE$path" "$@"
}
