#!/usr/bin/env bash
# Fetch field schema de un request type específico.
#
# Uso:
#   scripts/get-fields.sh <serviceDeskId> <requestTypeId>
#   scripts/get-fields.sh 1 1404
#
# Output: tabla con req | fieldId | jiraSchemaType | name | (validValues count)

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./_common.sh
source "$HERE/_common.sh"

SD="${1:?serviceDeskId requerido}"
RT="${2:?requestTypeId requerido}"
RAW="${3:-}"

RESP="$(jsm_get "/servicedesk/$SD/requesttype/$RT/field")"

if [[ "$RAW" == "--json" || "$RAW" == "-j" ]]; then
  echo "$RESP" | python3 -m json.tool
  exit 0
fi

echo "$RESP" | python3 - <<'PY'
import json, sys
j = json.load(sys.stdin)
print(f"canRaiseOnBehalfOf={j.get('canRaiseOnBehalfOf')}  canAddRequestParticipants={j.get('canAddRequestParticipants')}")
print()
print(f"{'req':<4}{'fieldId':<30}{'type':<14}name  | extras")
print("-" * 80)
for f in j.get("requestTypeFields", []):
    req = "REQ" if f.get("required") else "opt"
    t = (f.get("jiraSchema") or {}).get("type", "?")
    extras = []
    vv = f.get("validValues") or []
    if vv: extras.append(f"validValues={len(vv)}")
    dv = f.get("defaultValues") or []
    if dv: extras.append(f"default={[d.get('value') for d in dv][:2]}")
    print(f"{req:<4}{f['fieldId']:<30}{t:<14}{f.get('name','')[:50]}{'  | ' + ', '.join(extras) if extras else ''}")
print()
# Imprimir validValues completos
for f in j.get("requestTypeFields", []):
    vv = f.get("validValues") or []
    if vv:
        print(f"\n# validValues de {f['fieldId']} ({f.get('name','')})")
        for v in vv:
            print(f"  - id={v.get('value','?')} | label={v.get('label','?')}")
PY
