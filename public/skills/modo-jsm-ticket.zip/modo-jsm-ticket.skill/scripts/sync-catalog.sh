#!/usr/bin/env bash
# Refrescar el catálogo de service desks + request types de JSM MODO.
#
# Uso:
#   scripts/sync-catalog.sh
#
# Escribe:
#   reference/desks.json    (listado de service desks visibles)
#   reference/catalog.json  (flat list de request types, ~318)
#   reference/catalog.md    (humano-legible)
#
# Requiere API token (~/.atlassian/email + ~/.atlassian/jsm-token).

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REF="$HERE/../reference"
# shellcheck source=./_common.sh
source "$HERE/_common.sh"

echo "→ Fetcheando service desks ..."
DESKS_JSON="$(jsm_get "/servicedesk?limit=100")"

echo "→ Fetcheando request types por desk ..."
ALL_JSON="$(python3 - <<PY
import json, sys, os, urllib.request, base64, ssl

email = os.environ["ATLASSIAN_EMAIL"]
token = os.environ["ATLASSIAN_TOKEN"]
auth = "Basic " + base64.b64encode(f"{email}:{token}".encode()).decode()
ctx = ssl.create_default_context()

def get(path):
    req = urllib.request.Request(
        "https://play-sistemico.atlassian.net/rest/servicedeskapi" + path,
        headers={"Authorization": auth, "Accept": "application/json", "X-ExperimentalApi": "opt-in"}
    )
    with urllib.request.urlopen(req, context=ctx) as r:
        return json.loads(r.read().decode())

desks_resp = json.loads('''$DESKS_JSON''')
out = []
for d in desks_resp.get("values", []):
    sd_id = d["id"]
    try:
        rts = get(f"/servicedesk/{sd_id}/requesttype?limit=200")
        out.append({
            "id": sd_id,
            "projectId": d.get("projectId"),
            "projectKey": d.get("projectKey"),
            "projectName": d.get("projectName"),
            "requestTypes": [
                {"id": t["id"], "name": t.get("name"), "description": t.get("description"),
                 "helpText": t.get("helpText"), "issueTypeId": t.get("issueTypeId")}
                for t in rts.get("values", [])
            ]
        })
    except Exception as e:
        print(f"WARN sd={sd_id}: {e}", file=sys.stderr)
print(json.dumps(out))
PY
)"

# Reuse python builder for desks/catalog/catalog.md
python3 - "$REF" <<PY
import json, os, sys
dst = sys.argv[1]
all_data = json.loads('''$ALL_JSON''')
desks = [{
    "id": int(d["id"]),
    "projectId": d.get("projectId"),
    "projectKey": d.get("projectKey"),
    "projectName": d.get("projectName"),
    "portalUrl": f"https://play-sistemico.atlassian.net/servicedesk/customer/portal/{d['id']}",
    "requestTypeCount": len(d.get("requestTypes", [])),
} for d in sorted(all_data, key=lambda x: int(x.get("id",0)))]
with open(f"{dst}/desks.json", "w") as f:
    json.dump(desks, f, indent=2, ensure_ascii=False)
catalog = []
for d in all_data:
    sd_id = int(d["id"])
    for rt in d.get("requestTypes", []):
        catalog.append({
            "serviceDeskId": sd_id,
            "projectKey": d.get("projectKey","?"),
            "projectName": d.get("projectName","?"),
            "requestTypeId": int(rt["id"]),
            "name": rt.get("name",""),
            "description": rt.get("description",""),
            "helpText": rt.get("helpText",""),
            "issueTypeId": rt.get("issueTypeId"),
            "createUrl": f"https://play-sistemico.atlassian.net/servicedesk/customer/portal/{sd_id}/create/{rt['id']}",
        })
catalog.sort(key=lambda x: (x["serviceDeskId"], x["requestTypeId"]))
with open(f"{dst}/catalog.json", "w") as f:
    json.dump(catalog, f, indent=2, ensure_ascii=False)
md = ["# JSM catálogo MODO\n", f"{len(desks)} service desks · {len(catalog)} request types\n"]
for desk in desks:
    md.append(f"\n## [{desk['projectKey']}] {desk['projectName']} (id={desk['id']}, {desk['requestTypeCount']} forms)")
    md.append(f"Portal: {desk['portalUrl']}\n")
    rts = [r for r in catalog if r["serviceDeskId"] == desk["id"]]
    for r in sorted(rts, key=lambda x: x["name"].lower()):
        md.append(f"- **{r['name']}** · sd={r['serviceDeskId']} rt={r['requestTypeId']}")
with open(f"{dst}/catalog.md", "w") as f:
    f.write("\n".join(md))
print(f"✓ desks={len(desks)}  request_types={len(catalog)}")
PY
echo "✓ Catálogo refrescado en $REF/"
