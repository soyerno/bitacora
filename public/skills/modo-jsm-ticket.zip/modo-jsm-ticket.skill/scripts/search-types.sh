#!/usr/bin/env bash
# Search request types por keyword. Combina catálogo local (offline, rápido)
# + API global search (si hay auth).
#
# Uso:
#   scripts/search-types.sh "github"
#   scripts/search-types.sh "1password" --live
#   scripts/search-types.sh "acceso" --desk HD
#
# Output: tabla pipe-separated (sd | rt | projectKey | name | createUrl)

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CATALOG="$HERE/../reference/catalog.json"

[[ -r "$CATALOG" ]] || { echo "ERROR: $CATALOG no existe. Corré sync-catalog.sh primero." >&2; exit 1; }

QUERY=""
LIVE=0
DESK=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --live) LIVE=1; shift ;;
    --desk) DESK="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,12p' "$0" | sed 's/^# //;s/^#//'
      exit 0
      ;;
    *) QUERY="${QUERY:+$QUERY }$1"; shift ;;
  esac
done

[[ -n "$QUERY" ]] || { echo "ERROR: falta query" >&2; exit 1; }

# Local grep
python3 - "$CATALOG" "$QUERY" "$DESK" <<'PY'
import json, sys, re
catalog_path, query, desk = sys.argv[1], sys.argv[2], sys.argv[3]
with open(catalog_path) as f:
    items = json.load(f)
needles = [n.lower() for n in re.split(r"\s+", query.strip()) if n]
def score(item):
    fields = [
        item.get("name","").lower(),
        item.get("description","").lower(),
        item.get("helpText","").lower(),
        item.get("projectName","").lower(),
    ]
    s = 0
    for n in needles:
        for f in fields:
            if n in f: s += 1
        if n in item.get("name","").lower(): s += 2
    return s
hits = [(score(i), i) for i in items if score(i) > 0 and (not desk or i["projectKey"].upper() == desk.upper())]
hits.sort(key=lambda x: -x[0])
print(f"# {len(hits)} matches en catálogo local")
print("sd|rt|key|name|createUrl")
for s, i in hits[:25]:
    print(f"{i['serviceDeskId']}|{i['requestTypeId']}|{i['projectKey']}|{i['name']}|{i['createUrl']}")
PY

if [[ "$LIVE" == "1" ]]; then
  echo
  echo "# Live API search (X-ExperimentalApi):"
  # shellcheck source=./_common.sh
  source "$HERE/_common.sh"
  jsm_get "/requesttype?searchQuery=$(printf '%s' "$QUERY" | python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.stdin.read()))')&limit=20" \
    | python3 -c '
import sys, json
j = json.load(sys.stdin)
print("sd|rt|name|createUrl")
for v in j.get("values", []):
    sd = v.get("serviceDeskId","?")
    rt = v.get("id","?")
    nm = v.get("name","?")
    print(f"{sd}|{rt}|{nm}|https://play-sistemico.atlassian.net/servicedesk/customer/portal/{sd}/create/{rt}")
'
fi
