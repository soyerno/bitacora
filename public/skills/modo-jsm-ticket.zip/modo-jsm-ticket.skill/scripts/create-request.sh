#!/usr/bin/env bash
# Crear un ticket en JSM. Validación de schema antes de POST.
#
# Uso:
#   scripts/create-request.sh --payload payload.json [--dry-run]
#   scripts/create-request.sh --payload - <<< '{"serviceDeskId":"1",...}'
#
# Validaciones pre-POST:
#   - payload tiene serviceDeskId, requestTypeId, requestFieldValues
#   - fetcheo schema y verifico que cada required esté presente
#   - --dry-run imprime el payload normalizado y los warnings, no POSTea
#
# Salida exitosa:
#   { "issueKey": "HD-12345", "_links": { "web": "..." } }

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./_common.sh
source "$HERE/_common.sh"

PAYLOAD_FILE=""
DRY_RUN=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --payload) PAYLOAD_FILE="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) sed -n '2,15p' "$0" | sed 's/^# //;s/^#//'; exit 0 ;;
    *) echo "Flag desconocido: $1" >&2; exit 1 ;;
  esac
done

[[ -n "$PAYLOAD_FILE" ]] || { echo "ERROR: --payload <file|->" >&2; exit 1; }

if [[ "$PAYLOAD_FILE" == "-" ]]; then
  PAYLOAD="$(cat)"
else
  PAYLOAD="$(cat "$PAYLOAD_FILE")"
fi

# Parse + validate básico
SD="$(printf '%s' "$PAYLOAD" | python3 -c 'import json,sys;j=json.load(sys.stdin);print(j["serviceDeskId"])')"
RT="$(printf '%s' "$PAYLOAD" | python3 -c 'import json,sys;j=json.load(sys.stdin);print(j["requestTypeId"])')"

echo "→ Validando schema sd=$SD rt=$RT ..."
SCHEMA="$(jsm_get "/servicedesk/$SD/requesttype/$RT/field")"

# Cross-check required fields
REPORT="$(python3 <<PY
import json, sys, os
payload = json.loads('''$PAYLOAD''')
schema = json.loads('''$SCHEMA''')
rfv = payload.get("requestFieldValues", {}) or {}
required = [(f["fieldId"], f["name"], (f.get("jiraSchema") or {}).get("type")) for f in schema.get("requestTypeFields", []) if f.get("required")]
missing = [r for r in required if r[0] not in rfv]
extra = [k for k in rfv if k not in {r[0] for r in [(f["fieldId"], f["name"], None) for f in schema.get("requestTypeFields", [])]}]
print("== required ==")
for fid, name, t in required:
    have = "✓" if fid in rfv else "✗"
    print(f"  {have} {fid} ({t}) — {name}")
if missing:
    print("\nFALTAN required:")
    for m in missing: print(f"  - {m[0]} ({m[1]})")
    sys.exit(2)
if extra:
    print(f"\nWARN: campos en payload que no están en schema: {extra}")
PY
)"

echo "$REPORT"

if [[ "$DRY_RUN" == "1" ]]; then
  echo
  echo "=== DRY RUN — payload normalizado ==="
  echo "$PAYLOAD" | python3 -m json.tool
  echo
  echo "(no POST realizado)"
  exit 0
fi

echo
read -r -p "Confirmás POST a JSM? (yes/no): " CONFIRM
if [[ "$CONFIRM" != "yes" ]]; then
  echo "Abortado."
  exit 1
fi

echo "→ Creando ticket ..."
RESP="$(printf '%s' "$PAYLOAD" | jsm_post_stdin "/request")"
echo "$RESP" | python3 -m json.tool
KEY="$(echo "$RESP" | python3 -c 'import json,sys;j=json.load(sys.stdin);print(j.get("issueKey",""))' 2>/dev/null || true)"
if [[ -n "$KEY" ]]; then
  echo
  echo "✓ Ticket creado: $KEY"
  echo "  https://play-sistemico.atlassian.net/browse/$KEY"
  echo "  Portal:  https://play-sistemico.atlassian.net/servicedesk/customer/portal/$SD"
fi
