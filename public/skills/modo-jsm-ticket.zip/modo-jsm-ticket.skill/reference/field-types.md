# JSM field types → payload shape

Cada request type expone su schema con `GET /servicedesk/{sd}/requesttype/{rt}/field`. Cada elemento de `requestTypeFields[]` tiene `fieldId`, `name`, `required`, `defaultValues`, `validValues`, `jiraSchema`. Acá mapeo cómo construir el valor en `requestFieldValues` para cada tipo observado.

> Regla de oro: **siempre fetcheá el schema en runtime**. Los `customfield_*` cambian por desk y no se pueden hardcodear.

## string

Texto plano. Single-line o multi-line — el schema no lo distingue, lo decide el form web. Tratá descripciones largas como `description` (multi-line).

```json
"customfield_10897": "Necesito acceso de lectura al repo modo-landing"
```

## number

```json
"customfield_10678": 12500
```

(No string, no string con guiones de miles.)

## date

ISO 8601 corto:

```json
"customfield_10651": "2026-06-30"
```

Con hora: `"2026-06-30T15:00:00.000-0300"` para `datetime` (poco común en JSM customer-facing).

**Browser/portal mode (Chrome devtools session)**: el combobox `date` del portal parsea ambiguo y resuelve `2/6/2026` como **MM/DD = 6/feb/26** en vez de DD/MM. Usar formato literal `D/mmm/YY` (ej. `2/jun/26`, `15/dic/26`). Verificar con snapshot post-fill que `description="<fecha esperada>"` quedó bien. Si quedó mal, hay un botón "Clear" adyacente al combobox.

## option (select / radio)

`validValues` trae array de `{ id, value, children? }`. POST con `id`:

```json
"customfield_11572": { "id": "10325" }
```

Si la API te tira 400, probá con `value`:
```json
"customfield_11572": { "value": "Usuario vulnerable" }
```

## array de options (multi-select / checkboxes)

```json
"customfield_X": [
  { "id": "10325" },
  { "id": "10326" }
]
```

## user (single)

POST con `accountId` (resuelto desde email vía `lookupJiraAccountId`):

```json
"customfield_11958": { "accountId": "557058:abc-123-def" }
```

También acepta `{ "name": "user@modo.com.ar" }` en algunos sites, pero `accountId` es el camino safe post-GDPR.

## array de users (multi-user picker — aprobadores, participants)

```json
"customfield_10003": [
  { "accountId": "557058:abc-123" },
  { "accountId": "557058:def-456" }
]
```

## labels (array de strings)

```json
"labels": ["acceso-prod", "trust-team"]
```

(Cuando es `required` — caso LCA-TRUST / 512 — pediselas siempre.)

## attachment (array)

**Dos pasos.** No mandes el archivo en `requestFieldValues`. Subí primero a `attachTemporaryFile`, recibí `temporaryAttachmentId`s, después POSTeá la request con:

```json
"attachment": ["TEMP-ID-1", "TEMP-ID-2"]
```

O dejá `attachment: []` al crear y subí adjuntos después con `/request/{key}/attachment`.

Detalle multipart en `api-endpoints.md`.

## priority

```json
"priority": { "name": "Medium" }
```

Valores típicos: `Highest`, `High`, `Medium`, `Low`, `Lowest`. Confirmar con `validValues` por si el desk personalizó.

## Built-in fields que ves seguido

| fieldId | Type | Notas |
|---|---|---|
| `summary` | string | Título corto. Casi siempre required. |
| `description` | string | Cuerpo del ticket. Markdown limitado (ADF en backend). |
| `attachment` | array | Ver "attachment" arriba. |
| `priority` | priority | Pocos forms lo exponen. |
| `duedate` | date | Cuando exista. |
| `labels` | array | Multi-label. |
| `assignee` | user | Casi nunca expuesto a customers. |

## Cómo Claude resuelve campos automáticamente

1. Fetch schema → leer `required: true` filter.
2. Para cada required: si `defaultValues` ya tiene un valor sensato, usarlo y declararlo.
3. Si `validValues` existe → mostrar opciones al user y pedir elegir.
4. Si el `name` o `description` da pista sobre formato (ej. "CBU" → 22 dígitos), validar antes de POST.
5. Si el field es `user` → usar `mcp__claude_ai_Atlassian__lookupJiraAccountId` con el email.
6. Si quedan campos opcionales que el user no aclaró → no inventarlos, dejarlos fuera.

## Validaciones MODO-específicas

- **CBU** (`customfield_10845`): 22 dígitos.
- **CUIT** (`customfield_10795`): 11 dígitos, validar.
- **Email** en campos `user`: pertenece al dominio `modo.com.ar` para empleados.
- **Job description** en SDV-375 (Solicitar contratación): adjuntar PDF, no texto.
- **Fechas de vencimiento** (`customfield_10651` en HD-1404): no antes de hoy.

Si una validación falla, decirlo y pedir corrección antes de POST. No mandar y dejar que JSM rebote.
