# JSM REST API · cheatsheet

Base: `https://play-sistemico.atlassian.net/rest/servicedeskapi`

Auth modes:
- **Chrome session** — `credentials: "include"` desde el browser logueado (no headers extra).
- **API token** — `Authorization: Basic base64(email:token)` con `Content-Type: application/json`.

## Discovery

| Verbo | Path | Notas |
|---|---|---|
| GET | `/servicedesk?limit=100` | Lista todos los service desks. `id` = portal numeric ID. |
| GET | `/servicedesk/{sd}/requesttype?limit=200` | Request types de un desk. |
| GET | `/servicedesk/{sd}/requesttype/{rt}` | Metadata de un request type (incluye `icon`, `helpText`, `practice`, `serviceCategory`). |
| GET | `/servicedesk/{sd}/requesttype/{rt}/field` | **El más importante**: schema de campos. Devuelve `requestTypeFields[]` con `fieldId`, `required`, `jiraSchema.type`, `validValues`, `defaultValues`. |
| GET | `/requesttype?searchQuery=X&limit=20` | Búsqueda global cross-desk. Requiere `X-ExperimentalApi: opt-in`. |

## Crear ticket

```http
POST /rest/servicedeskapi/request
Content-Type: application/json
Accept: application/json

{
  "serviceDeskId": "1",
  "requestTypeId": "1404",
  "raiseOnBehalfOf": "<accountId opcional>",
  "requestParticipants": ["<accountId>", ...],
  "requestFieldValues": {
    "summary": "Lorem ipsum",
    "description": "...",
    "customfield_10341": "valor",
    "customfield_10651": "2026-06-30",
    "priority": { "name": "Medium" },
    "customfield_10003": [{ "accountId": "abc-123" }]
  }
}
```

Response 201:
```json
{
  "issueId": "12345",
  "issueKey": "HD-12345",
  "requestTypeId": "1404",
  "serviceDeskId": "1",
  "_links": {
    "jiraRest": "...",
    "web": "https://play-sistemico.atlassian.net/browse/HD-12345",
    "self": ".../rest/servicedeskapi/request/HD-12345"
  }
}
```

## Attachments

Dos pasos: subir temp + linkearlo al ticket.

```http
POST /rest/servicedeskapi/servicedesk/{sd}/attachTemporaryFile
X-Atlassian-Token: no-check
X-ExperimentalApi: opt-in
Content-Type: multipart/form-data

(field "file" = archivo, repetir si son varios)
```

Response trae `temporaryAttachments[].temporaryAttachmentId`. Después:

```http
POST /rest/servicedeskapi/request/{issueKey}/attachment

{
  "temporaryAttachmentIds": ["abc", "def"],
  "public": true,
  "additionalComment": { "body": "Adjuntos solicitados" }
}
```

## Mis tickets

```http
GET /rest/servicedeskapi/request?requestOwnership=OWNED_REQUESTS&limit=20
GET /rest/servicedeskapi/request?requestStatus=OPEN_REQUESTS&limit=20
GET /rest/servicedeskapi/request/{issueKey}
GET /rest/servicedeskapi/request/{issueKey}/comment
GET /rest/servicedeskapi/request/{issueKey}/status
```

## Transitions / approvals

```http
GET  /rest/servicedeskapi/request/{issueKey}/transition
POST /rest/servicedeskapi/request/{issueKey}/transition { "id": "<transitionId>" }
GET  /rest/servicedeskapi/request/{issueKey}/approval
POST /rest/servicedeskapi/request/{issueKey}/approval/{approvalId} { "decision": "approve|decline" }
```

## SLA / participants

```http
GET /rest/servicedeskapi/request/{issueKey}/sla
GET /rest/servicedeskapi/request/{issueKey}/participant
POST /rest/servicedeskapi/request/{issueKey}/participant { "accountIds": ["..."] }
```

## Headers a recordar

- `Accept: application/json` — siempre.
- `Content-Type: application/json` — para POST/PUT.
- `X-ExperimentalApi: opt-in` — para `requesttype?searchQuery=*` y otros experimentales.
- `X-Atlassian-Token: no-check` — para uploads multipart.

## Endpoints que NO funcionan (testeados 2026-05-21)

- `/rest/servicedesk/1/servicedesk/customer/models/portals/*` — 404
- `/rest/servicedesk/menu/latest/customer-portals` — 404
- Cualquier endpoint del path `/rest/servicedesk/1/*` (legacy SPA-internal) — bloqueado.

Usar siempre `/rest/servicedeskapi/*` (público de JSM Cloud).
