# Auth · cómo autenticar al JSM de MODO

Dos caminos. Elegí según el contexto.

## A. Browser session (preferido para uso interactivo)

Atlassian usa Google SSO con passkey/2FA. Una vez logueado en Chrome, las cookies sirven para llamar a `/rest/servicedeskapi/*` desde la misma sesión.

**Cómo se usa desde Claude Code:**

1. Asegurate que el user esté logueado en `https://play-sistemico.atlassian.net`. Lo más rápido:
   ```
   mcp__chrome-devtools__list_pages  → verificar tabs abiertas
   mcp__chrome-devtools__navigate_page → https://play-sistemico.atlassian.net/servicedesk/customer/portals
   mcp__chrome-devtools__wait_for ["Centro de ayuda", "Bienvenido al Centro de ayuda"]
   ```

2. Ejecutá fetches desde la página con `evaluate_script`:
   ```js
   async () => {
     const r = await fetch("/rest/servicedeskapi/request", {
       method: "POST",
       credentials: "include",
       headers: { "Content-Type": "application/json", "Accept": "application/json" },
       body: JSON.stringify(payload)
     });
     return { status: r.status, body: await r.json() };
   }
   ```

**Ventajas**: sin tokens, refleja exactamente lo que el user vería en el portal, respeta restricciones de visibilidad.

**Limitaciones**:
- Necesitás Chrome corriendo y el user logueado (passkey/2FA al inicio).
- Sesión expira ~24h. Si vence, el endpoint te redirige a 303 login y `fetch` ve el HTML del login.
- No funciona en CI / automation headless.

## B. API token (Basic auth)

Atlassian permite crear API tokens personales. Funciona desde cualquier host con `curl`.

### Setup (1 vez)

1. Crear token: https://id.atlassian.com/manage-profile/security/api-tokens
2. Guardar en `~/.atlassian/jsm-token` con perms 600:
   ```bash
   mkdir -p ~/.atlassian && chmod 700 ~/.atlassian
   printf '%s' 'EL_TOKEN' > ~/.atlassian/jsm-token
   chmod 600 ~/.atlassian/jsm-token
   ```
3. Email en `~/.atlassian/email` (o usar `hernan.desouza@modo.com.ar`):
   ```bash
   printf '%s' 'hernan.desouza@modo.com.ar' > ~/.atlassian/email
   chmod 600 ~/.atlassian/email
   ```

### Uso

```bash
EMAIL=$(cat ~/.atlassian/email)
TOKEN=$(cat ~/.atlassian/jsm-token)
AUTH=$(printf '%s:%s' "$EMAIL" "$TOKEN" | base64)

curl -sS -X POST \
  "https://play-sistemico.atlassian.net/rest/servicedeskapi/request" \
  -H "Authorization: Basic $AUTH" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d @payload.json
```

### Scope mínimo del token

API tokens de Atlassian Cloud heredan los permisos del usuario. No hay scopes granulares. Para crear tickets, basta con que el user sea customer del portal target.

### Rotación

Atlassian recomienda rotar cada 90 días. Los tokens viejos no se invalidan al crear uno nuevo — borrá los obsoletos en el management UI.

## Cuál elegir

| Contexto | Auth |
|---|---|
| Crear ticket interactivo con Claude Code + Chrome abierto | **A. Browser** |
| Script en CI / cron / agente headless | **B. API token** |
| Bulk operations (crear N tickets) | **B. API token** |
| User es customer pero no admin del proyecto | Cualquiera (no requiere admin) |
| Necesitás `raiseOnBehalfOf` de otro usuario | **B. API token** (más predecible) |

## Validar que el auth funciona

```bash
# Browser (desde evaluate_script)
fetch("/rest/servicedeskapi/info").then(r => r.json())

# API token
EMAIL=$(cat ~/.atlassian/email)
TOKEN=$(cat ~/.atlassian/jsm-token)
curl -sS -u "$EMAIL:$TOKEN" "https://play-sistemico.atlassian.net/rest/servicedeskapi/info" | jq .version
```

Si devuelve el `version` hash, estás dentro. Si devuelve HTML o 401/403, revisar credenciales.

## Errores comunes

- **401 Unauthorized** → token incorrecto, expirado, o email no matchea.
- **403 Forbidden** → el user no es customer del portal target.
- **303 See Other** → la sesión del browser expiró (re-loguearse).
- **HTML en lugar de JSON** → mismo problema que 303, o sin headers `Accept: application/json`.
