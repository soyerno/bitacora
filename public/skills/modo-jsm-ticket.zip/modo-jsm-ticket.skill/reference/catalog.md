# JSM catálogo MODO

Generado desde Chrome session · 2026-05-21 · 29 service desks · 318 request types

Mantenelo fresco con `scripts/sync-catalog.sh`.


## [HD] IT-Solicitudes (id=1, 47 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/1

- ** Desbloqueo Usuario JumpCloud** · sd=1 rt=76
- **1Password** · sd=1 rt=71
- **ABM De Moders** · sd=1 rt=49
- **ABM de Repositorios de GitHub** · sd=1 rt=1175
- **ABM de Repositorios de GitHub** · sd=1 rt=1403
- **ABM de Repositorios de GitHub** · sd=1 rt=1404
- **ABM de Snipe-IT** · sd=1 rt=2899
- **Acceso a Amplitude** · sd=1 rt=165
- **Acceso a AWS** · sd=1 rt=64
- **Acceso a Confluence** · sd=1 rt=67
- **Acceso a Datadog** · sd=1 rt=62
- **Acceso a Drive** · sd=1 rt=68
- **Acceso a Github** · sd=1 rt=66
- **Acceso a Google** · sd=1 rt=70
- **Acceso a Jira** · sd=1 rt=61
- **Acceso a Microsoft** · sd=1 rt=69
- **Acceso a Quicksight** · sd=1 rt=65
- **Acceso a Slack** · sd=1 rt=63
- **Acceso Unidad Compartida** · sd=1 rt=74
- **Accesos y permisos** · sd=1 rt=53
- **Agente de seguridad sin reportar** · sd=1 rt=809
- **Alta Externo** · sd=1 rt=81
- **AntiVirus** · sd=1 rt=79
- **Autenticador de Google** · sd=1 rt=73
- **Baja/Modificación externo** · sd=1 rt=82
- **Celular** · sd=1 rt=78
- **Entrega de Equipo de Beneficio "Mi Compu"** · sd=1 rt=1736
- **Google password reset** · sd=1 rt=75
- **Hardware** · sd=1 rt=54
- **Hardware** · sd=1 rt=72
- **Incorporación de nuevos empleados** · sd=1 rt=7
- **Informar mal funcionamiento de Internet** · sd=1 rt=80
- **Informar mal funcionamiento de Plataforma** · sd=1 rt=86
- **Instalacion de Software** · sd=1 rt=83
- **JumpCloud Password Reset** · sd=1 rt=77
- **Mantenimiento Correctivo y Preventivo** · sd=1 rt=1735
- **Netskope** · sd=1 rt=85
- **Onboarding** · sd=1 rt=48
- **Onboarding de Moders** · sd=1 rt=1734
- **Préstamo de dispositivos de prueba** · sd=1 rt=1436
- **Recambio de Equipo** · sd=1 rt=1733
- **Reposición de Periféricos** · sd=1 rt=4739
- **Reposición de Periféricos** · sd=1 rt=4772
- **Solicitud de accesos** · sd=1 rt=84
- **Solicitud de permisos** · sd=1 rt=31
- **Solicitud enviada por correo electrónico** · sd=1 rt=10
- **Soporte General** · sd=1 rt=1832

## [DS] DATA - Soporte (id=3, 16 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/3

- **Create a post-incident review** · sd=3 rt=47
- **Emailed request** · sd=3 rt=41
- **Fix an account problem** · sd=3 rt=33
- **Get a guest wifi account** · sd=3 rt=34
- **Get IT help** · sd=3 rt=32
- **Investigate a problem** · sd=3 rt=46
- **New mobile device** · sd=3 rt=42
- **Onboard new employees** · sd=3 rt=38
- **Report a system problem** · sd=3 rt=43
- **Report broken hardware** · sd=3 rt=44
- **Request a change** · sd=3 rt=45
- **Request a new account** · sd=3 rt=37
- **Request admin access** · sd=3 rt=36
- **Request new hardware** · sd=3 rt=40
- **Request new software** · sd=3 rt=39
- **Set up VPN to the office** · sd=3 rt=35

## [LCA] LCA (id=4, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/4

- **Emailed request** · sd=4 rt=52
- **Questions for legal** · sd=4 rt=51
- **Request a contract review** · sd=4 rt=50

## [DSOSH] DSO Security Hub (id=6, 17 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/6

- **AWS Security Hub Finding** · sd=6 rt=103
- **Create a post-incident review** · sd=6 rt=95
- **Emailed request** · sd=6 rt=89
- **Fix an account problem** · sd=6 rt=96
- **Get a guest wifi account** · sd=6 rt=97
- **Get IT help** · sd=6 rt=87
- **Investigate a problem** · sd=6 rt=94
- **New mobile device** · sd=6 rt=90
- **Onboard new employees** · sd=6 rt=100
- **Report a system problem** · sd=6 rt=91
- **Report broken hardware** · sd=6 rt=92
- **Request a change** · sd=6 rt=93
- **Request a new account** · sd=6 rt=88
- **Request admin access** · sd=6 rt=99
- **Request new hardware** · sd=6 rt=102
- **Request new software** · sd=6 rt=101
- **Set up VPN to the office** · sd=6 rt=98

## [RDG] Rendición de gastos (id=8, 15 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/8

- **Beneficio de capacitación** · sd=8 rt=153
- **Eventos MKT ** · sd=8 rt=152
- **Factura de celular** · sd=8 rt=154
- **Factura de internet** · sd=8 rt=156
- **Factura Guardería** · sd=8 rt=155
- **Lavado de auto en oficina** · sd=8 rt=158
- **Otros** · sd=8 rt=164
- **Pruebas en comercios/con usuarios** · sd=8 rt=159
- **Suggest a new feature** · sd=8 rt=111
- **Suggest improvement** · sd=8 rt=112
- **Team Building por H** · sd=8 rt=151
- **Traslados** · sd=8 rt=160
- **Uso tarjeta corporativa** · sd=8 rt=161
- **Work from anywhere** · sd=8 rt=162
- **WOW Experience** · sd=8 rt=163

## [ITDMS] Infosec - Test de mensajes slack (id=9, 1 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/9

- **Emailed request** · sd=9 rt=116

## [TS] TestITCsat (id=10, 33 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/10

- **ABM De Moders** · sd=10 rt=117
- **Accesos y permisos** · sd=10 rt=146
- **Hardware** · sd=10 rt=148
- **Incorporación de nuevos empleados** · sd=10 rt=144
- **IT-AYUDA** · sd=10 rt=118
- **IT-AYUDA** · sd=10 rt=119
- **IT-AYUDA** · sd=10 rt=120
- **IT-AYUDA** · sd=10 rt=121
- **IT-AYUDA** · sd=10 rt=122
- **IT-AYUDA** · sd=10 rt=123
- **IT-AYUDA** · sd=10 rt=124
- **IT-AYUDA** · sd=10 rt=125
- **IT-AYUDA** · sd=10 rt=126
- **IT-AYUDA** · sd=10 rt=127
- **IT-AYUDA** · sd=10 rt=128
- **IT-AYUDA** · sd=10 rt=129
- **IT-AYUDA** · sd=10 rt=130
- **IT-AYUDA** · sd=10 rt=131
- **IT-AYUDA** · sd=10 rt=132
- **IT-AYUDA** · sd=10 rt=133
- **IT-AYUDA** · sd=10 rt=134
- **IT-AYUDA** · sd=10 rt=135
- **IT-AYUDA** · sd=10 rt=136
- **IT-AYUDA** · sd=10 rt=137
- **IT-AYUDA** · sd=10 rt=138
- **IT-AYUDA** · sd=10 rt=139
- **IT-AYUDA** · sd=10 rt=140
- **IT-AYUDA** · sd=10 rt=141
- **IT-AYUDA** · sd=10 rt=142
- **IT-AYUDA** · sd=10 rt=143
- **Onboarding** · sd=10 rt=149
- **Solicitud de permisos** · sd=10 rt=145
- **Solicitud enviada por correo electrónico** · sd=10 rt=147

## [AAA] AAA - Infosec Automatizacion ABM (id=11, 1 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/11

- **Emailed request** · sd=11 rt=150

## [SIEMDESA] InfosecSIEM-Desarrollo (id=12, 1 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/12

- **Emailed request** · sd=12 rt=166

## [PEOP] People | Compensaciones (id=13, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/13

- **Beneficios** · sd=13 rt=10931
- **Email request** · sd=13 rt=10796
- **Sueldo** · sd=13 rt=10932

## [FIN] Finance (id=14, 8 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/14

- **Defensa al consumidor/Fraude (Legales)** · sd=14 rt=186
- **FP&A** · sd=14 rt=188
- **Incentivos a usuarios (UX)** · sd=14 rt=185
- **PAYROLL** · sd=14 rt=187
- **Reintegros a usuarios (CX)** · sd=14 rt=184
- **Rendición de comprobantes Tarjetas de crédito** · sd=14 rt=183
- **Solicitud enviada por correo electrónico** · sd=14 rt=179
- **TAX** · sd=14 rt=189

## [LSM] LCA - Solicitudes marcarías (id=15, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/15

- **Consultas Marcas** · sd=15 rt=206
- **Solicitud de registro** · sd=15 rt=205
- **Suggest a new feature** · sd=15 rt=203

## [ECO] Soporte E-Commerce (id=16, 2 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/16

- **Consulta** · sd=16 rt=210
- **Solicitud enviada por correo electrónico** · sd=16 rt=216

## [IH] Infosec - HD (id=17, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/17

- **Ask a question** · sd=17 rt=218
- **Emailed request** · sd=17 rt=219
- **Submit a request or incident** · sd=17 rt=217

## [CN] Contratos MODO (id=18, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/18

- **Email request** · sd=18 rt=10908
- **Questions for legal** · sd=18 rt=10910
- **Request a contract review** · sd=18 rt=10909

## [NFSC] Infosec  (id=20, 1 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/20

- **Gestión de identidades** · sd=20 rt=247

## [PEA] Platform-Assistant (id=23, 2 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/23

- **Email request** · sd=23 rt=10935
- **Investigar un problema** · sd=23 rt=10936

## [CYBS] Cyber | Solicitudes IAM (id=24, 100 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/24

- **1Password** · sd=24 rt=1042
- **1Password - Asignar vaults** · sd=24 rt=1476
- **1Password - Crear Vault** · sd=24 rt=1475
- **1Password - Generar API token para integraciones** · sd=24 rt=1474
- **1Password - Recupero de contraseña (Moders)** · sd=24 rt=1469
- **1Password-Guests** · sd=24 rt=1041
- **Acceso en varias plataformas** · sd=24 rt=1106
- **Airflow** · sd=24 rt=3141
- **Amplitude - Acceso a Proyectos** · sd=24 rt=1477
- **Amplitude - Alta de usuario** · sd=24 rt=1107
- **Amplitude - Cambio de Team** · sd=24 rt=1502
- **API Key** · sd=24 rt=4706
- **App Store Connect - TestFlight - Alta de Usuario** · sd=24 rt=1108
- **App Store Connect - TestFlight - Cambiar Recursos Asignados** · sd=24 rt=1537
- **App Store Connect - TestFlight - Cambio de Recurso y Aplicaciones** · sd=24 rt=1535
- **App Store Connect - TestFlight - Crear y  Cambiar Funciones** · sd=24 rt=1536
- **Apple Business Manager - Alta de Usuario** · sd=24 rt=1109
- **Apple Business Manager - Cambio de Grupos** · sd=24 rt=1539
- **Apple Business Manager - Crear Grupos** · sd=24 rt=1538
- **AppsFlyer - Alta de Usuario** · sd=24 rt=1110
- **AppsFlyer - Cambio de Roles** · sd=24 rt=1541
- **AppsFlyer - Creación de Roles** · sd=24 rt=1540
- **Aric - Alta de Usuario SaaS** · sd=24 rt=1542
- **Aric - Asignación de Grupo** · sd=24 rt=1543
- **Aric - Cambio de Grupo** · sd=24 rt=1544
- **Auth0 - Alta de Usuario** · sd=24 rt=1112
- **Auth0 - Asignación de Tenants** · sd=24 rt=1545
- **Auth0 - Crear API Key** · sd=24 rt=1546
- **Auth0 - Crear Aplicación** · sd=24 rt=1548
- **Auth0 - Crear Roles** · sd=24 rt=3108
- **Auth0 - Modificación de API Key** · sd=24 rt=1547
- **AWS - Alta de Usuario** · sd=24 rt=1139
- **AWS - Asignación de Grupo** · sd=24 rt=1549
- **AWS - Cambio de Grupo** · sd=24 rt=1550
- **Beygoo - Alta de Usuario ** · sd=24 rt=1140
- **Beygoo - Cambio de Rol** · sd=24 rt=1552
- **Botmaker - Alta de Usuario** · sd=24 rt=1141
- **Botmaker - Asignación de Filtros** · sd=24 rt=1560
- **Botmaker - Cambio de Grupo** · sd=24 rt=1558
- **Botmaker - Cambio de Rol** · sd=24 rt=1559
- **Botmaker - Creación de Grupo** · sd=24 rt=1554
- **Botmaker - Creación de Rol** · sd=24 rt=1553
- **Compass - Alta de Usuario** · sd=24 rt=3006
- **Confluence - Acceso a Espacios** · sd=24 rt=1561
- **Confluence - Acceso a Grupo** · sd=24 rt=1564
- **Confluence - Alta de Service Account** · sd=24 rt=3240
- **Confluence - Alta de Usuario** · sd=24 rt=1142
- **Confluence - Creación de Espacio** · sd=24 rt=1562
- **Confluence - Creación de Grupo** · sd=24 rt=1563
- **Contract Managers** · sd=24 rt=3407
- **Crowdstrike - Alta de Usuario** · sd=24 rt=1143
- **Crowdstrike - Cambio de roles** · sd=24 rt=1698
- **Crowdstrike - Creación de Roles** · sd=24 rt=1697
- **Crowdstrike - Solicitar privilegios elevados** · sd=24 rt=1699
- **Datadog - Alta de Usuario** · sd=24 rt=1144
- **Datadog - Cambio de Rol** · sd=24 rt=1570
- **Github - Agregar Usuario a Team** · sd=24 rt=1577
- **Github - Alta de Copilot** · sd=24 rt=1580
- **Github - Alta de Usuario** · sd=24 rt=1146
- **Github - Aprobación de Fine-Grained Tokens** · sd=24 rt=1337
- **Github - Cambio de Miembros en un Grupo** · sd=24 rt=1578
- **Github - Creación de Team** · sd=24 rt=1576
- **Github - Eliminar Usuario de Team** · sd=24 rt=1579
- **Google - Acceso a MODO Knowledge** · sd=24 rt=1583
- **Google - Acceso a MODO Promociones** · sd=24 rt=1584
- **Google - Acceso a Unidades Compartidas Drive** · sd=24 rt=1587
- **Google - Alta de Grupo de Distribución** · sd=24 rt=1582
- **Google - Alta de Usuario** · sd=24 rt=1147
- **Google - Alta de Usuario de Servicio** · sd=24 rt=1581
- **Google - Configuración de SSO por OAuth 2.0** · sd=24 rt=3373
- **Google - Modificación de Grupo de Distribución** · sd=24 rt=3174
- **Google - Reactivación de Usuario** · sd=24 rt=1768
- **Google - Reset de Password y/o MFA** · sd=24 rt=1601
- **Google - Transferencia de Propiedad de Archivos y Calendar** · sd=24 rt=1586
- **Google Cloud – Creación de proyecto y habilitación de APIs** · sd=24 rt=3441
- **Insider - Alta de Usuario** · sd=24 rt=1148
- **Insider - Cambio de Roles** · sd=24 rt=1668
- **Insider - Creación de Roles** · sd=24 rt=1667
- **Jira - Acceso a Tableros** · sd=24 rt=1669
- **Jira - Alta de Service Account** · sd=24 rt=3241
- **Jira - Alta de Usuario** · sd=24 rt=1149
- **Jira - Creación de Tableros** · sd=24 rt=1671
- **Jira - Modificación de Tableros** · sd=24 rt=1670
- **Jumpcloud - Acceso a Grupos** · sd=24 rt=1150
- **Jumpcloud - Alta de Usuario** · sd=24 rt=1701
- **Jumpcloud - Configuración de SSO** · sd=24 rt=3374
- **Jumpcloud - Creación de Grupos** · sd=24 rt=1700
- **Jumpcloud - Reactivación de Usuario** · sd=24 rt=3672
- **Licencias de Claude** · sd=24 rt=3474
- **Licencias de Gamma** · sd=24 rt=1799
- **Licencias de Lovable** · sd=24 rt=3606
- **Licencias de testeo en herramientas de IA** · sd=24 rt=1172
- **Microsoft 365 - Acceso a Azure Storage** · sd=24 rt=1704
- **Microsoft 365 - Acceso a Sentinel** · sd=24 rt=1703
- **Microsoft 365 - Asignación de Licencia O365 Acceso a Azure** · sd=24 rt=1154
- **Microsoft 365 - Creación de grupos** · sd=24 rt=1674
- **Microsoft 365 - Problemas de Acceso a O365** · sd=24 rt=1675
- **MODO Central (BO) - Alta de Usuario** · sd=24 rt=1155
- **MODO Central (BO) - Cambio de Roles** · sd=24 rt=1702
- **Netskope** · sd=24 rt=1156

## [OMI2120] Opsgenie Migrated Incidents 23-10-2024 04:28 (id=25, 16 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/25

- **Create a post-incident review** · sd=25 rt=304
- **Emailed request** · sd=25 rt=298
- **Fix an account problem** · sd=25 rt=305
- **Get a guest wifi account** · sd=25 rt=306
- **Get IT help** · sd=25 rt=293
- **Investigate a problem** · sd=25 rt=303
- **New mobile device** · sd=25 rt=299
- **Onboard new employees** · sd=25 rt=307
- **Report a system problem** · sd=25 rt=300
- **Report broken hardware** · sd=25 rt=301
- **Request a change** · sd=25 rt=302
- **Request a new account** · sd=25 rt=296
- **Request admin access** · sd=25 rt=295
- **Request new hardware** · sd=25 rt=308
- **Request new software** · sd=25 rt=297
- **Set up VPN to the office** · sd=25 rt=294

## [SDV] Solicitud de vacantes (id=26, 2 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/26

- **Emailed request** · sd=26 rt=373
- **Solicitar contratación** · sd=26 rt=375

## [LT] LCA-TRUST  (id=27, 6 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/27

- **Desbloqueo de usuarios** · sd=27 rt=512
- **Emailed request** · sd=27 rt=479
- **Ingeniería social** · sd=27 rt=482
- **Operaciones desconocidas** · sd=27 rt=480
- **Otros** · sd=27 rt=513
- **Robo Celular** · sd=27 rt=481

## [TA] test-aprobadores (id=60, 4 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/60

- **Emailed request** · sd=60 rt=648
- **github prueba** · sd=60 rt=653
- **Report a system problem** · sd=60 rt=649
- **Report broken hardware** · sd=60 rt=650

## [BCB] BX Content BOARD (id=93, 2 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/93

- **Creación de logo** · sd=93 rt=682
- **Emailed request** · sd=93 rt=681

## [ACR] Cyber | GRC Solicitudes (id=126, 5 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/126

- **Autoevaluación de Activos** · sd=126 rt=11579
- **Autoevaluación de Riesgos** · sd=126 rt=11578
- **Email request** · sd=126 rt=11575
- **Identificación de riesgos** · sd=126 rt=12202
- **Solicitudes de auditoria** · sd=126 rt=12203

## [LEGOPS] Legal Ops (id=159, 5 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/159

- **Consulta - Compleja** · sd=159 rt=11807
- **Consulta - Simple** · sd=159 rt=11808
- **Documentación Promoción** · sd=159 rt=11806
- **Otras Tareas** · sd=159 rt=11809
- **Solicitud de correo electrónico** · sd=159 rt=11608

## [OFFSEC] Cyber | Offensive Security (id=192, 6 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/192

- **Cyber & GRC Hub** · sd=192 rt=14111
- **Email request** · sd=192 rt=11618
- **Pentesting (WebSec / AppSec / Cloud)** · sd=192 rt=11620
- **Security Design Review (Threat Modeling)** · sd=192 rt=11619
- **Third-Party & Partner Offensive Audit** · sd=192 rt=11621
- **Vulnerability Disclosure** · sd=192 rt=11623

## [CSMYR] Cyber | Solicitudes Monitoreo y respuesta (id=225, 7 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/225

- **Análisis de Herramienta / Software** · sd=225 rt=12204
- **Análisis de phishing** · sd=225 rt=12205
- **Email request** · sd=225 rt=12103
- **Excepción de USB** · sd=225 rt=12466
- **Problema con agente de seguridad** · sd=225 rt=12206
- **Requerimientos OffSec** · sd=225 rt=14181
- **SIEM Requerimientos** · sd=225 rt=14043

## [CBM] Comercial - Big Merchants (id=258, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/258

- **Enviar una solicitud o incidente** · sd=258 rt=12140
- **Solicitud de correo electrónico** · sd=258 rt=12136
- **Tarea** · sd=258 rt=12170

## [ENDESA] Endesa (id=1325, 3 forms)
Portal: https://play-sistemico.atlassian.net/servicedesk/customer/portal/1325

- **Ask a question** · sd=1325 rt=13700
- **Email request** · sd=1325 rt=13698
- **Submit a request or incident** · sd=1325 rt=13699