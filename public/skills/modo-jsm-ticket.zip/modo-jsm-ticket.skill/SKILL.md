---
name: modo-jsm-ticket
description: Crear tickets en el Jira Service Management de MODO (https://play-sistemico.atlassian.net/servicedesk/customer/portals) de punta a punta — descubrir el portal correcto, mapear los campos requeridos y generar el ticket vía REST API. 29 service desks · 318 request types catalogados. Auto-invocable cuando el usuario diga (ES/EN) "armá un ticket en JSM", "abrí un ticket de IT", "necesito acceso a X", "ticket de Cyber", "1Password ticket", "GitHub team access ticket", "JSM ticket", "service desk ticket", "abrí ticket en MODO", "/modo-jsm-ticket". Output canónico — JSON payload listo + URL del portal + (opcional) POST real con confirmación.
---

# modo-jsm-ticket

Skill para automatizar la generación de tickets en el JSM de Play Digital / MODO. Está construido sobre la REST API `/rest/servicedeskapi/*` y autentica con cookies de Chrome (vía `mcp__chrome-devtools__*`) o con API token (Basic auth). Cubre los 29 service desks de la org y los 318 request types catalogados (snapshot 2026-05-21).

## Cuándo se dispara

Auto-invocar cuando el user diga cosas como:
- "armá un ticket de IT para 1Password"
- "necesito un ticket para acceso a GitHub team modo-landing-dev"
- "abrí ticket en JSM para Quicksight"
- "create a JSM ticket for Cyber/IAM"
- "/modo-jsm-ticket acceso a DataDog para Juan"

No disparar para:
- Tickets de Jira normales (issues en COENXT, EXA, etc.) — eso no es JSM, no requiere request type.
- Solo consultas sobre estado de un ticket existente — usar `mcp__claude_ai_Atlassian__getJiraIssue`.

## Flujo canónico (5 pasos)

### 1. Intent → search del catálogo
- Si el user nombra un service exacto ("1Password en IT-Solicitudes") → match directo en `reference/catalog.json`.
- Si es ambiguo ("acceso a GitHub") → grep en el catálogo + global search del JSM. Devolver top-3 con scores: `[SD] projectName · requestTypeName · createUrl`.
- Pedir confirmación si hay >1 match razonable.

```bash
# Quick search local (offline catalog)
~/.claude/skills/modo-jsm-ticket/scripts/search-types.sh "github"

# Búsqueda live (browser session)
# fetch("/rest/servicedeskapi/requesttype?searchQuery=github&limit=20", {headers:{"X-ExperimentalApi":"opt-in"}})
```

### 2. Fetch field schema
Una vez confirmado `serviceDeskId` + `requestTypeId`:

```bash
~/.claude/skills/modo-jsm-ticket/scripts/get-fields.sh <sd> <rt>
```

Devuelve la lista de campos con: `fieldId`, `required`, `jiraSchema.type`, `validValues`, `defaultValues`, `name`.

### 3. Recolectar valores
Una pregunta por cada campo `required`. Para cada tipo:
- `string` / `number` / `date` → input plano.
- `option` → mostrar `validValues` (id + value) y pedir uno.
- `user` → email del beneficiario (skill resuelve `accountId` vía `lookupJiraAccountId`).
- `array` con `items=user` → lista de emails.
- `attachment` → preguntar paths locales (subida temporal vía `/rest/servicedeskapi/servicedesk/{sd}/attachTemporaryFile`).
- `priority` → mostrar opciones (`Highest/High/Medium/Low/Lowest`).

NO inventar valores. Si falta info, preguntar. Si el user quiere copy en castellano, usá voz rioplatense (sin "stakeholders", sin "leverage").

### 4. Preview payload
Mostrar el body completo antes de POSTear:

```json
{
  "serviceDeskId": "1",
  "requestTypeId": "1404",
  "requestFieldValues": {
    "summary": "...",
    "customfield_10341": "...",
    "priority": { "name": "Medium" }
  }
}
```

Y la URL del portal equivalente para que el user pueda crear manualmente si prefiere.

### 5. Crear el ticket
Solo con confirmación explícita del user. Métodos:

**A. Browser session (mcp__chrome-devtools)** — preferido si el user está logueado en `play-sistemico.atlassian.net`:
```js
await fetch("/rest/servicedeskapi/request", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json", "Accept": "application/json" },
  body: JSON.stringify(payload)
}).then(r => r.json())
```

**B. API token (curl)** — para uso headless:
```bash
~/.claude/skills/modo-jsm-ticket/scripts/create-request.sh --payload <file> [--dry-run]
```

Output esperado:
```json
{ "issueKey": "HD-12345", "_links": { "web": "https://play-sistemico.atlassian.net/browse/HD-12345" } }
```

Mostrar el issue key + link del portal + recordatorio del SLA si el portal lo declara (ej. Cyber-Solicitudes = 72h hábiles desde aprobación).

## Reglas duras

- **Nunca POSTear sin confirmación explícita** ("dale", "creá", "POST", "confirmar"). Mostrar preview siempre.
- **Nunca inventar `customfield_*` IDs**. Cambian por desk. Fetch fields siempre.
- **Nunca asumir que el catálogo está fresco**. Si falla un fetch o no aparece un request type esperado, correr `scripts/sync-catalog.sh` antes de seguir.
- **Auth en orden**: Chrome session > API token. Si el browser está logueado, evitá pedir token.
- **`raiseOnBehalfOf`** — solo cuando el user lo pide explícito ("este ticket es para Juan"). Default: a nombre propio.
- **Voz**: rioplatense en cualquier copy generado (`summary`, `description`). Sin buzzwords. Sin "apetito".
- **Sin overclaim**: no decir que el ticket está "approved" o "in progress" — solo confirmar `issueKey` + estado inicial real.

## Catálogo de portales (snapshot 2026-05-21)

29 service desks, 318 request types. Ver `reference/catalog.md` para listado humano-legible o `reference/catalog.json` para parsing.

Los más usados por Hernán (del histórico personal — `requestOwnership=OWNED_REQUESTS`):
- **HD / IT-Solicitudes** (sd=1, 47 forms) — accesos, hardware, software, password resets
- **CYBS / Cyber Solicitudes IAM** (sd=24, 100 forms) — GitHub tokens, AWS, Google Cloud, etc.
- **DSOSH / DSO Security Hub** (sd=6, 17 forms) — DevSecOps
- **FIN / Finance** (sd=14, 8 forms)
- **LEGOPS / Legal Ops** (sd=159, 5 forms)
- **OFFSEC / Offensive Security** (sd=192, 6 forms) — pentests, threat modeling
- **RDG / Rendición de gastos** (sd=8, 15 forms)

## Templates conocidos

`templates/*.json` tiene payloads canónicos para los forms más usados — listos para parametrizar. Casos:
- `it-1password.json` (HD-71, solo `summary`)
- `it-abm-repos-github.json` (HD-1404, 8 campos · **validado live HD-11623 el 2026-05-26** via Chrome session, sin API token)
- `cyber-1password.json` (CYBS-1042)
- `cyber-github-team-access.json` (CYBS-1577, 5 required)
- `cyber-datadog-llm-observability.json` (CYBS-1144 reutilizado para API key · **validado live CYBS-6841 el 2026-05-21**)

## Gotchas conocidos

- **CYBS-4706 "API Key" es SOLO Gemini/Claude.** El form literal pregunta "¿Qué otras soluciones consideró antes de concluir que necesita específicamente una API key de Gemini/Claude?". NO usarlo para Datadog/AWS/otros.
- **Datadog API keys → CYBS-1144 reutilizado.** No hay form dedicado. Usar "Datadog - Alta de Usuario" y aclarar explícito en `customfield_10897` que es para API key + scope + endpoints + uso. Patrón histórico en #cloudops es pedir directo a CloudOps, pero el form CYBS también funciona si se redacta bien.
- **Slack scope escalation.** El classifier bloquea `from:<otro-usuario>` en `mcp__claude_ai_Slack__*`. Investigar precedentes con keyword puro, sin `from:`.
- **One-name autorizador.** Cuando el user dice "X y no otros" sobre el autorizador → el field es string libre, escribir solo ese nombre sin CCs ni listas.
- **Creación de repos NO está en CYBS.** Si el user pide "ticket de Cyber para crear repo", el path canónico es **HD-1404 "ABM de Repositorios de GitHub"** en IT-Solicitudes (sd=1). CYBS solo tiene operaciones de team/access (1576 Creación de Team, 1577 Agregar Usuario a Team). Avisar al user y mover a HD.
- **Date picker JSM ambiguo.** El combobox `date` parsea `2/6/2026` como **MM/DD = 6/feb/26** (no DD/MM como esperaría locale es-AR). Formato seguro: `D/mmm/YY` literal (ej. `2/jun/26`, `15/dic/26`). Verificar siempre con snapshot post-fill que la fecha resuelta es la correcta.
- **Combobox user-picker (Aprobador, asignee, etc.).** Click el combobox → `type_text "Nombre Apellido"` → aparece listbox con N opciones → click la opción exacta por uid. Si hay varios con mismo nombre (ej. Fernando Garade vs Fernando Vega), confirmar email/displayName antes de click.

## Referencias

- `reference/api-endpoints.md` — cheatsheet REST completo
- `reference/field-types.md` — mapping fieldType → payload shape
- `reference/auth-modes.md` — Chrome session vs API token (con setup)
- `reference/catalog.json` — denormalizado, parseable, 318 entradas
- `reference/catalog.md` — humano-legible, agrupado por desk
- `reference/desks.json` — 29 desks con portalUrl + count

## Troubleshooting rápido

- **403 al crear** → el user no es customer del portal. Verificar logueado en `play-sistemico.atlassian.net` y que figure en la lista de "Portales" del Help Center.
- **400 con field error** → re-fetch fields (el schema puede haber cambiado). Comparar `fieldId` esperados vs los del payload.
- **"This API is..."** sin JSON → falta header `X-ExperimentalApi: opt-in`. Aplica a `requesttype?searchQuery=*` y otros endpoints experimentales.
- **Catálogo stale** → correr `scripts/sync-catalog.sh` (usa API token, idempotente, escribe `reference/catalog.json` y `desks.json`).
- **`option` field con `value` vs `id`** → siempre POST `{ id: "<id>" }`. JSM acepta `value` pero es lossy.

## Sync a erno-modo

Cuando esto cambie sustancialmente (catálogo, recipes, auth modes), correr `erno-modo-sync-all` para refrescar el bundle público de skills en la bitácora.
