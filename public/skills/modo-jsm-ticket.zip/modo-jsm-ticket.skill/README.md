# modo-jsm-ticket

Skill para generar tickets en el Jira Service Management de Play Digital / MODO de punta a punta — desde "necesito acceso a X" hasta el `issueKey` con link al portal.

**Portal**: https://play-sistemico.atlassian.net/servicedesk/customer/portals
**Snapshot del catálogo**: 2026-05-21 · 29 service desks · 318 request types

## Por qué este skill existe

El portal de JSM de MODO tiene 29 service desks y 318 forms distintos. La mayoría tiene `customfield_*` IDs únicos por desk, validValues internos, y campos obligatorios poco documentados. Pedir un ticket "para acceso a GitHub" implica:

1. Saber si es **HD** (IT-Solicitudes) o **CYBS** (Cyber-Solicitudes) — ambos tienen forms de GitHub.
2. Saber el `requestTypeId` exacto.
3. Resolver los campos custom: tipo de solicitante, autorizador, beneficiario, etc.
4. Adjuntar lo que corresponda.

Este skill lo automatiza: el user describe la necesidad, el skill resuelve el desk + request type + schema + payload, muestra preview, y POSTea solo con confirmación.

## Cómo se invoca

Auto-invoca cuando el user dice algo del estilo:
- "armá un ticket de IT para 1Password"
- "necesito acceso al team modo-landing-dev en GitHub"
- "abrí un ticket en JSM de Quicksight"
- "/modo-jsm-ticket acceso a AWS para Juan Perez"

También se puede llamar manual via `Skill` tool: `skill: "modo-jsm-ticket"`.

## Arquitectura

```
~/.claude/skills/modo-jsm-ticket/
├── SKILL.md                          # entrada principal — workflow + triggers
├── README.md                         # este archivo
├── reference/
│   ├── api-endpoints.md              # REST cheatsheet completo
│   ├── field-types.md                # payload shape por tipo de campo
│   ├── auth-modes.md                 # Chrome session vs API token
│   ├── desks.json                    # 29 service desks (id, key, name, portalUrl, count)
│   ├── catalog.json                  # 318 request types flat-list (parseable)
│   └── catalog.md                    # mismo catálogo, humano-legible
├── scripts/
│   ├── _common.sh                    # helpers: require_auth, jsm_get, jsm_post
│   ├── search-types.sh               # grep local + opcional live search
│   ├── get-fields.sh                 # field schema de un (sd, rt)
│   ├── create-request.sh             # validate + POST con --dry-run
│   └── sync-catalog.sh               # refrescar catalog.json (API token)
└── templates/
    ├── it-1password.json
    ├── it-abm-repos-github.json
    ├── cyber-1password.json
    └── cyber-github-team-access.json
```

## Setup (1 vez)

Para uso CLI / headless necesitás API token de Atlassian:

```bash
mkdir -p ~/.atlassian && chmod 700 ~/.atlassian
printf '%s' 'hernan.desouza@modo.com.ar' > ~/.atlassian/email
printf '%s' 'TU_TOKEN_DE_atlassian.com' > ~/.atlassian/jsm-token
chmod 600 ~/.atlassian/*
```

Token se genera en https://id.atlassian.com/manage-profile/security/api-tokens.

Para uso interactivo con Claude Code, basta tener Chrome logueado en `play-sistemico.atlassian.net` — el skill usa `mcp__chrome-devtools__evaluate_script` para fetch con cookies.

## Workflow corto

```bash
# 1. Buscar form
~/.claude/skills/modo-jsm-ticket/scripts/search-types.sh "1password"
# → sd=1 rt=71 (HD)   y   sd=24 rt=1042 (CYBS)

# 2. Ver schema
~/.claude/skills/modo-jsm-ticket/scripts/get-fields.sh 24 1042

# 3. Armar payload (copiar de templates/ y editar)
cp ~/.claude/skills/modo-jsm-ticket/templates/cyber-1password.json /tmp/ticket.json
$EDITOR /tmp/ticket.json

# 4. Dry-run
~/.claude/skills/modo-jsm-ticket/scripts/create-request.sh --payload /tmp/ticket.json --dry-run

# 5. Crear
~/.claude/skills/modo-jsm-ticket/scripts/create-request.sh --payload /tmp/ticket.json
```

Claude Code hace los 5 pasos en una sola interacción siguiendo el workflow del SKILL.md.

## Service desks · top usados

| sd | key | name | forms |
|---|---|---|---|
| 1 | HD | IT-Solicitudes | 47 |
| 24 | CYBS | Cyber \| Solicitudes IAM | 100 |
| 6 | DSOSH | DSO Security Hub | 17 |
| 14 | FIN | Finance | 8 |
| 159 | LEGOPS | Legal Ops | 5 |
| 192 | OFFSEC | Cyber \| Offensive Security | 6 |
| 8 | RDG | Rendición de gastos | 15 |

(Ver `reference/desks.json` para los 29 completos.)

## Reglas duras

- Nunca POSTear sin confirmación explícita del user.
- Nunca hardcodear `customfield_*` IDs — fetch siempre.
- Nunca asumir que el catálogo cacheado refleja el live — re-sync ante errores raros.
- Voz rioplatense en `summary` y `description` si Claude redacta copy.
- `raiseOnBehalfOf` solo cuando el user lo pide explícito.

## Troubleshooting

| Síntoma | Causa | Fix |
|---|---|---|
| 401 al hacer fetch | API token vencido o mal | Re-generar y actualizar `~/.atlassian/jsm-token` |
| 403 al crear ticket | User no es customer del portal | Pedir add a customer-list al admin del portal |
| 303 → login HTML | Sesión Chrome expiró | Re-loguearse en `play-sistemico.atlassian.net` |
| 400 "field required" | Schema cambió o falta un required | Re-fetch fields y comparar |
| "This API is..." | Falta `X-ExperimentalApi: opt-in` | Agregar header |
| Catálogo no encuentra un form | Snapshot stale | `scripts/sync-catalog.sh` |

## Cambios

- 2026-05-21 — v0.1 inicial. Catálogo capturado con cookies del browser logueado de Hernán.
- 2026-05-26 — Gotchas: creación de repos NO está en CYBS (path canónico HD-1404); date picker JSM parsea ambiguo MM/DD, usar `D/mmm/YY`; combobox user-picker confirmation flow. Template `it-abm-repos-github.json` validado live en HD-11623 via Chrome session (sin API token). Detalle en SKILL.md `## Gotchas conocidos` + `reference/field-types.md ## date`.
