---
name: optimistic-persist-rq
description: Use this skill to persist a write surface (likes/comments/bookmarks/follows/reactions) with TanStack Query (React Query) v5 and optimistic UI, applied uniformly across views. Captures the canonical onMutate/onError/onSettled mutation shape, a typo-proof query-key factory, seeding the cache from server props, and the count-on-entity + membership-set split. Framework-agnostic React; distilled from a production app's migration off hand-rolled useState.
---

One shared client cache + ONE optimistic-mutation pattern for every per-user write. Replaces
scattered `useState` + manual optimistic bookkeeping that drifts across views and loses state
on navigation. Does not touch the server, schema, or REST contracts.

## Goals this enforces

- One cache so a record's counts are identical in list, detail, and profile.
- One reusable optimistic pattern for likes/comments/bookmarks/etc.
- **Honest rollback**: a failed mutation visibly reverts and surfaces a real error message.
- Survives navigation/reload without losing freshly-made interactions.

## The 3 decisions

1. **One `QueryClientProvider`** at the app root as a `'use client'` wrapper, with one
   `QueryClient` per browser session (created in a `useState`/ref so it isn't recreated on
   re-render). Sits alongside your other providers.
2. **Query-key factory** in one module so keys are typo-proof and invalidations centralized:
   ```ts
   export const keys = {
     posts: { list: f => ['posts','list',f], detail: id => ['posts','detail',id] },
     comments: { list: postId => ['comments', postId] },
     likes: { byUser: uid => ['likes', uid] },        // a Set of liked ids
     bookmarks: { byUser: uid => ['bookmarks', uid] },
   };
   ```
3. **Seed cache from server props.** Keep server-side data fetching; the client seeds React
   Query with `initialData` so first paint is unchanged and there's no double-fetch.

## Canonical optimistic mutation shape (every write implements this)

```ts
useMutation({
  mutationFn: vars => api.toggleLike(vars),
  onMutate: async (vars) => {
    await qc.cancelQueries({ queryKey: key });      // stop in-flight refetch racing us
    const previous = qc.getQueryData(key);          // snapshot for rollback
    qc.setQueryData(key, applyOptimistic(previous, vars));
    return { previous };
  },
  onError: (_e, _vars, ctx) => {
    qc.setQueryData(key, ctx.previous);             // honest revert
    showError('…');                                 // real message, not "Error"
  },
  onSettled: () => qc.invalidateQueries({ queryKey: key }), // reconcile w/ server truth
});
```

## Count-on-entity + membership-set split

A like has two facts: the **count** (lives on the record entity) and **whether *this user*
liked it** (a per-user Set). A like mutation optimistically updates BOTH `posts.detail`/
`posts.list` (count) and `likes.byUser` (membership), mirroring the server response
`{ liked, likes }`. Update list items **by `id`, not by index** — lists may be shuffled/paged.

## Risks to design against (learned the hard way)

- **Partial migration = two state systems.** Scope explicitly (e.g. likes→comments→bookmarks→
  feed→profile), migrate one surface at a time, and delete the orphaned manual state for each
  migrated surface. Leave the rest untouched.
- **Cache identity vs shuffling.** If the list reorders, key the list cache by filters and
  update items by `id` so optimistic updates land on the right record.
- **Count drift on rapid toggles.** `cancelQueries` in `onMutate` + `invalidateQueries` in
  `onSettled` reconciles; counts derive from the server on settle, not from accumulated clicks.

## Migration order (each step independently revertable)

1. Add dep, mount provider (no behavior change). 2. Add key factory + read hooks behind the
existing UI, seeded from current props. 3. Swap reads to hooks, then swap writes to optimistic
mutations one surface at a time, verifying each. 4. Delete orphaned manual state for migrated
surfaces.

## One line

One QueryClient + key factory + the `onMutate`/`onError`/`onSettled` triad; seed from server
props, split count-on-entity from membership-set, migrate one surface at a time.
