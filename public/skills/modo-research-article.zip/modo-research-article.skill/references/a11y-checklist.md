# A11y baseline checklist para R&D HTML

Mínimo WCAG 2.2 AA para que un R&D pase un audit independiente de Accessibility Auditor sin findings críticos.

## En el `<head>` (template ya lo trae a partir de 2026-05-28)

- [x] `<meta name="viewport" content="width=device-width, initial-scale=1.0">`
- [x] `<meta name="author" content="Hernán De Souza">`
- [x] `<link rel="canonical" href="https://soyernomodo.github.io/erno-modo/rd/<slug>.html">`
- [x] `<meta name="theme-color" content="#008859">`
- [x] Open Graph (`og:type`, `og:title`, `og:description`, `og:url`)
- [x] `article:author` + `article:published_time` + `article:section`

## En el header del site

- [x] `<a class="skip-link" href="#article-main">` antes de todo
- [x] Nav-counts con `aria-live="polite"` para que el screen reader anuncie cuando carga el count async
- [x] Theme toggle button con `aria-label` + `<span class="label" aria-live="polite">` para anunciar cambio de estado

## En el contenido

### Tablas

Cada `<table>` adentro de `<div class="table-scroll">` necesita 3 atributos en el wrapper:

```html
<div class="table-scroll" tabindex="0" role="region" aria-label="Tabla — <qué describe>">
  <table class="data-table">
    <caption>Caption corta</caption>
    <thead>
      <tr><th scope="col">Col 1</th></tr>
    </thead>
    ...
  </table>
</div>
```

- `tabindex="0"` permite scroll horizontal con teclado (WCAG 2.1.1).
- `role="region"` + `aria-label` identifica la tabla para screen readers cuando se navega por landmarks.
- `<th scope="col">` siempre.

### SVG diagramas

Cada `<svg>` necesita `<title>` + `<desc>` con `aria-labelledby`:

```html
<svg viewBox="..." class="diagram" role="img" aria-labelledby="topo-title topo-desc">
  <title id="topo-title">Topología — qué muestra</title>
  <desc id="topo-desc">Descripción larga accesible.</desc>
  ...
</svg>
```

Si el `<figcaption>` ya describe lo mismo que el `<desc>`, está OK (redundancia útil para screen readers que leen ambos).

### Chart.js canvas

Cada `<canvas>` con `aria-label` específico (no genérico tipo "chart"):

```html
<canvas id="my-chart" aria-label="Impacto estimado en authority transfer por movida — score 0 a 10" role="img"></canvas>
```

Y **siempre** un `<noscript>` fallback con tabla equivalente. Sin esto el usuario sin JS pierde los datos:

```html
<figure class="article-figure">
  <div class="chart-wrap">
    <canvas id="my-chart" aria-label="..." role="img"></canvas>
  </div>
  <noscript>
    <div class="table-scroll" tabindex="0" role="region" aria-label="Tabla — datos del chart (fallback sin JS)">
      <table class="data-table">
        <caption>Datos del chart · fallback no-JS</caption>
        <thead><tr><th scope="col">Categoría</th><th scope="col">Valor</th></tr></thead>
        <tbody>
          <tr><td>Cat 1</td><td>9</td></tr>
          ...
        </tbody>
      </table>
    </div>
  </noscript>
  <figcaption>...</figcaption>
</figure>
```

### Code blocks

`<pre>` con `aria-label` describiendo el contenido + `<code>` con `lang="<lang>"` para que screen readers anuncien el lenguaje:

```html
<pre aria-label="Ejemplo JSON-LD SaleEvent"><code lang="json" class="lang-json">
{
  "@context": "https://schema.org",
  ...
}
</code></pre>
```

NVDA/JAWS no anuncian "JSON code block" por la clase CSS — necesitan el atributo `lang`. Sin `aria-label` el bloque grande de JSON se lee byte por byte con llaves leídas.

### Breadcrumb

```html
<nav class="breadcrumb" aria-label="Breadcrumb">
  <a href="../">Erno × MODO</a>
  <span class="sep" aria-hidden="true">/</span>
  <a href="./">R&D</a>
  <span class="sep" aria-hidden="true">/</span>
  <span aria-current="page">Título corto</span>
</nav>
```

`aria-current="page"` en el último item.

### Heading order

H1 una sola vez (título del R&D). H2 por sección principal. H3 dentro de cada sección. **Nunca** saltar (h1→h3, h2→h4).

Validar con grep: `grep -E "<h[1-6]" rd/<slug>.html | sed 's/.*<h\([1-6]\).*/h\1/' | uniq`.

## Verify-grep canónico antes del PR

```bash
FILE=rd/<slug>.html

# 1. canonical + author meta presentes
grep -E 'rel="canonical"|name="author"' "$FILE"

# 2. table-scroll con tabindex/role/aria-label
grep -nE '<div class="table-scroll"[^>]*tabindex' "$FILE"
# si alguna table-scroll NO tiene tabindex/role/aria-label → fail

# 3. aria-live en nav-counts + theme-label
grep -cE 'aria-live="polite"' "$FILE"   # ≥4 esperado

# 4. noscript fallback si hay canvas
grep -q '<canvas' "$FILE" && grep -q '<noscript>' "$FILE" || echo "WARN: canvas sin noscript"

# 5. <pre><code> con aria-label + lang
grep -nE '<pre[^>]*aria-label' "$FILE"
grep -nE '<code lang=' "$FILE"

# 6. SVG con title+desc
grep -cE '<svg.*aria-labelledby' "$FILE"
grep -cE '<title id=' "$FILE"
grep -cE '<desc id=' "$FILE"

# 7. heading order sin saltos
grep -oE '<h[1-6]' "$FILE" | sed 's/<//' | uniq
# debería listar h1, h2, h3, h2, h3, h3, ... — nunca h1 seguido de h3 directo
```

Si cualquier check falla → arreglarlo antes del PR. Audit-iterate Round 1 (`AccessibilityAuditor`) lo va a catchear si no.

## Caso canónico

[RD04 · Landings temáticas evergreen + /comercios canonical hub](https://soyernomodo.github.io/erno-modo/rd/promos-hub-seo-geo-bridge.html) — pasó audit con 0 CRIT a11y después del Round 1 fix (2026-05-28).
