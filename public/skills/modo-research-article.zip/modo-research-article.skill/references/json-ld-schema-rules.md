# JSON-LD schema.org · reglas y trampas para R&D

Reglas duras al emitir JSON-LD `@graph` dentro de un R&D que propone structured data. Lo que pasa Rich Results Test vs lo que parece válido pero Google rechaza.

## Test obligatorio antes del PR

Cada sample JSON-LD que aparezca en el artículo:

1. **Parse sintáctico**: `python3 -c "import json,re; html=open('rd/<slug>.html').read(); [json.loads(m.group(1)) for m in re.finditer(r'<code lang=\"json\"[^>]*>(\{.*?\})</code>',html,re.DOTALL)]"` debe pasar.
2. **Rich Results Test**: https://search.google.com/test/rich-results — pegar el JSON, mirar errores.
3. **schema.org Validator**: https://validator.schema.org/ — útil para types menos comunes (SaleEvent, MerchantReturnPolicy, BankOrCreditUnion).

Si el R&D propone JSON-LD pero no incluyó este test, el reviewer tiene derecho a marcar CRIT.

## Campos obligatorios por type (Rich Results Google)

### `Event` / `SaleEvent` / cualquier subtipo de Event

| Campo | Obligatorio | Notas |
|---|---|---|
| `name` | sí | |
| `startDate` | sí | ISO-8601 con TZ |
| `endDate` | recomendado | Para Event terminado o future. Reemplaza al `validThrough` mal-attribuido. |
| `location` | **sí** | Para online: `VirtualLocation` con `url`. Para mixto online+físico: array `[VirtualLocation, Place]`. Para retail: `Place` con `address`. Sin este campo el rich result NO aparece. |
| `organizer` | **sí** | `Organization` o `Person`. Relación org → event va por `organizer`, NUNCA por `superEvent`. |
| `image` | **sí** | URL absoluta. |
| `description` | **sí** | Texto plano corto. |
| `eventStatus` | recomendado | `EventScheduled` por default. Solo usar `EventMovedOnline` si pasó de presencial a online. |
| `eventAttendanceMode` | recomendado | `OnlineEventAttendanceMode` / `OfflineEventAttendanceMode` / `MixedEventAttendanceMode`. Sin esto Google no sabe si es online/offline/mixto. |
| `offers` | opcional | Array de `Offer`. Cada `Offer` con su propio `validThrough`. |

### `Offer`

| Campo | Obligatorio | Notas |
|---|---|---|
| `@type` | sí | `Offer` |
| `validThrough` | recomendado | ISO-8601. Sin esto LLMs asumen vigencia indefinida y citan promos vencidas. |
| `offeredBy` | recomendado | Mejor `BankOrCreditUnion` que `Organization` genérico — habilita futuras páginas `/bancos/[slug]`. |
| `itemOffered` | recomendado | Apunta al brand del merchant por `@id`. |
| `url` | recomendado | URL canónica del hub. |

## Props prohibidas o mal-attribuidas (errores comunes)

| Error | Por qué está mal | Fix |
|---|---|---|
| `validThrough` en nivel `Event` | `validThrough` es prop de `Offer`/`Demand`/`CreativeWork`, NO de Event. Google la ignora silenciosamente. | Para Event usar `endDate`. |
| `superEvent: { Organization }` | `superEvent` espera otro `Event`, NO una Organization. La relación org → event es `organizer`. | Cambiar a `organizer: { @id: "#organization" }`. |
| `Event` genérico para evento comercial | Funciona pero pierdes especificidad. | Usar `SaleEvent` (subtype canónico de schema.org). |
| `eventStatus: EventMovedOnline` para evento online nativo | `EventMovedOnline` es para eventos que MIGRARON de presencial a online. | Usar `EventScheduled` + `eventAttendanceMode: OnlineEventAttendanceMode`. |
| Falta `location` en evento online | Google rechaza el rich result. | Agregar `VirtualLocation` con `url` del propio evento. |
| `Review` o `aggregateRating` sin fuente licenciada | Google penaliza self-rated. | Solo agregar con fuente externa licenciada (Trustpilot, Google Reviews API). |

## Caveat de Rich Results para `SaleEvent`

Al día de 2026-05 Google **NO** tiene un rich result dedicado para `SaleEvent`. Usa el rich result genérico de `Event`. No prometer "rich result de SaleEvent" en prose — decir "rich result genérico de Event que SaleEvent hereda".

Si el R&D promete rich result dedicado de un subtype, el reviewer puede marcar WARN. Verificar en https://developers.google.com/search/docs/appearance/structured-data/search-gallery antes de prometer.

## Estrategia `@id` global

Reglas para que los grafos sean reusables y no dupliquen entidades:

- `@id` siempre absoluto (con `https://`).
- `@id` del brand del merchant **sin sufijo de año/edición** — la entidad es estable across editions. Ej: `https://www.modo.com.ar/comercios/changomas#brand`.
- `@id` del evento **con sufijo de edición** — Hot Sale 2026 ≠ Hot Sale 2027. Ej: `https://www.modo.com.ar/promos/hotsale#event-2026`.
- `@id` de cada `Offer` **con sufijo de edición** — la oferta es per-edition. Ej: `https://www.modo.com.ar/promos/hotsale#offer-changomas-2026`.
- `@id` de banco **sin sufijo** — entidad estable. Ej: `https://www.modo.com.ar/bancos/galicia#bank`.

Cross-link: `Offer.itemOffered: { @id: "<brand sin año>" }`. Hub merchant consume `Offer` por `@id` con año (porque la promo es per-edition). Brand es ref estable, Offer es ref efímera.

## Anti-hallucination invariant (consumer protection AR)

Reglas para que el JSON-LD sea aceptable para Ley 24.240 (Argentina) y para que los LLMs no inventen detalles:

1. **Valores LITERALES del BFF** — el composer JSON-LD nunca calcula. Descuentos, topes, mínimos, validez vienen como aparecen en la fuente.
2. **`validThrough` siempre presente** cuando hay vigencia conocida. Sin él, LLMs asumen vigencia indefinida.
3. **`offeredBy` con tipo específico** (`BankOrCreditUnion` mejor que `Organization`).
4. **`@id` global y absoluto** — permite reutilización sin duplicar entidades.
5. **`sameAs` con sitio oficial + Wikipedia + redes** — refuerza identity disambiguation.
6. **Sin `Review` ni `Rating` falsos** — solo con fuente licenciada.

## Cuándo crear este sample en un R&D

Si el R&D propone JSON-LD nuevo o modifica grafo existente:
- Mostrar el sample completo en el artículo (no fragmentos).
- Validar pre-PR (test obligatorio arriba).
- Documentar las 3-5 decisiones de schema que hay que cerrar en un callout-info (qué campos son load-bearing, qué `@id` lleva año, qué relación va por qué prop).
- Documentar los caveats de Rich Results para el subtype específico en un callout-warn.

Caso canónico que cubre estos puntos: [RD04 · Landings temáticas evergreen + /comercios canonical hub](https://soyernomodo.github.io/erno-modo/rd/promos-hub-seo-geo-bridge.html) — sección 3 "JSON-LD SaleEvent denso".
