# hyperresearch → modo-research-article handoff

`hyperresearch` (jordan-gibbs/hyperresearch, MIT) es el **motor de research**; `modo-research-article` es el **formateador de salida** branded MODO. Capas distintas, pipeline en serie. NO es dependencia de código — es handoff de artefactos.

## Qué es hyperresearch

Sistema agent-driven de deep research. Pipeline de 16 pasos → reporte adversarialmente revisado con provenance completo. Guarda cada fuente fetcheada en un vault SQLite-indexado persistente que compone entre sesiones. Roster de subagents: Opus orquesta/sintetiza, Sonnet analiza, Haiku fetchea en paralelo. Integra crawl4ai (fetch), pymupdf (PDF), SQLite (índice del vault).

## Instalación (este host, 2026-05-27)

- **python3 default = 3.14.2** → INCOMPATIBLE (hyperresearch pide 3.11–3.13).
- Instalado vía **pipx** pinned a `python@3.13` brew (`/opt/homebrew/opt/python@3.13`):
  ```bash
  brew install pipx
  pipx install hyperresearch --python /opt/homebrew/opt/python@3.13/bin/python3.13
  ```
- Versión: **0.8.6**. Binarios `hyperresearch` + `hpr` en `~/.local/bin/` (en PATH via `pipx ensurepath`).
- **Entry skill global** (`/hyperresearch` en cualquier sesión): requiere
  ```bash
  hyperresearch install --global   # dropea entry skill + agents en ~/.claude/
  ```
  Este comando el **classifier de Claude Code lo bloquea en auto-mode** (escribe en `~/.claude/` = self-modification). Hay que: (a) agregar regla Bash `hyperresearch install*` en settings, o (b) correrlo manual en terminal. NO toca `CLAUDE.md` global, NO inicia vault (eso es per-project on first run).
- **NUNCA** correr `hyperresearch install` sin `--global` dentro de un repo MODO: el default inyecta el `CLAUDE.md` checked-in del repo + hooks. Invasivo.

## Comandos clave

```bash
hyperresearch research "<pregunta>" --tier light   # ~30-40 min
hyperresearch research "<pregunta>" --tier full    # ~1.5-2.5 h
hyperresearch status      # salud + stats del vault
hyperresearch search "<q>" # full-text search del vault
hyperresearch fetch <url>  # guardar 1 URL como nota
hyperresearch serve        # web UI para browsear el vault
hyperresearch mcp          # MCP server (stdio) para Claude Desktop/Cursor
```

## Handoff al artículo R&D

1. Correr `/hyperresearch <tema>` o `hyperresearch research "..."`.
2. El vault queda en `<proyecto>/research/` (markdown + SQLite). El reporte sintetizado es el insumo.
3. En `modo-research-article`:
   - **Paso 1 (Discovery)**: `sources` salen del vault, no se piden a mano.
   - **Paso 4 (fill template)**: reporte sintetizado → prosa + matrix + tablas + diagramas.
   - **Paso 5 (`rd.json`)**: array `sources` = URLs del vault.
4. La voz del reporte de hyperresearch es neutra/inglesa → **reescribir a voz rioplatense** al pasar al HTML (regla dura #9 del SKILL). hyperresearch da los datos, no el copy final.

## Costo + cuándo NO

hyperresearch consume **API Anthropic con tu key** (Opus/Sonnet/Haiku). Tier full = horas de cómputo = costo real. Disparar solo para research que justifica una R&D (≥1 diagrama, comparativo, mapeo grande). Research chico de 1 fuente → fetch manual o WebFetch directo, sin motor.
