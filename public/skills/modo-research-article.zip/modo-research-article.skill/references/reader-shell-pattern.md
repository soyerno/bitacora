# Reader shell pattern (canónico para R&D + lecciones + notas)

> Pattern de reader scroll-read unificado para sitios estáticos MODO. Base: `research-article.css`. Extensible a múltiples tipos de contenido vía `data-type`.

## Por qué este pattern

El reader es **un solo shell** que renderiza múltiples tipos de contenido. Evita drift entre 3 readers paralelos y centraliza la capa de inclusión (bionic, progress, glossary, skip-link).

Aplica a:
- R&D articles (`/rd/<slug>.html`) — autoría con este skill.
- Lecciones (`/lectura/lecciones/<slug>.html`) — conversión deck→scroll.
- Notas de bitácora (`/bitacora/<date>.html`) — daily digest scroll.

## Parametrización por `data-type`

El root del artículo declara el tipo:

```html
<article data-type="research"> <!-- o "leccion" / "nota" -->
  <!-- mismo CSS, mismo JS init -->
</article>
```

CSS lee el atributo para mostrar/ocultar componentes:

```css
[data-type="leccion"] .learn-objectives { display: block; }
[data-type="leccion"] .next-lesson { display: flex; }
[data-type="research"] .learn-objectives,
[data-type="research"] .next-lesson { display: none; }
[data-type="nota"] .learn-objectives,
[data-type="nota"] .next-lesson { display: none; }
```

JS detecta y activa solo módulos aplicables.

## Componentes del shell (matriz por tipo)

| Componente | Lección | Research | Nota |
|-----------|---------|----------|------|
| `.article-shell` container | ✅ | ✅ | ✅ |
| `.article-hero` + meta-pills | ✅ | ✅ | ✅ |
| TL;DR (`.tldr`) | ✅ | ✅ | opcional |
| TOC sticky (`.article-grid` 220px+1fr) | ✅ | ✅ | opcional |
| `.article-prose` (70ch, 17px, 1.75) | ✅ | ✅ | ✅ |
| Callouts (`.callout-info|warn`) | ✅ | ✅ | ✅ |
| Skip-link (WCAG SC 2.4.1) | ✅ | ✅ | ✅ |
| Theme toggle (light/dark/auto) | ✅ | ✅ | ✅ |
| **Bionic toggle** | ✅ | ✅ | ✅ |
| **Reading progress bar** | ✅ | ✅ | ✅ |
| **Glossary tooltips** (`.glossary-term` + `<abbr>`) | ✅ | ✅ | ✅ |
| `.learn-objectives` (qué vas a aprender) | ✅ obligatorio | ❌ | ❌ |
| `.next-lesson` footer | ✅ (track) | ❌ | ❌ |
| `.promoted-banner` (bidir link) | ❌ | ❌ | ✅ si `promoted_to` |
| Charts theme-aware (Chart.js + CSS vars) | opcional | ✅ frecuente | rara vez |
| SVG diagrams inline theme-aware | opcional | ✅ frecuente | rara vez |

## Bionic toggle (WCAG 2.2 AA SC 1.4.8 + 1.4.12)

- Botón en `.article-header-actions` junto al theme toggle.
- Click → wrap palabras ≥3 letras en `.article-prose` con `<b class="bionic-fixation">PRI</b>mer-half`.
- Persistencia `localStorage: modo-bionic = "on"|"off"`.
- **Exclusión obligatoria**: code blocks, `<pre>`, `<table>`, headings (h1-h6), nav, code inline. CSS:

```css
.article-prose code,
.article-prose pre,
.article-prose table,
.article-prose h1, .article-prose h2,
.article-prose h3, .article-prose h4 {
  /* skip bionic — el JS no procesa estos */
}
```

CSS canónico: reusar `assets/deck-bionic.css` (ya en erno-modo).

## Reading progress bar (WCAG SC 2.3.3 reduced-motion)

```css
.reading-progress {
  position: fixed; top: 0; left: 0;
  width: var(--scroll-progress, 0%);
  height: 4px;
  background: var(--accent);
  transition: width 0.05s linear;
  z-index: 999;
}
@media (prefers-reduced-motion: reduce) {
  .reading-progress { transition: none; }
  /* O binario: aparece solo al llegar al fondo */
}
```

JS: `requestAnimationFrame` throttled, escucha `scroll`. Setea `--scroll-progress` CSS var.

## Glossary tooltips (WCAG SC 3.1.3 Unusual Words)

CSS-only tooltip vía `<abbr>` nativo + wrap:

```html
<span class="glossary-term"><abbr title="Backend For Frontend">BFF</abbr></span>
```

`<abbr title>` lo lee NVDA/VoiceOver nativo (no JS necesario). Página central `/glosario/` linkeada como "Ver todos los términos" complementa con definiciones largas.

## Skip-link (WCAG SC 2.4.1)

Primer elemento del `<body>`:

```html
<a href="#article-main" class="skip-link">Saltar al contenido</a>
```

```css
.skip-link {
  position: absolute; top: -40px; left: 0;
  background: var(--accent); color: white;
  padding: 8px 16px; z-index: 1000;
}
.skip-link:focus { top: 0; }
```

## CSS vars del tema (heredadas de `assets/styles.css`)

```css
:root {
  --bg: #FAFAF7;        --ink: #1A1A1A;
  --ink-soft: #2A2A2A;  --muted: #6B6B6B;
  --border: #E2E2DC;    --border-soft: #EFEFE9;
  --accent: #008859;    --accent-ink: #00471B;
  --accent-light: #E6F4EE;
}
:root[data-theme="dark"] { /* dark overrides */ }
@media (prefers-color-scheme: dark) {
  :root[data-theme="auto"] { /* dark overrides */ }
}
```

**Nunca** hardcodear `#008859` ni hex en el reader — siempre via `var(--accent)`.

## Anti-patterns del reader

- ❌ CSS por tipo de contenido en archivos separados → drift garantizado.
- ❌ Aplicar bionic a code blocks o tablas → rompe lectura técnica.
- ❌ Progress bar con animación continua sin `prefers-reduced-motion` → barrera A11y.
- ❌ Tooltip con `position: absolute` manual sin `<abbr>` → screen readers no lo leen.
- ❌ `learn-objectives` opcional en lección → la pedagogía se diluye, queda como blog.
- ❌ Hardcoded color hex en el shell → rompe theme toggle.

## Caso canónico

`erno-modo` SDD `bitacora-reader-experience` (commits 2c0?? y 5df9570 en branch `feat/bitacora-reader-experience`, 2026-05-28) — 16 D-decisions completas sobre este pattern, incluyendo el flow de coexistencia bitácora↔lectura.
