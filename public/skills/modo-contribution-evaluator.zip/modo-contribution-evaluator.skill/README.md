# modo-contribution-evaluator

Evaluador de contribuciones en el ecosistema MODO. Cruza GitHub (PRs autorados + revisados) con Jira (assignee + reporter), enrichea con diff stats, y produce reporte ejecutivo en Markdown + HTML branded MODO estilo R&D.

## Trigger

- `/modo-contribution-evaluator` · `/eval-contribuciones`
- Frases: "evaluá mis contribuciones", "armá un reporte de impacto", "qué hice en MODO", "audit de actividad", "snapshot de contribuciones", "perf review packet", "review 1:1 para X".

## Quickstart

```bash
# default (Hernán, todo el historial)
~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh

# rango temporal
SINCE=2026-01-01 UNTIL=2026-03-31 ~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh

# otro dev
AUTHOR_GH=otro-login AUTHOR_JIRA=otro@modo.com.ar ~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh
```

Output → `~/Documents/Reports/contributions-<author>-<YYYY-MM-DD>/`.

## Pasos

1. Fetch PRs autorados (`gh api search/issues author:X`)
2. Fetch PRs revisados (`reviewed-by:X -author:X`)
3. Enrich top-N con diff stats (`gh pr view --json additions,deletions,changedFiles,reviews`)
4. Fetch Jira (API token o MCP fallback)
5. Classify + aggregate (type / domain / quarter / lifecycle / merge rate)
6. Render Markdown + HTML

## Files

```
SKILL.md                # spec canónico
scripts/
  run-all.sh            # orquestador end-to-end
  fetch-prs.sh          # Step 1
  fetch-reviews.sh      # Step 2
  fetch-pr-details.sh   # Step 3
  fetch-jira.sh         # Step 4 (con fallback MCP)
  classify.mjs          # Step 5a
  aggregate.mjs         # Step 5b
  render-markdown.mjs   # Step 6a
  render-html.mjs       # Step 6b
reference/
  taxonomy.md           # repo→domain mapping + tipos commit
  kpis.md               # métricas + fórmulas
  sample-output.md      # ejemplo real
```

## Pre-reqs

- `gh` CLI autenticado (`gh auth status` muestra `Logged in`)
- `node` ≥ 18
- `jq` (homebrew)
- Opcional: `JIRA_API_TOKEN` env var + `JIRA_EMAIL` para Step 4 vía REST. Sin esto, Step 4 imprime warning y skipea.

## No incluye

- Líneas de código por archivo (eso es `git log --numstat`, no PR-level)
- Time-tracking de horas reales (Jira no lo trackea bien en MODO)
- Sentiment/quality de reviews (sería otro skill, ver `modo-code-review-checklist`)

## Changelog

- **2026-05-25** — skill creado. SKILL.md + 5 scripts (.sh) + 4 nodes (.mjs) + 3 reference docs. Smoke test Q1 2026: 72 PRs / 46 merged / 35 revisados. Bugs cazados durante e2e: GH search exige range syntax `created:A..B` (codificado en `fetch-prs.sh`/`fetch-reviews.sh`), jq necesita `-c` para JSONL (codificado en `fetch-pr-details.sh`). Aprendizajes destilados a memoria persistente — `reference_gh_pr_inventory_pattern.md`, `reference_jq_compact_for_jsonl.md`, `feedback_smoke_test_before_distill.md`.
