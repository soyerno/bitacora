# Taxonomy

## Repo → Domain

Mapping explícito en `scripts/classify.mjs` (`DOMAIN_MAP`). Cualquier repo no listado cae al heurístico regex (`inferDomain`).

| Dominio | Qué incluye | Repos canónicos |
|---|---|---|
| `web` | Sitios públicos y portales (Next/Vite/Astro) | `modo-landing`, `promos-hub-site`, `benefits-personalization-portal-site`, `selector-pcp-site`, `banks-admin-site`, `developers-portal-site`, `aprendeatumodo` |
| `lib` | Libs internas, design system, SDK UI | `modo-ui-lib-web`, `modo-landing-sdk-ui-lib`, `modo-landing-web-ui-lib`, `stores-maps-lib` |
| `bff` | BFFs / APIs / servicios | `stores-bff`, `promos-bff`, cualquier `*-bff`, `*-api`, `*-svc` |
| `mobile` | Apps móviles | `modo-android`, `modo-ios`, RN |
| `tooling` | Skills, CLIs, scripts, POCs | `modo-checkout-skill`, `tofu-comercios`, cualquier `*-skill`, `*-cli`, `*-tool` |
| `bitacora` | Sitio público de Hernán y framework | `erno-modo`, `modo-dev-framework` |
| `infra` | IaC, helm charts, deploys | `*-infra`, `terraform-*`, `helm-charts`, `tf-aws-*` |
| `other` | Default fallback | — |

## Tipos de commit reconocidos

Parsea el title del PR contra:

```
^(feat|fix|refactor|chore|docs|test|ci|perf|style|build|merge|revert|hotfix)(\(SCOPE\))?!?:\s*
```

Si no matchea → `type=untyped`. Esos PRs no respetan la convención del repo, vale la pena flagearlos en reviews.

| Tipo | Interpretación |
|---|---|
| `feat` | Feature nuevo (impacto de usuario) |
| `fix` | Bug fix |
| `refactor` | Cambio interno sin alterar comportamiento |
| `perf` | Optimización de performance |
| `chore` | Mantenimiento (deps, configs, cleanup) |
| `docs` | Solo docs |
| `test` | Solo tests |
| `ci` | Workflows, GitHub Actions, pipelines |
| `style` | Format, lint, sin cambio semántico |
| `build` | Build tooling, dependencies, package scripts |
| `merge` | Merge commits (usualmente ruido) |
| `revert` | Revert de PR previo |
| `hotfix` | Urgent prod fix fuera del flow normal |

## Detección de Jira ticket

Regex global: `\b([A-Z]{2,}-\d{1,6})\b`.

Busca primero en el title, después en el scope `(SCOPE-N)` si existe. Proyectos canónicos MODO: `COENXT`, `EXA`, `IE`, `MFEX`. Cualquier match con shape `[A-Z]+-\d+` cuenta, pero las cifras de "Jira coverage" en el reporte solo son útiles si el equipo respeta el convention.
