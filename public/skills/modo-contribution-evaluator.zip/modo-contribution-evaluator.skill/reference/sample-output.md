# Sample output

Ejemplo abreviado del REPORT.md generado para `AUTHOR_GH=SoyErnoModo` (basado en el snapshot de `proyectos.json` 2026-05-22).

---

# Contribuciones MODO · SoyErnoModo

> Snapshot generado el 2026-05-25 · rango 2024-Q2 → 2026-Q2

## TL;DR

Tiré **616 PRs** en el ecosistema MODO. Mergueé **475** (77.1%), tengo 40 abiertos y descarté 101. Además revisé **N PRs** de otros.

En Jira moví **N tickets** (assignee o reporter). Cobertura PR↔Jira: 68.4% de los PRs tienen ticket detectable en el title.

Lifecycle: mediana 2.1d open→merged · p95 14d · máx 92d.

## Dónde aporté

| Dominio | PRs | Merged | Merge rate | Repos |
|---|---:|---:|---:|---:|
| Web frontends | 471 | 358 | 76.0% | 6 |
| Bitácora pública | 37 | 34 | 91.9% | 1 |
| Libs / design system | … | … | … | … |
| Tooling / skills | … | … | … | … |

## Top 10 repos por volumen

| Repo | PRs | Merged | Open | Merge rate | Primer PR | Último PR |
|---|---:|---:|---:|---:|---|---|
| `playsistemico/modo-landing` | 272 | 187 | 36 | 68.8% | 2024-04-19 | 2026-05-22 |
| `playsistemico/promos-hub-site` | 158 | 136 | 1 | 86.1% | 2024-05-02 | 2026-05-15 |
| `SoyErnoModo/erno-modo` | 37 | 34 | 2 | 91.9% | … | … |
| … | … | … | … | … | … | … |

---

## HTML version

`report.html` es la misma data pero branded MODO (verde `#008859`, Quicksand + Red Hat Display + JetBrains Mono) con Chart.js inline para:

- **Throughput por quarter** — barras agrupadas (autorados vs merged)
- **Por dominio** — donut chart
- **Por tipo** — bar chart horizontal

Más cards KPI superiores con los 5-6 números clave + tablas igual que el MD.

## Cómo se ve cuando hay creds Jira

Si `JIRA_API_TOKEN` está seteado, se agrega:

```
## Jira tickets

**Por proyecto:**
- EXA: 124
- COENXT: 38
- IE: 12

**Por status:**
- Done: 142
- In Progress: 8
- Backlog: 24
```

Sin creds, esa sección no aparece y el TL;DR menciona "Jira no fetcheado".
