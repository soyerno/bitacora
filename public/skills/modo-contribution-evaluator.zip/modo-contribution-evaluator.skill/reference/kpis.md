# KPIs · fórmulas y caveats

Métricas calculadas en `scripts/aggregate.mjs`. Definiciones explícitas para evitar overclaim.

## Volumen

| Métrica | Fórmula | Caveat |
|---|---|---|
| `prs_authored` | `count(PR where author=X)` | Incluye open + closed + merged + draft |
| `prs_merged` | `count(PR where merged_at != null)` | Excluye cerrados sin merge |
| `prs_open` | `count(PR where state=open)` | Incluye drafts |
| `prs_closed_not_merged` | `count(PR where state=closed AND merged_at=null)` | Descartados |
| `prs_draft` | `count(PR where draft=true)` | Subset de `prs_open` |
| `prs_reviewed` | `count(PR where reviewer=X AND author!=X)` | Solo cross-author reviews |
| `merge_rate` | `prs_merged / prs_authored * 100` | Segmentar por repo: tail repos distorsionan |

## Lifecycle

| Métrica | Fórmula | Caveat |
|---|---|---|
| `lifecycle.median` | mediana de `closed - created` (días) en PRs merged | Solo merged. Open PRs no aportan |
| `lifecycle.p95` | p95 del mismo set | Útil para detectar long-runners |
| `lifecycle.max` | max | Outlier puro, casi siempre un PR olvidado |

**Caveat**: lifecycle ignora si el PR estuvo bloqueado por reviews vs autor inactivo. Para coaching usar GitHub native "Time to first review" no este.

## Throughput

| Métrica | Fórmula | Caveat |
|---|---|---|
| `by_quarter[].total` | PRs autorados con `created` en el quarter | Quarters cortos al inicio/fin del rango |
| `by_quarter[].merged` | Subset merged | Subset, no acumulado |

Para velocidad sostenida ignorar primer y último quarter del rango (suelen estar parciales).

## Jira coverage

| Métrica | Fórmula | Caveat |
|---|---|---|
| `jira_coverage` | `count(PR with detectable Jira ticket) / prs_authored * 100` | Asume convention `type(SCOPE-N): subject`. PRs en bitácora/skill repos suelen no tener ticket → empujan abajo el número global |

Para snapshots útiles, filtrar por repos productivos (no bitácora/tooling).

## Stale

| Métrica | Fórmula | Caveat |
|---|---|---|
| `stale_open[]` | PRs open con `updated_at < now - 30d` | Open != stale necesariamente. Reviewer puede estar bloqueado |

## Top PRs by impact

| Métrica | Fórmula | Caveat |
|---|---|---|
| `top_prs[]` | Top 15 por `changedFiles` desc de `prs-details.jsonl` (subset enrichado, TOP_N=25) | **Impacto ≠ files changed**. 1 línea bien puesta puede outweighar 500 líneas de styles. Usar como starting point, no veredicto |

## Anti-patrones de reporting

1. **No reportar merge rate global sin segmentar** — 80% en bitácora vs 50% en modo-landing miden cosas distintas.
2. **No comparar throughput cross-quarters sin notar offsite/PTO** — mecánicamente baja por vacaciones, no por menos productividad.
3. **No usar LOC delta como proxy de impacto** — `+1234/-1234` puede ser un rename masivo trivial.
4. **No reportar Jira coverage <100% como falla** — el equipo no usa convention en todos los repos. Es señal, no veredicto.
5. **No incluir `chore(deps)` o `merge:` PRs en TL;DR de impacto** — son ruido necesario, sí contarlos en totals.

## Cómo usar el reporte

- **1:1 con tu manager**: TL;DR + dominios + Top PRs. 5 minutos.
- **Perf review**: dominios + throughput por quarter + Top PRs + stale (qué dejé atrás). 15 minutos.
- **Snapshot de quarter**: filtrar con `SINCE=YYYY-QN-start UNTIL=YYYY-QN-end` y compartir el HTML.
- **Audit de actividad cross-equipo**: correr para varios `AUTHOR_GH` y comparar (cuidado con incentivos perversos: PRs ≠ impacto).
