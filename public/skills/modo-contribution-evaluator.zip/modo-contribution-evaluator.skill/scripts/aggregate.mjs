#!/usr/bin/env node
// Step 5b — aggregate classified PRs into kpis.json + roll-ups.

import fs from 'node:fs';
import path from 'node:path';

const OUTDIR = process.argv[2];
if (!OUTDIR) {
  console.error('usage: aggregate.mjs <OUTDIR>');
  process.exit(1);
}

const classifiedFile = path.join(OUTDIR, 'prs-classified.jsonl');
const reviewedFile = path.join(OUTDIR, 'prs-reviewed.jsonl');
const detailsFile = path.join(OUTDIR, 'prs-details.jsonl');
const jiraFile = path.join(OUTDIR, 'jira-tickets.jsonl');

const readJSONL = (f) => fs.existsSync(f)
  ? fs.readFileSync(f, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse)
  : [];

const prs = readJSONL(classifiedFile);
const reviews = readJSONL(reviewedFile);
const details = readJSONL(detailsFile);
const jira = readJSONL(jiraFile);

// --- Totals ---
const totals = {
  prs_authored: prs.length,
  prs_merged: prs.filter(p => p.merged).length,
  prs_open: prs.filter(p => p.state === 'open').length,
  prs_closed_not_merged: prs.filter(p => p.state === 'closed' && !p.merged).length,
  prs_draft: prs.filter(p => p.draft).length,
  prs_reviewed: reviews.length,
  jira_tickets: jira.length,
};
totals.merge_rate = totals.prs_authored
  ? Math.round((totals.prs_merged / totals.prs_authored) * 1000) / 10
  : 0;

// --- By repo ---
function groupBy(items, key) {
  const m = new Map();
  for (const it of items) {
    const k = typeof key === 'function' ? key(it) : it[key];
    if (!m.has(k)) m.set(k, []);
    m.get(k).push(it);
  }
  return m;
}

function repoStats(items) {
  return {
    total: items.length,
    merged: items.filter(p => p.merged).length,
    open: items.filter(p => p.state === 'open').length,
    closed: items.filter(p => p.state === 'closed' && !p.merged).length,
    merge_rate: items.length ? Math.round((items.filter(p => p.merged).length / items.length) * 1000) / 10 : 0,
    first: items.reduce((a, p) => !a || p.created < a ? p.created : a, null),
    last: items.reduce((a, p) => !a || p.updated > a ? p.updated : a, null),
  };
}

const by_repo = [...groupBy(prs, 'repo').entries()]
  .map(([repo, items]) => ({ repo, ...repoStats(items), domain: items[0]?.domain }))
  .sort((a, b) => b.total - a.total);

// --- By domain ---
const by_domain = [...groupBy(prs, 'domain').entries()]
  .map(([domain, items]) => ({ domain, ...repoStats(items), repos: new Set(items.map(p => p.repo)).size }))
  .sort((a, b) => b.total - a.total);

// --- By type ---
const by_type = [...groupBy(prs, 'type').entries()]
  .map(([type, items]) => ({ type, count: items.length, merged: items.filter(p => p.merged).length }))
  .sort((a, b) => b.count - a.count);

// --- By quarter ---
const by_quarter = [...groupBy(prs, 'quarter').entries()]
  .map(([quarter, items]) => ({
    quarter,
    total: items.length,
    merged: items.filter(p => p.merged).length,
  }))
  .sort((a, b) => a.quarter.localeCompare(b.quarter));

// --- Lifecycle ---
const lifecycleDays = prs.filter(p => p.lifecycle_days != null).map(p => p.lifecycle_days).sort((a, b) => a - b);
const lifecycle = {
  count: lifecycleDays.length,
  median: lifecycleDays.length ? lifecycleDays[Math.floor(lifecycleDays.length / 2)] : null,
  p95: lifecycleDays.length ? lifecycleDays[Math.floor(lifecycleDays.length * 0.95)] : null,
  max: lifecycleDays.at(-1) ?? null,
};

// --- Stale (open > 30d) ---
const now = Date.now();
const stale_open = prs
  .filter(p => p.state === 'open' && (now - new Date(p.updated).getTime()) > 30 * 24 * 3600 * 1000)
  .map(p => ({ repo: p.repo, number: p.number, title: p.title, url: p.url, updated: p.updated, days_idle: Math.round((now - new Date(p.updated).getTime()) / (24 * 3600 * 1000)) }))
  .sort((a, b) => b.days_idle - a.days_idle);

// --- Jira coverage (% PRs con ticket detectable) ---
const jira_coverage = totals.prs_authored
  ? Math.round((prs.filter(p => p.jira).length / totals.prs_authored) * 1000) / 10
  : 0;

// --- Top PRs by impact (changedFiles desc, from details) ---
const top_prs = details
  .filter(d => d.changedFiles != null)
  .sort((a, b) => (b.changedFiles || 0) - (a.changedFiles || 0))
  .slice(0, 15)
  .map(d => ({
    repo: d.repo,
    number: d.number,
    title: d.title,
    url: d.url,
    additions: d.additions,
    deletions: d.deletions,
    changedFiles: d.changedFiles,
    reviewers: d.reviewers?.length || 0,
    mergedAt: d.mergedAt,
  }));

// --- Jira by status / project ---
const jira_by_status = jira.length
  ? [...groupBy(jira, 'status').entries()].map(([status, items]) => ({ status, count: items.length })).sort((a, b) => b.count - a.count)
  : [];
const jira_by_project = jira.length
  ? [...groupBy(jira, j => j.key.split('-')[0]).entries()].map(([project, items]) => ({ project, count: items.length })).sort((a, b) => b.count - a.count)
  : [];

// --- Output ---
const kpis = {
  generated_at: new Date().toISOString(),
  author_gh: process.env.AUTHOR_GH || 'unknown',
  author_jira: process.env.AUTHOR_JIRA || 'unknown',
  since: process.env.SINCE || null,
  until: process.env.UNTIL || null,
  totals,
  lifecycle,
  jira_coverage,
  by_repo,
  by_domain,
  by_type,
  by_quarter,
  stale_open,
  top_prs,
  jira: {
    by_status: jira_by_status,
    by_project: jira_by_project,
  },
};

const outFile = path.join(OUTDIR, 'kpis.json');
fs.writeFileSync(outFile, JSON.stringify(kpis, null, 2));
console.log(`  kpis → ${outFile}`);
console.log(`    totals: ${totals.prs_authored} authored / ${totals.prs_merged} merged (${totals.merge_rate}%) / ${totals.prs_reviewed} reviewed / ${totals.jira_tickets} Jira`);
