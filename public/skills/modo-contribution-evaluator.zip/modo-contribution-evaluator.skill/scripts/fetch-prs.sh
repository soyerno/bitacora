#!/usr/bin/env bash
# Step 1 — fetch PRs autorados por $AUTHOR_GH cross-org.

set -euo pipefail
export PATH="/opt/homebrew/bin:$PATH"

: "${AUTHOR_GH:?AUTHOR_GH required}"
: "${OUTDIR:?OUTDIR required}"

QUERY="author:${AUTHOR_GH} type:pr"
if [ -n "${SINCE:-}" ] || [ -n "${UNTIL:-}" ]; then
  QUERY="$QUERY created:${SINCE:-*}..${UNTIL:-*}"
fi

OUT="$OUTDIR/prs-authored.jsonl"
: > "$OUT"

gh api -X GET search/issues \
  -f q="$QUERY" \
  -f per_page=100 --paginate \
  --jq '.items[] | {
    repo: (.repository_url | sub("https://api.github.com/repos/"; "")),
    number: .number,
    title: .title,
    state: .state,
    merged: (.pull_request.merged_at != null),
    created: .created_at,
    updated: .updated_at,
    closed: .closed_at,
    url: .html_url,
    labels: ([.labels[].name] // []),
    draft: (.draft // false)
  }' > "$OUT"

COUNT=$(wc -l < "$OUT" | tr -d ' ')
echo "  $COUNT PRs autorados → $OUT"
