#!/usr/bin/env bash
# Step 3 — enrich top-N PRs autorados con diff stats reales (additions/deletions/changedFiles).

set -euo pipefail
export PATH="/opt/homebrew/bin:$PATH"

: "${OUTDIR:?OUTDIR required}"
TOP_N="${TOP_N:-25}"

IN="$OUTDIR/prs-authored.jsonl"
OUT="$OUTDIR/prs-details.jsonl"
: > "$OUT"

if [ ! -s "$IN" ]; then
  echo "  WARN: $IN vacío, skip"
  exit 0
fi

# Top-N por updated_at (DESC). Solo merged/closed para tener diff estable (PRs open siguen cambiando).
TOP_PRS=$(jq -s "sort_by(.updated) | reverse | .[0:$TOP_N] | .[] | \"\(.repo)|\(.number)\"" "$IN" | tr -d '"')

I=0
TOTAL=$(echo "$TOP_PRS" | grep -c . || echo 0)
echo "  enriching $TOTAL PRs (top-$TOP_N by updated)…"

while IFS='|' read -r REPO NUMBER; do
  [ -z "$REPO" ] && continue
  I=$((I+1))
  printf '    [%d/%d] %s#%s\n' "$I" "$TOTAL" "$REPO" "$NUMBER"
  gh pr view "$NUMBER" --repo "$REPO" \
    --json additions,deletions,changedFiles,reviewDecision,mergedAt,reviews,commits,title,url 2>/dev/null \
    | jq -c --arg repo "$REPO" --argjson number "$NUMBER" '{
        repo: $repo,
        number: $number,
        title: .title,
        url: .url,
        additions: .additions,
        deletions: .deletions,
        changedFiles: .changedFiles,
        reviewDecision: .reviewDecision,
        mergedAt: .mergedAt,
        reviewers: ([.reviews[].author.login] | unique),
        commits_count: (.commits | length)
      }' >> "$OUT" 2>/dev/null || echo "    skip $REPO#$NUMBER (acceso o not-found)"
done <<< "$TOP_PRS"

COUNT=$(wc -l < "$OUT" | tr -d ' ')
echo "  $COUNT PRs enriched → $OUT"
