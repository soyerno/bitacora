#!/usr/bin/env bash
# Step 4 — fetch Jira tickets (assignee/reporter = $AUTHOR_JIRA).
# Auth: JIRA_API_TOKEN + JIRA_EMAIL → REST direct. Sin eso → warning + skip.
# El MCP fallback (claude_ai_Atlassian) lo maneja Claude desde el chat, no este script bash.

set -euo pipefail

: "${AUTHOR_JIRA:?AUTHOR_JIRA required}"
: "${OUTDIR:?OUTDIR required}"

OUT="$OUTDIR/jira-tickets.jsonl"
: > "$OUT"

JIRA_BASE="${JIRA_BASE:-https://play-sistemico.atlassian.net}"
JIRA_PROJECTS="${JIRA_PROJECTS:-COENXT,EXA,IE,MFEX}"
JIRA_TOKEN="${JIRA_API_TOKEN:-}"
JIRA_EMAIL="${JIRA_EMAIL:-$AUTHOR_JIRA}"

if [ -z "$JIRA_TOKEN" ]; then
  cat <<EOF
  WARN: JIRA_API_TOKEN no seteado. Skip Step 4.

  Para enrichear con Jira tickets:
    export JIRA_API_TOKEN='<token de https://id.atlassian.com/manage-profile/security/api-tokens>'
    export JIRA_EMAIL='$AUTHOR_JIRA'
    bash $0

  O bien, desde el chat de Claude, pedir al asistente que use el MCP:
    mcp__claude_ai_Atlassian__searchJiraIssuesUsingJql
    cloudId: 17e75179-15ce-48f2-954d-ec6946aca61c
    jql: '(assignee = "$AUTHOR_JIRA" OR reporter = "$AUTHOR_JIRA") AND project in ($JIRA_PROJECTS) ORDER BY updated DESC'
EOF
  exit 0
fi

# JQL
PROJECT_LIST=$(echo "$JIRA_PROJECTS" | sed 's/,/, /g')
JQL="(assignee = \"$AUTHOR_JIRA\" OR reporter = \"$AUTHOR_JIRA\") AND project in ($PROJECT_LIST)"
[ -n "${SINCE:-}" ] && JQL="$JQL AND updated >= \"$SINCE\""
JQL="$JQL ORDER BY updated DESC"

START=0
MAX=100
TOTAL_FETCHED=0

while :; do
  RESP=$(curl -sS -u "$JIRA_EMAIL:$JIRA_TOKEN" \
    -H "Accept: application/json" \
    -G "$JIRA_BASE/rest/api/3/search" \
    --data-urlencode "jql=$JQL" \
    --data-urlencode "startAt=$START" \
    --data-urlencode "maxResults=$MAX" \
    --data-urlencode "fields=summary,status,issuetype,priority,assignee,reporter,created,updated,resolutiondate,labels,components")

  COUNT=$(echo "$RESP" | jq -r '.issues | length // 0')
  if [ "$COUNT" = "0" ] || [ -z "$COUNT" ]; then
    break
  fi

  echo "$RESP" | jq -c '.issues[] | {
    key: .key,
    type: .fields.issuetype.name,
    status: .fields.status.name,
    priority: (.fields.priority.name // "n/a"),
    summary: .fields.summary,
    assignee: (.fields.assignee.emailAddress // .fields.assignee.displayName // "unassigned"),
    reporter: (.fields.reporter.emailAddress // .fields.reporter.displayName // "unknown"),
    created: .fields.created,
    updated: .fields.updated,
    resolved: .fields.resolutiondate,
    labels: .fields.labels,
    components: ([.fields.components[].name] // [])
  }' >> "$OUT"

  TOTAL_FETCHED=$((TOTAL_FETCHED + COUNT))
  START=$((START + MAX))
  [ "$COUNT" -lt "$MAX" ] && break
done

echo "  $TOTAL_FETCHED Jira tickets → $OUT"
