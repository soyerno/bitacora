#!/usr/bin/env node
// Step 6a — render REPORT.md (rioplatense exec summary).

import fs from 'node:fs';
import path from 'node:path';

const OUTDIR = process.argv[2];
if (!OUTDIR) {
  console.error('usage: render-markdown.mjs <OUTDIR>');
  process.exit(1);
}

const kpis = JSON.parse(fs.readFileSync(path.join(OUTDIR, 'kpis.json'), 'utf8'));

const fmtPct = (n) => `${n.toFixed(1)}%`;
const fmtDate = (iso) => iso ? iso.split('T')[0] : '—';
const fmtRange = () => {
  const since = kpis.since ? fmtDate(kpis.since) : (kpis.by_quarter[0]?.quarter ?? '—');
  const until = kpis.until ? fmtDate(kpis.until) : (kpis.by_quarter.at(-1)?.quarter ?? 'hoy');
  return `${since} → ${until}`;
};

const DOMAIN_LABEL = {
  web: 'Web frontends',
  lib: 'Libs / design system',
  bff: 'BFFs / backends',
  mobile: 'Mobile',
  tooling: 'Tooling / skills',
  bitacora: 'Bitácora pública',
  infra: 'Infra / charts',
  other: 'Otros',
};

const lines = [];

lines.push(`# Contribuciones MODO · ${kpis.author_gh}`);
lines.push('');
lines.push(`> Snapshot generado el ${fmtDate(kpis.generated_at)} · rango ${fmtRange()}`);
lines.push('');

// TL;DR
lines.push('## TL;DR');
lines.push('');
lines.push(`Tiré **${kpis.totals.prs_authored} PRs** en el ecosistema MODO. Mergueé **${kpis.totals.prs_merged}** (${fmtPct(kpis.totals.merge_rate)}), tengo ${kpis.totals.prs_open} abiertos y descarté ${kpis.totals.prs_closed_not_merged}. Además revisé **${kpis.totals.prs_reviewed} PRs** de otros.`);
lines.push('');
if (kpis.totals.jira_tickets > 0) {
  lines.push(`En Jira moví **${kpis.totals.jira_tickets} tickets** (assignee o reporter). Cobertura PR↔Jira: ${fmtPct(kpis.jira_coverage)} de los PRs tienen ticket detectable en el title.`);
} else {
  lines.push(`Cobertura PR↔Jira: ${fmtPct(kpis.jira_coverage)} de los PRs tienen ticket detectable en el title. (Jira no fetcheado: faltan creds.)`);
}
lines.push('');

if (kpis.lifecycle.count > 0) {
  lines.push(`Lifecycle: mediana ${kpis.lifecycle.median}d open→merged · p95 ${kpis.lifecycle.p95}d · máx ${kpis.lifecycle.max}d.`);
  lines.push('');
}

// Dominios
lines.push('## Dónde aporté');
lines.push('');
lines.push('| Dominio | PRs | Merged | Merge rate | Repos |');
lines.push('|---|---:|---:|---:|---:|');
for (const d of kpis.by_domain) {
  lines.push(`| ${DOMAIN_LABEL[d.domain] || d.domain} | ${d.total} | ${d.merged} | ${fmtPct(d.merge_rate)} | ${d.repos} |`);
}
lines.push('');

// Por repo (top 10)
lines.push('## Top 10 repos por volumen');
lines.push('');
lines.push('| Repo | PRs | Merged | Open | Merge rate | Primer PR | Último PR |');
lines.push('|---|---:|---:|---:|---:|---|---|');
for (const r of kpis.by_repo.slice(0, 10)) {
  lines.push(`| \`${r.repo}\` | ${r.total} | ${r.merged} | ${r.open} | ${fmtPct(r.merge_rate)} | ${fmtDate(r.first)} | ${fmtDate(r.last)} |`);
}
if (kpis.by_repo.length > 10) {
  const tailTotal = kpis.by_repo.slice(10).reduce((a, r) => a + r.total, 0);
  lines.push(`| _(${kpis.by_repo.length - 10} repos más)_ | ${tailTotal} | — | — | — | — | — |`);
}
lines.push('');

// Por tipo
lines.push('## Distribución por tipo (conventional commits)');
lines.push('');
lines.push('| Tipo | Count | Merged |');
lines.push('|---|---:|---:|');
for (const t of kpis.by_type) {
  lines.push(`| ${t.type} | ${t.count} | ${t.merged} |`);
}
lines.push('');

// Throughput por quarter
lines.push('## Throughput por quarter');
lines.push('');
lines.push('| Quarter | PRs | Merged |');
lines.push('|---|---:|---:|');
for (const q of kpis.by_quarter) {
  lines.push(`| ${q.quarter} | ${q.total} | ${q.merged} |`);
}
lines.push('');

// Top PRs by impact
if (kpis.top_prs.length > 0) {
  lines.push('## Top PRs por impacto (changedFiles)');
  lines.push('');
  lines.push('| PR | Título | Files | +/- | Reviewers |');
  lines.push('|---|---|---:|---:|---:|');
  for (const p of kpis.top_prs) {
    const title = (p.title || '').replace(/\|/g, '\\|').slice(0, 80);
    lines.push(`| [\`${p.repo}#${p.number}\`](${p.url}) | ${title} | ${p.changedFiles} | +${p.additions}/-${p.deletions} | ${p.reviewers} |`);
  }
  lines.push('');
}

// Stale
if (kpis.stale_open.length > 0) {
  lines.push('## Pendientes (open >30d sin actividad)');
  lines.push('');
  lines.push('| PR | Título | Días idle |');
  lines.push('|---|---|---:|');
  for (const s of kpis.stale_open.slice(0, 20)) {
    const title = (s.title || '').replace(/\|/g, '\\|').slice(0, 80);
    lines.push(`| [\`${s.repo}#${s.number}\`](${s.url}) | ${title} | ${s.days_idle} |`);
  }
  if (kpis.stale_open.length > 20) {
    lines.push(`| _(${kpis.stale_open.length - 20} más)_ | — | — |`);
  }
  lines.push('');
}

// Jira
if (kpis.jira.by_project.length > 0) {
  lines.push('## Jira tickets');
  lines.push('');
  lines.push('**Por proyecto:**');
  for (const p of kpis.jira.by_project) {
    lines.push(`- ${p.project}: ${p.count}`);
  }
  lines.push('');
  lines.push('**Por status:**');
  for (const s of kpis.jira.by_status) {
    lines.push(`- ${s.status}: ${s.count}`);
  }
  lines.push('');
}

// Footer
lines.push('---');
lines.push('');
lines.push('## Método');
lines.push('');
lines.push(`- **Fuente PRs**: GitHub Search API (\`search/issues author:${kpis.author_gh} type:pr\`).`);
lines.push(`- **Fuente reviews**: \`reviewed-by:${kpis.author_gh} -author:${kpis.author_gh}\`.`);
lines.push(`- **Enrich**: \`gh pr view --json additions,deletions,changedFiles,reviews\` para top-${kpis.top_prs.length} PRs.`);
lines.push(`- **Jira**: ${kpis.totals.jira_tickets > 0 ? `REST API JQL en proyectos ${(kpis.jira.by_project.map(p => p.project).join(', '))}` : 'no fetcheado (faltan creds)'}.`);
lines.push(`- **Rango**: ${fmtRange()}.`);
lines.push(`- **Cierre**: ${fmtDate(kpis.generated_at)}.`);
lines.push('');
lines.push('Limitaciones — el title parser de Jira ticket asume formato `type(SCOPE-N): ...`. PRs sin scope o con scope no-Jira no aportan a cobertura. Velocidad y throughput asumen stack Claude Code + skills MODO.');
lines.push('');

const outFile = path.join(OUTDIR, 'REPORT.md');
fs.writeFileSync(outFile, lines.join('\n'));
console.log(`  REPORT.md → ${outFile}`);
