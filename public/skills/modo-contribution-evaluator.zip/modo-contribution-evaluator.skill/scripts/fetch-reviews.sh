#!/usr/bin/env bash
# Step 2 — fetch PRs revisados por $AUTHOR_GH (excluyendo los propios).

set -euo pipefail
export PATH="/opt/homebrew/bin:$PATH"

: "${AUTHOR_GH:?AUTHOR_GH required}"
: "${OUTDIR:?OUTDIR required}"

QUERY="reviewed-by:${AUTHOR_GH} -author:${AUTHOR_GH} type:pr"
if [ -n "${SINCE:-}" ] || [ -n "${UNTIL:-}" ]; then
  QUERY="$QUERY created:${SINCE:-*}..${UNTIL:-*}"
fi

OUT="$OUTDIR/prs-reviewed.jsonl"
: > "$OUT"

gh api -X GET search/issues \
  -f q="$QUERY" \
  -f per_page=100 --paginate \
  --jq '.items[] | {
    repo: (.repository_url | sub("https://api.github.com/repos/"; "")),
    number: .number,
    title: .title,
    state: .state,
    merged: (.pull_request.merged_at != null),
    created: .created_at,
    updated: .updated_at,
    url: .html_url,
    author: .user.login
  }' > "$OUT" 2>/dev/null || true

COUNT=$(wc -l < "$OUT" | tr -d ' ')
echo "  $COUNT PRs revisados → $OUT"
