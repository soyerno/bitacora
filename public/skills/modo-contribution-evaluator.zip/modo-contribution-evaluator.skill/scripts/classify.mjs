#!/usr/bin/env node
// Step 5a — classify PRs by type (conventional commit prefix), Jira ticket, and MODO domain.
// Reads:  $OUTDIR/prs-authored.jsonl
// Writes: $OUTDIR/prs-classified.jsonl

import fs from 'node:fs';
import path from 'node:path';

const OUTDIR = process.argv[2];
if (!OUTDIR) {
  console.error('usage: classify.mjs <OUTDIR>');
  process.exit(1);
}

const TYPE_RE = /^(feat|fix|refactor|chore|docs|test|ci|perf|style|build|merge|revert|hotfix)(\(([^)]+)\))?!?:\s*/i;
const JIRA_RE = /\b([A-Z]{2,}-\d{1,6})\b/;

// repo → domain. Tail catches via regex heuristic.
const DOMAIN_MAP = {
  // bitácora
  'SoyErnoModo/erno-modo': 'bitacora',
  'SoyErnoModo/modo-dev-framework': 'bitacora',
  // web frontends
  'playsistemico/modo-landing': 'web',
  'playsistemico/promos-hub-site': 'web',
  'playsistemico/benefits-personalization-portal-site': 'web',
  'playsistemico/hackathon-2025-benefits-analyzer-portal': 'web',
  'playsistemico/selector-pcp-site': 'web',
  'playsistemico/banks-admin-site': 'web',
  'playsistemico/developers-portal-site': 'web',
  // libs / design system
  'playsistemico/modo-ui-lib-web': 'lib',
  'playsistemico/modo-landing-sdk-ui-lib': 'lib',
  'playsistemico/modo-landing-web-ui-lib': 'lib',
  'playsistemico/stores-maps-lib': 'lib',
  // BFFs / backends
  'playsistemico/stores-bff': 'bff',
  'playsistemico/promos-bff': 'bff',
  // mobile
  'playsistemico/modo-android': 'mobile',
  'playsistemico/modo-ios': 'mobile',
  // tooling
  'playsistemico/modo-checkout-skill': 'tooling',
  'playsistemico/tofu-comercios': 'tooling',
  'playsistemico/aprendeatumodo': 'web',
};

function inferDomain(repo) {
  if (DOMAIN_MAP[repo]) return DOMAIN_MAP[repo];
  const lower = repo.toLowerCase();
  if (/\b(bff|api|backend|service|svc)\b/.test(lower)) return 'bff';
  if (/\b(lib|sdk|ui-lib|design-system|components)\b/.test(lower)) return 'lib';
  if (/\b(site|landing|portal|admin|web|app)\b/.test(lower)) return 'web';
  if (/\b(android|ios|mobile|react-native)\b/.test(lower)) return 'mobile';
  if (/\b(infra|terraform|helm|k8s|chart|deploy)\b/.test(lower)) return 'infra';
  if (/\b(skill|cli|tool|script)\b/.test(lower)) return 'tooling';
  return 'other';
}

function classifyOne(pr) {
  const title = pr.title || '';
  const typeMatch = title.match(TYPE_RE);
  const type = typeMatch ? typeMatch[1].toLowerCase() : 'untyped';
  const scope = typeMatch && typeMatch[3] ? typeMatch[3] : null;
  const jiraMatch = title.match(JIRA_RE);
  const jira = jiraMatch ? jiraMatch[1] : (scope && JIRA_RE.test(scope) ? scope.match(JIRA_RE)[1] : null);
  const domain = inferDomain(pr.repo);

  // lifecycle days
  let lifecycle_days = null;
  if (pr.merged && pr.closed) {
    const created = new Date(pr.created).getTime();
    const closed = new Date(pr.closed).getTime();
    lifecycle_days = Math.round((closed - created) / (1000 * 60 * 60 * 24) * 10) / 10;
  }

  // quarter (YYYY-QN by created)
  const d = new Date(pr.created);
  const quarter = `${d.getUTCFullYear()}-Q${Math.floor(d.getUTCMonth() / 3) + 1}`;

  return { ...pr, type, scope, jira, domain, lifecycle_days, quarter };
}

const inFile = path.join(OUTDIR, 'prs-authored.jsonl');
const outFile = path.join(OUTDIR, 'prs-classified.jsonl');

if (!fs.existsSync(inFile)) {
  console.error(`  ERR: ${inFile} no existe. Corré fetch-prs.sh primero.`);
  process.exit(1);
}

const lines = fs.readFileSync(inFile, 'utf8').trim().split('\n').filter(Boolean);
const out = lines.map(l => JSON.stringify(classifyOne(JSON.parse(l)))).join('\n') + '\n';
fs.writeFileSync(outFile, out);

console.log(`  classified ${lines.length} PRs → ${outFile}`);
