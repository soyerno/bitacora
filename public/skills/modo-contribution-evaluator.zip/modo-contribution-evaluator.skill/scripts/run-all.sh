#!/usr/bin/env bash
# modo-contribution-evaluator · orchestrator
# Runs all 6 steps end-to-end. Idempotent. Re-running overwrites prior output.

set -euo pipefail
export PATH="/opt/homebrew/bin:$PATH"

# --- Inputs (override via env) ---
AUTHOR_GH="${AUTHOR_GH:-SoyErnoModo}"
AUTHOR_JIRA="${AUTHOR_JIRA:-hernan.desouza@modo.com.ar}"
SINCE="${SINCE:-}"
UNTIL="${UNTIL:-}"
TOP_N="${TOP_N:-25}"
OUTDIR="${OUTDIR:-$HOME/Documents/Reports/contributions-${AUTHOR_GH}-$(date +%F)}"

export AUTHOR_GH AUTHOR_JIRA SINCE UNTIL TOP_N OUTDIR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$OUTDIR"
echo "==> output: $OUTDIR"
echo "==> author_gh: $AUTHOR_GH | author_jira: $AUTHOR_JIRA | since: ${SINCE:-all} | until: ${UNTIL:-now}"

echo "==> [1/6] fetch PRs autorados…"
bash "$SCRIPT_DIR/fetch-prs.sh"

echo "==> [2/6] fetch PRs revisados…"
bash "$SCRIPT_DIR/fetch-reviews.sh"

echo "==> [3/6] enrich top-$TOP_N PRs con diff stats…"
bash "$SCRIPT_DIR/fetch-pr-details.sh"

echo "==> [4/6] fetch Jira tickets (best effort)…"
bash "$SCRIPT_DIR/fetch-jira.sh" || echo "WARN: Jira step falló, sigo con PRs solamente."

echo "==> [5/6] classify + aggregate…"
node "$SCRIPT_DIR/classify.mjs" "$OUTDIR"
node "$SCRIPT_DIR/aggregate.mjs" "$OUTDIR"

echo "==> [6/6] render markdown + html…"
node "$SCRIPT_DIR/render-markdown.mjs" "$OUTDIR"
node "$SCRIPT_DIR/render-html.mjs" "$OUTDIR"

echo ""
echo "✓ DONE — output:"
echo "  $OUTDIR/REPORT.md"
echo "  $OUTDIR/report.html"
echo "  $OUTDIR/kpis.json"
