#!/usr/bin/env node
// Step 6b — render report.html (branded MODO, Chart.js, R&D style).

import fs from 'node:fs';
import path from 'node:path';

const OUTDIR = process.argv[2];
if (!OUTDIR) {
  console.error('usage: render-html.mjs <OUTDIR>');
  process.exit(1);
}

const kpis = JSON.parse(fs.readFileSync(path.join(OUTDIR, 'kpis.json'), 'utf8'));

const DOMAIN_LABEL = {
  web: 'Web frontends',
  lib: 'Libs / DS',
  bff: 'BFFs',
  mobile: 'Mobile',
  tooling: 'Tooling',
  bitacora: 'Bitácora',
  infra: 'Infra',
  other: 'Otros',
};

const fmtPct = (n) => `${n.toFixed(1)}%`;
const fmtDate = (iso) => iso ? iso.split('T')[0] : '—';
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const rangeLabel = (() => {
  const since = kpis.since ? fmtDate(kpis.since) : (kpis.by_quarter[0]?.quarter ?? '—');
  const until = kpis.until ? fmtDate(kpis.until) : (kpis.by_quarter.at(-1)?.quarter ?? 'hoy');
  return `${since} → ${until}`;
})();

const topPrsRows = kpis.top_prs.map(p => `
  <tr>
    <td><a href="${esc(p.url)}" target="_blank" rel="noopener"><code>${esc(p.repo)}#${p.number}</code></a></td>
    <td>${esc(p.title)}</td>
    <td class="num">${p.changedFiles}</td>
    <td class="num">+${p.additions}/-${p.deletions}</td>
    <td class="num">${p.reviewers}</td>
  </tr>
`).join('');

const repoRows = kpis.by_repo.slice(0, 15).map(r => `
  <tr>
    <td><code>${esc(r.repo)}</code></td>
    <td><span class="chip chip-${r.domain}">${DOMAIN_LABEL[r.domain] || r.domain}</span></td>
    <td class="num">${r.total}</td>
    <td class="num">${r.merged}</td>
    <td class="num">${r.open}</td>
    <td class="num">${fmtPct(r.merge_rate)}</td>
  </tr>
`).join('');

const staleRows = kpis.stale_open.slice(0, 10).map(s => `
  <tr>
    <td><a href="${esc(s.url)}" target="_blank" rel="noopener"><code>${esc(s.repo)}#${s.number}</code></a></td>
    <td>${esc(s.title)}</td>
    <td class="num">${s.days_idle}d</td>
  </tr>
`).join('');

const quarters = kpis.by_quarter.map(q => q.quarter);
const quarterAuthored = kpis.by_quarter.map(q => q.total);
const quarterMerged = kpis.by_quarter.map(q => q.merged);

const domainLabels = kpis.by_domain.map(d => DOMAIN_LABEL[d.domain] || d.domain);
const domainValues = kpis.by_domain.map(d => d.total);

const typeLabels = kpis.by_type.map(t => t.type);
const typeValues = kpis.by_type.map(t => t.count);

const html = `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contribuciones MODO · ${esc(kpis.author_gh)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:wght@400;500;700;900&family=Quicksand:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root {
  --modo: #008859;
  --modo-dark: #005a3b;
  --modo-light: #b8e6cd;
  --ink: #0f1419;
  --ink-2: #4a5560;
  --muted: #7a8590;
  --bg: #ffffff;
  --bg-2: #f7faf8;
  --border: #e3e8e5;
  --warn: #c44d2b;
  --good: #008859;
  --info: #2563a3;
}
* { box-sizing: border-box; }
body {
  font-family: 'Red Hat Display', system-ui, sans-serif;
  background: var(--bg);
  color: var(--ink);
  margin: 0;
  line-height: 1.55;
}
.container {
  max-width: 1080px;
  margin: 0 auto;
  padding: 48px 32px 96px;
}
header {
  border-bottom: 4px solid var(--modo);
  padding-bottom: 24px;
  margin-bottom: 32px;
}
header .eyebrow {
  font-family: 'Quicksand', sans-serif;
  font-weight: 700;
  font-size: 13px;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--modo);
  margin: 0 0 8px;
}
header h1 {
  font-family: 'Quicksand', sans-serif;
  font-weight: 700;
  font-size: 40px;
  line-height: 1.1;
  margin: 0 0 12px;
  letter-spacing: -0.02em;
}
header .meta {
  color: var(--ink-2);
  font-size: 14px;
}
header .meta strong { color: var(--ink); }

h2 {
  font-family: 'Quicksand', sans-serif;
  font-weight: 700;
  font-size: 24px;
  margin: 56px 0 16px;
  letter-spacing: -0.01em;
}
h2::before {
  content: '';
  display: inline-block;
  width: 4px;
  height: 20px;
  background: var(--modo);
  margin-right: 12px;
  vertical-align: -2px;
  border-radius: 2px;
}
h3 {
  font-family: 'Quicksand', sans-serif;
  font-weight: 600;
  font-size: 16px;
  margin: 24px 0 8px;
}

.tldr {
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-left: 4px solid var(--modo);
  padding: 24px 28px;
  border-radius: 8px;
  margin-bottom: 32px;
}
.tldr p { margin: 0 0 8px; font-size: 16px; }
.tldr p:last-child { margin: 0; }

.kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 16px;
  margin: 24px 0;
}
.kpi {
  background: var(--bg-2);
  border: 1px solid var(--border);
  padding: 20px;
  border-radius: 8px;
  text-align: left;
}
.kpi .label {
  font-family: 'Quicksand', sans-serif;
  font-weight: 600;
  font-size: 12px;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--muted);
  margin-bottom: 8px;
}
.kpi .value {
  font-family: 'Quicksand', sans-serif;
  font-weight: 700;
  font-size: 32px;
  line-height: 1;
  color: var(--ink);
  letter-spacing: -0.02em;
}
.kpi .delta {
  font-size: 12px;
  color: var(--ink-2);
  margin-top: 6px;
}

.chart-wrap {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 24px;
  margin: 16px 0 24px;
}
.chart-wrap canvas { max-height: 320px; }

.chart-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
@media (max-width: 720px) {
  .chart-grid { grid-template-columns: 1fr; }
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 12px 0 24px;
  font-size: 14px;
}
thead th {
  font-family: 'Quicksand', sans-serif;
  font-weight: 600;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--muted);
  text-align: left;
  padding: 12px 12px;
  border-bottom: 2px solid var(--border);
}
tbody td {
  padding: 12px 12px;
  border-bottom: 1px solid var(--border);
  vertical-align: top;
}
tbody tr:hover { background: var(--bg-2); }
.num { text-align: right; font-variant-numeric: tabular-nums; }
code, .mono {
  font-family: 'JetBrains Mono', monospace;
  font-size: 12.5px;
  background: var(--bg-2);
  padding: 2px 6px;
  border-radius: 3px;
}
a { color: var(--modo-dark); text-decoration: none; }
a:hover { text-decoration: underline; }

.chip {
  display: inline-block;
  font-family: 'Quicksand', sans-serif;
  font-weight: 600;
  font-size: 11px;
  padding: 3px 10px;
  border-radius: 999px;
  background: #eef2ee;
  color: var(--ink-2);
}
.chip-web { background: #d8f0e3; color: var(--modo-dark); }
.chip-lib { background: #fde7c4; color: #8a5a17; }
.chip-bff { background: #cee1f5; color: #1a4778; }
.chip-mobile { background: #f2d9e8; color: #883460; }
.chip-tooling { background: #e2d9f2; color: #463078; }
.chip-bitacora { background: #fff2c4; color: #7c5e10; }
.chip-infra { background: #d9ebf2; color: #155a78; }
.chip-other { background: #e3e8e5; color: var(--ink-2); }

footer {
  margin-top: 64px;
  padding-top: 24px;
  border-top: 1px solid var(--border);
  font-size: 13px;
  color: var(--ink-2);
  line-height: 1.6;
}
footer strong { color: var(--ink); }
</style>
</head>
<body>
<div class="container">

<header>
  <p class="eyebrow">Contribuciones MODO</p>
  <h1>${esc(kpis.author_gh)}</h1>
  <p class="meta">
    Snapshot generado el <strong>${fmtDate(kpis.generated_at)}</strong> · rango <strong>${esc(rangeLabel)}</strong>
  </p>
</header>

<section class="tldr">
  <p>Tiré <strong>${kpis.totals.prs_authored} PRs</strong> en el ecosistema MODO. Mergueé <strong>${kpis.totals.prs_merged}</strong> (${fmtPct(kpis.totals.merge_rate)}), tengo ${kpis.totals.prs_open} abiertos y descarté ${kpis.totals.prs_closed_not_merged}.</p>
  <p>Además revisé <strong>${kpis.totals.prs_reviewed} PRs</strong> de otros. ${kpis.totals.jira_tickets > 0 ? `Moví <strong>${kpis.totals.jira_tickets} tickets</strong> en Jira.` : ''} Cobertura PR↔Jira: <strong>${fmtPct(kpis.jira_coverage)}</strong>.</p>
  ${kpis.lifecycle.count > 0 ? `<p>Lifecycle de mis PRs merged: mediana <strong>${kpis.lifecycle.median}d</strong> · p95 <strong>${kpis.lifecycle.p95}d</strong>.</p>` : ''}
</section>

<section class="kpi-grid">
  <div class="kpi"><div class="label">PRs autorados</div><div class="value">${kpis.totals.prs_authored}</div></div>
  <div class="kpi"><div class="label">Merged</div><div class="value">${kpis.totals.prs_merged}</div><div class="delta">${fmtPct(kpis.totals.merge_rate)} merge rate</div></div>
  <div class="kpi"><div class="label">PRs revisados</div><div class="value">${kpis.totals.prs_reviewed}</div></div>
  <div class="kpi"><div class="label">Repos tocados</div><div class="value">${kpis.by_repo.length}</div></div>
  <div class="kpi"><div class="label">Dominios</div><div class="value">${kpis.by_domain.length}</div></div>
  ${kpis.totals.jira_tickets > 0 ? `<div class="kpi"><div class="label">Jira tickets</div><div class="value">${kpis.totals.jira_tickets}</div></div>` : ''}
</section>

<h2>Throughput por quarter</h2>
<div class="chart-wrap"><canvas id="quarterChart"></canvas></div>

<h2>Dónde aporté</h2>
<div class="chart-grid">
  <div class="chart-wrap"><canvas id="domainChart"></canvas></div>
  <div class="chart-wrap"><canvas id="typeChart"></canvas></div>
</div>

<h2>Top 15 repos por volumen</h2>
<table>
  <thead><tr><th>Repo</th><th>Dominio</th><th class="num">PRs</th><th class="num">Merged</th><th class="num">Open</th><th class="num">Merge rate</th></tr></thead>
  <tbody>${repoRows}</tbody>
</table>

${kpis.top_prs.length > 0 ? `
<h2>Top PRs por impacto (changedFiles)</h2>
<table>
  <thead><tr><th>PR</th><th>Título</th><th class="num">Files</th><th class="num">+/-</th><th class="num">Reviewers</th></tr></thead>
  <tbody>${topPrsRows}</tbody>
</table>
` : ''}

${kpis.stale_open.length > 0 ? `
<h2>Pendientes (open &gt;30d sin actividad)</h2>
<table>
  <thead><tr><th>PR</th><th>Título</th><th class="num">Días idle</th></tr></thead>
  <tbody>${staleRows}</tbody>
</table>
` : ''}

<footer>
  <p><strong>Método</strong> — Fuente PRs: GitHub Search API (<code>author:${esc(kpis.author_gh)} type:pr</code>). Reviews: <code>reviewed-by:${esc(kpis.author_gh)} -author:${esc(kpis.author_gh)}</code>. Top-${kpis.top_prs.length} PRs enrichados con <code>gh pr view --json additions,deletions,changedFiles,reviews</code>. ${kpis.totals.jira_tickets > 0 ? `Jira: REST JQL en proyectos ${esc(kpis.jira.by_project.map(p => p.project).join(', '))}.` : 'Jira no fetcheado (faltan creds).'}</p>
  <p><strong>Rango</strong> — ${esc(rangeLabel)} · cierre ${fmtDate(kpis.generated_at)}.</p>
  <p><strong>Limitaciones</strong> — El parser de Jira ticket asume el formato <code>type(SCOPE-N): subject</code>. PRs sin ese formato no cuentan en cobertura. Velocidad y throughput asumen stack Claude Code + skills MODO.</p>
</footer>

</div>

<script>
const MODO = '#008859';
const MODO_DARK = '#005a3b';
const PALETTE = ['#008859', '#fab432', '#2563a3', '#c44d2b', '#7a4ed3', '#117ba9', '#996913', '#a8327a'];

Chart.defaults.font.family = "'Red Hat Display', system-ui, sans-serif";
Chart.defaults.color = '#4a5560';

new Chart(document.getElementById('quarterChart'), {
  type: 'bar',
  data: {
    labels: ${JSON.stringify(quarters)},
    datasets: [
      { label: 'Autorados', data: ${JSON.stringify(quarterAuthored)}, backgroundColor: '#b8e6cd', borderRadius: 4 },
      { label: 'Merged', data: ${JSON.stringify(quarterMerged)}, backgroundColor: MODO, borderRadius: 4 }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: 'top' } },
    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
  }
});

new Chart(document.getElementById('domainChart'), {
  type: 'doughnut',
  data: {
    labels: ${JSON.stringify(domainLabels)},
    datasets: [{ data: ${JSON.stringify(domainValues)}, backgroundColor: PALETTE }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'right' },
      title: { display: true, text: 'Por dominio', font: { family: 'Quicksand', size: 14, weight: '600' } }
    }
  }
});

new Chart(document.getElementById('typeChart'), {
  type: 'bar',
  data: {
    labels: ${JSON.stringify(typeLabels)},
    datasets: [{ data: ${JSON.stringify(typeValues)}, backgroundColor: MODO, borderRadius: 4 }]
  },
  options: {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      title: { display: true, text: 'Por tipo (conventional commits)', font: { family: 'Quicksand', size: 14, weight: '600' } }
    },
    scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }
  }
});
</script>

</body>
</html>
`;

const outFile = path.join(OUTDIR, 'report.html');
fs.writeFileSync(outFile, html);
console.log(`  report.html → ${outFile}`);
