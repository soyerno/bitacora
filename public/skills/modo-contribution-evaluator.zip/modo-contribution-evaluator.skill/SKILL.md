---
name: modo-contribution-evaluator
description: Evaluar contribuciones de Hernán (o cualquier dev) en el ecosistema MODO cruzando GitHub PRs (autor + reviewer) + Jira tickets (assignee + reporter) + repos del workspace. Produce inventario raw (JSONL/JSON), métricas (volumen, lifecycle, merge rate, throughput por quarter, dominios), narrative ejecutivo (MD) y reporte HTML branded MODO estilo R&D. Auto-invocable cuando el usuario dice (ES/EN) "evaluá mis contribuciones", "armá un reporte de impacto", "qué hice en MODO", "audit de actividad", "snapshot de contribuciones", "perf review packet", "review 1:1 para X", "/modo-contribution-evaluator", "/eval-contribuciones". Output canónico en `~/Documents/Reports/contributions-<author>-<YYYY-MM-DD>/`.
---

# MODO Contribution Evaluator Skill

Skill para producir un evaluador de contribuciones MODO-completo que cruza:
- PRs autorados en GitHub cross-org (`gh api search/issues author:<login>`).
- PRs revisados (`reviewed-by:<login>`) — participación en code review.
- Jira tickets asignados/reportados en proyectos MODO (COENXT, EXA, IE, etc).
- Enrichment con stats reales del diff (additions/deletions/files) para top PRs.
- Repos del workspace local (mapeo a dominios: web / lib / BFF / tooling / bitácora).

Output siempre en `~/Documents/Reports/contributions-<author>-<YYYY-MM-DD>/`. No toca repos MODO.

## Cuándo se invoca

- El user pide evaluar/auditar sus contribuciones o las de otro dev.
- Perf review interno · 1:1 · snapshot para PM/TL/Manager · postmortem de quarter.
- Necesita material para un deck "qué hice este trimestre" sin armarlo a mano.
- El user pregunta "¿cuántos PRs merguié?", "¿qué proyectos toqué?", "¿en qué área aporté más?".
- Auto-trigger: frase "evaluá mis contribuciones", "audit de actividad", "perf review packet".

## Proceso (7 pasos)

### Step 0 — Inputs

Parámetros (con defaults):

```bash
AUTHOR_GH="${AUTHOR_GH:-SoyErnoModo}"           # GitHub login
AUTHOR_JIRA="${AUTHOR_JIRA:-hernan.desouza@modo.com.ar}"  # Jira accountId/email
SINCE="${SINCE:-}"                              # ISO date, vacío = todo el historial
UNTIL="${UNTIL:-}"                              # ISO date
TOP_N="${TOP_N:-25}"                            # cuantos PRs enriquecer con diff stats
OUTDIR="${OUTDIR:-$HOME/Documents/Reports/contributions-${AUTHOR_GH}-$(date +%F)}"
```

Crear `OUTDIR` (`mkdir -p`).

### Step 1 — Fetch PRs autorados

```bash
~/.claude/skills/modo-contribution-evaluator/scripts/fetch-prs.sh
```

Patrón canónico (ver [[reference-gh-pr-inventory-pattern]]):

```bash
gh api -X GET search/issues \
  -f q="author:${AUTHOR_GH} type:pr${SINCE:+ created:>=$SINCE}${UNTIL:+ created:<=$UNTIL}" \
  -f per_page=100 --paginate \
  --jq '.items[] | {repo: (.repository_url | sub("https://api.github.com/repos/"; "")),
                    number: .number,
                    title: .title,
                    state: .state,
                    merged: (.pull_request.merged_at != null),
                    created: .created_at,
                    updated: .updated_at,
                    closed: .closed_at,
                    url: .html_url,
                    labels: [.labels[].name]}' > "$OUTDIR/prs-authored.jsonl"
```

**Gotcha PATH**: `gh` vive en `/opt/homebrew/bin/gh` y el shell del agente NO lo tiene en PATH por default. El script prependea `export PATH="/opt/homebrew/bin:$PATH"`.

### Step 2 — Fetch PRs revisados (participación)

```bash
~/.claude/skills/modo-contribution-evaluator/scripts/fetch-reviews.sh
```

```bash
gh api -X GET search/issues \
  -f q="reviewed-by:${AUTHOR_GH} -author:${AUTHOR_GH} type:pr" \
  -f per_page=100 --paginate \
  --jq '.items[] | {repo: (.repository_url | sub("https://api.github.com/repos/"; "")),
                    number: .number, title: .title, state: .state,
                    merged: (.pull_request.merged_at != null),
                    created: .created_at, url: .html_url}' > "$OUTDIR/prs-reviewed.jsonl"
```

`-author:X` excluye los propios PRs (un PR donde sos autor Y reviewer ya cuenta como authored).

### Step 3 — Enrich top-N PRs con stats reales

```bash
~/.claude/skills/modo-contribution-evaluator/scripts/fetch-pr-details.sh
```

Toma los TOP_N PRs por updated_at del JSONL y por cada uno corre:

```bash
gh pr view "$NUMBER" --repo "$REPO" --json additions,deletions,changedFiles,reviewDecision,mergedAt,reviews,commits \
  | jq '{repo: "'$REPO'", number: '$NUMBER', additions, deletions, changedFiles, reviewDecision, mergedAt,
         reviewers: ([.reviews[].author.login] | unique),
         commits_count: (.commits | length)}' >> "$OUTDIR/prs-details.jsonl"
```

Rate-limit: TOP_N=25 = 25 calls. Para TOP_N>200 usar `gh api graphql` batch (un solo round-trip).

### Step 4 — Fetch Jira tickets

```bash
~/.claude/skills/modo-contribution-evaluator/scripts/fetch-jira.sh
```

Dual-auth: API token primero, fallback al MCP `mcp__claude_ai_Atlassian__searchJiraIssuesUsingJql` (cloudId `17e75179-15ce-48f2-954d-ec6946aca61c`, ver [[reference-atlassian-cloudid-modo]]).

JQL canónico:

```jql
(assignee = currentUser() OR reporter = currentUser())
  AND project in (COENXT, EXA, IE, MFEX)
  ${SINCE:+AND updated >= "$SINCE"}
  ORDER BY updated DESC
```

Si no hay credenciales, el script imprime un warning y sigue (PRs solos ya son útiles). Mismo patrón que `modo-jsm-ticket`.

### Step 5 — Classify + aggregate

```bash
node ~/.claude/skills/modo-contribution-evaluator/scripts/classify.mjs "$OUTDIR"
node ~/.claude/skills/modo-contribution-evaluator/scripts/aggregate.mjs "$OUTDIR"
```

`classify.mjs` agrega 3 dimensiones a cada PR:
1. **type** — parsea conventional commit prefix del title (`feat|fix|refactor|chore|docs|test|ci|perf|style|build|merge|revert`).
2. **jira** — extrae ticket del title (regex `\b([A-Z]+-\d+)\b`).
3. **domain** — bucket repo → `web` / `lib` / `bff` / `tooling` / `bitacora` / `infra` / `mobile` / `other` (ver `reference/taxonomy.md`).

`aggregate.mjs` produce `kpis.json` con:
- totals (PRs, merged, open, closed, merge_rate)
- by_repo (top 10 + tail)
- by_domain (counts + merge_rate)
- by_type (feat/fix/refactor/etc)
- by_quarter (throughput temporal)
- lifecycle (median + p95 days open→merged)
- review_participation (reviews dadas vs PRs propios)
- jira_coverage (% de PRs con ticket detectable)
- top_prs (TOP_N enriquecidos, ordenados por changedFiles)

### Step 6 — Render

```bash
node ~/.claude/skills/modo-contribution-evaluator/scripts/render-markdown.mjs "$OUTDIR"
node ~/.claude/skills/modo-contribution-evaluator/scripts/render-html.mjs "$OUTDIR"
```

**Markdown** (`$OUTDIR/REPORT.md`) — exec summary rioplatense:
- TL;DR con números clave
- Dominios donde aporté más
- Top 10 PRs por impacto (changedFiles)
- Distribución por tipo (feat/fix/refactor)
- Pendientes (PRs open >30d sin merge)
- Jira coverage

**HTML** (`$OUTDIR/report.html`) — branded MODO estilo R&D (reutiliza `~/Documents/Proyectos/modo/erno-modo/rd/research-article.css` si existe, sino inline minimal styles + Chart.js):
- TL;DR + TOC + cards de KPIs
- Chart.js: throughput por quarter (line), distribución por dominio (donut), tipo (bar)
- Tabla de top PRs con link a GitHub
- Footer con disclaimer de método (rango temporal, fuente, fecha de corte)

Ver [[reference-modo-research-article-skill]] para estilos canónicos.

## Outputs canónicos

```
~/Documents/Reports/contributions-<author>-<YYYY-MM-DD>/
├── prs-authored.jsonl          # raw Step 1
├── prs-reviewed.jsonl          # raw Step 2
├── prs-details.jsonl           # raw Step 3
├── jira-tickets.jsonl          # raw Step 4 (opcional)
├── prs-classified.jsonl        # output Step 5 classify
├── kpis.json                   # output Step 5 aggregate
├── REPORT.md                   # output Step 6 markdown
└── report.html                 # output Step 6 HTML branded
```

## Voz y estilo del output

- **Voz rioplatense** (ver [[feedback-rioplatense-voice]]): voseo, "tiré X PRs", "metí Y tickets", "arranqué con Z". No "stakeholders", "deliverables", "leverage".
- **Sin overclaim** (ver [[feedback-no-overclaim-unshipped]]): PRs draft/closed-not-merged van en sección separada con disclaimer. No mezclar con shipped en el TL;DR.
- **Estimates con IA** (ver [[feedback-estimates-assume-ai]]): si el reporte incluye velocidad ("X PRs por semana"), aclarar "con stack Claude Code + skills MODO".
- **Footnotes para POCs**: features en QA / draft / RFC viejo van en footnote con estado real.

## Anti-patrones

- **No reportar merge rate global sin segmentar por repo** — 80% en bitácora vs 50% en modo-landing son tareas distintas, mezclarlas distorsiona.
- **No clasificar PRs por LOC** — diff size no es proxy de impacto (1 línea bien puesta > 500 líneas de styles).
- **No incluir PRs `chore(deps)` en el TL;DR de impacto** — son ruido. Sí contarlos en totals.
- **No invocar el skill sin `AUTHOR_GH`** — el default `SoyErnoModo` es de Hernán; si querés audit a otro dev, el flag es obligatorio.
- **No subir el output al repo erno-modo sin worktree** — los reportes son privados (mencionan repos privados); si querés publicar, anonimizar primero y seguir [[feedback-git-worktrees]].

## Cross-links

- [[reference-gh-pr-inventory-pattern]] — patrón base de `gh search/issues`.
- [[reference-atlassian-cloudid-modo]] — cloudId para MCP Jira sin gastar tool call.
- [[reference-modo-research-article-skill]] — estilo R&D del HTML output.
- [[feedback-rioplatense-voice]] — voz del REPORT.md.
- [[feedback-no-overclaim-unshipped]] — qué NO ir al TL;DR.
- [[reference-modo-postman-pack-skill]] — patrón sibling (inventario cross-app MODO).

## Quickstart

```bash
# eval propio · default
~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh

# eval con rango
SINCE=2026-01-01 UNTIL=2026-03-31 ~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh

# eval de otro dev
AUTHOR_GH=otro-login AUTHOR_JIRA=otro@modo.com.ar ~/.claude/skills/modo-contribution-evaluator/scripts/run-all.sh
```

Output: `~/Documents/Reports/contributions-<author>-<YYYY-MM-DD>/REPORT.md` + `report.html`.
