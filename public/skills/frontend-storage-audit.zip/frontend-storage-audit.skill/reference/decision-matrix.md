# Decision matrix · cookies vs localStorage vs sessionStorage

> Regla canónica para decidir capa por dato en frontends MODO.

## La pregunta clave

**¿Quién necesita leer el dato?**

| Capa | Server lee? | Cross-tab? | Sobrevive cierre tab? | Sobrevive cierre browser? | Auto-enviado en request? | Tamaño |
|---|---|---|---|---|---|---|
| **cookie** | ✅ sí | ✅ sí | ✅ (con Expires/Max-Age) | ✅ | ✅ cada request | 4KB |
| **localStorage** | ❌ no | ✅ sí | ✅ | ✅ | ❌ | 5-10MB |
| **sessionStorage** | ❌ no | ❌ no (per-tab) | ❌ | ❌ | ❌ | 5-10MB |

## Reglas de decisión

```
1. Server lee pre-render?         → cookie
2. JS NO debe leer (security)?    → cookie HttpOnly
3. Solo UX client + grande?       → localStorage
4. Solo UX client + tab-scope?    → sessionStorage
```

Aplicar en orden. Primer match gana.

## Decisión por dato típico MODO

| Dato | Capa recomendada | Por qué |
|---|---|---|
| Consent flags | cookie | Server debe decidir scripts pre-render |
| A/B variant | cookie | Server bucketea → mata flash + sirve SEO |
| `is_sdk` flag | cookie | Server conoce WebView primer paint |
| Auth token | cookie HttpOnly | JS no debe leer → bloquea XSS exfil |
| device_id (correlation) | cookie HttpOnly | BFF correlation logs sin código manual |
| Geo lat/lng | sessionStorage | Sensible + tab-scoped + server no decide |
| `status_bar_height` | sessionStorage | Tab-scoped + UI-only |
| `LAST_USED_APP` | localStorage | UX client-only + sin valor server |
| Search history / favoritos | localStorage | UX client-only + potencial >4KB |
| Sidebar open/closed (shadcn) | cookie | Server lee para SSR primer paint correcto |
| Locale preference (futuro i18n) | cookie | Server elige idioma pre-render (`NEXT_LOCALE`) |
| Theme dark/light | cookie | Server evita flash light→dark en hydration |

## Costos de cookies (por qué NO todo va a cookies)

1. **Overhead cada request**: 10 cookies × 200 bytes = 2KB extra por request. Mata cache CDN si `Vary: Cookie`.
2. **Cap 4KB total por dominio** → no sirve para state grande.
3. **CSRF surface**: cookie auto-enviada es lo que CSRF explota. Mitigás con `SameSite=Strict`, agrega complejidad si cross-origin necesario.
4. **Privacy**: cookie persistente entre sesiones = identifiable. Datos sensibles (geo, PII) mejor en `sessionStorage` (muere al cerrar tab).
5. **CDN cache invalidation**: cookies en gSSP rompen cache compartido a menos que se setee `Vary: Cookie` correctamente.

## Flags canónicas por tipo de cookie

### Consent (`cookie_consent`)
- Sin prefix `__Host-` (client debe leerla).
- `SameSite=Lax`
- `Secure` en prod
- `HttpOnly=false` (client gate de scripts pre-DOM ready)
- `Max-Age=31536000` (12 meses, práctica EU)
- Versionado en value: `v1:essential,analytics,marketing`

### Auth token (`__Host-auth_<scope>`)
- Prefix `__Host-` obligatorio (forza Secure + Path=/ + sin Domain)
- `HttpOnly=true`
- `Secure=true`
- `SameSite=Strict`
- `Path=/`
- TTL session (sin Max-Age) o corto (15min con refresh endpoint)

### device_id (`__Host-device_id`)
- Prefix `__Host-`
- `HttpOnly=true`
- `Secure=true`
- `SameSite=Lax`
- `Path=/`
- `Max-Age=63072000` (2 años, estándar industria)
- Solo emit con consent analytics

### A/B variant (`ab_<flag>`)
- Sin prefix (no security-critical)
- `SameSite=Lax`
- `Secure=true`
- `HttpOnly=false` (Amplitude SDK lee para `trackExposure`)
- `Max-Age=7776000` (90 días)

### Runtime flag (`is_sdk`, `NEXT_LOCALE`)
- Sin prefix
- `SameSite=Lax`
- `Secure=true`
- `HttpOnly=false`
- `Max-Age=86400` (24h) para flags volátiles, longer para preferences

### Preview Storyblok (`__prerender_bypass`, `__next_preview_data`)
- Emitidas por `res.setPreviewData({})` (Next builtin)
- Post-replace a `SameSite=None;Secure` (necesario para iframe Storyblok)
- **Filter obligatorio**: replace solo aplica a estos 2 nombres, no a todo `Set-Cookie` del response.
