#!/usr/bin/env bash
# frontend-storage-audit · grep patterns canónicos (fase 1 + 3 del workflow)
#
# Usage:
#   bash ~/.claude/skills/frontend-storage-audit/reference/grep-patterns.sh [src_dir]
#
# Si no se pasa src_dir, usa `src/` desde cwd.
# Output: secciones separadas por categoría. Salida directa a stdout.

set -u

SRC="${1:-src}"

if [[ ! -d "$SRC" ]]; then
  echo "ERROR: directorio '$SRC' no existe." >&2
  exit 1
fi

echo "============================================"
echo "frontend-storage-audit · grep patterns"
echo "Dir: $SRC"
echo "Date: $(date +%Y-%m-%d)"
echo "============================================"
echo ""

# 1. Cookies first-party usadas en el código
echo "## 1. Cookies first-party"
grep -rEn "document\.cookie|setCookie|getCookie|js-cookie|cookies\(\)|setPreviewData|Set-Cookie|nookies|cookies-next|iron-session" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | head -80
echo ""

# 2. sessionStorage usage
echo "## 2. sessionStorage usage"
grep -rEn "sessionStorage\.|globalThis\?\.sessionStorage" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | head -80
echo ""

# 3. localStorage usage
echo "## 3. localStorage usage"
grep -rEn "localStorage\.|globalThis\?\.localStorage" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | head -80
echo ""

# 4. Consent / CMP existente?
echo "## 4. Consent / CMP (debería existir; si NO match = gap legal)"
grep -rEn "consent|cookieConsent|gdpr|ccpa|cookies-banner|banner.*cook|useConsent" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | grep -v "contratos\|politicas\|terminos" | head -30
echo ""

# 5. Política privacidad cita consent? (puede haber gap entre lo que dice y lo que se hace)
echo "## 5. Política privacidad menciona consent (cross-check con punto 4)"
grep -rEn "consentimiento|cookies para" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" "$SRC" 2>/dev/null | grep -E "contratos|politicas|privacidad" | head -20
echo ""

# 6. Auth token MODO (header SDK pattern)
echo "## 6. Auth token / SDK headers"
grep -rEn "auth-token-sdk|headerToken|set-cookie|getAuthSDKToken|setAuthSDKToken" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | head -20
echo ""

# 7. A/B experiments
echo "## 7. A/B experiments (debe pasar variant via pageProps; client-only init = gap)"
grep -rEn "Experiment|ab.?test|startExperiment|getVariant|getExperimentVariantApplied|variant" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.astro" "$SRC" 2>/dev/null | grep -v "contratos\|politicas\|test\.ts\|spec\.ts" | head -30
echo ""

# 8. Third-party trackers (mapeo a CMP categoría)
echo "## 8. Third-party trackers (mapeo a CMP categoría · analytics/marketing/essential)"
grep -nE "amplitude|gtag|googletagmanager|firebase|GA_|posthog|facebook|tiktok|linkedin|crazyegg|appsflyer|botmaker|freshbots|hotjar|segment|mixpanel" \
  -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.html" "$SRC" index.html 2>/dev/null | head -30
echo ""

# 9. Middleware / gSSP (Next puede leer cookies server-side)
echo "## 9. Server-side cookie reads (gSSP, middleware)"
grep -rEn "getServerSideProps|req\.cookies|req\.headers\.cookie|cookies\(\)" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" "$SRC/pages" "$SRC/app" "$SRC/middleware" 2>/dev/null | head -20
echo ""

# 10. CSP unsafe-inline (correlaciona con auth token storage para XSS exfil window)
echo "## 10. CSP 'unsafe-inline' (correlaciona con gap 2 security)"
grep -nE "'unsafe-inline'|unsafe-inline|script-src" next.config.js astro.config.* vite.config.* 2>/dev/null | head -10
echo ""

# 11. setPreviewData replace pattern (defensive · gap 5)
echo "## 11. Set-Cookie replace patterns (defensive · check name filter)"
grep -rEn "getHeader\\('Set-Cookie'\\)|res\\.setHeader\\('Set-Cookie'|\\.replace\\('SameSite" \
  --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" "$SRC" 2>/dev/null | head -10
echo ""

echo "============================================"
echo "Audit grep done."
echo "Siguiente: armar tabla mapping (paso 1 SKILL.md) y aplicar decision matrix (paso 2)."
echo "============================================"
