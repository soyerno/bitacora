# SDD scaffold template · iniciativa cookies-*

> Template canónico para cada iniciativa identificada en el audit.
> Path: `openspec/changes/cookies-<slug>/README.md`.
> Reemplazar `<placeholders>` antes de commitear.

```markdown
# cookies-<slug> · <título corto>

> Status: Draft · <YYYY-MM-DD>
> Prioridad: **<P0|P1|P2|P3|FIX> · <razón corta>**
> Esfuerzo: ~<Nd|Nh> con IA
> Owner: <nombre> · <rol>
> Squad sugerido: <squad>
> Related: <link a otros PRs/SDDs si aplica>

## Why

<2-4 párrafos · qué dolor concreto resuelve · evidencia con archivo:línea · referencias a memory si existe>

## What

<2-3 párrafos · propuesta técnica · scope · alternativas descartadas con razón>

## Spec delta

### REQUIREMENT: <nombre del requirement>
**Why**: <razón breve>

#### Scenario: <nombre escenario>
- WHEN: <trigger>
- THEN: <observable outcome>
- AND: <observable extra>

#### Scenario: <otro escenario>
- WHEN: ...
- THEN: ...

(Repetir REQUIREMENT + Scenarios según necesidad. Cada requirement debe ser verificable con test.)

## Tasks

- [ ] T1 · <task descripción específica · archivo o componente>
- [ ] T2 · <...>
- [ ] T3 · <...>
- [ ] ...

(Tasks deben ser ejecutables independientemente. Cada uno cabe en 1-4h IA-assisted.)

## Design

### D1: <decisión técnica>
<opción elegida>.
- Razón: <por qué esta opción>.
- Alternativas rechazadas: <opción A · razón>, <opción B · razón>.
- Tradeoff: <costo asumido>.

### D2: <otra decisión>
...

(Cada D-decision debe nombrar la opción elegida + alternativas + tradeoff explícito.)

## Riesgos

- **<riesgo 1>**: <descripción> · Mitigation: <cómo se mitiga>.
- **<riesgo 2>**: ...

## Dependencias

- **Bloqueante**: <PR/SDD que debe mergear antes>.
- **Soft dep**: <PR/SDD que ayuda pero no bloquea>.

## Out of scope

- <feature relacionada que NO entra · razón>.
- <ítem siguiente fase>.

## Test plan

\`\`\`bash
# unit
pnpm test <archivos específicos>

# integration
pnpm test <integration specs>

# e2e
pnpm playwright test <e2e spec>

# manual
# 1. <paso reproducible>
# 2. <assertion observable>
\`\`\`
```

## Tips

- **No vaporware**: si el SDD propone un endpoint, nombrarlo en T1 con path exacto.
- **Spec delta es contrato**: cada REQUIREMENT + Scenario debe traducirse a un test verificable. Si no se puede testear, no es REQUIREMENT.
- **D-decisions con tradeoff**: si no podés nombrar la alternativa rechazada, todavía no decidiste bien.
- **Dependencias cross-PR explícitas**: linkear PR # cuando ya están creados; "TBD" si no.
- **Esfuerzo "con IA"** según memoria `feedback_estimates_assume_ai`: toda cifra de tiempo asume Claude Code + skills. Explicitar.
