# frontend-storage-audit

> Skill MODO · Auditá la capa de storage client-side y producí plan multi-PR de hardening con sección dolor explícita.

## TLDR

Si abrís un frontend MODO y querés saber dónde vive cada dato (cookies vs sessionStorage vs localStorage), qué debería mover de capa, qué dolor real (legal/seguridad/UX/observability) hay sin atender y cómo armar un plan multi-PR draft con SDD scaffolds, este skill te lo arma.

Output canónico: tabla mapping + SDD scaffolds + master plan doc + 6-7 PRs draft con sección "🩹 Por qué · qué dolor soluciona".

## Por qué existe

Auditoría 2026-05-28 sobre modo-landing reveló:
- Token auth en `sessionStorage` con CSP `'unsafe-inline'` + 10+ scripts third-party = XSS exfil window real.
- Política privacidad MODO cita consent pero NO existe banner ni CMP.
- A/B variants pintan control siempre en primer paint → flash visible + SEO bait + data sucia.
- Header `auth-token-sdk` se detecta server pero `is_sdk` flag se decide client → flash chrome web→WebView en SDK.
- Sin device_id correlation, oncall pierde 30min/incident reconstruyendo journey BFF↔Amplitude.
- `Set-Cookie` rewrite en `/api/preview.js` afecta TODO el response, no solo cookies preview.

Total 5 gaps + 1 deuda silenciosa = 7 iniciativas de mejora.

En lugar de re-descubrir esto en cada front MODO (modo-landing, aprendeatumodo, promos-hub-site, modo-landing-astro), este skill codifica el workflow audit + plan.

## Cómo se invoca

### Auto-invocación

El skill auto-invoca cuando el user dice:
- "auditá las cookies" / "audit cookies"
- "validá las cookies" / "validate cookies"
- "cookies vs localStorage" / "cookies vs storage"
- "dónde guardamos X"
- "auth token storage" / "token en sessionStorage"
- "GDPR cookies" / "Ley 25.326 cookies" / "consent banner" / "CMP"
- "cookies layer hardening"
- "/frontend-storage-audit" / "/cookies-audit" / "/storage-audit"

También auto-invoca al editar:
- archivos con `document.cookie`, `setPreviewData`, `sessionStorage`, `localStorage`
- imports de `js-cookie`, `nookies`, `cookies-next`, `iron-session`
- `next.config.js` headers que tocan `Set-Cookie` o CSP

### Slash commands

- `/frontend-storage-audit` · audit completo + producir SDD + PRs.
- `/cookies-audit` · alias corto.

## Estructura del repo del skill

```
~/.claude/skills/frontend-storage-audit/
├── SKILL.md                        # entry principal con frontmatter + workflow 5 fases
├── README.md                       # este archivo (human-readable)
└── reference/
    ├── decision-matrix.md          # cookies vs storage por dato (regla canónica)
    ├── grep-patterns.sh            # script grep canónico para audit paso 1
    ├── sdd-scaffold-template.md    # template SDD por iniciativa
    └── pain-section-template.md    # template sección dolor para PR description
```

## Workflow resumido

1. **Audit** · grep canónico → tabla mapping (dato | capa actual | archivo:línea | server lee? | sensible?).
2. **Decision matrix** · aplicar regla `server lee pre-render? → cookie · JS no debe leer? → cookie HttpOnly · UX grande? → localStorage · UX tab-scope? → sessionStorage` por dato.
3. **Identificar gaps** · 5 categorías canónicas (legal CMP, security token, UX A/B+WebView, observability device_id, defensive Set-Cookie filter).
4. **Plan multi-PR** · SDD scaffold por iniciativa + master plan doc.
5. **Fan-out** · 1 worktree por PR + commit SDD-only + `gh pr create --draft` con sección dolor obligatoria.

Detalle workflow completo: ver `SKILL.md` arriba.

## Naming convention canónica

Resumida en `SKILL.md` sección "Naming convention canónica". Cookie names por tipo de uso, flags correctos, schema value versionado.

## Caso canónico

### modo-landing + aprendeatumodo · 2026-05-28

Primer aplicación end-to-end del workflow. 7 PRs draft creados:

| PR | Iniciativa | Prioridad | Esfuerzo |
|---|---|---|---|
| [#1511](https://github.com/playsistemico/modo-landing/pull/1511) | `fix/cookies-preview-name-filter` | FIX defensive | 2h con IA |
| [#1512](https://github.com/playsistemico/modo-landing/pull/1512) | `chore/cookies-cmp-consent` + master plan | **P0 · legal blocker** | 5d con IA |
| [#1513](https://github.com/playsistemico/modo-landing/pull/1513) | `feat/cookies-is-sdk-flag` | P1 · WebView UX | 1d con IA |
| [#1514](https://github.com/playsistemico/modo-landing/pull/1514) | `feat/cookies-ab-server-bucketed` | P1 · LCP/CLS + SEO | 3d con IA |
| [#1515](https://github.com/playsistemico/modo-landing/pull/1515) | `feat/cookies-device-id` | P3 · observability | 1d con IA |
| [#1516](https://github.com/playsistemico/modo-landing/pull/1516) | `chore/cookies-auth-httponly` | P2 · security XSS | 8d cross-team |
| [SoyErnoModo#25](https://github.com/SoyErnoModo/aprendeatumodo/pull/25) | `chore/cookies-cmp-consent` (aprende) | **P0 · legal blocker** | 3d con IA |

### Lecciones del caso

1. **Pain section es load-bearing** — un PR draft sin sección dolor es prosa decorativa. Cada PR debe nombrar al stakeholder concreto que sufre hoy.
2. **Master plan vive en el P0** — el PR P0 (suele ser CMP consent) lleva el master plan; otros PRs linkean al P0.
3. **Worktree por PR cuesta poco** — `git worktree add` × 7 = ~5min total + cleanup limpio.
4. **Lint-staged solo matchea código** — commits docs-only (`openspec/`, `docs/`) pasan husky sin pre-commit checks.
5. **Cross-property reuse** — schema cookie value (`v1:essential,analytics,marketing`) idéntico cross-property habilita lib compartida `modo-ui-lib-web` futura.
6. **`__Host-` prefix obligatorio** para cookies HttpOnly (auth, device_id). Forza Secure + Path=/ + sin Domain → bloquea cookie injection cross-subdomain (`pix.modo.com.ar`, `comercios.modo.com.ar`).

### Memoria persistente generada

Tras correr el audit en modo-landing + aprendeatumodo, las siguientes memorias quedaron:

- (futura) `reference_frontend_storage_audit_canonical_case_2026_05_28` · 7 PRs creados + lecciones.
- (futura) `feedback_pain_section_load_bearing_in_prs` · sección dolor obligatoria en PRs MODO.

## Skills relacionados

| Skill | Relación |
|---|---|
| `frontend-security-checklist` | Complemento. Layer 3 (CSP post-deploy) corre DESPUÉS de CMP para promover `report-only` → `enforce`. |
| `csp-hardening` | Complemento. Drop `'unsafe-inline'` script-src solo viable post-CMP (scripts marketing cargan con nonce condicional al consent). |
| `modo-pr-author` | Sub-componente. Autorea PR descriptions con voz rioplatense + estructura dolor/hicimos/para qué. Este skill llama implícitamente a esa convención en fase 5. |
| `sdd-propose` / `sdd-design` / `sdd-tasks` | SDD lifecycle. Este skill produce `openspec/changes/<slug>/` que esos skills enriquecen con design.md, tasks.md, spec-delta.md. |
| `modo-planner` | Wrapper. Cuando scope cruza ≥3 archivos o múltiples repos, este skill es 1 fase del MODO Planning Framework. |
| `sonar-best-practices` | Complemento. Cookies HttpOnly + SameSite=Strict aparecen como hot-spots Sonar; este skill los resuelve antes de que aparezcan en SC. |

## Riesgos del workflow

1. **CDN cache invalidation** — cookies en gSSP rompen cache si no se setean `Vary: Cookie`. Mitigation documentada en SDD per iniciativa.
2. **GDPR doble standard** — Argentina más permisivo que EU. Default opt-in para todos.
3. **Backward compat** — auth-httponly requiere coord SDK Android + iOS. Rollout con feature flag + telemetry + canary.
4. **Husky hooks** — si el repo tiene pre-commit que toca docs (markdownlint, prettier), pueden bloquear los commits scaffold. Mitigación: lint-staged scope debe excluir `openspec/` + `docs/`.

## Roadmap del skill

- [x] v1.0 · workflow 5 fases + decision matrix + 5 gaps canónicos + caso canónico 2026-05-28.
- [ ] v1.1 · script `audit.sh` que automatiza fase 1 + 3 (grep + gap detection).
- [ ] v1.2 · integración con `modo-services-monitor` para mostrar consent rate por env.
- [ ] v1.3 · Edge Middleware patterns (post Next 16 migration) para emit cookies con <5ms overhead.
- [ ] v2.0 · cross-property unified lib `@playsistemico/modo-consent` (`<ConsentBanner>` + `useConsent()` + `parseCookie()` + tipos compartidos).

## Versión + fuente

- v1.0 · 2026-05-29 · Hernán De Souza · Sr AI Engineer
- Source canónico: `~/.claude/skills/frontend-storage-audit/`
- Bundled en: https://soyernomodo.github.io/erno-modo/skills/ (vía `erno-modo-sync-all`).
