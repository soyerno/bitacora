---
name: frontend-storage-audit
description: 'Auditá la capa de almacenamiento client-side en frontends MODO (cookies vs sessionStorage vs localStorage). Mapea cada dato a su capa actual, identifica candidatos a mover, detecta gaps legales (CMP/consent), de seguridad (auth token en sessionStorage = XSS exfil), UX (flash A/B, WebView chrome mismatch) y observability (device_id correlation BFF), y produce SDD scaffolds + master plan + PRs draft fan-out con sección dolor explícita. Auto-invocar cuando el usuario diga (ES/EN) "auditá las cookies", "validá las cookies", "cookies vs localStorage", "dónde guardamos X", "auth token storage", "GDPR cookies", "consent banner", "cookies layer hardening", "/frontend-storage-audit", "/cookies-audit", "/storage-audit", o cuando edite archivos que tocan `document.cookie`, `setPreviewData`, `sessionStorage`, `localStorage`, `useCookie`, `js-cookie`, `nookies`, `cookies-next`. Aplica cross-property: modo-landing (Next 12), aprendeatumodo (Vite SPA), promos-hub-site (Next 15), modo-landing-astro (Astro), promos-hub-site, cualquier MODO front.'
---

# frontend-storage-audit

Auditá + plan de mejora para la capa de storage client-side (cookies + sessionStorage + localStorage) de cualquier frontend MODO. Output canónico: SDD scaffolds en `openspec/changes/cookies-*/` + master plan doc + multi-PR draft fan-out con sección dolor.

## Cuándo se invoca (auto-invoke triggers)

### Phrase triggers (ES / EN)

- "auditá las cookies" / "audit cookies" / "validá las cookies" / "validate cookies"
- "cookies vs localStorage" / "cookies vs storage" / "dónde guardamos X"
- "auth token storage" / "token en sessionStorage" / "session storage security"
- "GDPR cookies" / "Ley 25.326 cookies" / "consent banner" / "CMP"
- "cookies layer hardening" / "storage hardening" / "storage layer audit"
- "qué movemos a cookies" / "movemos X a cookie"
- "/frontend-storage-audit" / "/cookies-audit" / "/storage-audit"

### File triggers (auto-invoke al editar)

- `**/document.cookie` references
- `**/api/preview*.{js,ts}` (Next preview API con `setPreviewData`)
- `**/sessionStorage.ts` / `**/localStorage*` utils
- `**/useCookie*` hooks
- imports de `js-cookie`, `nookies`, `cookies-next`, `iron-session`
- `next.config.js` headers que tocan `Set-Cookie` o CSP

### Context triggers

- Auditoría seguridad pre-pen-test.
- Pre-release con cambios de privacy policy.
- Investigación de flash en A/B experiments.
- Investigación de chrome flip WebView post-hydration.
- Bug report "soporte: usuarios reportan flash en WebView".
- "no se puede correlacionar logs BFF con eventos Amplitude" en post-incident.

## Workflow (5 fases)

### 1. Audit · mapeo del estado actual

Inventariar **cada** dato persistido client-side y su capa actual.

Correr grep canónico desde la raíz del repo (ver [reference/grep-patterns.sh](reference/grep-patterns.sh) para script completo):

```bash
# cookies first-party
grep -rEn "document\.cookie|setCookie|getCookie|js-cookie|cookies\(\)|setPreviewData|Set-Cookie" \
  --include="*.{ts,tsx,js,jsx,astro}" src/

# Storage usage
grep -rEn "localStorage\.|sessionStorage\." \
  --include="*.{ts,tsx,js,jsx,astro}" src/

# Consent / CMP
grep -rEn "consent|cookieConsent|gdpr|ccpa|cookies-banner|banner.*cook" \
  --include="*.{ts,tsx,js,jsx,astro}" src/

# Auth headers (typical SDK WebView pattern MODO)
grep -rEn "auth-token-sdk|headerToken|set-cookie" \
  --include="*.{ts,tsx,js,jsx,astro}" src/

# Third-party trackers en CSP / scripts
grep -nE "amplitude|gtag|googletagmanager|firebase|GA_|posthog|facebook|tiktok|linkedin|crazyegg|appsflyer|botmaker|freshbots" \
  --include="*.{ts,tsx,js,jsx,html}" -r src/ index.html

# Middleware / gSSP (Next puede leer cookies server-side)
grep -rEn "getServerSideProps|req\.cookies|req\.headers\.cookie|cookies\(\)" \
  --include="*.{ts,tsx,js,jsx}" src/pages src/app src/middleware* 2>/dev/null
```

Producir tabla canónica:

| Dato | Capa actual | Archivo:línea | Server lee? | Sensible? |
|---|---|---|---|---|
| auth token | sessionStorage | ... | sí (via header) | sí · token full BFF |
| device_id | localStorage (Amplitude SDK) | ... | no | medio · PII |
| geo lat/lng | sessionStorage | ... | no | sí · ubicación |
| ... | ... | ... | ... | ... |

### 2. Decision matrix · qué capa corresponde

Aplicar la matriz canónica (detalle: [reference/decision-matrix.md](reference/decision-matrix.md)):

```
Server lee pre-render?     → cookie
JS NO debe leer (security)? → cookie HttpOnly
Solo UX client + grande?    → localStorage
Solo UX client + tab-scope? → sessionStorage
```

Por cada fila de la tabla del paso 1, decidir si la capa actual es correcta o si hay que mover. Justificar la decisión con la regla de la matriz.

### 3. Identificar gaps · 5 categorías canónicas

Buscar específicamente estos antipatrones MODO:

#### Gap 1 · Legal · CMP ausente

Síntoma:
- Política privacidad cita "consentimiento expreso para cookies" pero NO existe banner ni `cookie_consent` cookie.
- Scripts marketing/analytics (Amplitude, GTM, Firebase, Meta, TikTok, etc.) cargan incondicional.

Impact: Argentina Ley 25.326 (DNPDP, multa máx ~ARS 100M) + GDPR EU (hasta 4% revenue global). Due-diligence partners flagea en primera hora.

#### Gap 2 · Seguridad · auth token en sessionStorage

Síntoma:
- Token de autenticación legible vía `getItem()` JS.
- CSP permite `'unsafe-inline'` o scripts third-party (Botmaker, Freshbots, CrazyEgg, AppsFlyer, GTM).

Impact: XSS exfil window — partner third-party comprometido puede mandar token a attacker. OWASP ASVS V3.5.3 fallido.

#### Gap 3 · UX · A/B variant flash + WebView chrome flip

Síntoma A/B:
- `startExperimentAmplitude` (o equivalente) corre client-side post-mount.
- Primer paint = control siempre.
- Variante real flippea post-mount → flash + CLS + Google indexa solo control.

Síntoma WebView (MODO-specific):
- Header `auth-token-sdk` llega en request pero `is_sdk` se decide client-side post-mount.
- Primer paint = chrome WEB → flippea a chrome WebView (SDK Android/iOS).
- Flash visible WebView slow = usuario percibe bug en la app MODO.

Impact: CLS hit, experiments con data contaminada, tickets soporte recurrentes.

#### Gap 4 · Observability · sin device_id correlation key

Síntoma:
- BFF logs (Datadog) tienen IP + UA + path.
- Amplitude eventos tienen device_id en su storage interno.
- Cruce manual por timing + IP (NAT colision = falsos positivos).

Impact: 30min oncall extra por incident reconstruyendo journey. Cohort analysis cross-canal imposible. Snowflake reports cross-canal con error margin 10-20%.

#### Gap 5 · Defensive · `Set-Cookie` rewrites sin filtro de nombre

Síntoma (MODO-specific, Next preview pattern):
```js
const cookies = res.getHeader('Set-Cookie');
res.setHeader('Set-Cookie',
  cookies.map((c) => c.replace('SameSite=Lax', 'SameSite=None;Secure'))
);
```
Aplica el replace a TODO `Set-Cookie` del response, no solo a las cookies preview.

Impact: deuda silenciosa. Si Next 16 o copy-paste a otra ruta API agrega cookies, leak cross-site silencioso.

### 4. Plan multi-PR · scaffold SDD + master plan

Por cada gap identificado, generar un SDD scaffold bajo `openspec/changes/cookies-<slug>/README.md` siguiendo el template canónico ([reference/sdd-scaffold-template.md](reference/sdd-scaffold-template.md)).

Estructura SDD obligatoria:
- **Status / Prioridad / Esfuerzo / Owner / Squad**
- **Why** (problem statement)
- **What** (proposal)
- **Spec delta** (REQUIREMENT + Scenario WHEN/THEN)
- **Tasks** T1..Tn checklist
- **Design** D1..Dn decisiones técnicas
- **Riesgos**
- **Dependencias** (cross-PR)
- **Out of scope**
- **Test plan**

Adicional: master plan doc en `docs/cookies-layer-plan/README.md` (un solo repo, owner) con:
- Decision matrix cookies vs storage por dato.
- Tabla con N iniciativas, prioridad, esfuerzo, PR.
- Orden de merge sugerido (dependencies-aware).
- Decisiones técnicas globales (nombre cookies, lib, CSP nonce post-CMP, test strategy).
- Riesgos cross-iniciativa (CDN cache, GDPR doble standard, backward compat).

### 5. Fan-out · multi-PR draft con sección dolor

Por cada SDD, crear 1 branch + 1 PR draft. **Sección "🩹 Por qué · qué dolor soluciona" obligatoria** ([reference/pain-section-template.md](reference/pain-section-template.md)).

Cada pain section debe cubrir:
1. **Dolor concreto** (no abstracto). Nombrar el síntoma observable.
2. **Frecuencia / probabilidad real** con precedente industria si aplica.
3. **Costo de no hacerlo** — financiero / regulatorio / reputacional.
4. **Costo de hacerlo** — esfuerzo + risk level.
5. **Backward compat** si aplica.

Anti-patrón a evitar: "buenas prácticas" sin tie-back a dolor real. Reglón: si no puedo nombrar al stakeholder que sufre hoy, el PR no se justifica.

Pattern de fan-out (no inventar — usar exacto):

```bash
# 1 worktree base con TODOS los SDD docs (escritura paralela cómoda)
git worktree add /tmp/wt-storage-base -b chore/storage-base origin/main

# Por PR sub-iniciativa:
git worktree add /tmp/wt-pr-<slug> -b <branch> origin/main
cp -r /tmp/wt-storage-base/openspec/changes/<slug> /tmp/wt-pr-<slug>/openspec/changes/
cd /tmp/wt-pr-<slug>
git add openspec/changes/<slug>
git -c user.email="..." -c user.name="..." commit -m "$(cat <<'EOF'
type(scope): SDD scaffold <slug>

Scaffold-only PR — SDD docs en openspec/changes/<slug>/.
Implementación en PR follow-up (N tasks).
EOF
)"
git push -u origin <branch>
gh pr create --draft --base main --head <branch> --title "..." --body-file <body>.md
```

Master plan vive en el PR P0 (CMP consent suele ser el P0). Cada PR sub-iniciativa linkea al master plan PR.

## Naming convention canónica

| Tipo | Nombre cookie | Prefix | Flags |
|---|---|---|---|
| Consent | `cookie_consent` | — | `SameSite=Lax`, Max-Age=31536000, sin HttpOnly |
| Auth token | `__Host-auth_<scope>` | `__Host-` | HttpOnly, Secure, SameSite=Strict, Path=/ |
| device_id | `__Host-device_id` | `__Host-` | HttpOnly, Secure, SameSite=Lax, Path=/, Max-Age=63072000 |
| A/B variant | `ab_<flag>` | — | SameSite=Lax, Secure, Max-Age=7776000 |
| Detección runtime (is_sdk, locale) | `is_<x>` o standard Next (`NEXT_LOCALE`) | — | SameSite=Lax, Secure, Max-Age=86400 |
| Preview Storyblok | `__prerender_bypass` + `__next_preview_data` | — | `SameSite=None;Secure` (post-filtered replace) |

Schema cookie value canónico (cross-property): `v1:essential,analytics,marketing` (versionado para migración futura sin breaking).

## Cross-property checklist

Aplicar este audit cross-property MODO:

- [ ] modo-landing (Next 12 → 16 migración activa)
- [ ] aprendeatumodo (Vite SPA + React)
- [ ] promos-hub-site (Next 15)
- [ ] modo-landing-astro (Astro)
- [ ] modo-landing-sdk-ui-lib (lib propia, no aplica audit pero validar si emite cookies)

Coordinación cross-property: mismo schema cookie value (`v1:essential,analytics,marketing`) en todos los properties → futuro consolidation en lib compartida `modo-ui-lib-web` (banner + hook reutilizables).

## Anti-patrones detectables

| Anti-pattern | Detección | Fix |
|---|---|---|
| Token auth en `sessionStorage` con `'unsafe-inline'` CSP | grep `auth-token` + `sessionStorage` + `next.config.js` headers | Migrar a cookie `__Host-` HttpOnly + coord SDK |
| A/B variant client-only | grep `startExperiment` / `getVariant` + grep `getServerSideProps` (debe pasar variant via pageProps) | Bucketing server-side cookie `ab_<flag>` |
| `Set-Cookie` rewrite sin filter | grep `getHeader('Set-Cookie')` + `.map((c) => c.replace(` | Filtrar por `cookie.split('=')[0]` against allowlist |
| Política privacidad cita consent + no banner | grep `consentimiento` en `src/contratos/` + grep `cookieConsent`/`useConsent` (debe existir) | Implementar CMP first-party |
| device_id solo en Amplitude SDK | grep `Amplitude.init` + no `Set-Cookie` en gSSP | Cookie `__Host-device_id` + Amplitude init con `initialDeviceId` |
| WebView is_sdk post-mount | grep `setIsSDK` en post-hydration code + `req.headers['auth-token-sdk']` en gSSP (debe emitir cookie) | Cookie `is_sdk` en gSSP cuando detecta header |

## Output deliverables

Al terminar el audit, producir:

1. **Tabla mapping** (paso 1) en `docs/storage-audit-<date>/inventory.md`.
2. **SDD scaffolds** en `openspec/changes/cookies-<slug>/README.md` (uno por iniciativa).
3. **Master plan** en `docs/cookies-layer-plan/README.md`.
4. **N PRs draft** en GitHub con sección dolor.
5. **Recovery memory** opcional si la auditoría detecta gap legal P0 (memoria persistente con fecha + multa estimada + status mitigación).

## Caso canónico (referencia)

modo-landing + aprendeatumodo · 2026-05-28 · 7 PRs draft creados:
- [#1511](https://github.com/playsistemico/modo-landing/pull/1511) FIX preview-name-filter
- [#1512](https://github.com/playsistemico/modo-landing/pull/1512) P0 CMP consent + master plan
- [#1513](https://github.com/playsistemico/modo-landing/pull/1513) P1 is-sdk-flag
- [#1514](https://github.com/playsistemico/modo-landing/pull/1514) P1 ab-server-bucketed
- [#1515](https://github.com/playsistemico/modo-landing/pull/1515) P3 device-id
- [#1516](https://github.com/playsistemico/modo-landing/pull/1516) P2 auth-httponly
- [SoyErnoModo#25](https://github.com/SoyErnoModo/aprendeatumodo/pull/25) P0 CMP consent

Ver detalle en `~/.claude/skills/frontend-storage-audit/README.md` sección "Caso canónico".

## Skills relacionados

- `frontend-security-checklist` · Layer 3 CSP validation post-deploy. Complemento defensive para post-CMP nonce-based CSP migration.
- `csp-hardening` · Endurecer Content-Security-Policy. Recomendable correr DESPUÉS de CMP (drop `'unsafe-inline'` solo cuando consent gate inyecta scripts con nonce).
- `modo-pr-author` · Autorea descripciones PR con voz rioplatense + estructura dolor/hicimos/para qué. Usar al crear PRs draft del fan-out.
- `sdd-propose` / `sdd-design` / `sdd-tasks` · SDD lifecycle. Este skill produce `openspec/changes/<slug>/` que esos skills enriquecen.
- `modo-planner` · MODO Planning Framework. Cuando el scope cruza ≥3 archivos o múltiples repos, este skill es 1 fase de un plan más amplio.
