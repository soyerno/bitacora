---
name: pr-pain-purpose-how
description: Use this skill when writing a pull request description. Every PR opens with three sections — Pain (the problem/symptom), Purpose (what it's for / why it matters), How (what the change does) — so a reviewer gets the why before the what. Use whenever drafting or rewriting a PR body.
---

Every PR description opens with three sections, in this order, before any diff detail:

1. **Pain** — the concrete problem or symptom this PR exists to fix. What hurts today, observably.
   ("Tapping the admin panel from the profile kicks the user out to the browser in the native
   app.") Lead with the user/dev pain, not the solution.
2. **Purpose** — what it's for / why it matters. The goal behind fixing the pain; who benefits.
   Ties the change to a user or product outcome.
3. **How** — what the change actually does, at the altitude a reviewer needs: the approach, the
   key files/seams touched, anything non-obvious. Not a line-by-line restatement of the diff.

## Why this order

A reviewer who reads Pain → Purpose → How understands *why the diff exists* before judging *what
it does* — so review is about whether the change solves the right problem, not reverse-engineering
intent from code. It also forces the author to have a real problem statement; "How" with no "Pain"
is a smell that the PR is solution-in-search-of-problem.

## Notes

- Keep each section tight — a few sentences. This is a frame, not an essay.
- Write the PR body in natural prose (this is human-facing); don't compress it telegraphically.
- Adapt the labels to the team's language if needed (the three beats — problem / why / what —
  are what matter), but keep all three present.

## One line

Open every PR with Pain (the problem) → Purpose (why it matters) → How (what the change does),
so reviewers get intent before implementation.
