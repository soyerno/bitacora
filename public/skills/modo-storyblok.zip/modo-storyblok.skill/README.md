# modo-storyblok

Orquestar contenido editorial en frontends MODO via Storyblok. Schemas + TS types + bloks renderer + dual-source con fallback + Mgmt API push scripts + visual editor wiring. Reusable para cualquier content type MODO.

## Quick start

- Triggers: `armá Storyblok para X`, `convertí esto a CMS`, `migrá hardcoded a Storyblok`, `schema de Storyblok para Y`, `/modo-storyblok`
- Output: schemas + TS types + renderer + dual-source page + push scripts + tests
- Caso canónico: aprendeatumodo · migró 1655 LOC de JSX hardcoded a Storyblok-driven en 7 PRs

## Features

- **Patrón canónico end-to-end** · 9 schemas reutilizables (course, course_module + 7 body bloks)
- **Bloks renderer mapeado 1:1 a primitivas MODO branded** (Callout, Tile, Step, CheckItem, SubHeading, Prose, ProseList)
- **Dual-source pattern** · Storyblok + fallback al código durante migración · adapter en boundary mantiene componentes downstream sin cambios
- **iconMap whitelist Lucide** · 32 iconos · anti bundle bloat
- **richtextRenderer hand-rolled** · 175 LOC · 3KB · soporta paragraph/heading/lists/marks (bold/italic/link/code) + opción `unwrapParagraphs` anti `<p>`-en-`<p>` DOM nesting
- **Mgmt API push scripts sin deps** · `_mapi.mjs` + `push-components.mjs` + `push-stories.mjs` · region routing EU/US/AP/CA/CN · retry exponencial · dry-run default
- **Visual editor wireado** · `useStoryblok` carga StoryblokBridge cuando URL trae `?_storyblok=*`
- **Testing parametrizado con `describe.each`** · 1 test setup para N stories

## Files

- `SKILL.md` — proceso end-to-end + core principles + caso canónico
- `README.md` — esta doc
- `reference/schemas-canonical.md` — 9 schemas con JSON completo + TypeScript types
- `reference/blok-renderer-pattern.md` — iconMap + richtextRenderer + BodyRenderer
- `reference/dual-source-pattern.md` — adapter en boundary + page wiring + tests
- `reference/mgmt-api-scripts.md` — `_mapi.mjs` + push-components + push-stories
- `reference/folder-routing.md` — folders + is_startpage children + parent_id + nested multilinks gotchas (W7)
- `reference/testing-pattern.md` — fixtures + describe.each + path tests

## Caso canónico · aprendeatumodo

| Métrica | Valor |
|---|---|
| Stories creadas | 7 (cursos) |
| Modules nested | 34 |
| Body bloks nested | 176 |
| Schemas | 9 (1 root + 1 module + 7 body) |
| TS types | 14 |
| Iconos whitelisted | 32 |
| Tests RTL | 126 (passing) |
| Build time | 1.89s |
| LOC migration | -1655 (cuando se borre fallback) |

| Wave | PR | Scope |
|---|---|---|
| W1 | #11 | SDD + 9 schemas + 14 TS types |
| W2 | #12 | Renderer + iconMap + richtextRenderer + 25 tests |
| W1b | #13 | Gap fixes A+B+C (callout title · subheading icon · intro/outro bloks) |
| W3 | #14 | CoursePage + Carousel dual-source con adapter |
| W4 | #15 | Piloto Seguridad story 634 LOC |
| W5 | #16 | Mgmt API push scripts (dry-run + apply) |
| W6 | #17 | 6 cursos restantes (2318 LOC JSON · 30 modules · 148 bloks) |
| W7 | — | Split nested modules → standalone stories + folder routing (is_startpage children) |
| W7b | — | Course startpage child stories per folder con refs populados |

## Cross-link

- [`modo-seo-geo-audit`](../modo-seo-geo-audit/) — el CSR trap aplica a SPAs Vite que renderean Storyblok via React/Helmet. Resolverlo: migrar a SSG
- [`modo-design-system`](../modo-design-system/) — tokens MODO y componentes branded (Callout, Tile, Step, etc.) que el renderer mapea
- [`sdd-init`](../sdd-init/) — scaffold openspec/changes/<slug>/ para tracking de waves
- [`nextjs-pages-router-migration`](../nextjs-pages-router-migration/) — destino SSG natural

## Changelog

- **2026-05-25** — Skill creado · 4 references + caso canónico aprendeatumodo PRs #11-#17 · pattern end-to-end consolidado tras migrar 1655 LOC hardcoded → Storyblok
- **2026-05-25 W7** — Reference `folder-routing.md` agregada · 5 gotchas (is_startpage children, idempotency, story→folder block, parent_id mandatory, nested multilinks no resuelven). Principio P7 en SKILL.md. Caso aprendeatumodo expandido a 42 stories organizadas en folder tree
- **2026-05-26** — `folder-routing.md` extendido con sección "Implementation · option A · `useCourseStory` hook" drop-in (resuelve "carga y desaparece" causado por refs unresolved). Defensive fallthrough en page. Caso canónico PR #20 aprendeatumodo commit `4ea9643`
- **2026-06-01** — Reference `visual-editor-wiring.md` agregada · wire del Visual Editor nativo (NO editor custom): `cmsEditable` reimpl 6-líneas (sin sumar `@storyblok/react`), draft seguro en cualquier env vía firma HMAC `_storyblok_tk`, edición en vivo `input`→`setStory`. Decisión load-bearing native-vs-custom documentada. Caso modo-landing `feat/storyblok-visual-editor` (10/10 tests green)
- **2026-06-01** — Reference `ai-editor-chat.md` agregada · editor-chat IA Lovable-style constrained al design system MODO (catálogo cerrado + voz rioplatense en system prompt) · multi-provider Claude (tool-use) + Gemini (function-calling) con un solo contrato de ops · dev-only triple-gate · gotchas Gemini (tipos MAYÚSCULA, OBJECT necesita properties→fields como STRING, `x-goog-api-key` header, alias `-latest`). Caso modo-landing PR #1523, probado en vivo con Gemini Flash
