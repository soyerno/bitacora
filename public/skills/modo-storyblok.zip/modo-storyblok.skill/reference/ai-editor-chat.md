# Editor-chat IA constrained al design system (Lovable-style)

Panel de chat in-app que edita el contenido CMS en lenguaje natural, **encerrado
al sistema de diseño + reglas MODO**. Complementa `visual-editor-wiring.md`: el
wiring nativo da click-to-edit; este da edición conversacional asistida por IA.
Caso canónico: modo-landing PR #1523 (`feat/storyblok-visual-editor`), probado en
vivo con Gemini Flash editando el hero respetando voz rioplatense.

## Arquitectura (las piezas)

```
[[...slug]] (gated dev) → <CMSEditorChat> (dynamic ssr:false)
   story + onApplyOps                      │ {body, message, model}
   ▼                                        ▼
 setStory (re-render vivo) ◄── ops ── POST /api/cms-editor (server-only)
                                            │ API key del provider (NUNCA al browser)
                                            ▼  system prompt MODO + tool/function-calling
                                       Claude | Gemini → {ops, notes}
```

- **`applyOps(body, ops)`** — pure fn, aplica `edit_text`/`reorder`/`add`/`remove`
  al body en memoria (efímero). `add` validado contra un **catálogo cerrado** de
  componentes (rechaza lo que no existe). Copia profunda, no muta. Testeable.
- **`componentCatalog.ts`** — data-only (sin imports React) → usable en cliente,
  API route y tests sin arrastrar el árbol de componentes. Evita el error
  `Cannot find module '@/ui-lib'` al importar el registry real en tests/SSR-light.
- **system prompt** — embebe brand voice (voseo, sin buzzwords, frases cortas,
  sin emojis, concreto, sin claim falso) + catálogo + reglas de ops. El schema de
  la tool usa `enum` con los nombres de componentes → el modelo **no puede
  inventar** componentes fuera de MODO.
- **API route dev-only** — `if (!isLowEnv()) return 404`. La key es server-only
  (no en `next.config` env). Panel gated `preview && isLowEnv` + `ssr:false`.

## Multi-provider: un solo contrato de ops, dos APIs

Claude (tool-use) y Gemini (function-calling) devuelven el **mismo** `{ops, notes}`.

| | Claude | Gemini |
|---|---|---|
| Endpoint | `api.anthropic.com/v1/messages` | `generativelanguage.googleapis.com/v1beta/models/{model}:generateContent` |
| Auth | header `x-api-key` + `anthropic-version` | header **`x-goog-api-key`** (NO `?key=` en la URL → no leakea en logs) |
| Tools | `tools:[{name,input_schema}]` + `tool_choice:{type:'tool',name}` | `tools:[{function_declarations}]` + `tool_config:{function_calling_config:{mode:'ANY',allowed_function_names}}` |
| Forzar tool | `tool_choice` | `mode:'ANY'` |
| Parse | `content[].type==='tool_use'` → `.input` | `candidates[0].content.parts[].functionCall.args` |
| Model ids | `claude-sonnet-4-6`, `claude-opus-4-8`, `claude-haiku-4-5-20251001` | alias `gemini-flash-latest`, `gemini-pro-latest` (robustos a versionado) |

### Gotchas Gemini function-calling (verificados en vivo)

1. **Tipos en MAYÚSCULA**: `OBJECT/ARRAY/STRING/NUMBER/BOOLEAN` (no lowercase como Anthropic/JSON-schema).
2. **OBJECT exige `properties`**: un campo freeform tipo `fields:{type:'OBJECT'}` sin properties es rechazado. Workaround: declararlo `STRING` (JSON serializado) y `JSON.parse` en el route (`normalizeOps`).
3. **Auth por header** `x-goog-api-key`, no `?key=` (lo segundo funciona pero leakea la key en logs/URL).
4. **Model alias `-latest`**: `gemini-2.5-flash` puede no resolver según key/región; `gemini-flash-latest` es más robusto.
5. Mensajes: `contents:[{role:'user'|'model', parts:[{text}]}]` (assistant→`model`); system aparte en `system_instruction`.

## Reglas de diseño que se respetaron

- Catálogo cerrado (`enum`) en ambos providers → imposible inventar componentes.
- Edición de **contenido** (campos de texto), no de clases/colores/layout: el
  design system ya vive en los componentes. El chat no toca CSS.
- Prompt caching en Claude (system prompt grande y estático con `cache_control`).
- `summarizeBodyForPrompt`: manda solo uid + component + strings (recortados),
  no el blok entero (assets/refs) → menos tokens.

## Por qué dev-only

Editor in-app que muta contenido + key de IA server-side = jamás en prod público.
Triple gate: API route 404 si no es low-env, panel solo si `preview && isLowEnv`,
`dynamic ssr:false` (no entra al bundle de render prod). El Visual Editor nativo
de Storyblok SÍ corre en prod (vía firma), pero este chat IA es herramienta local.
