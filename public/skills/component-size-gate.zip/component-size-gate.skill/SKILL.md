---
name: component-size-gate
description: Use this skill to add or maintain an automated architecture gate that fails when a UI file grows past a line budget, with a grandfathered allow-list that can only shrink (boy-scout migration). Stops new god-components without forcing a big-bang refactor of existing ones. Framework-agnostic; distilled from a production app's check:architecture script.
---

An automated gate (run in your `validate`/CI step) that caps UI-file size so god-components
can't grow unchecked — while not punishing the debt you already have.

## The rule

- A file under your UI root (e.g. `src/components/**`, `src/app/**` excluding `api/`) that
  exceeds **N lines** (400 is a sane default) is a violation.
- A **grandfathered allow-list** holds the files already over budget the day you add the gate.
  Those don't fail the build — but the gate is **shrink-only**: a grandfathered file may be
  edited, yet if it grows *or* a new file crosses the budget, the gate fails.
- New files have zero tolerance: cross the budget → fail.

## Why grandfathered + shrink-only

Big-bang "split every god-component now" refactors are risky and never get prioritized. This
gate freezes the debt (no new offenders, existing ones can't get worse) and rewards
incremental boy-scout cleanup: every time someone touches a grandfathered file and shaves it
under budget, it drops off the list permanently. The list only goes down.

## Implementation sketch (Node, no deps)

```js
const MAX = 400;
const GRANDFATHERED = new Set([/* paths over budget on day one */]);
const isUi = r => r.startsWith('src/components/') ||
                  (r.startsWith('src/app/') && !r.startsWith('src/app/api/'));

const violations = [];
for (const file of uiFiles) {
  const lines = countLines(file);
  if (lines <= MAX) continue;
  if (GRANDFATHERED.has(file)) { stillGrandfathered.push(file); continue; }
  violations.push(`R4 ${file}: ${lines} lines > ${MAX} (split it)`);
}
// fail if violations.length; otherwise print "(N grandfathered pending migration)"
```

Pair it with the report line: `Architecture check passed (N grandfathered violation(s)
pending boy-scout migration)` so the debt stays visible without blocking.

## Maintenance

- When you split a god-component below budget, **remove it from `GRANDFATHERED`** in the same
  PR — that's what makes the list monotonically shrink.
- Don't add to the list. If a legit large file appears (generated, data table), exclude it by
  path/glob with a comment, not by grandfathering.
- Keep this rule beside your other static arch rules (no-Firestore-in-UI, layer-import
  boundaries) in one `check:architecture` script wired into `validate`.

## One line

UI file > N lines fails; a shrink-only grandfathered list freezes existing debt and rewards
boy-scout splits — no big-bang refactor, no new god-components.
