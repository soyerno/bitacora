#!/usr/bin/env node
// prompt-coach · ACTIVE — UserPromptSubmit hook.
// Classifies each prompt the user submits and, ONLY when it's weak
// (a vague work-launch or a blind irreversible-action bundle toward prod),
// injects a one-line directive telling Claude to coach the user in-line.
// Silent otherwise (good prompts get no nag = positive reinforcement).
//
// Wired in ~/.claude/settings.json under hooks.UserPromptSubmit.
// Toggle off: set env PROMPT_COACH_OFF=1.  Sensitivity: PROMPT_COACH_COOLDOWN (seconds, default 480).
//
// Never blocks, never throws to the session: any error → exit 0 silent.

import fs from 'fs';
import path from 'path';

const DATA_DIR = path.join(path.dirname(new URL(import.meta.url).pathname), 'data');
const STATE = path.join(DATA_DIR, 'coach-state.json');
const COOLDOWN = (parseInt(process.env.PROMPT_COACH_COOLDOWN || '', 10) || 480) * 1000;

function emit(additionalContext) {
  process.stdout.write(JSON.stringify({
    suppressOutput: true,
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext },
  }));
  process.exit(0);
}
function silent() { process.exit(0); }

if (process.env.PROMPT_COACH_OFF === '1') silent();

// ---- read stdin ----
let raw = '';
try { raw = fs.readFileSync(0, 'utf8'); } catch { silent(); }
let input;
try { input = JSON.parse(raw); } catch { silent(); }
const prompt = (input && input.prompt) || '';
const session = (input && input.session_id) || 'global';
const t = prompt.trim();
if (!t || t.startsWith('<')) silent();

const low = t.toLowerCase();
const len = t.length;

// ---- skip: not a coachable launch ----
// pure approvals / control tokens — these are VALID as responses, never nag them
const APPROVAL = /^(si|sí|ok|oka|okok|dale|listo|ya|no|nop|gracias|👍|merge|continua|continúa|continue|seguimos|sigue|reintenta|valida|validá|publica|actualiza|1|a|b)\.?$/;
if (APPROVAL.test(low)) silent();
if (low.endsWith('?') && len < 80) silent();          // a question, not a work-launch

// already-strong prompt → stay silent (reinforce good behavior)
const SCOPE = /no toques|no rompas|no cambies|solo |sólo |únicamente|unicamente|sin tocar|quirúrgic|quirurgic|alcance|scope|mínimo|minimo/;
const CRITERION = /listo *=|criterio|hasta que|debe quedar|queda listo cuando|test|pasa|verde|sin error|funcione cuando/;
const PLAN = /enfoque|opciones|propon|propón|propone|planific|planea|antes de codear|no codees|dame .* (plan|enfoque|opciones)/;
if (len >= 120 || SCOPE.test(low) || CRITERION.test(low) || PLAN.test(low)) silent();

// ---- classify weak patterns ----
const PROD_BUNDLE =
  /(merge|deploy|publica|sube|push).*(prod|publica|deploy|merge|ambientes?)/.test(low) ||
  (/\bmerge\b/.test(low) && /(publica|deploy|prod|sube)/.test(low)) ||
  /(commit.*pr.*merge|sube hasta prod|publica a prod|deploya|merge y (publica|deploy|continua|seguimos))/.test(low);

const WORK_VERB =
  /^(complet(a|á)|termin(a|á)|arregl(a|á)|haz|hac(e|é)|hazlo|comienz(a|á)|comenz(á)|mejor(a|á)|aplic(a|á)|implement(a|á)|resolv(e|é)|segu(i|í)|gener(a|á)|crea|cre(á)|arma|arm(á)|sum(a|á)|agreg(a|á))\b/.test(low);
const VAGUE_WORK = WORK_VERB && len < 70;

let type = null;
if (PROD_BUNDLE) type = 'prod-bundle';
else if (VAGUE_WORK) type = 'vague-launch';
if (!type) silent();

// ---- rate limit (per session) ----
let state = {};
try { state = JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch { state = {}; }
const now = Date.now();
const last = state[session];
if (last && (now - last.ts) < COOLDOWN && last.type === type) silent();  // same nag too soon
try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  state[session] = { ts: now, type };
  fs.writeFileSync(STATE, JSON.stringify(state));
} catch { /* non-fatal */ }

// ---- the nudge (a directive to Claude; Claude delivers coaching in voseo) ----
if (type === 'prod-bundle') {
  emit(
    '[prompt-coach · activo] El usuario encadena acciones irreversibles hacia prod sin checkpoint humano. ' +
    'Ofrecé en un bloque corto una VERSIÓN MEJORADA de SU pedido que incluya un checkpoint de revisión ' +
    '(mostrar el diff / blast-radius / qué puede romper) ANTES de mergear/publicar/deployar, encabezada exactamente ' +
    '"💡 Probá pedirlo así:" y entre comillas. Luego esperá su OK antes de shippear a prod. ' +
    'Si ya revisó el diff en esta sesión, no repreguntes. Una sola vez.'
  );
} else {
  emit(
    '[prompt-coach · activo] El prompt del usuario es un work-launch vago (sin criterio de "listo" ni límite de scope). ' +
    'NO le des una clase: ofrecé una VERSIÓN REESCRITA y concreta de SU prompt, inferida del contexto, que agregue ' +
    '"listo = <criterio verificable>" + "no toques <X>", en 1-2 líneas, encabezada exactamente "💡 Probá pedirlo así:" y el rewrite entre comillas. ' +
    'Después procedé con esa misma interpretación, nombrando tu supuesto. No esperes confirmación (salvo acción a prod). Una sola vez.'
  );
}
