#!/usr/bin/env node
// prompt-coach · DELIVERABLE eval — measures the PRODUCT, not how it was asked.
// Unit = a session's deliverable. Signals = automatic (git/tests/rework) + the agent's
// self-evaluation + the USER's verdict. Tracks deliverable quality over time and how well
// the agent's self-score is calibrated against the user's verdict.
//
// The human coordinates and judges the product; everything else automates.
//
// Usage:
//   node deliver-eval.mjs --self 78 --summary "..."     record this session's deliverable + agent self-score (0-100), awaits verdict
//   node deliver-eval.mjs --verdict 4                    set the USER verdict (1-5) on the latest pending snapshot
//   node deliver-eval.mjs --report                       print the trend + calibration, no new snapshot
//   node deliver-eval.mjs --since-sha <sha>              window = commits after <sha> (default: last eval marker, else last 24h)
//   --stamp <ISO>                                        snapshot date (pass "$(date +%FT%TZ)")
//
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const SKILL_DIR = path.dirname(new URL(import.meta.url).pathname);
const DATA_DIR = path.join(SKILL_DIR, 'data');
const argv = process.argv.slice(2);
const has = (f) => argv.includes(f);
const val = (f) => { const i = argv.indexOf(f); return i >= 0 ? argv[i + 1] : null; };

function git(cmd) {
  try { return execSync(`git ${cmd}`, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] }).trim(); }
  catch { return ''; }
}
const repoRoot = git('rev-parse --show-toplevel');
if (!repoRoot) { console.error('Not in a git repo.'); process.exit(1); }
const scope = path.basename(repoRoot);
fs.mkdirSync(DATA_DIR, { recursive: true });
const histPath = path.join(DATA_DIR, `deliverable-${scope}.jsonl`);
const markerPath = path.join(DATA_DIR, `deliverable-${scope}.marker`);

function readHistory() {
  if (!fs.existsSync(histPath)) return [];
  return fs.readFileSync(histPath, 'utf8').split('\n').filter(Boolean)
    .map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
let history = readHistory();

// ---------- --verdict: attach the user's product verdict to the latest pending snapshot ----------
if (has('--verdict')) {
  const v = parseInt(val('--verdict'), 10);
  if (!(v >= 1 && v <= 5)) { console.error('verdict must be 1-5'); process.exit(1); }
  const pendingIdx = [...history].reverse().findIndex((h) => h.verdict == null);
  if (pendingIdx < 0) { console.error('No pending deliverable to rate. Record one first (--self).'); process.exit(1); }
  const idx = history.length - 1 - pendingIdx;
  history[idx].verdict = v;
  fs.writeFileSync(histPath, history.map((h) => JSON.stringify(h)).join('\n') + '\n');
  console.log(`Verdict ${v}/5 set on deliverable "${history[idx].summary?.slice(0, 60) || history[idx].stamp}".`);
  renderChart(history);
  process.exit(0);
}

// ---------- --report ----------
if (has('--report')) { renderChart(history); process.exit(0); }

// ---------- auto signals from git window ----------
let sinceSha = val('--since-sha');
if (!sinceSha && fs.existsSync(markerPath)) sinceSha = fs.readFileSync(markerPath, 'utf8').trim();
if (!sinceSha) {
  // No baseline and no explicit window → establish baseline at HEAD; there is no deliverable
  // window to score yet. (Pass --since-sha to score a specific range manually.)
  const headNow = git('rev-parse HEAD');
  if (headNow) fs.writeFileSync(markerPath, headNow);
  console.log(`\nBaseline fijado en ${headNow.slice(0, 7)} para ${scope}. Todavía no hay ventana que evaluar — lo que commitees a partir de acá es el próximo entregable.`);
  console.log('Para evaluar un rango puntual: --since-sha <sha>.');
  process.exit(0);
}
const range = `${sinceSha}..HEAD`;

const shas = git(`log ${range} --pretty=format:%H`).split('\n').filter(Boolean);
const subjects = git(`log ${range} --pretty=format:%s`).split('\n').filter(Boolean);
const filesRaw = git(`log ${range} --name-only --pretty=format:`).split('\n').map((s) => s.trim()).filter(Boolean);
const files = [...new Set(filesRaw)];
const numstat = git(`log ${range} --numstat --pretty=format:`).split('\n').filter(Boolean);
let ins = 0, del = 0;
for (const l of numstat) { const [a, b] = l.split('\t'); ins += parseInt(a, 10) || 0; del += parseInt(b, 10) || 0; }

const TEST_RE = /\.(test|spec)\.|__tests__\//i;
const testsTouched = files.filter((f) => TEST_RE.test(f)).length;
const REWORK_RE = /^(revert|fixup|hotfix)|\brevert\b|^fix(\(|:|\b)|arregl|rollback/i;
const reworkCommits = subjects.filter((s) => REWORK_RE.test(s)).length;
const CONV_RE = /^(feat|fix|docs|chore|refactor|test|perf|build|ci|style)(\(.+\))?!?:/;
const conventional = subjects.filter((s) => CONV_RE.test(s)).length;

const auto = {
  commits: shas.length,
  files: files.length,
  insertions: ins,
  deletions: del,
  testsTouched,
  reworkCommits,
  conventionalRatio: shas.length ? Math.round((conventional / shas.length) * 100) : 0,
};

// transparent auto proxy (the USER verdict is ground truth; this is just a cheap signal)
let autoScore = 60;
if (testsTouched > 0) autoScore += 12;
autoScore += Math.min(10, Math.round(auto.conventionalRatio / 10));
autoScore -= Math.min(25, reworkCommits * 8);
if (auto.commits === 0) autoScore = 0;
autoScore = Math.max(0, Math.min(100, autoScore));
auto.autoScore = autoScore;

// ---------- record snapshot (needs agent self-eval) ----------
if (!has('--self')) {
  console.log(`\nAuto-señales de la sesión (scope ${scope}, rango ${sinceSha ? sinceSha.slice(0, 7) + '..HEAD' : 'últimas 24h'}):`);
  console.log(JSON.stringify(auto, null, 2));
  console.log('\nPara registrar el entregable, pasá tu autoevaluación:  --self <0-100> --summary "qué entregaste"');
  process.exit(0);
}
const self = parseInt(val('--self'), 10);
if (!(self >= 0 && self <= 100)) { console.error('--self must be 0-100'); process.exit(1); }
const summary = val('--summary') || '';
const stamp = val('--stamp') || new Date().toISOString();
const headSha = git('rev-parse HEAD');

const snapshot = { stamp, scope, headSha, selfScore: self, summary, verdict: null, auto };
fs.appendFileSync(histPath, JSON.stringify(snapshot) + '\n');
if (headSha) fs.writeFileSync(markerPath, headSha);   // advance window for next session
history = readHistory();

console.log(`\nEntregable registrado (snapshot ${history.length}). Auto-score ${autoScore}, self ${self}. Falta tu veredicto.`);
console.log(`→ Cuando lo evalúes:  node deliver-eval.mjs --verdict <1-5>`);
renderChart(history);

// ---------- render ----------
function bar(v, max, width = 18) { const f = Math.round((v / max) * width); return '█'.repeat(f) + '░'.repeat(width - f); }
function spark(values) {
  if (!values.length) return '';
  const blocks = '▁▂▃▄▅▆▇█';
  const min = Math.min(...values), max = Math.max(...values), span = max - min || 1;
  return values.map((v) => blocks[Math.round(((v - min) / span) * 7)]).join('');
}
function renderChart(hist) {
  if (!hist.length) { console.log('\nSin entregables registrados todavía.'); return; }
  const last = hist[hist.length - 1];
  console.log(`\n┌─ deliverable · ${scope} ─ ${hist.length} entregables`);
  console.log('│');
  console.log(`│  último: "${(last.summary || '').slice(0, 56)}"`);
  console.log(`│  self-score ${String(last.selfScore).padStart(3)}/100   auto ${String(last.auto.autoScore).padStart(3)}/100   veredicto ${last.verdict != null ? last.verdict + '/5' : '— (pendiente)'}`);
  console.log(`│  commits ${last.auto.commits}  ·  tests tocados ${last.auto.testsTouched}  ·  rework ${last.auto.reworkCommits}  ·  conv ${last.auto.conventionalRatio}%`);
  console.log('│');
  const verdicts = hist.filter((h) => h.verdict != null);
  if (verdicts.length >= 1) {
    console.log(`│  veredicto (1-5)   ${spark(verdicts.map((h) => h.verdict))}   prom ${(verdicts.reduce((a, h) => a + h.verdict, 0) / verdicts.length).toFixed(1)}`);
  }
  if (hist.length >= 2) {
    console.log(`│  self-score        ${spark(hist.map((h) => h.selfScore))}`);
    console.log(`│  auto-score        ${spark(hist.map((h) => h.auto.autoScore))}`);
  }
  // calibration: agent self vs user verdict (self/20 → 1-5 scale)
  if (verdicts.length >= 2) {
    const errs = verdicts.map((h) => Math.abs(h.selfScore / 20 - h.verdict));
    const mae = (errs.reduce((a, b) => a + b, 0) / errs.length).toFixed(2);
    console.log('│');
    console.log(`│  calibración self↔veredicto (MAE, menor=mejor): ${mae}  ${mae <= 0.5 ? '✓ calibrado' : mae <= 1 ? '~ aceptable' : '✗ overconfident/under'}`);
  }
  console.log('└─────────────────────────────────────────────');
  console.log(`\nHistory: ${histPath}`);
}
