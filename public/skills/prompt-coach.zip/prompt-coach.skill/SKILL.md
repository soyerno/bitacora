---
name: prompt-coach
description: Use this skill to (a) measure HOW THE USER prompts Claude and coach it live, and (b) measure the DELIVERABLE the agent ships, with the human as the product evaluator. It reads the project's Claude Code session logs to score prompting quality and chart progress, runs a live UserPromptSubmit hook that rewrites weak prompts, and runs a deliverable loop (auto git signals + agent self-eval + the user's 1-5 verdict + calibration) closed automatically by a Stop hook. Use when the user asks to "measure / re-measure my prompting", "track my prompt progress", "measure the deliverable", "evaluate the product", or wants a prompt/deliverable quality dashboard.
---

This skill measures **how the user writes prompts** (not how Claude responds), so they can improve
their side of the loop over time. Each run is a snapshot; snapshots accumulate into a progress chart.

## What it measures

It scans the project's session logs at `~/.claude/projects/<encoded-cwd>/*.jsonl`, extracts the
**real user-typed prompts** (filtering out tool results, system reminders, hook injections, image
placeholders, resumed-session duplicates), and computes per window:

- **score** (0–100) — composite. Rewards planning/scope/verify, penalizes vague delegation & blind bundling.
- **plan-first %** — prompts asking to plan/think/propose options *before* coding.
- **scope guard %** — prompts that bound scope ("solo X", "no toques", "quirúrgico").
- **verify-ask %** — prompts asking to validate/test/review.
- **vague-deleg %** — bare one-liner delegations ("si", "merge", "completa el trabajo", "continua").
- **blind-bundle %** — prompts chaining irreversible actions ("commit, merge y publica") with no checkpoint.
- **median length** — chars; telegraphic vs directed.

The formula lives in `measure.mjs` (`metrics()` → `m.score`). Tune weights there if priorities change.

## How to run

Default = **incremental**: measures only prompts since the last snapshot, so the trend reflects
recent behavior, not a slow-moving lifetime average.

```bash
# This repo provides the cwd. Pass --stamp so the snapshot date is correct
# (the script can't read the clock reliably in some sandboxes).
node ~/.claude/skills/prompt-coach/measure.mjs --stamp "$(date +%FT%TZ)" --html
```

Flags:
- `--all` — measure the full corpus (use for the **baseline / first** snapshot).
- `--window 7d` — measure prompts from the last N days (snapshot a fixed window).
- `--global` — measure every project under `~/.claude/projects` (overall prompting style).
- `--project NAME` — substring-match a different project folder.
- `--report` — print history + chart, do NOT add a snapshot.
- `--html` — also write `data/dashboard-<scope>.html` (offline, no CDN; openable in a browser).
- `--stamp <ISO>` — date for this snapshot. Always pass `"$(date +%FT%TZ)"`.

## Workflow when invoked

1. **First time in a repo** → take the baseline: run with `--all --stamp ...`. Tell the user the baseline score and the 1–2 weakest metrics.
2. **Re-measure** → run incremental (no `--all`), `--stamp ...`. Read the printed chart: report SCORE delta, which metrics moved, and whether the weak ones improved.
3. Surface the trend honestly — if vague-delegation went UP or score dropped, say so with the numbers.
4. Give **one concrete, prompt-level** suggestion tied to the worst metric (e.g. low plan-first → "open the next non-trivial feature with: 'dame 2 enfoques, el más simple, espero OK'").
5. Offer to open the HTML dashboard (`data/dashboard-<scope>.html`) if they want the visual chart.

Data persists in `~/.claude/skills/prompt-coach/data/history-<scope>.jsonl` (one JSON line per
snapshot) — that's the source for the chart. Never edit it by hand; re-run the skill to extend it.

## Active mode (live coaching during sessions)

Besides on-demand measurement, prompt-coach runs **live** via a `UserPromptSubmit` hook
(`coach-hook.sh` → `coach-hook.mjs`), wired in `~/.claude/personas/{modo,firulapp}/settings.json`.
On every prompt the user submits it classifies the text and, **only when it's weak**, injects a
one-line directive (`additionalContext`) telling Claude to coach the user inline. It fires for:

- **vague work-launch** — an imperative work verb with no "listo =" criterion and no scope limit,
  under ~70 chars ("completá el trabajo", "arreglá todo"). → Claude offers a concrete **rewritten
  version of the user's own prompt** (headed `💡 Probá pedirlo así:`, the rewrite quoted) that adds a
  verifiable done-criterion + what-not-to-touch, then proceeds with that same interpretation. This is
  the prompt-iteration loop: the user sees a better phrasing of what they just typed, not a lecture.
- **blind prod-bundle** — chaining irreversible actions toward prod ("merge y publicá", "subí a
  prod"). → Claude offers a rewritten request that bakes in a review checkpoint (show diff /
  blast-radius) and waits for OK before shipping.

It stays **silent** for approvals/control tokens ("si", "merge", "dale", "continuá"), questions,
and already-strong prompts (≥120 chars, or containing scope/criterion/plan markers) — silence on a
good prompt is the positive signal. Rate-limited per session (`PROMPT_COACH_COOLDOWN`, default 480s)
so the same nudge never repeats back-to-back. Never blocks, never errors the session.

**When Claude sees a `[prompt-coach · activo]` directive in context**, surface the suggested
rewrite (`💡 Probá pedirlo así:` + the quoted better prompt) in a short warm voseo block, then
continue — show the rewrite, don't lecture, and don't repeat it more than once per topic.

Toggle / tune:
- **Off:** `export PROMPT_COACH_OFF=1` (or remove the `UserPromptSubmit` block from the persona settings).
- **Less naggy:** raise `PROMPT_COACH_COOLDOWN` (seconds).
- **New persona:** add the same `hooks.UserPromptSubmit` block to that persona's `settings.json`.
- The classifier lives in `coach-hook.mjs` (`APPROVAL/SCOPE/CRITERION/PLAN/PROD_BUNDLE/WORK_VERB`);
  extend those regexes if phrasing drifts. Keep triggers tight — over-firing trains the user to ignore it.

## Deliverable evaluation (measure the product, not the prompt)

The higher-leverage half: instead of grading how the user phrases things, measure **what the agent
ships** and let the human be the **product evaluator**. The user coordinates; the agent delivers and
**self-evaluates**; the user gives a verdict. Unit = a session's deliverable. (`deliver-eval.mjs`,
closed automatically by `deliver-close-hook.mjs` on the `Stop` hook.)

The loop, per deliverable:
1. **Auto signals** from git (free): commits, tests touched, rework/reverts, conventional-commit ratio → a transparent `autoScore`.
2. **Agent self-eval**: the agent runs `deliver-eval.mjs --self <0-100> --summary "<honest, include the weak parts>"`.
3. **User verdict**: the user judges the product (`deliver-eval.mjs --verdict <1-5>`).
4. **Trend + calibration**: deliverable quality over time, and how far the agent's self-score sits from the user's verdict (MAE) — surfaces over/under-confidence.

```bash
node ~/.claude/skills/prompt-coach/deliver-eval.mjs --self 76 --summary "..." --stamp "$(date +%FT%TZ)"
node ~/.claude/skills/prompt-coach/deliver-eval.mjs --verdict 4        # the user's product verdict
node ~/.claude/skills/prompt-coach/deliver-eval.mjs --report           # trend + calibration only
node ~/.claude/skills/prompt-coach/deliver-eval.mjs --since-sha <sha>   # score a specific range manually
```

**Baseline semantics (load-bearing):** a deliverable is what's committed *after* a baseline, never
the repo's pre-existing history. The first run in a repo (no marker) **sets the baseline at HEAD and
stays silent** — it does NOT default to a time window, because in a busy shared repo that grabs
unrelated commits from other sessions and fires a false "deliverable" (a real bug this caught). The
`Stop` hook (`deliver-close-hook.mjs`) only fires when there are commits since the marker, at most
once per HEAD (no nag, no loop, respects `stop_hook_active`), and advances the marker on each eval.

**When Claude sees a `[prompt-coach · entregable]` directive**, run the self-eval honestly (including
what's weak), show the product summary in 1-2 voseo lines, ask the user for a 1-5 verdict, and do NOT
expand scope. If the work isn't actually finished, say so and don't evaluate yet. If the commits
aren't your deliverable (someone else's history), say so and don't fabricate a score.

Data: `data/deliverable-<repo>.jsonl` (snapshots), `…marker` (baseline), `…close-state.json` (anti-nag).
Wiring lives in `~/.claude/personas/{modo,firulapp}/settings.json` under `hooks.Stop`.

## Notes / gotchas

- **Incremental window can be empty** (no new sessions since last snapshot) → the skill prints the
  existing chart and skips adding a duplicate. That's correct, not an error.
- The metric regexes are Spanish-first (Rioplatense voseo) plus common English. If the user's
  phrasing drifts, extend the `VAGUE/PLAN/VERIFY/SCOPE/BUNDLE` patterns in `measure.mjs`.
- Score is **relative to the user's own history** — the point is the slope, not the absolute number.
  Compare snapshot-to-snapshot, not against some external ideal.
