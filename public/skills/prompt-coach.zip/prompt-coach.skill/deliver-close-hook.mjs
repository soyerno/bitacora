#!/usr/bin/env node
// prompt-coach · DELIVERABLE close — Stop hook.
// When Claude finishes a turn and there are NEW commits since the last deliverable eval,
// it blocks the stop once and tells Claude to run deliver-eval (self-score + product summary)
// and ask the user for a 1-5 verdict. The human just judges the product; the rest automates.
//
// Gated so it never nags or loops:
//   - fires only if `git log <marker>..HEAD` has commits (a real deliverable exists),
//   - at most ONCE per HEAD sha (if Claude doesn't eval, it won't re-block until HEAD changes),
//   - respects stop_hook_active (no recursion).
// Toggle off: PROMPT_COACH_OFF=1.  Never throws to the session: any error → exit 0 (stop normally).

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const SKILL_DIR = path.dirname(new URL(import.meta.url).pathname);
const DATA_DIR = path.join(SKILL_DIR, 'data');

function stop() { process.exit(0); }                 // let the turn end normally
if (process.env.PROMPT_COACH_OFF === '1') stop();

let input = {};
try { input = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { stop(); }
if (input.stop_hook_active) stop();                  // already in a hook-induced continuation

const cwd = input.cwd || process.cwd();
function git(c) {
  try { return execSync(`git -C "${cwd}" ${c}`, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] }).trim(); }
  catch { return ''; }
}
const root = git('rev-parse --show-toplevel');
if (!root) stop();
const scope = path.basename(root);
const head = git('rev-parse HEAD');
if (!head) stop();

const marker = path.join(DATA_DIR, `deliverable-${scope}.marker`);
const closeState = path.join(DATA_DIR, `deliverable-${scope}.close-state.json`);

// new commits since last eval?
let sinceSha = '';
try { sinceSha = fs.readFileSync(marker, 'utf8').trim(); } catch { /* none yet */ }
if (!sinceSha) {
  // No baseline yet → establish it at HEAD and stay SILENT. A deliverable is what gets
  // committed AFTER the baseline, never the repo's pre-existing history. (Prevents the
  // "first run in a busy shared repo grabs N unrelated commits" false trigger.)
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(marker, head); } catch { /* non-fatal */ }
  stop();
}
const newCommits = git(`log ${sinceSha}..HEAD --pretty=format:%H`).split('\n').filter(Boolean).length;
if (newCommits === 0) stop();                        // no fresh deliverable → end normally

// already prompted for this exact HEAD? don't nag / don't loop
let state = {};
try { state = JSON.parse(fs.readFileSync(closeState, 'utf8')); } catch { state = {}; }
if (state.lastPromptedHead === head) stop();

try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  state.lastPromptedHead = head;
  fs.writeFileSync(closeState, JSON.stringify(state));
} catch { /* non-fatal */ }

const reason =
  `[prompt-coach · entregable] Hay ${newCommits} commit(s) nuevos sin evaluar en ${scope}. ` +
  `Cerrá el loop de entregable: (1) corré ` +
  `\`node ~/.claude/skills/prompt-coach/deliver-eval.mjs --self <0-100> --summary "<qué entregaste, honesto>" --stamp "$(date +%FT%TZ)"\` ` +
  `con tu autoevaluación honesta del PRODUCTO (incluí lo flojo). (2) Mostrale al usuario el resumen del producto en 1-2 líneas (voseo). ` +
  `(3) Pedile su veredicto 1-5 y, cuando lo diga, corré \`deliver-eval.mjs --verdict <n>\`. ` +
  `No expandas el alcance ni sigas con otro trabajo: solo cerrá este entregable. Si el trabajo NO está terminado, decílo y no evalúes todavía.`;

process.stdout.write(JSON.stringify({ decision: 'block', reason }));
process.exit(0);
