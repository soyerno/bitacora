#!/usr/bin/env bash
NODE="$(command -v node 2>/dev/null || true)"
[ -z "$NODE" ] && NODE="/Users/guillermohernandesouza/.nvm/versions/node/v24.4.1/bin/node"
exec "$NODE" "$(dirname "$0")/deliver-close-hook.mjs"
