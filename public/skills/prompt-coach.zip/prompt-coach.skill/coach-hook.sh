#!/usr/bin/env bash
# Resolve node robustly: prefer PATH, fall back to the nvm binary.
NODE="$(command -v node 2>/dev/null || true)"
[ -z "$NODE" ] && NODE="/Users/guillermohernandesouza/.nvm/versions/node/v24.4.1/bin/node"
exec "$NODE" "$(dirname "$0")/coach-hook.mjs"
