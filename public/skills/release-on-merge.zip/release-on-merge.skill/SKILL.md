---
name: release-on-merge
description: Use this skill to wire automated release-on-merge with semantic-release — every merge to the default branch computes the next version from Conventional Commits, tags it, publishes a GitHub Release, and updates the changelog. Captures the two gotchas (disable the commit hook inside the release job; the race between parallel merges). Use when setting up automated versioning/changelog/releases, or debugging a release job that hangs or mis-versions.
---

Every merge to `main` triggers a release: semantic-release reads the Conventional Commits since
the last tag, computes the next semver, tags it, publishes a GitHub Release, and appends to
`CHANGELOG.md`. No manual version bumps.

## Wiring

- A CI job on push-to-`main` runs `semantic-release` with the GitHub plugin (tag + release +
  changelog commit). Versions derive from commit types: `fix:` → patch, `feat:` → minor,
  `BREAKING CHANGE:`/`!` → major.
- Requires Conventional Commits to be real — enforce them (commitlint, or a caveman-commit-style
  generator) or the version math is garbage in/garbage out.

## The two gotchas (both cost real time)

1. **Disable the commit hook inside the release job.** semantic-release makes its own commit
   (the changelog/version bump). If your husky `pre-commit` runs there, it re-triggers the gate
   inside CI and can hang or fail the job. Set `HUSKY=0` (or equivalent) in the release job's env.
2. **Race between parallel merges.** Two PRs merging to `main` close together can race the release
   job — the second runs against a tree the first just tagged. Serialize the release job
   (concurrency group) so only one release runs at a time; let the later one pick up both commits.

## Verify it's live

After the first qualifying merge: a new git tag exists, a GitHub Release is published with notes,
and `CHANGELOG.md` has a new section. The first release often lands as a minor (e.g. v0.2.0) if
the history has accumulated `feat:` commits.

## One line

semantic-release on push-to-main: Conventional Commits → tag + GitHub Release + changelog;
set `HUSKY=0` in the release job and serialize it (concurrency group) to dodge the parallel-merge race.
