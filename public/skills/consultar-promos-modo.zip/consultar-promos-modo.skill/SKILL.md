---
name: consultar-promos-modo
description: Responder consultas sobre promociones, comercios adheridos y bancos asociados de MODO usando el MCP `modo-promos`. Auto-invocar cuando el usuario haga preguntas tipo "¿qué promos hay?", "¿cuáles son los descuentos de hoy?", "¿qué promos tiene Banco Galicia?", "¿qué comercios aceptan MODO?", "promociones vigentes", "descuentos de supermercados", "promo para restaurantes", "cashback de cines", o cualquier consulta orientada a obtener una respuesta humana sobre el catálogo de promos de MODO. Complementa al skill `modo-promos` (que es referencia técnica del MCP); este skill se enfoca en mapear preguntas en lenguaje natural a las tools correctas y devolver respuestas en formato consumible por el usuario final.
---

# consultar-promos-modo

Skill task-oriented para responder preguntas en lenguaje natural sobre promociones MODO. Mapea cada tipo de pregunta a la(s) tool(s) MCP correctas y arma una respuesta lista para CX/usuario final.

## Prerequisito

MCP `modo-promos` registrado en `~/.claude/.mcp.json`. Tools disponibles bajo prefijo `mcp__modo-promos__modo_*`. Si no aparecen → fallback a fetch directo a `https://rewards-handler.playdigital.com.ar/...` (es público).

## Mapa intent → tool

| Pregunta del usuario | Tool(s) a invocar | Notas |
|----------------------|-------------------|-------|
| "¿qué promos hay?" / "promos vigentes" / "descuentos de hoy" | `modo_get_promotions_by_slot` con `slot="web-modo-hub-carrousel_principal"`, `limit=10` | Mostrar las primeras 5-6 cards |
| "promos de banco X" | (1) `modo_list_active_banks` para encontrar el `id` (2) `modo_get_promotions_by_slot` con `banks: [id]` | Confirmar nombre del banco con fuzzy match |
| "detalle de la promo Y" | `modo_get_promotion_detail` con `slug` | Si solo hay nombre, primero `modo_list_promotion_slugs` + match |
| "comercios adheridos a la promo Z" | (1) `modo_get_promotion_detail` para `application_id` (2) `modo_get_stores_by_promotion` | |
| "promos para supermercados / cines / restaurantes" | `modo_search_stores_online` con `search="supermercado"` + `modo_get_promotions_by_slot` | Cruzar resultados |
| "lista de bancos en MODO" | `modo_list_active_banks` | Devolver nombres en orden alfabético |
| "comercios online" / "donde puedo comprar online" | `modo_search_stores_online` con search del rubro | |
| "promos en develop/qa" (developer) | Cualquier tool con `env="develop"` (o qa/preprod/prod) | Avisar el ambiente en la respuesta |

Para detalles de cada query, ejemplos input/output y casos edge ver [references/queries-comunes.md](references/queries-comunes.md).

## Plantillas de respuesta

Para WhatsApp / chat: respuestas breves (3-5 líneas), emojis con moderación, URL en texto plano.
Para Slack/dashboard: tabla markdown con título, banco, vigencia, URL.

Templates concretos en [references/response-templates.md](references/response-templates.md).

## Convenciones MODO

- **Mencionar siempre los bancos asociados** cuando aplique (Galicia, Santander, BBVA, Macro, Nación, ICBC, Supervielle, Credicoop, etc.). Es preferencia explícita del equipo MODO.
- **No inventar** slugs, IDs, URLs ni fechas — todo debe venir de la respuesta del MCP. Si la tool devuelve vacío, decir "no tengo esa info" en vez de fabricar.
- **Default env = `prod`** salvo que el usuario diga lo contrario. Si la pregunta es técnica ("paridad prod vs develop"), llamar dos veces en paralelo.
- **Limit por default = 5-10** para queries de listado, para no abrumar.

## Slots conocidos

Slots más usados en queries de promos:

- `web-modo-hub-carrousel_principal` — hero/destacadas (default para "qué promos hay")
- `web-modo-hub-grilla_principal` — grilla completa
- `web-modo-hub-bancos` — agrupadas por banco
- `web-modo-hub-categorias` — por categoría/rubro
- `web-modo-hub-comercios` — por comercio

Catálogo completo en [references/slots-catalogo.md](references/slots-catalogo.md).

## Workflow recomendado

1. **Detectar intent** — clasificar la pregunta según el mapa de arriba.
2. **Resolver dependencias** — si el intent requiere lookups previos (banco ID, slug, application_id), hacerlos primero, en paralelo si son independientes.
3. **Ejecutar tool principal** — la que devuelve el resultado final.
4. **Aplicar template** — formato según el canal (WhatsApp/Slack/CLI).
5. **Citar fuente** — adjuntar la `url` que devuelve el MCP, así el usuario puede reproducirlo con curl.

## No hacer

- **No** llamar tools si el usuario solo pide ayuda general ("¿cómo funciona MODO?") — no es una consulta de promo.
- **No** filtrar promos por banco si el usuario no lo pide — devolver el slot completo.
- **No** mezclar este skill con `modo-promos` (technical reference); usar este para responder al humano, el otro para que el dev/agente entienda las tools.
- **No** repetir la misma tool si ya devolvió vacío — ofrecer alternativa o derivar.

## Referencia cruzada

- Skill `modo-promos` → referencia técnica del MCP (parámetros, schema, ambientes).
- MCP server → `/Users/hernan.desouza/Documents/Proyectos/modo/modo-landing-workspace/mcp-servers/modo-promos-mcp/`
- Skill `agente-cx-whatsapp` → cómo el agente WhatsApp consume estas mismas tools en runtime.
