# Plantillas de respuesta

## WhatsApp / chat (CX)

**Constraints**: máx 5 líneas, emojis con moderación, URL en texto plano, español rioplatense ("vos", "podés").

### Listado de promos

```
🏷️ Promos de hoy en MODO:

• {title 1} — {banco/condición corta}
• {title 2} — {banco/condición corta}
• {title 3} — {banco/condición corta}

Más en modo.com.ar/promos
```

### Detalle de una promo

```
{title}
📅 Hasta {valid_to}
🏦 Banco: {bank_names}
💳 {discount_mode_label} {discount_percentage}%
🔗 {url}
```

### Comercios adheridos

```
Comercios que tienen "{promo_title}":
• {store_name_1}
• {store_name_2}
• {store_name_3}
...y {N-3} más en {url}
```

### Cuando no hay resultado

```
No encontré promos vigentes con ese criterio 😕. ¿Querés que te pase las más populares de hoy? O escribinos a hola@modo.com.ar para más detalle.
```

### Cuando falla la API

```
⚠️ Tuvimos un problema consultando las promos. Probá de nuevo en unos minutos o entrá a modo.com.ar/promos
```

## Slack / dashboard interno (developer/PM)

**Constraints**: tabla markdown, más detalle, IDs visibles.

### Listado

```markdown
**Promos en `{slot}` ({env}) — {total_cards_count} totales**

| # | Title | Banco | CTA | URL |
|---|-------|-------|-----|-----|
| 1 | {title} | {bank} | {cta_type} | {cta_value} |
| 2 | ... | ... | ... | ... |

Fuente: {url}
```

### Detalle

```markdown
**{title}**

- Slug: `{slug}`
- Application ID: `{application_id}`
- Vigencia: {valid_from} → {valid_to}
- Bancos: {bank_names_csv}
- Modo: {discount_mode}
- Term & Cond: {terms_url}

Fuente: {url}
```

### Diff entre ambientes

```markdown
**Diff `{tool}` develop vs prod**

| Campo | develop | prod | Δ |
|-------|---------|------|---|
| Total | X | Y | ±N |
| ... | ... | ... | ... |

Items solo en develop: {list}
Items solo en prod: {list}
```

## CLI (developer)

Salida cruda + URL para reproducir con curl:

```
✓ {tool_name} env={env}
  url: {url}
  status: 200
  count: {N}

  {data preview, primeras 3 items en JSON formateado}

Reproducir: curl '{url}'
```

## Reglas comunes

- **Bancos**: usar el `name` que devuelve el MCP exactamente, no inventar abreviaturas. "Banco Nación" no "BNA", "Galicia" no "BG".
- **URLs**: siempre incluir la URL del backend MODO (`cta_value`) cuando aplique — el usuario suele querer ir directo.
- **Vigencia**: formatear `valid_to` a DD/MM/AAAA en respuestas a usuario final; ISO en logs/dashboards.
- **Cashback %**: mostrar el `discount_percentage` con `%` literal. Si es por monto fijo (`cashback_manual`), decir "cashback fijo de $X".
- **Truncado**: si `cards.length > 5` en WhatsApp, mostrar las primeras 5 + "y N más en {url}".
