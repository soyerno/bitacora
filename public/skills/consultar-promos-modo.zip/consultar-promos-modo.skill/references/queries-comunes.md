# Queries comunes — recetas

## "¿Qué promos hay?" / "Promos vigentes"

**Tool**: `mcp__modo-promos__modo_get_promotions_by_slot`
**Args**: `{ slot: "web-modo-hub-carrousel_principal", limit: 10 }`

**Procesar**:
- Devuelve `{ slot_id, slot_title, total_cards_count, cards: [...] }`
- Cada card: `{ id, title, cta_value (URL), cta_type, suggested_order, cards: [...sub] }`
- Mostrar las primeras 5 ordenadas por `suggested_order`.

## "Promos de Banco Galicia" (o cualquier banco)

**Paso 1** — resolver bank ID:
```
mcp__modo-promos__modo_list_active_banks { source: "web_modo" }
```
Buscar entre `data[]` el `id` cuyo `name` matchea "Galicia" (fuzzy). En MODO el name suele venir como `"Galicia"`, `"Banco Nación"`, `"BBVA"`, etc.

**Paso 2** — filtrar slot por bank:
```
mcp__modo-promos__modo_get_promotions_by_slot {
  slot: "web-modo-hub-carrousel_principal",
  banks: ["88d8705e-2dda-46f9-8411-bb4916af858e"],
  limit: 10
}
```

## "Detalle de la promo X" (cuando se conoce el slug)

```
mcp__modo-promos__modo_get_promotion_detail { slug: "coto-mayo" }
```

**Procesar**: devuelve título, descripción, vigencia (`valid_from`, `valid_to`), `application_id`, bancos asociados (otro objeto), términos y condiciones (URL).

## "Detalle de la promo X" (solo nombre, sin slug)

**Paso 1** — listar slugs:
```
mcp__modo-promos__modo_list_promotion_slugs { statuses: ["running"] }
```

**Paso 2** — fuzzy match con el nombre que dio el usuario.
**Paso 3** — `modo_get_promotion_detail` con el slug matcheado.

## "Comercios adheridos a la promo X"

**Paso 1** — slug → `application_id`:
```
mcp__modo-promos__modo_get_promotion_detail { slug: "..." }
```
Leer `application_id` del payload.

**Paso 2** — resumen de stores:
```
mcp__modo-promos__modo_get_stores_by_promotion { applicationId: "..." }
```
Devuelve `{ stores: { count, items }, brands: { count, items }, groups: { count, items } }`.

**Paso 3 opcional** — paginar por tipo:
```
mcp__modo-promos__modo_get_stores_by_type {
  applicationId: "...",
  type: "stores",   // o "brands" o "groups"
  page: 1,
  limit: 10
}
```

## "Comercios donde puedo usar MODO online"

```
mcp__modo-promos__modo_search_stores_online { search: "", limit: 20 }
```
Devuelve `{ stores: [...], pagination: {...} }`. Cada store tiene `name`, `logo`, `categories`, `application_count`.

## "Comercios de supermercado / restaurante / cine"

```
mcp__modo-promos__modo_search_stores_online { search: "supermercado", limit: 10 }
```
El backend hace match por nombre + categoría. Para casos comunes:
- "super" / "supermercado" → Coto, Carrefour, Día, Jumbo, Disco, Vea
- "cine" → Cinemark Hoyts, Cinépolis, Showcase
- "restaurante" / "comida" → Burger King, McDonalds, PedidosYa, Rappi
- "farmacia" → Farmacity, Dr. Ahorro
- "indumentaria" → Nike, Adidas, Frávega, Garbarino

## "Lista de bancos en MODO"

```
mcp__modo-promos__modo_list_active_banks { source: "web_modo" }
```
Devuelve array. Ordenar alfabéticamente por `name`. Campos típicos: `id`, `name`, `image`, `bcra_code`, `promotion_url`.

## "Slugs de todas las promos" (sitemap, batch lookup)

```
mcp__modo-promos__modo_list_promotion_slugs { statuses: ["running","next_for_product"] }
```
Devuelve `{ data: { slugs: [...] } }`. Para sitemap incluir `finished_for_product` también.

## "Paridad develop vs prod" (dev/QA)

Llamar dos veces en paralelo:
```
modo_list_active_banks { env: "develop" }
modo_list_active_banks { env: "prod" }
```
Diff por `id`. Si hay banco en develop que no está en prod → flag "pendiente de promoción".

## Casos edge

| Síntoma | Causa probable | Acción |
|---------|----------------|--------|
| `cards: []` en el slot | Slot incorrecto o sin promos activas | Reintentar con `web-modo-hub-grilla_principal` |
| 404 en `/landing/{slug}` | Slug typo o promo finalizada | Listar slugs y rematch |
| Stores devuelve vacío para una promo | La promo es PDV (no online) | Probar `modo_get_stores_by_type` con type="brands" |
| Banks vacío | Token de auth requerido para algunos campos | Llamar con `sessionToken` si el usuario lo pasó |
| Timeout | Backend MODO degradado | Esperar 30s y retry; si persiste, decir "servicio degradado" |
