# Catálogo de slots conocidos

Los slots son los IDs que usa el rewards-handler-bff para agrupar promociones según el contexto donde se muestran. El skill `consultar-promos-modo` mapea las preguntas del usuario al slot correcto.

## Slots web modo

| Slot ID | Uso | Default para |
|---------|-----|--------------|
| `web-modo-hub-carrousel_principal` | Hero / destacadas del homepage | "¿qué promos hay?" |
| `web-modo-hub-grilla_principal` | Grilla completa del listado de promos | "todas las promos" |
| `web-modo-hub-bancos` | Promos agrupadas por banco | "promos por banco" |
| `web-modo-hub-categorias` | Promos por categoría/rubro | "promos de gastronomía" |
| `web-modo-hub-comercios` | Promos agrupadas por comercio | "qué promos tiene Coto" |
| `web-modo-promo-banco-carrousel` | Carrousel dentro de una landing de banco | promo banco-específica |
| `web-modo-promo-categoria` | Carrousel dentro de una landing de categoría | promo categoría-específica |

## Slots app modo (webview)

Análogos a los web pero con `source=app_modo`. Cambian el orden, los assets y las CTAs. No usar para consultas de CX a menos que el usuario lo pida explícitamente.

| Slot ID | Uso |
|---------|-----|
| `mobile-modo-hub-carrousel_principal` | Hero in-app |
| `mobile-modo-hub-grilla_principal` | Grilla in-app |

## Source

Cada call al slot lleva `source`:

- `web_modo` (default) — modo.com.ar
- `app_modo` — webview dentro de la app MODO
- `web_bank` — landing de banco (ej. bancogalicia.com.ar con MODO)
- `app_bank` — webview dentro de la app del banco

## Reglas de elección

- **Si la pregunta es genérica** ("¿qué promos hay?") → `web-modo-hub-carrousel_principal` con `limit=10`.
- **Si la pregunta menciona un banco** → mismo slot, agregar `banks: [id]`.
- **Si la pregunta menciona un rubro** ("supermercado", "gastronomía") → no filtrar por slot; usar `modo_search_stores_online` con `search` + cruzar con `modo_get_promotions_by_slot` del slot principal.
- **Si la pregunta es para auditoría/sitemap** → usar `modo_list_promotion_slugs` directamente, no slots.

## Notas

- El slot título (`slot_title`) viene en la respuesta y suele ser legible ("Hub promo web MODO Carrousel principal"). Usarlo en respuestas técnicas/Slack.
- Los slots pueden tener subgrupos (`cards: [{ cards: [...] }]`) en categorías y bancos. Aplanar para listados simples.
- `total_cards_count` es el total real; `current_page_cards_count` es lo devuelto en esta página.
