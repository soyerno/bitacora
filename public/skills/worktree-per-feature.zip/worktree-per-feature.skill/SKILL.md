---
name: worktree-per-feature
description: Use this skill to enforce the discipline of doing each feature/fix in its own isolated git worktree + branch + PR, based off a fresh main, never mutating a shared checkout or another session's active branch. Prevents cross-session collisions and false-revert diffs. Use when running multiple parallel agent sessions on one repo, or whenever starting new work in a repo that already has in-flight branches.
---

Every feature/fix gets its **own git worktree + branch + PR**. Never mutate the shared checkout,
never push onto a branch another session is using. This is what makes parallel agent sessions on
one repo safe.

## The rules

1. **One worktree per unit of work.** Create an isolated worktree (`git worktree add`) so each
   task has its own working directory; sessions don't step on each other's files or index.
2. **Branch off a FRESH base.** Base the branch on `origin/main` freshly fetched — not on
   whatever the shared checkout happens to be sitting on. Stale bases produce diffs that look like
   reverts of work already merged (a real, recurring trap: a branch cut from an old main
   "reverts" translations/renames that main already landed).
3. **Never touch another session's active branch.** Don't check out, rebase, or push a branch you
   didn't create for this task. If `main` is already checked out in another worktree, your
   `--delete-branch` / checkout will fail — that's the guardrail working, not an error to force.
4. **One PR per worktree.** Open the PR from that branch; keep the worktree until merged.

## Workflow

```
git fetch origin
git worktree add ../wt-<slug> -b <type>+<slug> origin/main
# …work in ../wt-<slug>…
gh pr create --base main --head <type>+<slug>
# after merge:
git worktree remove ../wt-<slug>
```

## Gotchas (learned in production)

- **False-positive conflicts.** A squash-merged branch still shows "ahead of origin/main" and
  `merge-tree` reports CONFLICT — that's the squash, not real divergence. Re-cut from fresh main
  to confirm before "resolving" a phantom conflict.
- **`gh pr merge --delete-branch` fails when the branch is checked out elsewhere** (e.g. `main`
  live in another worktree). Merge succeeds; the local branch delete is what fails. Delete it
  from the worktree that owns it, or skip `--delete-branch`.
- **Audit before building.** In a repo with ~dozens of worktrees, most "unmerged" branches are
  already squash-merged. Verify against fresh main before re-doing work.

## One line

Isolated worktree + branch + PR per task, always cut from fresh `origin/main`, never touch
another session's branch — and treat squash-merge "conflicts" as phantoms until re-cut proves otherwise.
