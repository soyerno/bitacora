---
name: prompt-injection-hardening
description: Use this skill when any user- or third-party-controlled text reaches an LLM — chat messages, free-text notes, or stored user content re-shown to a model — including the second-order vector where stored UGC is later read by an external MCP/agent. Provides a pure sanitizer + delimiter-wrapping helper and the rule "untrusted text is DATA, never instruction". Framework-agnostic; distilled from a production AI app.
---

Any text controlled by the user — or by third parties via **stored content** — that travels to
a model (the chat message, a free-text note, the fields of a record re-shown to the model) is
**DATA, never instruction**. Treat it like SQL params: neutralize at the boundary, every time.

## Two threat vectors

1. **First-order** — the user types an injection directly into a chat/describe input.
2. **Second-order (stored)** — the user saves benign-looking UGC (a pet name, a case
   description); later an external MCP/agent reads it and the injected instruction fires in
   *that* agent's context. The sanitizer must run wherever stored UGC is composed into a prompt,
   not only at the chat entry point.

## The helper (pure, no imports — testable in isolation, fits a `domain/` layer)

Two variants by destination:

- **`sanitizeUntrusted(text, maxLen)`** — clean in place, NO delimiters. For UGC that is also
  shown in the UI (names, descriptions): you don't want tag noise on screen.
- **`wrapUntrusted(text, label)`** — additionally wraps the text in unambiguous delimiters
  (`<untrusted label="…">…</untrusted>`) for embedding in a prompt, where the model must tell
  data from order. Strips any injected `<untrusted>` tags so an attacker can't close the
  envelope early.

What the sanitizer does (in order): clamp length → strip control/invisible code points →
neutralize line-start override markers → collapse runs of whitespace → trim. It **never throws
and never drops the message** — it defangs, preserving shape/length.

### Invisible / control ranges to strip (table, not a literal regex)

Use a code-point table so the source file contains no invisible bytes (eyeball-reviewable,
copy-paste-safe). Strip C0 (except `\t`,`\n`), C1, zero-width (200B–200F), BIDI overrides
(202A–202E), math invisibles (2060–2064), BOM (FEFF). This kills ASCII smuggling / zero-width /
RTL-override tricks.

```ts
const INVISIBLE_RANGES = [
  [0x00,0x08],[0x0b,0x1f],[0x7f,0x9f],
  [0x200b,0x200f],[0x202a,0x202e],[0x2060,0x2064],[0xfeff,0xfeff],
];
```

### Override markers (anchored to line start, multilingual, case-insensitive)

Anchor to `^`/`\n` so legit prose mid-sentence doesn't match. Replace each matched marker's
non-space chars with `·` to keep shape without destroying surrounding prose. Cover both
languages you support: `ignore|disregard|forget|system prompt|new instructions|act as|you are
now` (+ your locale's equivalents).

## Where to wire it

- Chat route: `sanitizeUntrusted` (or `wrapUntrusted`) every user turn before it hits the model.
- `/describe`-style routes: same, on the free-text input.
- **Tool catalog / MCP handlers**: when composing stored record fields into a prompt for an
  external agent, `wrapUntrusted` them — this is the second-order seam most people miss.

## Test it

Unit tests on the pure function: zero-width injection, BIDI override, line-start "ignore your
instructions", length clamp, and "benign prose isn't mangled". No framework needed.

## One line

Untrusted text = data. `sanitizeUntrusted` for UI-shown UGC, `wrapUntrusted` for prompt
embedding; run it at the chat entry AND wherever stored UGC reaches an external agent.
