#!/usr/bin/env python3
"""Generate a slide-deck HTML from an existing lección article (for PDF export).

SDD reference: erno-modo `bitacora-reader-experience` · D7 + T18.
Use case: lección live as scroll-read on the site; presenter needs PDF for
in-person/Zoom briefing. This script regenerates the slides on-demand to
/tmp/ — the slides are NOT versioned (lección is the single source of truth).

Input: a lección HTML at `lectura/lecciones/<slug>.html` (data-type="leccion").
Output: `/tmp/leccion-slides-<slug>.html` ready for browser print → PDF.

Slide mapping:
  - Slide 01: hero (title + deck/subtitle + first 3 meta-pills).
  - Slide 02: TL;DR (the .tldr <ul> as bullets).
  - Slide 03: Learn-objectives (the .learn-objectives <ul>).
  - Slides 04..N: one slide per <section id> in .article-prose.
  - Slide N+1: closing CTA (footer text + link back to lección).

Usage:
  python3 leccion_to_slides.py <erno-modo-root> <slug>
  python3 leccion_to_slides.py ~/Documents/Proyectos/modo/erno-modo usa-la-bitacora

Then: open /tmp/leccion-slides-usa-la-bitacora.html → Cmd+P → Save as PDF.
"""
from __future__ import annotations

import re
import sys
from html.parser import HTMLParser
from pathlib import Path


# ── Lección parser ────────────────────────────────────────────────────

class LeccionExtractor(HTMLParser):
    """Pull out hero + TL;DR + learn-objectives + prose sections from a lección."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.title = ""
        self.deck_para = ""
        self.meta_pills: list[str] = []
        self.tldr_items: list[str] = []
        self.learn_items: list[str] = []
        self.sections: list[dict] = []  # {id, heading, body}
        self._mode: str = ""             # "title" / "deck" / "pill" / "tldr-li" / "learn-li" / "sect-h2" / "sect-body"
        self._buf: list[str] = []
        self._depth_section = 0
        self._depth_tldr = 0
        self._depth_learn = 0
        self._current_section: dict | None = None
        self._in_prose = False
        self._prose_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = dict(attrs)
        cls = (a.get("class") or "").split()

        if tag == "h1" and "article-title" in cls:
            self._mode = "title"; self._buf = []
            return
        if tag == "p" and "article-deck" in cls:
            self._mode = "deck"; self._buf = []
            return
        if tag == "span" and "meta-pill" in cls:
            self._mode = "pill"; self._buf = []
            return

        if tag == "section" and "tldr" in cls:
            self._depth_tldr = 1; return
        if self._depth_tldr > 0 and tag == "li":
            self._mode = "tldr-li"; self._buf = []; return
        if self._depth_tldr > 0 and tag in ("section", "ul", "ol", "div"):
            self._depth_tldr += 1; return

        if tag == "section" and "learn-objectives" in cls:
            self._depth_learn = 1; return
        if self._depth_learn > 0 and tag == "li":
            self._mode = "learn-li"; self._buf = []; return
        if self._depth_learn > 0 and tag in ("section", "ul", "ol", "div"):
            self._depth_learn += 1; return

        if tag == "div" and "article-prose" in cls:
            self._in_prose = True; self._prose_depth = 1; return

        if self._in_prose and tag == "section" and a.get("id"):
            self._current_section = {"id": a["id"], "heading": "", "body": ""}
            self._depth_section = 1
            return
        if self._depth_section > 0 and tag == "h2":
            self._mode = "sect-h2"; self._buf = []; return
        if self._depth_section > 0 and tag != "h2" and tag != "section":
            self._depth_section += 1
            self._mode = "sect-body"
            attr_str = "".join(f' {k}="{v}"' for k, v in attrs if v is not None)
            self._buf.append(f"<{tag}{attr_str}>")
            return

    def handle_endtag(self, tag: str) -> None:
        if self._mode == "title" and tag == "h1":
            self.title = "".join(self._buf).strip()
            self._mode = ""
            return
        if self._mode == "deck" and tag == "p":
            self.deck_para = "".join(self._buf).strip()
            self._mode = ""
            return
        if self._mode == "pill" and tag == "span":
            text = "".join(self._buf).strip()
            if text and len(self.meta_pills) < 3:
                self.meta_pills.append(text)
            self._mode = ""
            return

        if self._depth_tldr > 0:
            if self._mode == "tldr-li" and tag == "li":
                self.tldr_items.append("".join(self._buf).strip())
                self._mode = ""
                return
            if tag in ("section", "ul", "ol", "div"):
                self._depth_tldr -= 1
                return

        if self._depth_learn > 0:
            if self._mode == "learn-li" and tag == "li":
                self.learn_items.append("".join(self._buf).strip())
                self._mode = ""
                return
            if tag in ("section", "ul", "ol", "div"):
                self._depth_learn -= 1
                return

        if self._depth_section > 0:
            if self._mode == "sect-h2" and tag == "h2":
                if self._current_section is not None:
                    self._current_section["heading"] = "".join(self._buf).strip()
                self._mode = "sect-body"
                self._buf = []
                return
            if tag != "section":
                self._buf.append(f"</{tag}>")
                self._depth_section -= 1
                return
            if tag == "section" and self._depth_section == 1:
                if self._current_section is not None:
                    self._current_section["body"] = "".join(self._buf).strip()
                    self.sections.append(self._current_section)
                self._current_section = None
                self._depth_section = 0
                self._mode = ""
                self._buf = []
                return

    def handle_data(self, data: str) -> None:
        if self._mode in ("title", "deck", "pill", "tldr-li", "learn-li", "sect-h2", "sect-body"):
            self._buf.append(data)

    def handle_entityref(self, name: str) -> None:
        if self._mode:
            self._buf.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        if self._mode:
            self._buf.append(f"&#{name};")


# ── Slide rendering ───────────────────────────────────────────────────

SLIDE_CSS = """
@page { size: 16in 9in; margin: 0; }
* { box-sizing: border-box; }
body { font-family: 'Red Hat Display', system-ui, sans-serif; margin: 0; background: #FAFAF7; color: #1A1A1A; }
.slide {
  width: 16in; height: 9in; padding: 80px 96px;
  page-break-after: always; display: flex; flex-direction: column; justify-content: space-between;
  background: #FAFAF7; position: relative; overflow: hidden;
}
.slide:last-child { page-break-after: auto; }
.slide__chrome-top { display: flex; justify-content: space-between; align-items: center; font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 13px; letter-spacing: 0.12em; text-transform: uppercase; color: #6B6B6B; }
.slide__chrome-top .logo { color: #008859; font-weight: 700; }
.slide__body { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 24px; }
.slide__chrome-bottom { display: flex; justify-content: space-between; align-items: center; font-family: 'Quicksand', sans-serif; font-size: 12px; color: #6B6B6B; }
h1.title { font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 64px; line-height: 1.1; color: #008859; margin: 0; letter-spacing: -0.02em; max-width: 24ch; }
h2.heading { font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 44px; line-height: 1.15; color: #1A1A1A; margin: 0 0 24px; letter-spacing: -0.01em; }
p.deck-para, p.body { font-size: 22px; line-height: 1.5; color: #2A2A2A; max-width: 64ch; margin: 0; }
ul.bullets { font-size: 22px; line-height: 1.55; color: #2A2A2A; max-width: 64ch; padding-left: 24px; }
ul.bullets li { margin-bottom: 14px; }
.eyebrow { font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 13px; letter-spacing: 0.12em; text-transform: uppercase; color: #00471B; margin: 0; }
.meta-pills { display: flex; gap: 12px; flex-wrap: wrap; }
.meta-pill { background: #E6F4EE; color: #00471B; padding: 6px 14px; border-radius: 999px; font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; }
.counter { font-variant-numeric: tabular-nums; }
"""


def slide_html(idx: int, total: int, content: str, slug: str, footer_text: str) -> str:
    return f"""
<section class="slide">
  <div class="slide__chrome-top">
    <span class="logo">MODO</span>
    <span>{idx:02d} · {footer_text}</span>
  </div>
  <div class="slide__body">
    {content}
  </div>
  <div class="slide__chrome-bottom">
    <span>{slug} · soyernomodo.github.io/erno-modo</span>
    <span class="counter">{idx:02d} / {total:02d}</span>
  </div>
</section>
""".rstrip()


def render(extracted: LeccionExtractor, slug: str) -> str:
    pills_html = "".join(f'<span class="meta-pill">{p}</span>' for p in extracted.meta_pills)
    tldr_lis = "".join(f"<li>{x}</li>" for x in extracted.tldr_items)
    learn_lis = "".join(f"<li>{x}</li>" for x in extracted.learn_items)

    slides: list[str] = []
    slides.append(slide_html(
        1, 0,
        f'<p class="eyebrow">{extracted.meta_pills[0] if extracted.meta_pills else "Lección"}</p>'
        f'<h1 class="title">{extracted.title}</h1>'
        f'<p class="deck-para">{extracted.deck_para}</p>'
        f'<div class="meta-pills">{pills_html}</div>',
        slug, "Hero"
    ))
    if extracted.learn_items:
        slides.append(slide_html(
            2, 0,
            f'<p class="eyebrow">Qué vas a aprender</p>'
            f'<h2 class="heading">Objetivos</h2>'
            f'<ul class="bullets">{learn_lis}</ul>',
            slug, "Objetivos"
        ))
    if extracted.tldr_items:
        slides.append(slide_html(
            3, 0,
            f'<p class="eyebrow">TL;DR</p>'
            f'<h2 class="heading">Resumen</h2>'
            f'<ul class="bullets">{tldr_lis}</ul>',
            slug, "TL;DR"
        ))

    body_offset = len(slides) + 1
    for i, sec in enumerate(extracted.sections):
        # Strip remaining tags from the body, keep p/ul/li/strong/code; convert
        # things deeper than headlines to <p class="body">
        body = sec["body"]
        # Strip subsection h3 → bold + line break (slides don't nest deeper)
        body = re.sub(r"<h3[^>]*>(.*?)</h3>", r'<p class="eyebrow">\1</p>', body, flags=re.DOTALL)
        # Glossary-term spans → keep as plain
        body = re.sub(r'<span class="glossary-term">(.*?)</span>', r"\1", body, flags=re.DOTALL)
        # abbr → keep its text only
        body = re.sub(r'<abbr[^>]*>(.*?)</abbr>', r"\1", body, flags=re.DOTALL)
        # Wrap remaining plain paragraphs (anything outside <ul>/<p>/<h>) — keep simple
        slides.append(slide_html(
            body_offset + i, 0,
            f'<h2 class="heading">{sec["heading"]}</h2>{body}',
            slug, sec["heading"][:48]
        ))

    closing_idx = body_offset + len(extracted.sections)
    slides.append(slide_html(
        closing_idx, 0,
        f'<p class="eyebrow">Cierre</p>'
        f'<h1 class="title">Gracias</h1>'
        f'<p class="deck-para">Versión scroll-read + glosario en '
        f'<a href="https://soyernomodo.github.io/erno-modo/lectura/lecciones/{slug}.html">'
        f'soyernomodo.github.io/erno-modo/lectura/lecciones/{slug}</a></p>',
        slug, "Cierre"
    ))

    # Renumber slides with the final total
    total = len(slides)
    rendered = []
    for i, s in enumerate(slides, start=1):
        s = re.sub(r"\d{2:02d}", f"{i:02d}", s)  # noop in py
        s = re.sub(r"\b\d+ / \d+\b", f"{i:02d} / {total:02d}", s, count=1)
        rendered.append(s)

    return (
        '<!DOCTYPE html>\n'
        '<html lang="es">\n<head>\n'
        '<meta charset="UTF-8" />\n'
        f'<title>{extracted.title} · Slides · MODO</title>\n'
        '<link rel="preconnect" href="https://fonts.googleapis.com" />\n'
        '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n'
        '<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@600;700&family=Red+Hat+Display:wght@400;500;600;700&display=swap" rel="stylesheet" />\n'
        f'<style>{SLIDE_CSS}</style>\n'
        '</head>\n<body>\n'
        + "\n".join(rendered) +
        '\n</body>\n</html>\n'
    )


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 1
    repo_root = Path(sys.argv[1]).expanduser().resolve()
    slug = sys.argv[2]
    leccion_path = repo_root / "lectura" / "lecciones" / f"{slug}.html"
    if not leccion_path.exists():
        print(f"ERROR: not found {leccion_path}", file=sys.stderr)
        return 1
    html = leccion_path.read_text(encoding="utf-8")
    extractor = LeccionExtractor()
    extractor.feed(html)
    if not extractor.title:
        print("ERROR: could not parse <h1 class='article-title'> from lección", file=sys.stderr)
        return 1
    out_html = render(extractor, slug)
    out_path = Path("/tmp") / f"leccion-slides-{slug}.html"
    out_path.write_text(out_html, encoding="utf-8")
    print(f"✓ {len(extractor.sections)} prose sections")
    print(f"✓ {len(extractor.tldr_items)} TL;DR bullets")
    print(f"✓ {len(extractor.learn_items)} learn-objectives")
    print(f"✓ slides: {3 + len(extractor.sections) + 1}")
    print(f"✓ output: {out_path}")
    print(f"  → open file in browser, Cmd+P, Save as PDF for the presentation export.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
