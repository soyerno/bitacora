---
name: distill-design-system-skill
description: Use this skill to turn a project's design system into a reusable Claude skill so the agent designs on-brand by default. Meta-skill — it tells you HOW to author a `<project>-design` skill: runtime token source-of-truth, a pass/fail brand checklist, an atomic-design component map, and load-bearing non-negotiables. Use when onboarding a new product/brand or when brand drift keeps showing up in generated UI.
---

A brand skill exists so the agent produces on-brand UI without being re-briefed each time. This
meta-skill is the recipe for authoring one. Output: a `<project>-design/` skill folder.

## What goes in the skill (the parts that actually carry weight)

1. **Runtime source of truth for tokens — and name it.** Point at where tokens *actually live
   in production code* (e.g. `globals.css` `@theme inline`, a tokens module, a Tailwind theme),
   not a copy. If the skill also ships a spec file (`colors_and_type.css`), state that the two
   **must stay in sync — disagreement is a drift bug to flag**, not a style choice. The #1 way
   brand skills rot is a token copy that silently diverges from the app.
2. **`BRAND_CHECKLIST.md` — verifiable pass/fail.** Not vibes. Each line is a test someone can
   run pre-ship ("coral text on light uses the AA-safe dark variant", "buttons are pill"). This
   doubles as the rubric a brand-fidelity harness scores against.
3. **`ATOMIC_DESIGN.md` — map specimens ↔ real components.** For each layer
   (atoms/molecules/organisms/templates), link the design specimen to the actual component in
   `src/components/` so the agent reuses instead of reinventing. Mark what's brand-critical and
   where stories/coverage are missing.
4. **Non-negotiables, short and load-bearing.** 5–8 rules max, each one a thing that, if broken,
   reads as off-brand: the restraint rule for the accent color (and its AA-safe text variant),
   the type pairing (emotion font vs function font), the semantic colors that carry meaning (not
   decoration), the logo lockup ("never redraw it"), the icon set.

## How to author it

1. **Find the runtime tokens first.** Grep for the color/type definitions the build actually
   uses. That file is the spine; everything else references it.
2. **Interview the brand for non-negotiables.** What must never happen? Those become the
   checklist's hard fails.
3. **Walk the component tree** and build the atomic map from real files.
4. **Write the SKILL.md as a quick map** that points at the sub-files (checklist, atomic map,
   token spec, assets) rather than inlining everything — keep the entry skimmable.
5. **Split voice/copy into its own skill** ([[distill-brand-voice-skill]]) and UX/a11y into a
   third ([[distill-ux-a11y-layer-skill]]); design owns the *visual*. Cross-link them.

## Anti-patterns

- A token table pasted into the skill with no link to the runtime source → guaranteed drift.
- "Non-negotiables" that are actually 30 soft preferences → the agent can't tell what's load-bearing.
- A checklist of adjectives ("modern, clean") instead of runnable tests.

## One line

Point at the runtime tokens (and flag drift), ship a pass/fail BRAND_CHECKLIST, map specimens
to real components, and keep 5–8 load-bearing non-negotiables — split voice & UX into sibling skills.
