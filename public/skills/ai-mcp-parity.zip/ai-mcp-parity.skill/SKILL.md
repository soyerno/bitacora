---
name: ai-mcp-parity
description: Use this skill before shipping any PR in an app that exposes its functionality to AI — an in-app assistant and/or external MCP agents (Claude/ChatGPT/Gemini). It runs a pre-prod parity loop so the AI layer never drifts from the app's real features: a single tool catalog as source of truth, exposure rules (public vs assistant-only), docs/FAQ sync, and a blocking check. Invoke whenever a PR adds or changes a user-facing functionality. Framework-agnostic; distilled from a production app.
---

Pre-prod AI parity loop. Guarantees the app's AI layer (in-app assistant + external MCP
agents) never desyncs from the actual features. The automatic gate is a `check:ai-parity`
script you wire into CI and your validate step.

## Source of truth

ONE module (e.g. `src/mcp/tools.ts`), shared by the external MCP route (`/api/mcp`) and the
in-app assistant (`/api/ai/chat`). It declares:

- `FUNCTIONALITIES` — the canonical list of user-facing functionalities.
- `TOOLS` — each tool tagged with `functionality` + `exposure` (`public` | `assistant-only`).

## Checklist (run on every PR to prod)

1. **Does the PR add/change a user functionality?** If no → run `check:ai-parity` and stop.
2. **Tool.** Add/adjust the tool in the catalog with `functionality` + `exposure`:
   - Public read, or a write already attributable to an external caller → `public`.
   - Per-user write (needs a verified `userId`) → `assistant-only`. If there's no safe way to
     expose it yet, mark the functionality `assistantInformationalOnly` with a short reason.
     **Never** expose a per-user write to a shared-token external MCP — that attributes the
     action to an anonymous agent.
   - Real handler: call the server-callable function that already backs the feature
     (`*Db.ts`, `*Server.ts`, domain use-cases). No stubs.
3. **External route.** Confirm the MCP route only exposes `PUBLIC_TOOLS` — don't leak an
   assistant-only tool.
4. **Human-in-the-loop confirmation.** If the new tool is a write, add its case to the
   assistant's `proposalMessage()` (a natural-language summary the user confirms before it runs).
5. **Docs.** If the tool is `public`, add it to the MCP integration guide: catalog table +
   the tool-name enum in the connector schema.
6. **FAQ.** Keep one assistant entry and one MCP-connection entry in the public FAQ. Copy in
   natural brand voice — never telegraphic.
7. **System prompt.** Verify the assistant's `SYSTEM_PROMPT` describes the new functionality
   (the assistant explains it even when there's no actionable tool).
8. **Validate.** `check:ai-parity` must be green; if it fails, read the rule and fix.

## The gate, one line

`check:ai-parity` — P1 known functionality · P2 catalog fields present · P3 coverage
(every functionality reachable or explicitly informational-only) · P4 docs · P5 FAQ.
Blocking in CI and in validate.

## Security note (carries over from prompt-injection hardening)

Per-user writes attributed to an anonymous shared-token agent are a privilege/attribution
hole, not a convenience. The exposure split exists for that reason — keep it strict.
