---
name: distill-framework-conventions-skill
description: Use this skill to author a `<project>-<framework>` conventions skill for a repo running a modified/bleeding-edge/forked framework whose APIs differ from training data. Meta-skill — it gives the hard rule "read the local docs before writing framework code", the confirmed-stack section, and the known-traps list, so the agent stops shipping code from stale memory. Use when a repo pins an unusual framework version (Next 16, Tailwind v4, React 19, a fork) and the agent keeps assuming old APIs.
---

When a repo runs a framework version your training data predates or a fork that changed APIs,
the agent's biggest failure mode is **confidently writing code from memory that no longer
applies**. This meta-skill is the recipe for a guardrail skill. Output: a `<project>-<fw>/` skill.

## The one hard rule (lead with it)

**Before writing ANY framework code, read the relevant guide in the repo's own docs** —
`node_modules/<fw>/dist/docs/`, a `docs/` folder, or the pinned version's site. Heed deprecation
notices. Do not assume APIs from memory. Make this the first line of the skill; everything else
supports it.

## Sections the skill must have

1. **Confirmed stack, with the surprising bits called out.** List exact major versions and the
   conventions that differ from defaults: e.g. "Tailwind v4 — NO `tailwind.config.{ts,js}`; theme
   lives inline in `globals.css` via `@import "tailwindcss"` + `@theme inline`"; "App Router in
   `src/app/`"; "React 19". The value is in the deltas from what the agent expects.
2. **Where the tokens / config actually live.** Point at the real files (globals.css, postcss
   config) so the agent uses utility classes/vars instead of hardcoding.
3. **How to work (the loop).** Identify the area (routing / server components / data / fonts /
   images) → read its local doc FIRST → make surgical changes respecting the file's existing
   pattern → verify with the repo's real commands (`lint` / `build` / `test`).
4. **Known traps (from the repo's own history).** Mine past bug-fix commits for framework
   gotchas — "filesystem ops must be production-safe for <host>", "dynamic-route vs host-redirect
   conflicts", "generated types stale-poison a full typecheck (scope it to src/)". These are the
   highest-value lines because they're things memory can't know.

## How to author it

1. Read the repo's `AGENTS.md`/`CLAUDE.md` — the "this isn't the framework you know" rule often
   already lives there; the skill makes it loud and actionable.
2. `ls node_modules/<fw>/dist/docs/` (or equivalent) and confirm the docs are actually shipped.
3. Grep git log / fix commits for framework-specific gotchas → the traps list.
4. Keep it short and imperative — this skill is read right before touching framework code.

## One line

Lead with "read the local docs before writing framework code", list the confirmed stack's
surprising deltas, point at where config really lives, and mine the repo's fix history for traps.
