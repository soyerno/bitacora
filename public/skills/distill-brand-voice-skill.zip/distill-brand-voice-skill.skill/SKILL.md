---
name: distill-brand-voice-skill
description: Use this skill to turn a product's voice & tone into a reusable Claude skill so all user-facing copy sounds like the brand by default. Meta-skill — it tells you HOW to author a `<project>-voice` skill: non-negotiables, the persona, "say this not that" pairs, voice-constant/tone-modulating, and the guard that copy compression (caveman-style) never touches UI strings. Use when onboarding a brand or when generated copy keeps sounding robotic/off.
---

Copy is part of the brand as much as the accent color. A voice skill makes every UI string,
notification, empty state, and error sound like one specific person. This meta-skill is the
recipe. Output: a `<project>-voice/` skill.

## What the skill must nail

1. **A concrete persona, in one sentence.** Not "friendly and professional" — name *who* speaks.
   ("A well-informed neighbor who knows the area and actually helps." "A blunt senior engineer.")
   Everything downstream derives from this.
2. **Non-negotiables (hard fails).** Grammatical register (formal vs informal address — and in
   Spanish, voseo vs tuteo vs usted: pick ONE and forbid the others by example), casing rules,
   the brand name lockup, emoji policy ("rare and earned, only at the emotional peak"), honest
   numbers (real figures, no inflated stats), and "never robotic" (no "Action completed
   successfully" / "Error 404").
3. **Six-ish traits**, each a tension that prevents blandness ("urgent but calm", "optimistic
   not naive", "empathetic without condescending", "precise", "human not app-like").
4. **Voice is constant; tone modulates by moment.** List the moments (onboarding → warm;
   transactional flow → direct/efficient; the one celebratory peak; errors → honest, never
   blaming) and how the tone shifts while the voice stays.
5. **"Say this → not this" pairs.** The highest-signal section. 5–8 real before/after pairs for
   the actual surfaces (match found, alert, error, empty state, form label). The agent pattern-
   matches off these more than off adjectives.
6. **Lead with the actionable datum** in alerts/notifications (the what/where/when), then context.

## The compression guard (load-bearing)

If the environment runs a copy-compression mode (caveman-style "talk like caveman to save
tokens"), the voice skill MUST state: **that compresses how the *agent* talks to you — it NEVER
compresses the copy the app shows a user.** All output of this skill ships in full, natural
voice. Without this guard, brand copy silently degrades into telegraphic fragments.

## How to author it

1. Collect real strings from the product (good and bad), extract the implicit persona.
2. Turn every "we'd never say that" into a non-negotiable or a "not this" example.
3. Keep it skimmable; this skill is invoked mid-copywriting, not read end-to-end.
4. Cross-link the design skill ([[distill-design-system-skill]]) — voice owns words, design owns pixels.

## One line

Name the persona, fix the register/casing/emoji/honesty non-negotiables, give 5–8 say-this-not-
this pairs, separate constant-voice from per-moment-tone, and guard copy from agent-speak compression.
