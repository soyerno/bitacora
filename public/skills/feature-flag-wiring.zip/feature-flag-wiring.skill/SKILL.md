---
name: feature-flag-wiring
description: Use this skill when adding, editing, or auditing a feature behind an admin/runtime feature flag, or when asked to "validate feature-flag wiring / prove nothing of a disabled feature shows". Captures the contract (feature OFF ⇒ nothing related renders or is reachable), the layers to gate, the static-check blind spots, and the gating patterns so a disabled feature leaves zero visible trace. Framework-agnostic; distilled from a production Next.js app.
---

Feature-flag contract: **if a feature is OFF, NOTHING related is shown or reachable** — no
text, option, button, link, card, tab, notification, copy, nor third-party script. A central
**registry is the single source of truth**; the datastore (Firestore/Redis/env) holds only
boolean overrides, everything else falls back to `defaultEnabled`.

## Source of truth

One registry module (e.g. `src/config/features.ts` → `FEATURES`). Each feature declares the
surfaces it owns: `routes` (route-level 404 gate), `navIds` (navigation), `apis` (API gate),
`events` (analytics), optional `audience`. This declaration is what the static checks read.

## The 4 layers — and how to gate each

1. **Route** — every declared `route` has its layout/page call `isFeatureEnabled(key)` →
   `notFound()` (or framework 404). Admin-bypass features gate inside the component instead.
2. **Nav** — the nav/menu filters items by `navIds`; custom navs use a `{id: featureKey}` map
   + `isEnabled`.
3. **Component** — `<Feature flag={key}>…</Feature>` or `useFeature(key)`. Every component
   validates its OWN flag; never trust that the parent hid it.
4. **API** — each handler under an `api` prefix calls `requireFeature(key)` (or
   `requireFeatureOrAdmin`). Audited escape hatch: a commented allow-marker with a reason.

## The automatic gate (wire it into your validate/CI step)

- **coverage check** — statically asserts route→404-gate and api→requireFeature.
- **citations check** — no `<Link href>`/`router.push`/redirect to a gated route without a
  guard for that feature in the same module. Escape hatch: `// ff-allow:<key> <reason>`.

Both blocking. But know their **BLIND SPOTS** (this is where human review lives):

- The citations check is **module-level** and only sees links to gated routes. It does NOT
  prove every surface of a guarded module is itself gated.
- **Features with NO route/api are invisible to the checks** (chrome, assistants, ambient
  widgets, ads). Gate their surfaces by hand + test.
- **Cross-feature controls**: a control belonging to feature B living inside a surface of
  feature A (a bookmark from `collections` inside each feed post, a chat button from
  `messaging` on a card). The check can't see it.

## Gating patterns (pick by context)

- **Own screen/section** → `{isEnabled(key) && (…)}` at the call-site.
- **Presentational component with stories/tests** → prop `<feature>Enabled?: boolean`
  (default `true`); the call-site passes `isEnabled(key)`. Keeps stories/tests decoupled.
- **Component that is 100% one feature** → self-gate: wrap its return in `<Feature flag>` or
  `useFeature` + early-return null. If it has a story, add a decorator with the flag provider.
- **List/menu/quick-action item** → tag each item with `flag?: FeatureKey` and
  `.filter(a => !a.flag || isEnabled(a.flag))`.
- **Cross-feature control on a card** → optional handler + conditional render; the call-site
  passes the handler only when the feature is on (`onMessage={isEnabled('messaging') ? … : undefined}`).
- **Third-party scripts (layout)** → server-side: `featureFlags[key] && <Script…/>`.

## Add a new flag (checklist)

1. **Registry**: add the entry with `defaultEnabled`, real `routes/navIds/apis`, and `events`.
2. **Gate the layers** that apply with the patterns above.
3. **Surfaces with no route** (chrome, scripts, copy): gate by hand — the checks don't see them.
4. **Tests**: a unit test asserting `off ⇒ not visible` (provider with the flag false). If it's
   a public route, add an e2e with the seam below.
5. **Validate**: coverage + citations green, plus your full validate step.

## End-to-end invisibility seam (non-prod only)

A cookie (e.g. `ff-e2e`) carrying JSON overrides that the server honors ONLY in non-production
(`applyTestOverride`, no-op in prod). In Playwright: `context.addCookies([{name:'ff-e2e',
value: encodeURIComponent(JSON.stringify({ads:false})), domain:'localhost', path:'/'}])`.

Gotchas: auth-gated internal routes show a login wall that masks the gate → test on **public**
surfaces. `notFound()` in a streaming layout can return HTTP 200 in dev → assert on the
**content** ("Not found"), not the status.

## Audit ("prove nothing of a disabled flag shows")

1. Run both checks. 2. For EACH off-able feature, list its UI surfaces
(launcher/FAB/tab/section/card/chip/copy/script) and verify the guard — prioritize features
**without route/api** and **cross-feature** controls (the blind spots). 3. Reproduce with the
seam: turn the feature off, confirm real invisibility. 4. Pin findings with a gating test.

## One line

Registry = truth · gate 4 layers + no-route surfaces by hand · coverage + citations checks in
validate · human review covers cross-feature & route-less features · `ff-e2e` seam to prove it.
