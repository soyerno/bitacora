---
name: modo-landing-smoke-test
description: Smoke-testea modo-landing (modo.com.ar) por ambiente — valida rutas clave a nivel HTTP contra el edge live, compara prod vs preprod para cazar regresiones, y conoce qué versión está desplegada por env. Auto-invocable cuando el user diga "smoke test de modo-landing", "probá preprod", "validá las features en prod/preprod", "se rompió algo en X ambiente", "qué versión hay en preprod", "/smoke-modo-landing". Útil tras deploys (sobre todo migraciones Next) para verificar que las pages no rompen. Incluye el catálogo de pages high-risk sin tests (deeplink/qr/linking) que las migraciones de Next ponen en peligro.
---

# modo-landing smoke test

Validación rápida HTTP-level de las features de modo-landing contra el edge live, por ambiente. No reemplaza tests unitarios/integración — es la red de seguridad post-deploy cuando esos tests no existen (ver `reference/high-risk-pages.md`).

## Cuándo usar

- Después de un deploy a un ambiente (sobre todo migraciones Next que tocan routing/SSR/Image).
- Para comparar prod vs preprod y cazar regresiones de entorno.
- Para saber qué versión/ref está desplegada en un env.
- Cuando el user dice "se rompió X en preprod" / "probá que ande Y".

## Topología de hosts (gotcha #1)

modo.com.ar redirige el **apex → www con 301**. Siempre curl-ear el host `www.` o seguir redirects con `-L`, sino todo da 301 y parece roto.

| Env | Host canónico |
|---|---|
| prod | `www.modo.com.ar` |
| preprod | `www.preprod.modo.com.ar` |
| qa | `www.qa.modo.com.ar` |
| develop | `www.develop.modo.com.ar` |

`curl -sL` (follow redirects) + `-A "Mozilla/..."` (algunos edges filtran UA vacío).

## Smoke test rápido

```bash
~/.claude/skills/modo-landing-smoke-test/scripts/smoke.sh www.preprod.modo.com.ar
```

Imprime tabla `ROUTE · HTTP · TIME · BYTES · VERDICT · TITLE` y exit 1 si algo falla. Editar el array `ROUTES` para agregar/quitar rutas o cambiar la expectativa (`ok2xx` / `redirect-shell` / `404ok`).

## Interpretar resultados (gotcha #2 · deeplink shells)

Las pages de **deeplink/redirect** (`/qr`, `/account_linking`, `/account_linking_error`, `/personal_qr_error`, `/pagar`, `/recargas`) devuelven **200 con un shell mínimo (~10KB) y `<title>` vacío**. Eso es CORRECTO, no un fallo: hacen `getServerSideProps` + redirect client-side a la app / store. No las marques como rotas por el title vacío. El fallo real ahí sería 5xx o el body con "Application error: a client-side exception".

Las pages de contenido (`/`, `/comercios`, `/blog`, `/tiendas-online`, `/promos`) sí tienen `<title>` y body grande (35-60KB). Title vacío + body chico en una de éstas = sospechar SSR roto.

## Comparar prod vs preprod (gotcha #3 · regresiones de entorno)

Muchas pages son CMS-driven (Storyblok). Una page puede dar **404 en preprod y 200 en prod** porque falta la *story* en el Storyblok de preprod, no por código. Siempre comparar el mismo path en ambos hosts antes de declarar bug de código:

```bash
for h in www.modo.com.ar www.preprod.modo.com.ar; do
  printf "%-30s " "$h/promos"; curl -sL -o /dev/null -w "%{http_code}\n" -A "Mozilla/5.0" "https://$h/promos"
done
```

Si prod=200 y preprod=404 → regresión de entorno (CMS content o deploy viejo), reportar como tal, no como bug del PR. Caso observado 2026-05-27: `/promos` prod 200 / preprod 404.

## Qué versión está desplegada (antes de smoke-testear, sabé qué estás testeando)

```bash
gh api "repos/playsistemico/modo-landing/deployments?environment=preprod&per_page=1" \
  -q '.[0] | "\(.ref) | \(.created_at)"'
```

**Crítico**: si el deploy del PR que querés validar NO se promovió a ese env, vas a estar smoke-testeando la versión vieja. Caso 2026-05-27: preprod servía `main` (Next 12), no el alpha de la migración Next 16 → el smoke era baseline pre-migración, no validación de la migración.

## Tests locales (la red real, no el smoke)

```bash
cd <repo>
pnpm test                       # jest unit
pnpm test:specific -- -t "X"    # un test por nombre
pnpm build                      # lint + next build (parity con Frontend CI - Builder)
```

El smoke HTTP cubre "¿la page levanta?", no "¿la lógica es correcta?". Para pages sin tests (ver `reference/high-risk-pages.md`) el smoke es lo único que hay — insuficiente para redirects/deeplinks cuya lógica vive en JS client-side que curl no ejecuta. Ahí: agregar tests o validar con browser (chrome-devtools MCP / Playwright).

## Imágenes rotas · el smoke HTTP NO las ve (gotcha #4)

Las imágenes via `next/image` se cargan client-side y lazy. Un curl/HTTP smoke ve la page 200 aunque las imágenes estén rotas. Para cazarlas hay que ir al **browser** + cargar todas las lazy (scroll) + medir `naturalWidth`:

```js
// chrome-devtools evaluate_script — broken = render OK pero recurso falló
async () => {
  for (let y=0;y<=document.body.scrollHeight;y+=600){window.scrollTo(0,y);await new Promise(r=>setTimeout(r,180));}
  await new Promise(r=>setTimeout(r,2500));
  const imgs=[...document.querySelectorAll('img')];
  const broken=imgs.filter(im=>im.complete&&im.naturalWidth===0&&!(im.src||'').match(/adsct|pixel|doubleclick|facebook|analytics|tiktok|linkedin/));
  return { total: imgs.length, brokenCount: broken.length, brokenSrcs: broken.slice(0,8).map(im=>(im.currentSrc||im.src||'').slice(0,80)) };
}
```
- `naturalWidth===0` con box dimensionado = rota. Excluir tracking pixels (1x1 adsct/doubleclick).
- Lo que se ve "0x0" en un primer check suele ser **lazy aún no en viewport** — re-medí tras scroll antes de gritar.

**Sospecha #1 en una migración Next 12→16: `images.qualities`.** Next 16 rechaza `quality≠75` con 400. Probe directo del optimizer:
```bash
U="https%3A%2F%2Fa.storyblok.com%2Ff%2F...%2Fimg.png"   # url-encoded del src real
for q in 75 95 100; do echo "q=$q → $(curl -s -o /dev/null -w '%{http_code}' "https://www.preprod.modo.com.ar/_next/image?url=$U&w=640&q=$q")"; done
# 400 "q parameter (quality) of N is not allowed" → falta whitelist en next.config images.qualities
```
Fix en el skill `nextjs-pages-router-migration` `### Next 15 → 16`. Caso #1482: 19 imgs Storyblok del home (q=95) rotas.

## Fingerprint de versión Next (12 vs 16) · cuál build corre

`buildId` solo no dice la versión. Señal decisiva: los chunks. **Next 16 con Turbopack emite `_next/static/chunks/turbopack-*.js`**; Next 12 (webpack) no.
```bash
curl -sL "https://www.preprod.modo.com.ar/" | grep -oE '_next/static/chunks/turbopack-[^"]+' | head -1 && echo "→ Next 16 (Turbopack)"
```
El `buildId` con timestamp unix reciente (`build-1779…`) vs uno viejo también discrimina prod (build viejo) de un deploy de hoy. Útil para confirmar que estás testeando la migración y no el build anterior.

> Trap de deploys solapados: si ves un `ChunkLoadError` con un chunk cuyo timestamp NO matchea el `buildId` desplegado (ej. chunk `3735-1779826…` con buildId `1779891…`), sospechá **artefactos mezclados de deploys solapados/fallidos** (CloudFront sirviendo HTML de un build + chunk async de otro), no bug de código. Re-verificar tras UN deploy limpio + invalidación CDN antes de cazar el bundler.

## Anti-patterns

- Curl-ear el apex sin `-L` → todo 301, falso "roto".
- Marcar las deeplink pages como rotas por `<title>` vacío → es el shell esperado.
- Reportar un 404 de preprod como bug de código sin comparar contra prod → suele ser CMS content faltante.
- Smoke-testear un env sin chequear primero qué versión tiene desplegada.
- Confiar el smoke HTTP como validación de lógica de redirect/deeplink → curl no corre el JS; usar browser o tests.

## Cross-reference

- `reference/high-risk-pages.md` — pages sin tests que las migraciones Next ponen en peligro (deeplink/qr/linking, usan `next/router` + SSR).
- `nextjs-pages-router-migration` — la migración que motivó este smoke (S1874, router breaking changes).
- `webapp-testing` / chrome-devtools MCP — para smoke con render real (console errors, redirects JS).
- `modo-services-monitor` — estado de servicios/versiones por env (capa más amplia).

## Funnel e2e (Playwright, cross-repo) — sibling más profundo

Este skill es **HTTP-level per-env** (curl contra el edge, "¿la page levanta?"). La capa más profunda — render real + contratos cross-repo — es el harness Playwright standalone en `/Users/hernan.desouza/Documents/Proyectos/modo/modo-landing-workspace/modo-landing/e2e/` (paquete propio, Playwright 1.59, **live-env: sin `webServer` en `playwright.config.ts`**). Selecciona env vía `WEB_ENVIRONMENT` / `PLAYWRIGHT_BASE_URL`; helpers `e2e/utils/getEnvironment.ts` → `getBaseUrl()` + `getEnvironmentVariable(key)`. Los funnels cross-repo viven en `e2e/tests/funnel-{pagar,comercios,promos,recargas-sorteo-linking}.spec.ts`.

Correr: `cd e2e && cp .env.example .env && pnpm install && pnpm e2e` (o `npx playwright test funnel-promos.spec.ts`).

**Mapas + plan**: los 4 funnel maps (`funnel-*.md`) + el `e2e-plan.md` están en `/Users/hernan.desouza/Documents/Proyectos/modo/modo-landing-workspace/modo-landing/openspec/changes/cross-repo-funnel-e2e/`. El método genérico (trazar verticales src/pages → repo-owner + integration point → app-handoff boundary → escenarios) está en la memoria `reference_modo_landing_e2e_harness`; si se repite en otro front es candidato a un skill triple-layer `modo-funnel-e2e` (NO existe todavía — es propuesta, no path vivo).

**Gotcha clave (fixtures)**: `e2e/mocks/banks-*.json` (`banks-develop/qa/preprod/prod`) son **bank-registry** (`hub_bank_id`, `promotion_url`), NO la shape de `/banks/deep_links`. Para deeplinks usar `e2e/mocks/banks-deep-links.json` (campos reales `payment_ecommerce_url`/`coupon_link_url`/`link_accounts_url`). Y el stores BFF es **`map-handler.*`** (`API_BASE_STORES_BFF_URL` en `e2e/constants/base.ts`), no `stores-bff.*`.
