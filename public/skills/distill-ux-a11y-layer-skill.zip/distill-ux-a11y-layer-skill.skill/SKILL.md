---
name: distill-ux-a11y-layer-skill
description: Use this skill to author a project-specific UX/accessibility layer skill that complements (never overrides) the brand/design skill. Meta-skill — it gives the 3-pillar structure (mobile-first, the target persona's motor/visual a11y, simple-don't-overwhelm) and a verifiable pass/fail UX checklist. Use when a product has a specific core user (e.g. 40+, low-vision, one-handed) whose usability needs the design skill alone doesn't encode.
---

A UX skill says *how a screen is used*; the design skill owns *how it looks*. They're separate
so usability rules don't get buried in brand rules — and so the UX layer can never silently
override the brand. **When they conflict, name it and reconcile; don't resolve in silence.**
Output: a `<project>-ux/` skill + a verifiable `UX_CHECKLIST.md`.

## Anchor on the real core user

The whole skill hangs off ONE persona statement ("mobile-first; core user is a pet owner 40+";
"power user on desktop, keyboard-first"; "low-literacy, low-bandwidth"). Every rule is justified
by that user's constraints, not generic best practice. Generic a11y rules are the floor, not the skill.

## Three pillars (adapt to your persona)

1. **Primary context first.** If mobile-first: design at 360px, single column, scale *up* with
   breakpoints; primary action in the thumb zone; nothing hover-only (touch has no hover);
   respect the notch (`viewport-fit=cover` + safe-area insets). If desktop/keyboard-first: tab
   order, focus rings, shortcuts.
2. **The persona's motor + visual a11y (concrete numbers).** Touch target ≥48×48px with ≥8px
   gaps; call out which of your existing button sizes *don't* reach it and what to use instead
   (this repo-specific callout is what makes the skill load-bearing). Body text floor (16px,
   18px for long reads); WCAG AA contrast (4.5:1 normal, 3:1 large/icons); **color never alone**
   — pair semantic color with label + icon; visible labels, never placeholder-as-label;
   feedback under 100ms on every tap.
3. **Simple, don't overwhelm (cognitive load).** One primary action per screen (at most one
   accent CTA); progressive disclosure (hide advanced behind "more"); groups of ~5 (7 max);
   linear flow, no nested modals; empty states that guide to the next step; a 3-second "what do
   I do here" hierarchy test.

## Make it verifiable

`UX_CHECKLIST.md` — each line a pass/fail test with a concrete method ("CTA reachable one-handed
at 360px: y/n", "all interactive text ≥16px: y/n"). Pair with: test real at the target width
(browser or Playwright), and the Storybook a11y addon as a floor (not sufficient alone).

## Cross-links

Brand/visual → [[distill-design-system-skill]]. Copy → [[distill-brand-voice-skill]]. Framework
rules → [[distill-framework-conventions-skill]]. Gating long feature lists → [[feature-flag-wiring]]
(the "don't show all 30 features at once" rule lives at the intersection of UX and flags).

## One line

Anchor on the real core user, three pillars (primary-context / that user's motor+visual a11y with
real px numbers / simple-don't-overwhelm), ship a pass/fail UX_CHECKLIST, never override the brand.
