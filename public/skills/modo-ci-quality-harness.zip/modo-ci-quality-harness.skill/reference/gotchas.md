# Gotchas — cazados en el rollout 2026-05-26

## Storybook test-runner acopla la major de Storybook
`@storybook/test-runner` (cualquier versión) resuelve `@storybook/core-common`
que en repos con SB mezclado (7.2 + 7.6 + transitive 8.x) trae el 8.x →
`Error: Cannot find module 'storybook/internal/common'`. Downgrade a 0.17 NO
arregla (el transitive sigue resolviendo 8.x).
**Fix**: script Playwright + @axe-core/playwright que itera `storybook-static/index.json`.
Version-agnostic. Es el `a11y-storybook.mjs` del skill.

## andresz1/size-limit-action no maneja registry privado
La action corre su propio `pnpm install` sin el token de `@playsistemico`.
**Fix**: workflow propio con step "Configure private registry" que escribe `.npmrc`
con `secrets.MODO_PKG_TOKEN`, luego install/build/size manual + comment via github-script.

## pnpm store v10 vs v11
corepack pnpm (sin packageManager pinneado) usa store v11; system pnpm 10.32 usa v10.
Mezclarlos → `ERR_PNPM_UNEXPECTED_STORE`. **Fix**: usar UN pnpm consistente; si ya
instalaste con el otro, `rm -rf node_modules && pnpm install`.

## `[[...slug]]` rompe el glob de size-limit
Los brackets son glob character-class. `dist/static/chunks/pages/[[...slug]]-*.js`
→ "can't find files". **Fix**: no declarar esa page como budget individual; cuenta en el total.

## Chunks de Next con hash/timestamp inyectado
modo-landing tiene `chunkFilename` custom con timestamp → nombres cambian cada build.
**Fix**: globs (`framework-*.js`), nunca nombres fijos.

## `npx size-limit` baja v12 de la red
Ignora el local instalado, baja size-limit@latest y falla por falta de preset.
**Fix**: `node_modules/.bin/size-limit` o `pnpm size` (script).

## Cross-org token
Repos en `SoyErnoModo` (ej. aprendeatumodo) con deps `@playsistemico`: el
`github.token` del workflow NO accede a packages de la org `playsistemico`.
**Fix**: configurar secret `MODO_PKG_TOKEN` (PAT `read:packages`) en el repo.
El workflow usa `secrets.MODO_PKG_TOKEN || github.token`.

## a11y script: networkidle cuelga
`page.goto(url, {waitUntil:'networkidle'})` nunca asienta en iframes Storybook
(conexiones persistentes) → 15s timeout × N stories = minutos perdidos.
**Fix**: `waitUntil:'domcontentloaded'` + `waitForSelector('#storybook-root')` + 150ms.

## @axe-core/playwright exige newContext
`Error: Please use browser.newContext()`. **Fix**: `browser.newContext().newPage()`,
no `browser.newPage()`.

## promos-hub: Storybook dep sin Storybook configurado
Tiene `@storybook/react` en devDeps pero 0 stories y sin `.storybook/`. Gates C/D
no aplican. **Siempre** verificar `.storybook/` + `find src -name '*.stories.*' | wc -l`.

## aprendeatumodo usa Bun
`bun.lock` + `bun.lockb` (no pnpm). El lockfile puede estar desincronizado
(`bun install --frozen-lockfile` falla). Build = `bun run build`. Workflow con
`oven-sh/setup-bun@v2`. npm pkg set funciona para scripts (npm disponible).

## Build local pesado pero necesario
Next 12/15 builds tardan minutos pero hay que correrlos para sacar baselines reales
y validar los globs de chunks (cada repo difiere: distDir, pages vs app router).
NO setear thresholds a ojo.
