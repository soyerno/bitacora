# Rollout state · 2026-05-26

Plan canónico: `playsistemico/modo-landing#1493` (openspec/changes/ci-quality-harness-rollout/).

## PRs abiertos

| Gate | Repo | PR | Estado |
|------|------|-----|--------|
| Plan | modo-landing | #1493 | draft |
| A audit | modo-ui-lib-web | #178 | open |
| A audit | modo-landing | #1494 | open |
| A audit | promos-hub-site | #592 | open (alta) |
| A audit | aprendeatumodo | #21 | open (alta) |
| B bundle | modo-ui-lib-web | #179 | **CI verde end-to-end** |
| B bundle | modo-landing-web-ui-lib | #49 | open |
| B bundle | aprendeatumodo | #22 | open (⚠️ necesita MODO_PKG_TOKEN secret) |
| B bundle | modo-landing | #1495 | open |
| B bundle | promos-hub-site | #594 | open |
| D a11y | modo-ui-lib-web | #180 | open (report-only) |

## Backlog (generable con este skill)

- **D a11y** modo-landing-web-ui-lib (Storybook SB10) — mismo script `a11y-storybook.mjs`
- **D a11y** modo-landing (Playwright E2E, tiene `e2e/`) — variante @axe-core/playwright en specs
- **C visual** modo-ui-lib-web (Loki, docker baseline)
- **C visual** modo-landing-web-ui-lib (Loki)
- **A.5 audit** modo-landing-web-ui-lib — depende del merge de #41 (pr-quality workflows)

## Hallazgos a11y (modo-ui-lib-web, report-only)

Violaciones reales detectadas que el equipo debe limpiar antes de flipear a blocking:
- `image-alt` (critical) — SectionGrid, SectionCarousel, SectionRounded
- `button-name` (critical) — SectionShapes
- `aria-allowed-attr` / `aria-hidden-focus` (critical/serious) — SectionCollapsible
- `scrollable-region-focusable` (serious) — SectionCarousel

## Decisión de tooling tomada

- size-limit > bundlewatch
- Loki > Chromatic (free, baseline en repo) — confirmado por Hernán 2026-05-26
- Playwright+axe script > @storybook/test-runner (version coupling)
