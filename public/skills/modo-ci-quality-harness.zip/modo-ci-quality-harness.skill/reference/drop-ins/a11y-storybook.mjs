#!/usr/bin/env node
// A11y check sobre stories de un Storybook estático.
// Itera index.json, corre axe-core (WCAG 2.2 AA) contra cada story,
// falla si hay violaciones serious/critical. Version-agnostic (no usa
// @storybook/test-runner, que acopla a la major de Storybook).
//
// Usage: node scripts/a11y-storybook.mjs [--url http://127.0.0.1:6006]

import { chromium } from 'playwright';
import { AxeBuilder } from '@axe-core/playwright';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const URL = process.argv.includes('--url')
  ? process.argv[process.argv.indexOf('--url') + 1]
  : 'http://127.0.0.1:6006';

const rules = JSON.parse(readFileSync(resolve('axe-rules.json'), 'utf8'));
const BLOCKING = new Set(rules.blocking); // ["critical","serious"]
const DISABLED = rules.disabled ?? [];

const index = JSON.parse(readFileSync(resolve('storybook-static/index.json'), 'utf8'));
const entries = Object.values(index.entries ?? index.stories ?? {});
const stories = entries.filter((e) => (e.type ?? 'story') === 'story');

const browser = await chromium.launch();
const context = await browser.newContext();
const page = await context.newPage();
const failures = [];

for (const story of stories) {
  const url = `${URL}/iframe.html?id=${story.id}&viewMode=story`;
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('#storybook-root, #root', { timeout: 5000 });
    await page.waitForTimeout(150);
  } catch {
    continue; // story que no monta — no es violación a11y
  }

  const results = await new AxeBuilder({ page })
    .include('#storybook-root, #root')
    .withTags(['wcag2a', 'wcag2aa', 'wcag22aa'])
    .disableRules(DISABLED)
    .analyze();

  const blocking = results.violations.filter((v) => BLOCKING.has(v.impact));
  if (blocking.length) {
    failures.push({ story: story.id, violations: blocking });
  }
}

await browser.close();

if (failures.length) {
  console.error(`\n❌ a11y: ${failures.length} stories con violaciones blocking (${[...BLOCKING].join('/')})\n`);
  for (const f of failures) {
    console.error(`  ${f.story}`);
    for (const v of f.violations) {
      console.error(`    [${v.impact}] ${v.id}: ${v.help}`);
      for (const node of v.nodes.slice(0, 2)) {
        console.error(`      → ${node.target.join(', ')}`);
      }
    }
  }
  process.exit(1);
}

console.log(`✅ a11y: ${stories.length} stories sin violaciones ${[...BLOCKING].join('/')} (WCAG 2.2 AA)`);
