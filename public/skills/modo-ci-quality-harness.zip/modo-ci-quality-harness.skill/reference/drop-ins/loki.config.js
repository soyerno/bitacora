module.exports = {
  diffingEngine: 'looks-same',
  chromeSelector: '#storybook-root, #root',
  configurations: {
    'chrome.laptop': {
      target: 'chrome.docker',
      width: 1366,
      height: 768,
      deviceScaleFactor: 1,
      mobile: false,
    },
    'chrome.iphone7': {
      target: 'chrome.docker',
      preset: 'iPhone 7',
    },
  },
  fetchStories: async (storyStore) => {
    const stories = storyStore.cacheAllCSFFiles
      ? await storyStore.cacheAllCSFFiles().then(() => storyStore.extract())
      : storyStore.extract();
    return Object.values(stories).filter((s) => {
      return !s.parameters?.loki?.skip;
    });
  },
  threshold: 0.01,
};
