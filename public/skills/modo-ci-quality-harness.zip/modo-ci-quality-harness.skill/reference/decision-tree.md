# Decision Tree · config por tipo de build

Correr `scripts/detect-repo-type.sh` primero. Devuelve `TYPE`, `PM`, `DISTDIR`,
storybook info, `HAS_PRIVATE_DEPS`, `AUDIT_GATE` y los gates aplicables.

## Gate B · bundle-size por TYPE

### lib-rollup-preserve (preserveModules: true)
Tree-shakeable, sin bundle único. Medir el costo del consumer con `import`.
- Preset: `@size-limit/preset-small-lib` (esbuild)
- Config: `size-limit.lib-rollup-preserve.json` — `path: dist/index.js`, `import: "{ X }"` o `"*"`, `ignore: [peerDeps]`
- Baseline ejemplo (modo-ui-lib-web): full 33.76 kB, Button 2.11 kB
- Threshold: **+15%**

### lib-vite (build.lib, single bundle)
Bundle único ESM+UMD. Medir el archivo directo.
- Preset: `@size-limit/preset-small-lib`
- Config: `size-limit.lib-vite.json` — `path: dist/index.es.js` + `dist/index.umd.js` + css, `ignore: [peerDeps]`
- Baseline ejemplo (modo-landing-web-ui-lib): ESM 35.39, UMD 35.77, CSS 8.59 kB
- Threshold: **+15%**

### next-app (distDir importante!)
`next build` → `<distDir>/static/chunks`. **OJO**: muchos repos MODO usan
`distDir: dist` (NO `.next`). Chunks con hash/timestamp → globs.
- Preset: `@size-limit/file` (mide archivos, no bundlea)
- Config: `size-limit.next.json` — globs `<distDir>/static/chunks/framework-*.js`,
  `main-*.js`, `webpack-*.js`, `pages/_app-*.js` (Next 12) o `main-app-*.js`+`polyfills-*.js` (Next 15 app router),
  total `["*.js","app/**/*.js","pages/**/*.js"]`
- NO incluir `[[...slug]]-*.js` como budget (brackets rompen el glob)
- Baseline Next 12 (modo-landing): framework 45, main 33, **_app 222**, all 965 kB
- Baseline Next 15 (promos-hub): framework 58, main 40, polyfills 40, all 1.43 MB
- Threshold: **+10%**

### vite-app (no build.lib)
`vite build` → `dist/assets/*.{js,css}` con hash.
- Preset: `@size-limit/file`
- Config: `size-limit.vite.json` — `dist/assets/index-*.js`, `dist/assets/*.js`, `dist/assets/*.css`
- Baseline ejemplo (aprendeatumodo): main 167, all JS 177, CSS 18 kB
- Threshold: **+10%**

## Gate B · workflow por PM

- pnpm: `bundle-size.pnpm.yml` (pnpm/action-setup@v2 v9 + cache pnpm + .npmrc token)
- Bun: `bundle-size.bun.yml` (oven-sh/setup-bun@v2)
- npm: adaptar pnpm variant (setup-node cache npm, `npm ci`)

## Gate C · visual regression (solo si Storybook real)

Verificar `STORYBOOK_CONFIGURED=yes` Y `STORYBOOK_STORIES>0`. (promos-hub tiene
la dep pero 0 stories → skip.)
- Default: Loki (`loki.yml` + `loki.config.js`). Docker chrome matchea CI.
- Baseline: `pnpm build-storybook && pnpm loki:update` → commit `.loki/reference/`
- `.gitignore`: `.loki/current`, `.loki/difference`, `!.loki/reference`
- Upgrade a Chromatic documentado en el plan original.

## Gate D · a11y

### Repo con Storybook (libs)
- Script: `a11y-storybook.mjs` (Playwright + @axe-core/playwright, version-agnostic)
- `a11y.yml` + `axe-rules.json`
- **NO usar @storybook/test-runner** (acopla major de Storybook → rompe)
- Deps: `@axe-core/playwright`, `playwright`, `http-server`
- Arranca report-only si hay backlog de violaciones

### App con Playwright E2E (modo-landing tiene e2e/)
- `@axe-core/playwright` en specs existentes
- Helper `runAxeAudit(page)` (ver plan `pr-d-a11y/a11y-helper.ts`)
- Corre con el `playwright.yml` existente, sin workflow nuevo

## Gate A · audit (siempre)

- `AUDIT_GATE=absent` → drop-in `pr-audit.yml` completo
- `AUDIT_GATE=soft` → patch: quitar `continue-on-error: true` del step critical
- `AUDIT_GATE=blocking` → ya está, skip
- Blocking día 1 (no escalation)
