#!/usr/bin/env bash
# Detecta tipo de build + package manager de un frontend MODO.
# Output: KEY=value lines para consumir desde el skill.
#
# Usage: detect-repo-type.sh [repo-path]   (default: cwd)

set -uo pipefail   # NO -e: greps sin match devuelven 1 y son esperados
ROOT="${1:-.}"
cd "$ROOT" || exit 2

# Lee un campo de package.json sin mezclar || y ?? (syntax error en JS).
dep() {
  node -e "try{const p=require('./package.json');const d={...(p.dependencies||{}),...(p.devDependencies||{})};process.stdout.write(String(d['$1']||''))}catch(e){}" 2>/dev/null
}

# --- package manager ---
if [[ -f bun.lockb || -f bun.lock ]]; then PM=bun
elif [[ -f pnpm-lock.yaml ]]; then PM=pnpm
elif [[ -f package-lock.json ]]; then PM=npm
else PM=unknown; fi

# --- framework / build type ---
NEXT=$(dep next)
VITE=$(dep vite)
HAS_ROLLUP=$(ls rollup.config.* 2>/dev/null | head -1)
DISTDIR=""

if [[ -n "$NEXT" ]]; then
  TYPE="next-app"
  DISTDIR=$(grep -hoE "distDir:\s*['\"][^'\"]+['\"]" next.config.* 2>/dev/null | head -1 | sed -E "s/.*['\"]([^'\"]+)['\"].*/\1/")
  [[ -z "$DISTDIR" ]] && DISTDIR=".next"
elif [[ -n "$HAS_ROLLUP" ]]; then
  if grep -q "preserveModules" rollup.config.* 2>/dev/null; then
    TYPE="lib-rollup-preserve"
  else
    TYPE="lib-rollup-bundle"
  fi
elif [[ -n "$VITE" ]]; then
  if grep -qE "lib:" vite.config.* 2>/dev/null; then
    TYPE="lib-vite"
  else
    TYPE="vite-app"
  fi
else
  TYPE="unknown"
fi

# --- storybook ---
SB_CONFIGURED="no"
[[ -d .storybook ]] && SB_CONFIGURED="yes"
SB_STORIES=$(find src -name "*.stories.*" 2>/dev/null | wc -l | tr -d ' ')
SB_VERSION=$(dep @storybook/react)
[[ -z "$SB_VERSION" ]] && SB_VERSION=$(dep storybook)

# --- private @playsistemico deps (need token) ---
HAS_PRIVATE=$(node -e "try{const p=require('./package.json');const d={...(p.dependencies||{}),...(p.devDependencies||{})};process.stdout.write(Object.keys(d).some(k=>k.startsWith('@playsistemico'))?'yes':'no')}catch(e){process.stdout.write('no')}" 2>/dev/null)

# --- existing pr-audit gate state ---
AUDIT_STATE="absent"
if [[ -f .github/workflows/pr-audit.yml ]]; then
  if grep -A1 "audit-level=critical" .github/workflows/pr-audit.yml 2>/dev/null | grep -q "continue-on-error: true"; then
    AUDIT_STATE="soft"
  else
    AUDIT_STATE="blocking"
  fi
fi

cat <<EOF
PM=$PM
TYPE=$TYPE
DISTDIR=$DISTDIR
NEXT_VERSION=$NEXT
VITE_VERSION=$VITE
STORYBOOK_CONFIGURED=$SB_CONFIGURED
STORYBOOK_STORIES=$SB_STORIES
STORYBOOK_VERSION=$SB_VERSION
HAS_PRIVATE_DEPS=$HAS_PRIVATE
AUDIT_GATE=$AUDIT_STATE
# --- gates aplicables ---
GATE_A_audit=$([[ "$AUDIT_STATE" != "blocking" ]] && echo yes || echo skip)
GATE_B_bundle=yes
GATE_C_visual=$([[ "$SB_CONFIGURED" == "yes" && "$SB_STORIES" -gt 0 ]] && echo yes || echo skip)
GATE_D_a11y=$([[ "$SB_CONFIGURED" == "yes" && "$SB_STORIES" -gt 0 ]] && echo yes-storybook || echo maybe-playwright-e2e)
EOF
