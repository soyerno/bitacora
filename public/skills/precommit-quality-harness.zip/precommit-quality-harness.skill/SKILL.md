---
name: precommit-quality-harness
description: Use this skill to set up or maintain a fast, scoped pre-commit quality gate (husky + lint-staged + a validate step) that gates touched code without punishing pre-existing debt, and that avoids the "full typecheck poisoned by stale generated types" trap. Use when adding pre-commit hooks to a repo, when the hook is too slow, or when local typecheck fails on generated files that CI regenerates.
---

A pre-commit hook should be **fast, scoped to what you touched, and not block on pre-existing
debt**. The shape: husky `pre-commit` → `lint-staged` (autofix staged files) + a `validate` script
(scoped typecheck + arch checks + unit tests).

## The two stages

1. **`lint-staged`** — `eslint --fix` on **staged files only**. Gates touched code without
   punishing the repo's pre-existing lint debt. (Let CI run the full lint as `continue-on-error`
   so the debt is visible but not blocking.)
2. **`validate`** — `typecheck:src` + `check:architecture` + `test:unit`. The correctness gate.

## The scoping decisions that make it usable (deliberate, not laziness)

- **`typecheck:src` uses a scoped tsconfig** (`tsconfig.precommit.json`, limited to `src/`,
  excluding the build output dir). Why: a full `tsc` gets **poisoned locally by stale generated
  types** (e.g. `.next` types that go stale between builds). CI regenerates them with a real
  build, so the full typecheck belongs in CI, not the hook. Scoping to `src/` keeps the local
  gate honest and fast.
- **`test:unit` runs only the fast unit project** (jsdom/node), not the browser/Storybook test
  project. Those run in CI.
- **Emergency escape:** `git commit --no-verify`. The build/CI covers full lint + full typecheck,
  so a skipped local gate is recoverable, not a hole.

## What CI owns (so the hook can stay light)

Full lint, full typecheck (with freshly generated types), browser/e2e tests, security/arch
checks that are too slow for a hook. The hook is the fast first line; CI is the backstop.

## Setup sketch

```
# .husky/pre-commit
npx lint-staged
npm run validate     # typecheck:src + check:arch + test:unit

# package.json
"validate": "npm run typecheck:src && npm run check:arch && npm run test:unit",
"typecheck:src": "tsc -p tsconfig.precommit.json --noEmit",
```

## One line

husky → lint-staged (staged-only autofix) + validate (src-scoped typecheck + arch + unit); scope
the typecheck to dodge stale generated types, push the full/slow checks to CI, `--no-verify` for emergencies.
