#!/usr/bin/env python3
"""
Citability scorer para el audit GEO MODO — mide qué tan "citables" son los
bloques de contenido de una page por motores generativos (ChatGPT, Perplexity,
Claude, Google AI Overviews).

Cada bloque (sección delimitada por heading) se scorea 0-100 en 5 dimensiones:

  Answer Block Quality   30  patrones de definición, respuesta en primeras 60
                              palabras, heading-pregunta, claims atribuidos
  Self-Containment       25  largo óptimo 134-167 palabras, baja densidad de
                              pronombres, nombres propios (extraíble sin contexto)
  Structural Readability 20  largo medio de oración 10-20, conectores de lista,
                              ítems numerados, saltos de párrafo
  Statistical Density    15  porcentajes, montos, números con unidad, años, fuentes
  Uniqueness Signals     10  data original, casos reales, herramientas concretas

Score de la page = promedio de los top-5 bloques (o todos si hay <5).

Adaptaciones MODO sobre el método original (geo-seo-claude, MIT):
  - Default fetch con UA Googlebot/2.1 (mide lo que ve el CRAWLER, no el browser).
    Crítico en sitios CSR-only: el browser ve React rendereado, el crawler ve el
    index.html vacío. Scorear el render miente. Ver SKILL.md "trap del CSR-only".
  - Patrones bilingües ES+EN (el copy MODO es castellano rioplatense).
  - Guard CSR-shell: si la page trae <2 bloques o <50 palabras visibles, avisa
    que probablemente sea un shell CSR y los scores no son confiables.
  - Sin dependencias externas (html.parser de stdlib, no requests/bs4). Corre en
    cualquier host sin pip install.

Atribución: rúbrica y rangos (134-167 palabras, pesos 30/25/20/15/10) derivados de
zubair-trabzada/geo-seo-claude (MIT) scripts/citability_scorer.py. Reimplementado
stdlib-only + bilingüe + crawler-UA para el stack MODO.

Uso:
    python3 citability_scorer.py <url>            # baja con UA Googlebot
    python3 citability_scorer.py <html-file>
    curl -s -A "Googlebot/2.1" "$SITE/" | python3 citability_scorer.py -
    python3 citability_scorer.py <url> --json     # salida JSON raw
    python3 citability_scorer.py <url> --ua browser   # UA browser (NO recomendado)

Exit code 0 siempre salvo fetch fail (2).
"""
import argparse
import json
import re
import subprocess
import sys
from html.parser import HTMLParser

UA_GOOGLEBOT = "Googlebot/2.1 (+http://www.google.com/bot.html)"
UA_BROWSER = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)

# Tags cuyo contenido NO es contenido editorial — se descartan.
_SKIP_TAGS = {"script", "style", "nav", "footer", "header", "aside", "form", "noscript"}
_HEADING_TAGS = {"h1", "h2", "h3", "h4"}
_TEXT_TAGS = {"p", "li", "td", "th", "blockquote", "figcaption", "dd", "dt"}


class _BlockExtractor(HTMLParser):
    """Extrae bloques de texto delimitados por headings, ignorando chrome."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks = []
        self._heading = "Introducción"
        self._paras = []
        self._skip_depth = 0
        self._in_heading = False
        self._heading_buf = []
        self._in_text = False
        self._text_buf = []
        self._text_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag in _SKIP_TAGS:
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag in _HEADING_TAGS:
            self._flush_section()
            self._in_heading = True
            self._heading_buf = []
        elif tag in _TEXT_TAGS:
            # Text-tags anidados (ej. <li> dentro de <li>): no resetear el buffer
            # del outer — acumular bajo el outermost para no perder su contenido.
            if not self._in_text:
                self._in_text = True
                self._text_buf = []
            self._text_depth += 1

    def handle_endtag(self, tag):
        if tag in _SKIP_TAGS:
            if self._skip_depth:
                self._skip_depth -= 1
            return
        if self._skip_depth:
            return
        if tag in _HEADING_TAGS and self._in_heading:
            self._heading = " ".join("".join(self._heading_buf).split()) or self._heading
            self._in_heading = False
        elif tag in _TEXT_TAGS and self._in_text:
            self._text_depth -= 1
            if self._text_depth <= 0:
                txt = " ".join("".join(self._text_buf).split())
                if txt and len(txt.split()) >= 5:
                    self._paras.append(txt)
                self._in_text = False
                self._text_depth = 0

    def handle_data(self, data):
        if self._skip_depth:
            return
        if self._in_heading:
            self._heading_buf.append(data)
        elif self._in_text:
            self._text_buf.append(data)

    def _flush_section(self):
        if self._paras:
            combined = " ".join(self._paras)
            if len(combined.split()) >= 20:
                self.blocks.append({"heading": self._heading, "content": combined})
        self._paras = []

    def finish(self):
        self._flush_section()
        return self.blocks


def fetch_html(arg: str, ua: str) -> str:
    if arg == "-":
        return sys.stdin.read()
    if arg.startswith(("http://", "https://")):
        try:
            return subprocess.check_output(
                ["curl", "-sL", "--max-time", "30", "-A", ua, arg]
            ).decode("utf-8", errors="replace")
        except subprocess.CalledProcessError as e:
            print(f"ERROR: fetch falló ({e})", file=sys.stderr)
            sys.exit(2)
    with open(arg, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def score_passage(text: str, heading=None) -> dict:
    """Scorea un passage 0-100 para citabilidad por IA. Bilingüe ES+EN."""
    words = text.split()
    wc = len(words)
    scores = {
        "answer_block_quality": 0,
        "self_containment": 0,
        "structural_readability": 0,
        "statistical_density": 0,
        "uniqueness_signals": 0,
    }

    # === 1. Answer Block Quality (30) ===
    abq = 0
    definition_patterns = [
        r"\b\w+\s+es\s+(?:un|una|el|la|lo)\s",          # ES: "X es un/una..."
        r"\bse\s+refiere\s+a\b",
        r"\bsignifica\b",
        r"\bse\s+define\s+como\b",
        r"\ben\s+(?:otras|t[eé]rminos)\s+(?:palabras|simples)\b",
        r"\b\w+\s+is\s+(?:a|an|the)\s",                  # EN
        r"\b\w+\s+refers?\s+to\s",
        r"\b\w+\s+means?\s",
        r"\b\w+\s+(?:can be |are )?defined\s+as\s",
    ]
    if any(re.search(p, text, re.I) for p in definition_patterns):
        abq += 15
    first_60 = " ".join(words[:60])
    early_signals = [
        r"\b(?:es|son|fue|fueron|significa|consiste)\b",
        r"\b(?:is|are|was|were|means?|refers?)\b",
        r"\d+\s*%",
        r"\$\s*[\d.,]+",
        r"\d+\s+(?:mill[oó]n(?:es)?|mil\s+millones|million|billion|thousand)",
    ]
    if any(re.search(p, first_60, re.I) for p in early_signals):
        abq += 15
    if heading and heading.rstrip().endswith("?"):
        abq += 10
    sentences = [s for s in re.split(r"[.!?]+", text) if s.strip()]
    if sentences:
        clear = sum(1 for s in sentences if 5 <= len(s.split()) <= 25)
        abq += int((clear / len(sentences)) * 10)
    if re.search(
        r"(?:seg[uú]n|de acuerdo a|estudios?\s+(?:muestran|indican|sugieren)|"
        r"investigaci[oó]n\s+(?:muestra|indica)|datos?\s+(?:muestran|indican)|"
        r"according to|research shows|studies?\s+(?:show|indicate|suggest|found)|"
        r"data\s+(?:shows|indicates|suggests))",
        text, re.I,
    ):
        abq += 10
    scores["answer_block_quality"] = min(abq, 30)

    # === 2. Self-Containment (25) ===
    sc = 0
    if 134 <= wc <= 167:
        sc += 10
    elif 100 <= wc <= 200:
        sc += 7
    elif 80 <= wc <= 250:
        sc += 4
    elif wc < 30 or wc > 400:
        sc += 0
    else:
        sc += 2
    pron = len(re.findall(
        r"\b(?:lo|la|los|las|esto|eso|esta|este|esa|ese|estas|estos|esas|esos|"
        r"[eé]l|ella|ellos|ellas|su|sus|le|les|"
        r"it|they|them|their|this|that|these|those|he|she|his|her)\b",
        text, re.I,
    ))
    if wc >= 10:  # bajo 10 palabras el premio de baja-densidad-pronombre es ruido
        ratio = pron / wc
        if ratio < 0.02:
            sc += 8
        elif ratio < 0.04:
            sc += 5
        elif ratio < 0.06:
            sc += 3
    proper = len(re.findall(r"\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)*\b", text))
    if proper >= 3:
        sc += 7
    elif proper >= 1:
        sc += 4
    scores["self_containment"] = min(sc, 25)

    # === 3. Structural Readability (20) ===
    sr = 0
    if sentences:
        avg = wc / len(sentences)
        if 10 <= avg <= 20:
            sr += 8
        elif 8 <= avg <= 25:
            sr += 5
        else:
            sr += 2
    if re.search(
        r"(?:primero|segundo|tercero|finalmente|adem[aá]s|asimismo|por\s+[uú]ltimo|tambi[eé]n|"
        r"first|second|third|finally|additionally|moreover|furthermore)",
        text, re.I,
    ):
        sr += 4
    if re.search(r"(?:\d+[.\)]\s|\b(?:paso|tip|punto|step|point)\s+\d+)", text, re.I):
        sr += 4
    if wc > 0 and "\n" in text:
        sr += 4
    scores["structural_readability"] = min(sr, 20)

    # === 4. Statistical Density (15) ===
    sd = 0
    sd += min(len(re.findall(r"\d+(?:[.,]\d+)?\s*%", text)) * 3, 6)
    sd += min(len(re.findall(
        r"\$\s*[\d.,]+(?:\s*(?:mill[oó]n(?:es)?|mil\s+millones|million|billion|M|B|K))?",
        text, re.I,
    )) * 3, 5)
    sd += min(len(re.findall(
        r"\b\d+(?:[.,]\d{3})*(?:[.,]\d+)?\s+(?:usuarios|clientes|comercios|p[aá]ginas|"
        r"empresas|personas|veces|users|customers|pages|companies|people|times)\b",
        text, re.I,
    )) * 2, 4)
    if re.search(r"\b20(?:1\d|2[0-6])\b", text):
        sd += 2
    if any(re.search(p, text) for p in [
        r"(?:seg[uú]n|de acuerdo a|por|de|by|per|from)\s+[A-ZÁÉÍÓÚÑ]",
        r"(?:Gartner|Forrester|McKinsey|Harvard|Stanford|MIT|Google|Microsoft|OpenAI|Anthropic|Ahrefs)",
        r"\([A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+\d{4})?\)",
    ]):
        sd += 2
    scores["statistical_density"] = min(sd, 15)

    # === 5. Uniqueness Signals (10) ===
    us = 0
    if re.search(
        r"(?:nuestr[oa]\s+(?:estudio|an[aá]lisis|investigaci[oó]n|encuesta|data|datos|hallazgos?)|"
        r"(?:encontramos|descubrimos|analizamos|medimos|relevamos)|"
        r"our\s+(?:research|study|data|analysis|survey|findings)|"
        r"we\s+(?:found|discovered|analyzed|surveyed|measured))",
        text, re.I,
    ):
        us += 5
    if re.search(
        r"(?:caso\s+(?:de\s+(?:estudio|uso)|real)|por\s+ejemplo|por\s+caso|en\s+la\s+pr[aá]ctica|"
        r"case study|for example|for instance|in practice|real-world|hands-on)",
        text, re.I,
    ):
        us += 3
    if re.search(r"(?:usando|con|v[ií]a|mediante|using|with|via|through)\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+", text):
        us += 2
    scores["uniqueness_signals"] = min(us, 10)

    total = sum(scores.values())
    if total >= 80:
        grade, label = "A", "Highly Citable"
    elif total >= 65:
        grade, label = "B", "Good Citability"
    elif total >= 50:
        grade, label = "C", "Moderate Citability"
    elif total >= 35:
        grade, label = "D", "Low Citability"
    else:
        grade, label = "F", "Poor Citability"

    return {
        "heading": heading,
        "word_count": wc,
        "total_score": total,
        "grade": grade,
        "label": label,
        "breakdown": scores,
        "preview": " ".join(words[:30]) + ("…" if wc > 30 else ""),
    }


def analyze(html: str, source: str) -> dict:
    parser = _BlockExtractor()
    parser.feed(html)
    blocks = parser.finish()

    visible_words = sum(len(b["content"].split()) for b in blocks)
    warnings = []
    if len(blocks) < 2 or visible_words < 50:
        warnings.append(
            "POSIBLE CSR-SHELL: <2 bloques o <50 palabras visibles en el HTML del "
            "crawler. Si el sitio es CSR-only (Vite/Lovable/SPA), el scorer está "
            "midiendo el index.html vacío, no el contenido. Scores NO confiables. "
            "Embeber contenido inline o migrar a SSG/SSR primero. Ver SKILL.md."
        )

    scored = [score_passage(b["content"], b["heading"]) for b in blocks]
    if scored:
        top = sorted(scored, key=lambda x: x["total_score"], reverse=True)[:5]
        page_score = round(sum(b["total_score"] for b in top) / len(top), 1)
        avg = round(sum(b["total_score"] for b in scored) / len(scored), 1)
        optimal = sum(1 for b in scored if 134 <= b["word_count"] <= 167)
    else:
        top, page_score, avg, optimal = [], 0.0, 0.0, 0
    grade_dist = {g: 0 for g in "ABCDF"}
    for b in scored:
        grade_dist[b["grade"]] += 1

    return {
        "source": source,
        "blocks_analyzed": len(scored),
        "visible_words": visible_words,
        "citability_score": page_score,          # promedio top-5 → input al GEO Score
        "average_block_score": avg,
        "optimal_length_passages": optimal,
        "grade_distribution": grade_dist,
        "top_5_citable": top,
        "bottom_5_citable": sorted(scored, key=lambda x: x["total_score"])[:5],
        "warnings": warnings,
        "all_blocks": scored,
    }


def print_summary(r: dict) -> None:
    print(f"\n  CITABILITY · {r['source']}")
    print(f"  {'─' * 56}")
    for w in r["warnings"]:
        print(f"  ⚠️  {w}\n")
    print(f"  Citability score (top-5 avg) : {r['citability_score']}/100")
    print(f"  Bloques analizados           : {r['blocks_analyzed']}")
    print(f"  Palabras visibles (crawler)  : {r['visible_words']}")
    print(f"  Passages en rango óptimo     : {r['optimal_length_passages']} (134-167 palabras)")
    gd = r["grade_distribution"]
    print(f"  Grades                       : A:{gd['A']} B:{gd['B']} C:{gd['C']} D:{gd['D']} F:{gd['F']}")
    if r["top_5_citable"]:
        print(f"\n  Top bloques citables:")
        for b in r["top_5_citable"]:
            print(f"    [{b['grade']}] {b['total_score']:>3}  {(b['heading'] or '·')[:48]}")
    if r["bottom_5_citable"] and r["blocks_analyzed"] > 5:
        print(f"\n  Bloques más débiles (a mejorar):")
        for b in r["bottom_5_citable"]:
            print(f"    [{b['grade']}] {b['total_score']:>3}  {(b['heading'] or '·')[:48]}")
    print()


def main() -> None:
    ap = argparse.ArgumentParser(description="Citability scorer GEO MODO")
    ap.add_argument("target", help="URL, archivo HTML, o '-' para stdin")
    ap.add_argument("--json", action="store_true", help="salida JSON raw")
    ap.add_argument("--ua", choices=["googlebot", "browser"], default="googlebot",
                    help="user-agent del fetch (default googlebot = lo que ve el crawler)")
    args = ap.parse_args()

    ua = UA_GOOGLEBOT if args.ua == "googlebot" else UA_BROWSER
    html = fetch_html(args.target, ua)
    result = analyze(html, args.target)

    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    else:
        print_summary(result)


if __name__ == "__main__":
    main()
