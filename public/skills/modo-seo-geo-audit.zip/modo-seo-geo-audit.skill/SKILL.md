---
name: modo-seo-geo-audit
description: SEO/GEO/JSON-LD audit + fix workflow for MODO frontends (Vite SPAs, Next.js, Astro). Audits canonical signals, robots/sitemap/llms.txt, Open Graph, Schema.org JSON-LD against Google Rich Results, AI crawler accessibility, and URL-as-state for public filters (every filter/category/search/page must be a shareable, indexable URL with its own JSON-LD). Defaults to finding what's invisible to crawlers, not what looks fine in DevTools.
---

# modo-seo-geo-audit

SEO + GEO (Generative Engine Optimization) + JSON-LD audit y fix para frontends MODO. Pensado para sitios que pueden ser CSR-only (Vite SPA, Lovable, etc.), SSG (Astro, Next export) o SSR (Next dynamic). El audit detecta qué ven los crawlers (Googlebot, Bingbot, GPTBot, ClaudeBot, PerplexityBot) — no qué ves vos en DevTools.

## When to use (auto-invoke triggers)

- "validá SEO de <sitio>", "audit SEO/GEO", "JSON-LD ok?", "valida que cumpla SEO"
- Antes de lanzar una landing nueva (modo-landing, promos-hub-site, aprendeatumodo, comercios, etc.)
- Cuando el user reporta "no aparecemos en Google" o "Perplexity no nos conoce"
- Después de un rediseño que cambió rutas/canonicals/og
- Al armar un sitio que probablemente sea CSR-only (Vite, Lovable, Vercel SPA mode)
- **Filtros sin URL** — user dice "el filtro X no cambia la URL", "no puedo compartir el resultado filtrado", "Google no indexa /promos?categoria=...", "los crawlers solo ven el estado default", o cuando un PR agrega/modifica filtros públicos (chips, select, search, paginación, tabs, sort) sin tocar `router.push/replace` ni `useSearchParams`

## When NOT to use

- Auditorías de performance (usar Unlighthouse o Lighthouse direct, no esto)
- Auditorías de seguridad de headers (usar `frontend-security-checklist`)
- Validación de contenido editorial / copy / brand voice (usar `modo-design-system` o `lectura-bionica`)

## Core principle · URL-as-state para todo filtro público

**Regla**: cualquier cambio de estado público (filtro, chip, tab, select, search, sort, paginación, distancia, ubicación) en sitios MODO **tiene que vivir en la URL** — query string o segmento dinámico, no en `useState` solo. Razones:

1. **Crawlable** — Googlebot, Bingbot y AI crawlers indexan URLs distintas; no ejecutan clicks. Sin URL, todos los estados colapsan al default y el contenido filtrado es invisible.
2. **Shareable** — copiar/pegar el link conserva el resultado; el user puede compartir un filtro aplicado en WhatsApp/email.
3. **Bookmark/back/forward** — el browser navega correctamente; "atrás" vuelve al estado previo.
4. **JSON-LD per-state** — cada combinación filter→URL emite su propio `ItemList`/`CollectionPage` reducido a los items visibles. Sin URL, no hay anchor para LD scoped.
5. **Analytics** — Amplitude/GTM page_view per filter combination, sin custom event scaffolding.
6. **Cache SSR/CDN/ISR** — URL es la cache key. Sin URL-state, todos los filtros colapsan en 1 entry (cache poisoning o uncached). Con URL-state + cardinality controlada (whitelist top combos), cada estado se cachea independiente → LCP mejor, TTFB mejor, menos load al origen. Ver `reference/url-as-state-filters.md > §7 Cache SSR`.

**Aplica a**: `/promos` (categoría, banco, día, ciudad, búsqueda), `/comercios` (rubro, geo, búsqueda, página), promos-hub-site root, cualquier `<CollectionPage>` en cualquier site MODO.

**NO aplica a**: estado privado (modal open/closed, hover, focus, animation step, accordion expanded, tooltip visible, dropdown open, drawer open). Ese estado sigue en `useState`.

### Test rápido (1 línea)

```bash
# Aplicar 2 filtros distintos en el browser; comparar URLs. Si son iguales, fail.
diff <(echo "$URL_default") <(echo "$URL_post_filter")  # debe diferir en query/segment
```

Y un crawler check:
```bash
curl -s -A "Googlebot/2.1" "https://www.modo.com.ar/promos?categoria=supermercados" | grep -E "ld\+json|<title>|canonical"
# Si el LD/title/canonical son idénticos al default → el filtro no es indexable.
```

### Patrones canónicos por filtro

| Tipo de filtro | URL pattern | Por qué |
|---|---|---|
| Single category (top-level taxonomía) | **segmento** `/promos/categoria/supermercados` | Mejor PageRank, breadcrumb natural, JSON-LD `CollectionPage` puro |
| Múltiples filtros combinables | **query string** `/promos?categoria=supermercados&banco=galicia&dia=lunes` | Combinatoria explota como segmentos; query es plano y cacheable |
| Search box | **query string** `?q=cafe` | Genera `SearchAction` JSON-LD reutilizable |
| Paginación | **query string** `?page=2` + `rel=next/prev` (legacy) o `<link rel="canonical">` apuntando al merged | Google declaró rel=next/prev deprecated en 2019 pero la mayoría de sites MODO lo siguen usando con canonical |
| Sort | **query string** `?sort=relevance` | No-indexable por default (`noindex` si no agrega valor SEO); decisión per-route |
| Geo (lat/lng) | **query string** `?ciudad=caba` | Lat/lng directo es noise; ciudad/comuna es slug-friendly |

### Implementation checklist (cualquier filtro nuevo)

- [ ] Estado del filtro se inicializa desde la URL (no desde default hardcoded).
- [ ] Cambio de filtro escribe a URL con `router.replace`/`router.push` (Next Pages) o `useSearchParams` + `router.push` (Next App).
- [ ] URL→state es idempotente: parsear la URL en mount produce el mismo estado que aplicar las acciones del user.
- [ ] Default state (sin filtros) tiene URL limpia (sin query strings vacíos como `?categoria=`).
- [ ] Canonical de cada estado filtrado apunta a sí mismo (`<link rel="canonical" href="<self>">`) salvo decisión explícita de canonicalizar al padre.
- [ ] Estados sin SEO value tienen `<meta name="robots" content="noindex,follow">` (ej. `?sort=desc`).
- [ ] Sitemap incluye los estados con SEO value (top categorías, top bancos, top ciudades). No incluye combinaciones long-tail.
- [ ] JSON-LD per-state: `ItemList` reducido a los items visibles + `BreadcrumbList` con el filtro como último crumb.
- [ ] H1/title/description per-state reflejan el filtro aplicado.
- [ ] Cuando el filtro vacía resultados, página devuelve UI clara (no 404) y `noindex` si está vacío sostenido (>30 días).

Detalle de implementación + code patterns (Next 12 Pages router para modo-landing, Next 15 App router para promos-hub-site) en `reference/url-as-state-filters.md`.

## Core principle · el trap del CSR-only

**Regla cero**: si el sitio es CSR-only (Vite SPA en Lovable / Vercel SPA / Netlify SPA), TODO lo que emite React/Helmet/react-helmet-async en runtime es **invisible** a Googlebot, Bingbot y a los AI crawlers. Solo ven el `index.html` estático. Por lo tanto:

- LDs ricos generados via `<Helmet>` → invisibles
- `<title>` per-route via Helmet → todos los routes muestran el title del `index.html`
- `canonical` per-route via Helmet → todos los routes apuntan al canonical del `index.html`
- og:image, og:url per-route via Helmet → idem

Confirmar con:
```bash
curl -s -A "Googlebot/2.1" https://<sitio>/ruta-cualquiera | grep -E "<title>|canonical|og:url|ld\+json"
# Comparar con / — si son idénticos: CSR trap confirmado.
```

**Hasta que el sitio sea SSG/SSR**, todos los signals SEO viven en el `index.html` estático. La estrategia es embeber inline los LDs ricos hasta que aterrice la migración. Ver `## Wave 0 · curitas pre-SSG` abajo.

## Process

### Step 1 · Inventario de prod

Levantar el HTML real que ven los crawlers:

```bash
SITE="https://aprendeatumodo.modo.com.ar"
curl -s -A "Googlebot/2.1" "$SITE/" -o /tmp/audit-prod.html
curl -sI "$SITE/robots.txt" -o /dev/null -w 'robots: %{http_code}\n'
curl -sI "$SITE/sitemap.xml" -o /dev/null -w 'sitemap: %{http_code}\n'
curl -sI "$SITE/llms.txt" -o /dev/null -w 'llms.txt: %{http_code}\n'
curl -s "$SITE/sitemap.xml" | grep -oE '<loc>[^<]+</loc>' | head
curl -s "$SITE/robots.txt"
```

Y por cada ruta canónica (course/detail/category): `curl -sI`. Si todas devuelven 200 con el mismo `Content-Length` → CSR fallback.

### Step 2 · Parse + validate JSON-LD

Usar `scripts/validate-jsonld.py` (en este skill). Reporta:
- Cuántos LD blocks hay
- Cada `@type` con required fields missing (per Google Rich Results)
- Strict check específico para `Course` (offers + url + provider.url + provider.logo + CourseInstance con courseMode + workload/schedule)

```bash
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py /tmp/audit-prod.html
```

El validador también marca `@type` **deprecados/restringidos** por Google (HowTo, FAQPage rich-result, CourseInfo, etc.) — ver `## Deprecated/restricted schema status` abajo antes de recomendar cualquier LD como "win de rich result".

### Step 2.5 · Citability scoring (GEO core)

`scripts/citability_scorer.py` mide qué tan **citables** son los bloques de contenido por motores generativos (ChatGPT, Perplexity, Claude, Google AI Overviews). Scorea cada sección (delimitada por heading) 0-100 en 5 dimensiones: answer-block quality, self-containment (largo óptimo 134-167 palabras), structural readability, statistical density, uniqueness. El score de la page es el promedio de los top-5 bloques.

**Correr SIEMPRE con UA Googlebot** (default), no browser — mide lo que ve el crawler, no el render. En sitios CSR-only el scorer avisa con un warning de CSR-shell (0 bloques = contenido invisible a la IA, el bug #1 de GEO).

```bash
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/citability_scorer.py https://www.modo.com.ar/
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/citability_scorer.py /tmp/audit-prod.html --json
```

El `citability_score` (0-100) alimenta el GEO Score compuesto del Step 3.

> **Caso canónico**: `https://www.modo.com.ar/` devuelve 90KB de HTML a Googlebot pero **0 bloques de contenido** (body client-rendered vía `dynamic({ssr:false})`, P0 conocido #1466). Para la IA, el home está vacío. Ningún otro fix de GEO importa hasta resolver esto.

### Step 3 · GEO Score + matriz de findings

**GEO Score compuesto (0-100)** — número único trackeable cross-deploy, además de la matriz semáforo. Promedio ponderado de 6 categorías (pesos derivados de geo-seo-claude, MIT; opinables, no de estudio controlado):

```
GEO_Score = Citability   * 0.25   # citability_scorer.py (determinístico)
          + Brand         * 0.20   # presencia Wikipedia/Reddit/YouTube/LinkedIn (juicio)
          + EEAT          * 0.20   # autor + credenciales + Person schema + sourcing (juicio)
          + Technical     * 0.15   # SSR/JS-dependency, robots, sitemap, headers, CWV (juicio)
          + Schema        * 0.10   # JSON-LD completo, sameAs, no deprecados (validate-jsonld.py)
          + Platform      * 0.10   # readiness por plataforma (ver reference/platform-source-share.md)
```

| Rango | Rating | Significado |
|---|---|---|
| 90-100 | Excelente | Muy probable que la IA lo cite |
| 75-89 | Bueno | Base sólida, margen de mejora |
| 60-74 | Regular | Presencia moderada, oportunidades grandes |
| 40-59 | Pobre | Señales débiles, la IA puede no citarlo |
| 0-39 | Crítico | Prácticamente invisible para la IA |

**Determinístico vs juicio**: Citability y Schema salen de scripts (mismo HTML → mismo número). Brand/EEAT/Technical/Platform son evaluaciones guiadas por LLM siguiendo rúbrica — reproducibles ±, no exactas. Reportar el GEO Score con esa salvedad, nunca como medición dura.

Y la matriz semáforo por capa:

| Capa | Verde 🟢 / Amarillo 🟡 / Rojo 🔴 |
|---|---|
| HTTP/HSTS | `strict-transport-security` presente |
| `robots.txt` | AI bots declarados explícitos |
| `sitemap.xml` | sin `/#anchor` (Google los colapsa); URLs reales |
| `llms.txt` | existe + lista cursos/productos |
| OG/Twitter | imagen propia (no de Lovable/CDN preview); url + locale + image:alt |
| canonical | per-route correcto |
| `<title>` per-route | distinto al home |
| `<h1>` static | presente en HTML estático |
| Citability score | top-5 bloques ≥65 (grade B+); 0 bloques a Googlebot = 🔴 crítico |
| Course LD | offers, url, provider.url + provider.logo |
| FAQ LD | embebido si hay glossary/FAQ — **NO da rich result Google desde ago 2023 (restringido a gov/health); sí ayuda extracción AI/GEO**. No venderlo como win de SERP |
| VideoObject LD | si hay video embed |
| BreadcrumbList | en home y en course detail |
| CSR trap | resuelto (signals inline en index.html o SSG) |
| URL-as-state | filtros públicos reflejan en query/segment; sin filtros = URL limpia |
| LD per filter state | `ItemList`/`CollectionPage` scoped al subset visible; `BreadcrumbList` con filtro como último crumb |
| Canonical per filter | filtros indexables canonicalizan a sí mismos; sort/noise canonicalizan al padre o llevan `noindex` |
| Filter sitemap entries | top categorías/bancos/ciudades en sitemap; long-tail excluido |
| Cache `Cache-Control` per filter | top combos `s-maxage=600` SWR 1h; combos 2-filter `s-maxage=60`; search/sort `no-store`. `Vary: Accept-Encoding` solo (nunca Cookie/UA) |
| Cache hit rate | `x-cache: HIT` / `cf-cache-status: HIT` en repeat de top combos |

### Step 4 · Wave 0 · curitas pre-SSG

Si el sitio es CSR-only y no podés migrar ahora a SSG, embeber inline en `index.html`:

1. `EducationalOrganization` / `Organization` / `LocalBusiness` (según tipo MODO)
2. `WebSite` con `publisher`
3. `BreadcrumbList`
4. `CollectionPage` con `mainEntity.ItemList` de productos/cursos
5. `FAQPage` con preguntas reales del glossary/FAQ — **ojo**: desde ago 2023 ya NO genera rich result en Google SERP salvo sites gov/health, pero SIGUE ayudando la extracción Q&A de los motores AI (GEO). Embeberlo por GEO, no venderlo como win de rich result.
6. (opcional) `VideoObject` si hay video

Ver `reference/json-ld-recipes.md` para drop-ins listos. Cada Course/Product debe traer `offers`, `url`, `provider.url`, `provider.logo` para pasar Google Rich Results.

Además:
- `sitemap.xml`: drop URLs con `/#anchor` (Google las colapsa al home). Listar las rutas reales una por una.
- `robots.txt`: agregar AI bots explícitos (ver `reference/robots-ai-bots.md`).
- `llms.txt`: crear si no existe (ver `reference/llms-txt-template.md`).
- `index.html`: `<meta name="robots" content="index,follow,max-image-preview:large">`, `hreflang es-AR + x-default`, `og:image:alt`.

### Step 5 · Wave 1+ · habilitado por SSG/SSR

Cuando aterrice Next 16 SSG / Astro SSR / similar:

- LDs per-route en HTML estático (eliminar duplicación con inline)
- `canonical` / `og:url` / `og:type=article` / `<title>` per-route
- Sitemap dinámico desde `app/sitemap.ts` (Next) o equivalente
- Robots dinámico desde `app/robots.ts`
- Cuerpo de cada page en HTML estático (no solo CSR shell)

## Canonical MODO assets

Logos y OG images verificados (200 OK):
- Logo MODO oficial: `https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png` (436×96, PNG, transparente)
- OG image canónico de modo.com.ar: usado en `og:image` del home corporativo

NO hardcodear logos en `/modo-logo.png` que devuelven 404 — usar el Storyblok URL como source of truth.

## Deprecated/restricted schema status

Google retiró/restringió varios rich results. Antes de recomendar un `@type` como "win de SERP", chequear este estado (lo valida `validate-jsonld.py`):

| `@type` | Estado | Implicancia GEO |
|---|---|---|
| `HowTo` | Removido de rich results sep 2023 | No da rich result. LD inerte para SEO; bajo valor GEO. No embeber |
| `FAQPage` | Rich result restringido a gov/health desde ago 2023 | NO da rich result para MODO; SÍ ayuda extracción Q&A de motores AI. Embeber solo por GEO |
| `CourseInfo` | Retirado jun 2025 | Usar `Course` + `CourseInstance`, no `CourseInfo` |
| `EstimatedSalary` | Retirado jun 2025 | No usar |
| `LearningVideo` | Retirado jun 2025 | Usar `VideoObject` |
| `ClaimReview` | Retirado jun 2025 (fact-check rich results discontinuados) | No usar |
| `VehicleListing` | Retirado jun 2025 | No usar |
| `SpecialAnnouncement` | Retirado jun 2025 | No usar |
| `PracticeProblem` | Retirado jun 2025 | No usar |

Tipos que SÍ siguen dando valor (rich result o GEO entity-linking): `Organization`/`LocalBusiness` con `sameAs`, `Product`+`Offer`, `Article` con `author` Person + `dateModified`, `BreadcrumbList`, `WebSite`+`SearchAction`, `VideoObject`, `Person` con `sameAs`+`knowsAbout`, `speakable`.

Atribución del estado deprecado: cruzado con AgriciDaniel/claude-seo (MIT) `hooks/validate-schema.py` + Google Search Central changelog.

## PR pattern

Branch: `feat/COENXT-<ticket>-seo-geo-pX` (X = wave). PRs típicos:

- Wave 0 · `seo-geo-p0` — JSON-LDs inline + sitemap + robots + llms.txt + meta tags
- Wave 1+ · una vez SSG, dropear inline duplicates y emitir per-route

Workflow merge a main: `gh pr create` + `gh pr merge --squash --admin` (push directo bloqueado por classifier en repos MODO).

## Anti-patterns

- **Filtros con `useState` solo, sin URL**: chip de categoría que cambia el grid pero no la URL. Resultado: Googlebot solo ve el default, no indexa la combinación. Fix: `router.replace({ query: { categoria: 'supermercados' } })` en cada click.
- **Default state con query string vacío**: `?categoria=&banco=&dia=`. Confunde a crawlers (los considera URLs distintas que canonicalizan al home). Fix: omitir keys con valor default.
- **Filtros que generan combinatoria explosiva indexable sin sitemap curado**: `?categoria=X&banco=Y&dia=Z&ciudad=W` × N×M×7×24 = ~50k URLs duplicadas. Google las descubre, las clasifica como thin content, te penaliza. Fix: `noindex` por default en combinaciones de 2+ filtros, indexar solo lo curado.
- **LD global no scoped al filtro**: `ItemList` con los 500 items aunque el filtro reduzca a 8. Inconsistencia visible→LD daña confianza del crawler. Fix: regenerar el `ItemList` por estado.
- **Cambiar URL con `pushState` directo, sin `router.replace/push`**: Next no re-corre `getServerSideProps`/`getStaticProps`, la página se desincroniza, breaks back/forward. Fix: usar el router de Next siempre.
- **`router.push` en cada keystroke del search box**: spam al history stack. Fix: debounce 300ms + `router.replace` (no push).
- **`Vary: Cookie` o `Vary: User-Agent` en HTML público**: rompe cache CDN (cada user/browser = entry distinta → cache thrash). Fix: `Vary: Accept-Encoding` solo. Si necesitás variar por auth, separar rutas públicas/privadas.
- **`Cache-Control: no-cache` global por miedo a stale**: mata el cache CDN entero. Fix: `s-maxage` chico (60s) + `stale-while-revalidate` largo (1h) + `revalidateTag`/`res.revalidate` para invalidar on-demand desde CMS webhook.
- **Default URL con query no-vacío** (`?categoria=todas`): crea cache entry separada del home que nunca se reusa. Fix: `buildCanonical` strippea defaults; default = URL limpia.
- **Cardinality explosiva sin whitelist**: cachear todas las combinaciones N×M×7×24 → eviction agresiva, hit rate baja. Fix: whitelist top combos cacheables + `no-store` en long-tail.
- **Olvidar el CSR trap**: ver LDs ricos en source `<Helmet>` y declarar OK sin curl con `Googlebot` UA. Siempre curl primero.
- **Sitemap con anchors**: `/#cursos`, `/#video`. Google los colapsa al home. URLs reales por sección, no anchors.
- **OG image de Lovable/Vercel preview**: `pub-*.r2.dev/...lovable.app...`. Frágil, no branded, riesgo de rotación. Usar Storyblok MODO oficial o asset propio.
- **Course sin offers**: Google exige `offers` (incluso `price:"0"` + `category:"Free"`) para mostrar Course rich result, aunque `isAccessibleForFree:true`.
- **AI bots no declarados**: el wildcard `User-agent: *` los cubre por defecto, pero declararlos explícito comunica intención y permite revertir caso por caso.
- **Slugs en sitemap distintos de los reales**: si el catalog está en `src/lib/courses.ts` o equivalente, hay que sincronizar.
- **Validar solo schema.org sin Google Rich Results**: schema válido ≠ Google muestra rich result. Correr el strict check de `scripts/validate-jsonld.py`.
- **Cachear `notFound`/`redirect`/`preview` en SSR** (ver sección siguiente). Un `setHeader('Cache-Control', ...)` al tope del `getServerSideProps` cachea TODO, incluso un 404 transitorio sobre URL válida. Fix: cachear solo en el success path.
- **Fade-in de entrada con `opacity: 0` sobre el contenedor del LCP element**: difiere la métrica LCP (Chrome no cuenta elementos en `opacity:0`). Fix: arrancar el keyframe en `opacity: 0.6` (o transform-only), no en 0.

## Core principle · SSR cache-correctness + LCP de animaciones de entrada

Dos trampas que un audit de "filtros/CSR" no pesca pero rompen SEO/CWV en sitios SSR (Next dynamic). Cazadas en modo-landing PR #1489 (2026-05-27).

### A · `Cache-Control` en SSR: cachear SOLO en el success path

Cuando agregás `res.setHeader('Cache-Control', 'public, s-maxage=...')` en un `getServerSideProps`, **importa DÓNDE lo ponés**. Si va al tope de la función, cachea cualquier respuesta — incluyendo las que NO querés que el CDN guarde:

- `return { notFound: true }` → un 404 cacheado. Si el 404 vino de un error transitorio de Storyblok/BFF (no de una URL inexistente real), el CDN sirve un 404 sobre una URL **válida e indexada** por `s-maxage` segundos. Flapping 404 = deindex.
- `return { redirect: {...} }` → un 301/302 cacheado sobre una URL que debería renderizar.
- `preview` mode (`?preview=true` que sirve draft de Storyblok en lowenv) → draft cacheado público.

**Regla**: setear el header **después** de confirmar render exitoso y fuera de preview.

```js
// MAL — cachea notFound/redirect/error transitorio:
export async function getServerSideProps({ params, res }) {
  setCmsCacheHeaders(res);              // ← cachea TODO lo que retorne abajo
  try { const { data } = await cms.get(...); return { props: {...} }; }
  catch { return { notFound: true }; } // ← 404 cacheado sobre URL válida
}

// BIEN — cache solo en success path, skip preview:
export async function getServerSideProps({ params, query, res }) {
  const preview = query.preview === 'true';
  try {
    const { data } = await cms.get(...);
    if (!data?.story) return { redirect: { destination: '/', permanent: false } };
    if (!preview) setCmsCacheHeaders(res); // ← solo acá
    return { props: {...} };
  } catch { return { notFound: true }; }    // ← sin cache
}
```

Para listados que renderizan vacío-en-error (no `notFound`), usar un flag `fetchOk`:
```js
let fetchOk = false;
try { /* fetch */ fetchOk = true; } catch { /* log */ }
if (fetchOk && !preview) setCmsCacheHeaders(res); // no cachear listado vacío por error transitorio
```

**Helper canónico** (un solo TTL en todo el repo, evita drift):
```ts
// src/utils/cacheHeaders.ts
const MAX_AGE = 300, SWR = 3600;
export const CMS_CACHE_CONTROL = `public, s-maxage=${MAX_AGE}, stale-while-revalidate=${SWR}`;
export function setCmsCacheHeaders(res?: ServerResponse): void {
  if (!res || typeof res.setHeader !== 'function') return; // tolerante a tests sin context.res
  res.setHeader('Cache-Control', CMS_CACHE_CONTROL);
}
```

`public, s-maxage, stale-while-revalidate` (no `max-age` pelado): cachea en el **CDN/edge compartido**, el browser revalida cada vez → un edit de CMS no queda pegado en el browser del user por `max-age`. **Excluir del cache** pages por-usuario/auth/pago (`*_error`, `account_linking`, `invitation`, `pagar/*`, `validar-identidad`, `personal_qr`) — cachear HTML por-usuario en CDN filtra datos entre usuarios.

**Verify-grep** (correr antes de declarar "todo cacheado"):
```bash
# cada setCmsCacheHeaders debe estar DESPUÉS del notFound/redirect/catch, no antes:
for f in $(grep -rl setCmsCacheHeaders src/pages); do
  grep -nE "setCmsCacheHeaders|notFound:|redirect:|catch" "$f"
done
# y sin doble-set (helper + setHeader inline en el mismo gSSP):
grep -rn "setHeader.*Cache-Control" src/pages | grep -v setCmsCacheHeaders
```

### B · Animaciones de entrada y LCP

Un fade-in de primer paint (`opacity 0 → 1`) sobre el contenedor que envuelve el LCP element **difiere la métrica LCP**: Chrome no cuenta como "pintado" un elemento en `opacity:0`, así que la métrica espera a que el fade lo haga visible.

**Fix**: arrancar el keyframe en `opacity: 0.6` (no en 0) → el contenido es visible al primer frame, LCP intacto, y el efecto queda **más sutil**. Alternativa: animación transform-only (sin opacity sobre el LCP node), o aplicar el fade solo en transiciones client-side (no en el SSR first paint).

```css
@keyframes appFadeIn { from { opacity: 0.6; } to { opacity: 1; } } /* NO from 0 */
#main-content { animation: appFadeIn 300ms ease-out; }
@media (prefers-reduced-motion: reduce) { #main-content { animation: none; } }
```

Crawlers headless no se afectan: leen el HTML SSR + el resting computed style (sin `forwards`, resting = `opacity:1`), no el keyframe. El contenido sigue visible. Esto es **estrictamente más seguro** que un overlay `z-index` que cubre el viewport durante el primer paint (eso sí puede esconder contenido a renderers que snapshotean temprano → quitarlo es GEO-positivo).

## Files

- `SKILL.md` — proceso completo (este archivo)
- `README.md` — quick start
- `reference/json-ld-recipes.md` — recipes drop-in: Organization, WebSite, BreadcrumbList, CollectionPage, Course, FAQPage, VideoObject
- `reference/robots-ai-bots.md` — 17 AI bots canónicos para `robots.txt`
- `reference/llms-txt-template.md` — formato canónico de `llms.txt`
- `reference/csr-spa-trap.md` — explicación del trap CSR + cómo detectarlo + mitigaciones
- `reference/url-as-state-filters.md` — code patterns Next 12 Pages router + Next 15 App router para URL-as-state en filtros públicos (`/promos`, `/comercios`, promos-hub root). Incluye `useUrlFilter` hook + `parseFilterQuery` + `buildCanonical` + sitemap generator
- `reference/json-ld-per-filter-state.md` — recipes JSON-LD scoped a filtro: `CollectionPage` reducido al subset, `BreadcrumbList` con filtro como crumb, `SearchAction` para search box, `Offer`/`Promotion` per-card en grids de promos
- `reference/legacy-domain-redirect.md` — deindex de host/path viejo + migrar equity al propio: redirect cross-host SIEMPRE absoluto al host canónico, no mass-redirect (soft 404), no robots-block del viejo, deindex de host de terceros (Salesforce), y gotcha de GSC inspect apex-vs-www (falso "unknown to Google")
- `scripts/validate-jsonld.py` — validador Python local-only (sin tools externos)

## Cross-link

- [`frontend-security-checklist`](../frontend-security-checklist/) — headers/CSP/auth (complementario)
- [`modo-design-system`](../modo-design-system/) — tokens/branding/page-patterns
- [`modo-research-article`](../modo-research-article/) — output canónico para reports SEO largos en la bitácora
- [`nextjs-pages-router-migration`](../nextjs-pages-router-migration/) — destino natural cuando se migra a SSG/SSR

## Caso canónico

aprendeatumodo · 2026-05-23 · branch `feat/COENXT-309-seo-geo-p0` · PR #3:
- index.html 1 LD → 5 LDs ricos inline
- sitemap 5 (4 anchors) → 8 (1 home + 7 cursos reales)
- robots.txt 5 bots → 22 bots (17 AI + 5 search)
- llms.txt nuevo (era 404)
- Google Rich Results Course strict check 7/7 ✅
- Wave 1+ documentada en `openspec/changes/migrate-to-next16/`
