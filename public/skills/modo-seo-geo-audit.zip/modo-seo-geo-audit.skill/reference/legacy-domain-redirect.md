# Legacy domain / path redirect (deindex viejo, migrar a propio)

Patrón para retirar de Google un host/path viejo (centro de ayuda, blog migrado,
subdominio de terceros) y consolidar el equity en el dominio propio. Caso canónico:
`ayuda.modo.com.ar/support/*` (Freshdesk/Salesforce) → `www.modo.com.ar/ayuda/preguntas-frecuentes`
(modo-landing PR #1539, 2026-06).

## Reglas (no negociables)

### 1. Redirect cross-host SIEMPRE absoluto al host canónico
Si el handler de redirect puede recibir requests de MÁS de un host (apex, `www`,
un subdominio legacy repuntado a la misma app), el `destination` **debe ser absoluto**
al host canónico — nunca relativo.

- Relativo `/ayuda/preguntas-frecuentes` servido en `ayuda.modo.com.ar` → cae en
  `ayuda.modo.com.ar/ayuda/preguntas-frecuentes` (host equivocado, 404). Bug silencioso:
  anda en local (mismo host) y rompe solo cuando Infra repunta el subdominio.
- Usar la constante canónica del repo, no `req.headers.host`. En modo-landing:
  `CANONICAL_BASE_URL` (`src/utils/seo.ts` = `https://www.modo.com.ar`). `buildBaseUrl()`
  ignora el req y devuelve esa constante a propósito.

```ts
import { CANONICAL_BASE_URL } from '../../utils/seo';
const HUB = `${CANONICAL_BASE_URL}/ayuda/preguntas-frecuentes`;
return { redirect: { destination: HUB, statusCode: 301 } };
```

### 2. No mass-redirect a una sola página (soft 404)
Mandar N URLs viejas a un único hub = Google lo trata como **soft 404**, lo ignora y
NO pasa equity. Hay que mapear:
- Artículo con equivalente → 301 directo a su slug.
- Sin equivalente / índices / home → 301 al hub (fallback aceptable, no regla general).
- Contenido muerto sin equivalente → `410 Gone` (Google lo dropea más rápido que 404).

Si los slugs viejo/nuevo difieren (viejo con acentos + id; nuevo kebab sin acentos),
normalizá el viejo (NFD strip-diacríticos + saca id + kebab) y **validá contra el set
real de slugs vigentes** (de la fuente de datos), con fallback al hub. Evita cadenas
301→307 que aparecen si dejás que la página destino redirija el slug no-existente.

### 3. NO bloquear el viejo en robots.txt
Para deindexar, Google necesita **crawlear** el viejo y ver el 301/410/noindex. Si lo
bloqueás por robots, queda "indexed though blocked" y nunca sale. Dejá crawleable hasta
que desaparezca.

### 4. Deindex de host de terceros que no controlás en GSC
Si el viejo vive en un host que no es propiedad tuya en GSC (ej. Salesforce Experience
Cloud `*.my.site.com`): no podés usar Removals ahí. Palancas:
- Cortar la señal que lo alimenta (el 301 desde tu subdominio hacia ese host).
- `noindex` en la plataforma (Experience Builder → "Let search engines index your site"
  off + `<meta name="robots" content="noindex, follow">`).
- Verificar ese host como propiedad nueva en GSC para usar Removals (oculta ~6 meses,
  temporal — combinar siempre con la señal permanente).

## GSC URL Inspection · gotcha apex vs www

Inspeccionar el host equivocado da **falso "URL is unknown to Google"**. apex y www son
URLs DISTINTAS para Google: si el apex 301ea a www, el apex nunca se indexa (solo redirige)
y la inspección del apex dice "unknown" aunque la página esté perfectamente indexada en www.

**Siempre inspeccionar el host canónico** (el que está en el sitemap / el `google_canonical`).
Verificar cuál es: `curl -sI https://apex/ruta | grep -i location` muestra si redirige a www.
La API `inspect_url_enhanced` devuelve `google_canonical` — usar ESE host para la inspección
real. Caso: inspeccioné `modo.com.ar/ayuda/...` (apex) → "unknown"; `www.modo.com.ar/ayuda/...`
→ "Submitted and indexed". Falsa alarma de 30 min.

## Checklist al armar el redirect

- [ ] Destino absoluto al host canónico (no relativo, no `req.host`).
- [ ] Map 1:1 donde hay equivalente; hub solo como fallback; 410 para muertos.
- [ ] Slug normalizado validado contra el set real (sin cadenas de redirect).
- [ ] Viejo crawleable (no robots-block) hasta que Google lo dropee.
- [ ] Verificar indexación SIEMPRE en el host canónico (apex vs www).
- [ ] Host de terceros: noindex + (opcional) verificar en GSC para Removals.
