# JSON-LD per filter state · recipes scoped

Cada combinación de filtros indexable emite su propio JSON-LD scoped al subset visible. NO repetir el catálogo entero en cada estado — esto degrada confianza del crawler (LD inconsistente con UI = thin content signal).

Aplica a `/promos`, `/comercios`, promos-hub-site, cualquier `CollectionPage` con filtros.

## 1 · `CollectionPage` con `ItemList` scoped al subset

Estado: `/promos?categoria=supermercados&banco=galicia`. Subset: 8 promos visibles. LD debe listar las 8, no las 500 del catálogo.

```json
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "Promos de supermercados con Banco Galicia · MODO",
  "url": "https://www.modo.com.ar/promos?banco=galicia&categoria=supermercados",
  "inLanguage": "es-AR",
  "isPartOf": {
    "@type": "WebSite",
    "name": "MODO",
    "url": "https://www.modo.com.ar/"
  },
  "publisher": {
    "@type": "Organization",
    "name": "MODO",
    "url": "https://www.modo.com.ar/",
    "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png"
  },
  "mainEntity": {
    "@type": "ItemList",
    "name": "Promociones supermercados · Banco Galicia",
    "numberOfItems": 8,
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "url": "https://www.modo.com.ar/promos/coto-galicia-30-off",
        "item": {
          "@type": "Offer",
          "name": "30% off en Coto con Banco Galicia",
          "description": "Tope de reintegro $20.000 por mes. Válido lunes.",
          "url": "https://www.modo.com.ar/promos/coto-galicia-30-off",
          "category": "Supermercados",
          "validFrom": "2026-05-01",
          "validThrough": "2026-12-31",
          "availability": "https://schema.org/InStock",
          "eligibleRegion": { "@type": "Country", "name": "Argentina" },
          "priceCurrency": "ARS",
          "priceSpecification": {
            "@type": "UnitPriceSpecification",
            "priceCurrency": "ARS",
            "valueAddedTaxIncluded": true
          },
          "offeredBy": {
            "@type": "BankOrCreditUnion",
            "name": "Banco Galicia",
            "url": "https://www.bancogalicia.com/"
          },
          "seller": {
            "@type": "Organization",
            "name": "Coto"
          }
        }
      }
    ]
  }
}
```

**Notas**:
- `numberOfItems` debe coincidir con `itemListElement.length`.
- `position` arranca en 1, no en 0.
- Cada `Offer` lleva `validFrom`/`validThrough` (ISO 8601), `category`, `availability`, `eligibleRegion`.
- `offeredBy.BankOrCreditUnion` permite que Google entienda la afinidad banco-promo.
- `seller` es el comercio que aplica la promo. Distinto de `offeredBy` (el banco).

## 2 · `BreadcrumbList` con filtros como crumbs

Estado: `/promos?categoria=supermercados`. Breadcrumb refleja el filtro.

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Inicio", "item": "https://www.modo.com.ar/" },
    { "@type": "ListItem", "position": 2, "name": "Promos", "item": "https://www.modo.com.ar/promos" },
    { "@type": "ListItem", "position": 3, "name": "Supermercados", "item": "https://www.modo.com.ar/promos?categoria=supermercados" }
  ]
}
```

Múltiples filtros → último crumb es el más específico (no listar todos los filtros aplicados como crumbs separados — confunde a Google).

## 3 · `SearchAction` (search box del site)

Va en el `WebSite` LD del home, NO en la página resultante de la búsqueda. Sirve para que Google muestre el sitelink searchbox.

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "MODO",
  "url": "https://www.modo.com.ar/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://www.modo.com.ar/promos?q={search_term_string}"
    },
    "query-input": "required name=search_term_string"
  }
}
```

`urlTemplate` debe matchear el query string real del search box. Si el search es por path (`/buscar/[q]`), ajustar.

## 4 · `Product` + `Offer` en cards de promos (alternativa a `ItemList`)

Cuando cada card representa un producto comerciable más concreto (no una "promo abstracta"), usar `Product`:

```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "30% off en Coto",
  "image": "https://a.storyblok.com/f/.../coto-promo-banner.jpg",
  "description": "Reintegro 30% con MODO pagando con Banco Galicia los lunes.",
  "brand": { "@type": "Brand", "name": "Coto" },
  "offers": {
    "@type": "Offer",
    "url": "https://www.modo.com.ar/promos/coto-galicia-30-off",
    "priceCurrency": "ARS",
    "price": "0",
    "category": "Discount",
    "validFrom": "2026-05-01",
    "validThrough": "2026-12-31",
    "availability": "https://schema.org/InStock",
    "offeredBy": {
      "@type": "BankOrCreditUnion",
      "name": "Banco Galicia"
    }
  }
}
```

Decisión: si cada promo tiene página de detalle → `Product` (con su propia URL). Si solo viven en el listado filtrado → `ItemList` con `Offer`.

## 5 · `LocalBusiness` + `OfferCatalog` (comercios + sus promos)

Para `/comercios/<slug>` con promos vigentes:

```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Coto Belgrano",
  "url": "https://www.modo.com.ar/comercios/coto-belgrano",
  "image": "https://a.storyblok.com/f/.../coto-logo.png",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Av. Cabildo 2000",
    "addressLocality": "Belgrano",
    "addressRegion": "CABA",
    "postalCode": "C1428",
    "addressCountry": "AR"
  },
  "geo": { "@type": "GeoCoordinates", "latitude": -34.5634, "longitude": -58.4561 },
  "openingHours": "Mo-Su 08:00-22:00",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Promociones MODO vigentes",
    "itemListElement": [
      {
        "@type": "Offer",
        "name": "30% off con Banco Galicia los lunes",
        "url": "https://www.modo.com.ar/promos/coto-galicia-30-off",
        "validFrom": "2026-05-01",
        "validThrough": "2026-12-31"
      }
    ]
  }
}
```

`OfferCatalog` permite agrupar promos de un comercio sin perderlas en LD ruido.

## 6 · `FAQPage` per-filter (cuando el filtro genera FAQs específicas)

Estado: `/promos?categoria=gastronomia`. FAQs scoped a la categoría:

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "¿Qué promos de gastronomía hay con MODO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Hay 12 promos vigentes en restaurantes adheridos con bancos del ecosistema MODO. Topes mensuales de reintegro varían por banco."
      }
    }
  ]
}
```

NO inventar FAQs solo para llenar LD. Solo si hay FAQs reales en la UI o copy del filtro. Recordá: `FAQPage` no da rich result en Google para MODO (restringido a gov/health desde ago 2023); el valor acá es GEO (extracción Q&A de motores AI), no SERP.

## 7 · LD `noindex` strategy

Cuando una página tiene `noindex,follow` (long-tail combo, sort, search results), DEPENDE de la decisión:

- **Subset chico (<5 items) y específico** → mantener LD scoped. Si el user accede directo desde share, sigue siendo útil semánticamente.
- **Search results (`?q=cafe`)** → SIN `ItemList` LD (los results son volátiles, no canónicos). Solo `WebSite` global.
- **Combinatoria thin (`?categoria=X&banco=Y&dia=Z`)** → SIN LD scoped (no merece). Mantener solo `Organization` + `WebSite` heredados.

## 8 · Validation

```bash
# Por cada filtro state representativo:
for url in \
  "https://www.modo.com.ar/promos" \
  "https://www.modo.com.ar/promos?categoria=supermercados" \
  "https://www.modo.com.ar/promos?banco=galicia" \
  "https://www.modo.com.ar/promos?categoria=supermercados&banco=galicia" \
  "https://www.modo.com.ar/promos?q=cafe" \
  ; do
  echo "=== $url ==="
  curl -s -A "Googlebot/2.1" "$url" -o /tmp/state.html
  python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py /tmp/state.html
  curl -s -A "Googlebot/2.1" "$url" | grep -E "canonical|robots"
done
```

Esperado: cada URL devuelve LD scoped al subset + canonical correcto + `noindex` cuando aplica.

## 9 · Cross-link

- `json-ld-recipes.md` — recipes base (Organization, WebSite, BreadcrumbList genérico, CollectionPage default)
- `url-as-state-filters.md` — code patterns que generan estos LDs en runtime/SSR
- `scripts/validate-jsonld.py` — validador
