# JSON-LD recipes · drop-in para `index.html` MODO

Todos los snippets pasan el Google Rich Results strict check. Pegar dentro del `<head>` del `index.html`. Cuando aterrice SSG, mover a `app/<route>/page.tsx > generateMetadata` o equivalente.

## EducationalOrganization (programa educativo MODO)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "Aprendé con MODO",
  "alternateName": "MODO",
  "url": "https://aprendeatumodo.modo.com.ar/",
  "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png",
  "description": "Programa de educación financiera gratuita de MODO para Argentina.",
  "sameAs": ["https://www.modo.com.ar/"],
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "AR"
  },
  "inLanguage": "es-AR"
}
</script>
```

## WebSite con publisher

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "Aprendé con MODO",
  "alternateName": "MODO",
  "url": "https://aprendeatumodo.modo.com.ar/",
  "inLanguage": "es-AR",
  "publisher": {
    "@type": "Organization",
    "name": "MODO",
    "url": "https://www.modo.com.ar/",
    "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png"
  }
}
</script>
```

## BreadcrumbList

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Inicio",
      "item": "https://aprendeatumodo.modo.com.ar/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Cursos",
      "item": "https://aprendeatumodo.modo.com.ar/#cursos"
    }
  ]
}
</script>
```

## CollectionPage con mainEntity.ItemList de Courses

`offers`, `url`, `provider.url`, `provider.logo` son **mandatorios** para que Google muestre el rich result, aunque `isAccessibleForFree:true`.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "Aprendé con MODO",
  "url": "https://aprendeatumodo.modo.com.ar/",
  "inLanguage": "es-AR",
  "publisher": {
    "@type": "Organization",
    "name": "MODO",
    "url": "https://www.modo.com.ar/",
    "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png"
  },
  "mainEntity": {
    "@type": "ItemList",
    "name": "Materiales de educación financiera MODO",
    "numberOfItems": 1,
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "url": "https://aprendeatumodo.modo.com.ar/curso/seguridad",
        "item": {
          "@type": "Course",
          "name": "Seguridad y Prevención de Fraude",
          "description": "Identificá estafas telefónicas, virtuales y presenciales.",
          "url": "https://aprendeatumodo.modo.com.ar/curso/seguridad",
          "inLanguage": "es-AR",
          "isAccessibleForFree": true,
          "educationalLevel": "Beginner",
          "teaches": "Seguridad financiera",
          "timeRequired": "PT8M",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "ARS",
            "category": "Free",
            "availability": "https://schema.org/InStock"
          },
          "provider": {
            "@type": "Organization",
            "name": "MODO",
            "url": "https://www.modo.com.ar/",
            "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png",
            "sameAs": "https://www.modo.com.ar/"
          },
          "hasCourseInstance": {
            "@type": "CourseInstance",
            "courseMode": "Online",
            "courseWorkload": "PT8M",
            "inLanguage": "es-AR"
          }
        }
      }
    ]
  }
}
</script>
```

## FAQPage desde glossary

Ideal para glossary/preguntas frecuentes. AI crawlers (Perplexity, ChatGPT) lo levantan bien.

> **Estado rich result**: desde ago 2023 Google restringió el rich result de `FAQPage` a sites gov/health — para MODO **no genera el accordion en SERP**. Embeberlo igual: aporta a la extracción Q&A de los motores AI (valor GEO). No venderlo como win de rich result de Google.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "¿Qué es Phishing?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Engaño por internet donde alguien se hace pasar por un banco o empresa para robar tus datos."
      }
    }
  ]
}
</script>
```

## VideoObject

`thumbnailUrl` + `uploadDate` (ISO 8601) son obligatorios. `duration` opcional pero recomendado.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "MODO en acción",
  "description": "Mirá lo que hace MODO en Argentina.",
  "thumbnailUrl": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png",
  "uploadDate": "2025-01-01",
  "embedUrl": "https://drive.google.com/file/d/1iaO3A1hhtMUiex1_xfINE5QZ8YXpFAei/preview",
  "inLanguage": "es-AR",
  "publisher": {
    "@type": "Organization",
    "name": "MODO",
    "sameAs": "https://www.modo.com.ar/"
  }
}
</script>
```

## Organization (genérico, para sites MODO no-educativos)

Para modo.com.ar, promos-hub-site, comercios. Reemplaza `EducationalOrganization` cuando no aplica.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "MODO",
  "url": "https://www.modo.com.ar/",
  "logo": "https://a.storyblok.com/f/244835/436x96/54d30790a2/modo-logo-pay-default.png",
  "description": "Sistema de pagos del ecosistema bancario argentino.",
  "sameAs": [
    "https://www.modo.com.ar/",
    "https://twitter.com/modoapp",
    "https://www.instagram.com/modo.ar"
  ],
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "AR"
  }
}
</script>
```
