# Platform source-share — optimización GEO por motor

Cada motor generativo usa índice, ranking y fuentes distintas. **Solo el 11% de los dominios son citados por ChatGPT Y Google AI Overviews para la misma query.** Una page optimizada para AIO puede ser invisible para ChatGPT. Por eso "AI crawlers" no es un bloque monolítico — hay que optimizar por plataforma.

Esta tabla alimenta la categoría **Platform (10%)** del GEO Score (ver `SKILL.md > Step 3`).

Datos de source-share derivados de geo-seo-claude (MIT) + estudios públicos citados ahí (Ahrefs dic-2025, análisis de citations por plataforma). Pesos opinables; revalidar a medida que los motores evolucionan.

---

## Resumen — qué fuente pesa en cada motor

| Motor | Índice base | Top fuentes citadas | Señal #1 a mover para MODO |
|---|---|---|---|
| **Google AI Overviews** | Google | Pages ya en top-10 orgánico (92%), pero 47% vienen de <pos5 | Estructura: heading-pregunta + respuesta directa + tablas |
| **ChatGPT web search** | Bing | Wikipedia (47.9%), Reddit (11.3%), YouTube, news | Entity recognition: Wikipedia/Wikidata + `sameAs` |
| **Perplexity** | propio + APIs | Reddit (46.7%), Wikipedia, YouTube | Validación comunitaria: Reddit/foros |
| **Google Gemini** | Google | similar a AIO + YouTube (Google-owned) | Igual que AIO + presencia YouTube |
| **Bing Copilot** | Bing | similar a ChatGPT (mismo índice) | Bing Webmaster Tools + entity |

**Insight para MODO**: el contenido vive client-rendered en varias rutas (home #1466). Ningún motor ejecuta JS de forma confiable → **el bloqueador transversal #1 es SSR/contenido en el HTML estático**. Resolver eso antes de optimizar por plataforma.

---

## Google AI Overviews (AIO)

Cómo elige fuentes:
- 92% de las citations vienen de pages ya en top-10 orgánico → el SEO tradicional sigue siendo la puerta.
- Pero 47% vienen de posiciones <5 → AIO tiene lógica propia que premia claridad y respuesta directa sobre rank puro.
- Overlap ~70% con featured snippets.
- Prefiere respuestas concisas, factuales, sin hedging.

Checklist MODO:
1. **Headings-pregunta** (H2/H3) que matcheen queries reales ("¿Qué bancos tienen promo con MODO?"). Mirar "People Also Ask".
2. **Respuesta directa** en la 1ª oración bajo el heading (candidata a citation standalone), después expandir.
3. **Tablas** para comparativas (promos por banco, descuentos por rubro) — AIO cita tablas fuerte.
4. **Listas** ordenadas para procesos ("cómo pagar con QR"), no-ordenadas para features.
5. **Definiciones**: "**MODO** es [definición concisa]." AIO cita definiciones seguido.
6. **Stats con fuente atribuida**.
7. **Fechas** de publicación + last-updated visibles.
8. Page a ≤3 clicks del home.

---

## ChatGPT web search (+ Bing Copilot)

Cómo elige fuentes:
- Usa el índice de **Bing**, no Google.
- Top por dominio: **Wikipedia 47.9%**, Reddit 11.3%, YouTube, news mayores.
- Pesa fuerte **entity recognition**: si la marca existe como entidad estructurada (Wikipedia, Wikidata, Crunchbase) → mucho más citable.
- Prefiere fuentes establecidas y artículos comprehensivos (2000+ palabras).

Checklist MODO:
1. **Wikipedia** — MODO ya tiene presencia como entidad fuerte en AR; verificar que el artículo esté actual y correcto. Para sub-productos/comercios, evaluar notabilidad antes de crear.
2. **Wikidata** — item con `instance of`, official website, social links, fundación, sede.
3. **Bing Webmaster Tools** — registrar el site, submit sitemap, chequear crawl errors (suele estar olvidado vs GSC).
4. **Bing index coverage** — `site:modo.com.ar` en Bing; Bing indexa distinto que Google.
5. **`sameAs`** en `Organization` schema apuntando a Wikipedia/Wikidata/LinkedIn/redes.
6. **Consistencia de entidad** — nombre, fundación, leadership consistentes cross Wikipedia/LinkedIn/site.

> Bing Copilot comparte índice con ChatGPT → estos fixes cubren ambos.

---

## Perplexity

Cómo elige fuentes:
- Top: **Reddit 46.7%**, Wikipedia, YouTube, publicaciones.
- El que MÁS pesa validación comunitaria de todos.
- Favorece threads de discusión donde el claim se debate/valida.
- Premia frescura (fecha de publicación) más agresivo que otros.
- Cita 5-15 fuentes por respuesta → más chance para sites de autoridad media.

Checklist MODO:
1. Presencia auténtica en subreddits relevantes (r/argentina, r/merval, fintech AR) — útil, no promocional.
2. Threads/AMAs de discusión.
3. Foros: además de Reddit, evaluar dónde se discute fintech AR.
4. Contenido que invita discusión (data original, hallazgos).
5. **Fechas visibles + updates regulares**.
6. Claims respaldados por múltiples fuentes (Perplexity cross-referencia).

---

## Cómo scorear Platform (input al GEO Score)

Scorear cada motor 0-100 con su checklist (≈10-15 pts por ítem cumplido), promediar los 5. Reportar también el desglose per-motor — un site puede estar 80 en AIO y 20 en Perplexity, y eso dicta dónde invertir.

Atajo: si Citability (Step 2.5) y Brand Authority ya están altos, Platform suele venir decente — hay overlap. El gap típico de MODO es **Bing/Wikidata** (lado ChatGPT) y **Reddit** (lado Perplexity), porque el esfuerzo histórico fue Google-first.
