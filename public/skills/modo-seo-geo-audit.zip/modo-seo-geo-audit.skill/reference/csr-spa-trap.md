# El trap del CSR-only · `React-Helmet` invisible para crawlers

**Regla cero del audit SEO/GEO MODO**: si el sitio es CSR-only (Vite SPA en
Lovable / Vercel SPA mode / Netlify SPA), TODO lo que emite React/Helmet/
react-helmet-async en runtime es **invisible** a los crawlers (Googlebot,
Bingbot, GPTBot, ClaudeBot, PerplexityBot, etc.).

## Cómo detectarlo

```bash
SITE="https://<sitio>"
curl -s -A "Googlebot/2.1" "$SITE/" -o /tmp/audit-home.html
curl -s -A "Googlebot/2.1" "$SITE/ruta-cualquiera" -o /tmp/audit-route.html
diff /tmp/audit-home.html /tmp/audit-route.html
# Si son idénticos → CSR trap confirmado.
# Si hay diferencias → SSR/SSG sí está activo.
```

Tests adicionales:

```bash
# Cuántas palabras renderea el body en HTML estático (sin JS)
curl -s "$SITE/" | python3 -c "
import sys, re
body = re.search(r'<body[^>]*>(.*?)</body>', sys.stdin.read(), re.S)
txt = re.sub(r'<[^>]+>', ' ', body.group(1)) if body else ''
print('palabras visibles para crawler:', len(txt.split()))
"

# Cuántos JSON-LD blocks ve el crawler (vs los que emite React/Helmet)
curl -s "$SITE/ruta-detalle" | grep -c 'application/ld+json'
```

Si una course detail / product detail page tiene <100 palabras en el body y
mismo título que el home → CSR trap.

## Impacto

- **SEO**: Googlebot indexa el shell sin contenido. Cada ruta se canonicaliza
  contra `/` automáticamente. Sin per-route metadata.
- **GEO**: AI crawlers (Perplexity, ChatGPT browse, Claude web) reciben un HTML
  con `<title>` genérico y body vacío. Cero contexto para citar el sitio.
- **JSON-LD per-route**: invisible. Solo el LD inline del `index.html` estático
  llega al crawler. React/Helmet `<JsonLd>` por página no se ven.

## Mitigaciones

### Wave 0 · curitas pre-SSG (sin migrar framework)

Embeber inline en el `index.html` estático:

1. **JSON-LD ricos**: `EducationalOrganization` o `Organization` raíz +
   `WebSite` + `BreadcrumbList` + `CollectionPage` con `mainEntity.ItemList` de
   todos los items (cursos, comercios, productos). Cada item con `offers`,
   `url`, `provider.url`, `provider.logo` completos.
2. **FAQPage** con preguntas reales del glossary/FAQ (si aplica). Nota: no da rich result en Google SERP para MODO (restringido a gov/health desde ago 2023); se embebe por valor GEO (extracción Q&A de motores AI).
3. **VideoObject** si hay video destacado.
4. **`<meta name="robots" content="index,follow,max-image-preview:large">`**
   explícito.
5. **`hreflang es-AR + x-default`** declarados.
6. **`og:image:alt`** poblado.
7. **`sitemap.xml`** sin anchors (`/#section` se colapsa al home en Google), con
   las URLs reales una por una.
8. **`robots.txt`** con AI bots explícitos (ver `robots-ai-bots.md`).
9. **`llms.txt`** poblado (ver `llms-txt-template.md`).

Caso canónico: aprendeatumodo PR #3 (commit `258154b`) — 1 LD inline → 5 LDs
ricos; sitemap 5 (4 anchors) → 8 (1 home + 7 cursos reales); robots 5 bots → 22;
llms.txt nuevo. Google Rich Results Course strict check 7/7 ✅.

**Trade-off**: el contenido inline se duplica con lo que emite React/Helmet en
runtime. Cuando aterrice SSG, hay que retirar el inline (queda solo SSG).

### Wave 1+ · resolver con SSG/SSR

Solo SSG (Next 16 con `output: 'export'` / Astro / etc.) o SSR resuelve el trap
de raíz:

- LDs emitidos en HTML estático per-route.
- `<title>`, `canonical`, `og:url`, `og:type=article` per-route.
- Cuerpo de cada page en HTML estático (no solo CSR shell).
- Sitemap dinámico desde `app/sitemap.ts` o equivalente.

## Anti-patterns

- **Confiar en DevTools** — ver `<head>` en DevTools muestra lo que React/Helmet
  inyectó client-side. NO es lo que ve el crawler. Siempre `curl -A "Googlebot"`
  primero.
- **"Pero Googlebot ejecuta JS ahora"** — sí, en una segunda pasada que puede
  tardar días, y con limitaciones. Bingbot, AI crawlers y prefetch tools usan
  solo el HTML estático. Diseñar para "primer fetch wins".
- **Dejar `<title>` solo en Helmet** — el `index.html` estático tiene un
  `<title>` único compartido entre todas las rutas. Para CSR-only, hay que
  embeber per-route via build-time generation o aceptar que el title del home
  domina.
- **OG image dinámica via Helmet** — los social crawlers (Twitterbot,
  facebookexternalhit, LinkedIn Inspector) NO ejecutan JS. La OG image debe
  estar en el HTML estático servido en el primer fetch.

## Cuándo el trap NO aplica

- Sites con SSR activo (Next.js Pages Router con `getServerSideProps`,
  Next.js App Router server components, Remix loaders, SvelteKit SSR).
- Sites con SSG (Next export, Astro, Hugo, Eleventy).
- Hybrids con prerendering selectivo de rutas críticas (Vercel, Cloudflare
  Pages prerender, etc.).

## Cross-link

- [`reference_modo_navbar_max_width_canon`](../../../../projects/-Users-hernan-desouza-Documents-Proyectos-modo-modo-landing-workspace-modo-landing/memory/reference_modo_navbar_max_width_canon.md)
- [`frontend-security-checklist`](../../frontend-security-checklist/) — Layer 3 valida CSP post-deploy contra el edge live (complementario a este audit)
