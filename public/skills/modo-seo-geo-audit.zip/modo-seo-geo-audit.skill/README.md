# modo-seo-geo-audit

Audit + fix de SEO, GEO (Generative Engine Optimization) y JSON-LD para frontends MODO. Detecta qué ven los crawlers reales (Googlebot, Bingbot, GPTBot, ClaudeBot, PerplexityBot), no qué ves vos en DevTools.

## Quick start

- Triggers: `validá SEO de <sitio>`, `audit SEO/GEO`, `JSON-LD ok?`, `valida que el sitio cumpla SEO`, `el filtro X no cambia la URL`, `no puedo compartir el resultado filtrado`, `Google no indexa /promos?categoria=...`
- Output: matriz de findings por capa (robots, sitemap, llms.txt, OG, canonical, JSON-LD, CSR trap, URL-as-state, LD per filter state, sitemap entries per filter) + plan de fixes priorizados en waves
- Ejemplo: `validá SEO de aprendeatumodo` → audit completo + W0 P0 PRs listos para mergear
- Ejemplo: `/promos no indexa categorías` → audit URL-state + plan migración a hook `useUrlFilter` + LD scoped + sitemap top categorías

## Features

- **GEO Score compuesto (0-100)** — número único trackeable cross-deploy, además de la matriz semáforo. Promedio ponderado de 6 categorías (Citability 25% · Brand 20% · E-E-A-T 20% · Technical 15% · Schema 10% · Platform 10%). Citability + Schema son determinísticos (scripts); el resto, juicio guiado por rúbrica.
- **Citability scorer** (`scripts/citability_scorer.py`) — scorea cada bloque de contenido 0-100 por citabilidad en motores generativos (5 dims: answer-block, self-containment, readability, statistical density, uniqueness). Corre con **UA Googlebot** (mide lo que ve el crawler, no el render) y avisa cuando detecta CSR-shell (0 bloques = invisible a la IA). Bilingüe ES+EN, stdlib-only.
- **Optimización GEO por plataforma** (`reference/platform-source-share.md`) — AIO/ChatGPT/Perplexity/Gemini/Copilot usan fuentes distintas (solo 11% overlap ChatGPT↔AIO). Checklist + source-share por motor; alimenta la categoría Platform del GEO Score.
- **Deprecated/restricted schema check** — `validate-jsonld.py` marca `@type` retirados (HowTo, CourseInfo, ClaimReview, etc.) y restringidos (FAQPage rich result gov/health desde ago 2023) para no vender LD inerte como win de SERP.
- **Detección del CSR trap** — el patrón canónico donde React/Helmet emite JSON-LD invisible para crawlers en SPAs.
- **URL-as-state para filtros públicos** — todo filtro (categoría, banco, día, ciudad, search, sort, paginación) vive en URL para ser crawlable, shareable, emitir LD scoped Y servir como **cache key SSR/CDN/ISR**. Mejora LCP/TTFB al cachear top combos individualmente. Code patterns para Next 12 Pages router (modo-landing) y Next 15 App router (promos-hub-site).
- **Cache headers per filter class** — política `long`/`medium`/`short`/`none` según cardinality + cacheability del estado. `s-maxage` + `stale-while-revalidate` + tag-based `revalidateTag` para invalidación desde CMS webhook.
- **Drop-ins canónicos**: 8 recipes JSON-LD para `index.html` (`EducationalOrganization`, `Organization`, `WebSite`, `BreadcrumbList`, `CollectionPage`, `Course`, `FAQPage`, `VideoObject`) + recipes scoped per filter state (`ItemList` reducido, `BreadcrumbList` con filtro como crumb, `SearchAction`, `Offer`, `Product`, `LocalBusiness`+`OfferCatalog`).
- **`robots.txt` template** con los 17 AI bots explícitos (GPTBot, ClaudeBot, PerplexityBot, Google-Extended, CCBot, etc.).
- **`llms.txt` template** canónico siguiendo https://llmstxt.org/.
- **Validador local Python** (`scripts/validate-jsonld.py`) sin dependencias externas — corre required-field check + Google Rich Results Course strict check.
- **Smoke test pre-merge** para PRs de filtros (6 checks: URL refleja filtro, subset SSR, LD scoped, default URL limpia, noindex combinatoria, Googlebot ve subset).
- **MODO canonical assets** ya verificados (logo Storyblok 200 OK).

## Files

- `SKILL.md` — proceso completo de audit (1 inventario → 2 parse + lint → 2.5 citability → 3 GEO Score + matriz → 4 wave 0 curitas → 5 wave 1+ SSG)
- `README.md` — esta doc
- `reference/json-ld-recipes.md` — 8 recipes drop-in
- `reference/json-ld-per-filter-state.md` — recipes LD scoped a filtros (ItemList reducido, BreadcrumbList con filter crumb, SearchAction, Offer, Product, LocalBusiness+OfferCatalog, FAQPage scoped)
- `reference/url-as-state-filters.md` — code patterns Next 12 Pages + Next 15 App router (`useUrlFilter` hook, `buildCanonical`, sitemap dinámico, smoke test pre-merge)
- `reference/robots-ai-bots.md` — bots IA canónicos
- `reference/llms-txt-template.md` — formato canónico llms.txt
- `reference/csr-spa-trap.md` — explicación + detección + mitigación
- `reference/platform-source-share.md` — optimización GEO por motor (AIO/ChatGPT/Perplexity/Gemini/Copilot) + source-share + checklists
- `scripts/validate-jsonld.py` — validador local (file | url | stdin) + deprecated/restricted @type check
- `scripts/citability_scorer.py` — citability scorer GEO (file | url | stdin, UA Googlebot default, `--json`)

## Validador

```bash
# Contra una URL live
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py https://aprendeatumodo.modo.com.ar/

# Contra un archivo HTML
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py /tmp/index.html

# Por stdin
curl -s https://<sitio>/ | python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py -
```

Exit codes: 0 = todo OK · 1 = required-field gaps · 2 = parse errors.

## Citability scorer

```bash
# Contra una URL live (UA Googlebot — lo que ve el crawler)
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/citability_scorer.py https://www.modo.com.ar/

# JSON raw (para pipear al GEO Score)
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/citability_scorer.py /tmp/index.html --json
```

El `citability_score` (promedio top-5 bloques, 0-100) es el input determinístico de la categoría Citability (25%) del GEO Score. Si devuelve 0 bloques contra Googlebot → contenido CSR invisible a la IA = bloqueador GEO #1.

## Atribución

Rúbrica de citability (rangos 134-167 palabras, pesos 30/25/20/15/10) y el estado deprecated/restricted de schemas derivados de dos skills MIT, reimplementados/adaptados para el stack MODO (stdlib-only, bilingüe ES+EN, UA crawler, voz MODO):
- [zubair-trabzada/geo-seo-claude](https://github.com/zubair-trabzada/geo-seo-claude) (MIT) — `citability_scorer.py`, scoring methodology, platform source-share.
- [AgriciDaniel/claude-seo](https://github.com/AgriciDaniel/claude-seo) (MIT) — `hooks/validate-schema.py` deprecated-type list.

## Cross-link

- [`frontend-security-checklist`](../frontend-security-checklist/) — Layer 3 (CSP post-deploy) complementa este audit
- [`modo-design-system`](../modo-design-system/) — tokens/branding
- [`modo-research-article`](../modo-research-article/) — output canónico para reports SEO largos en bitácora
- [`nextjs-pages-router-migration`](../nextjs-pages-router-migration/) — destino natural cuando se migra a SSG/SSR para resolver el CSR trap de raíz

## Caso canónico

aprendeatumodo · 2026-05-23 · PR [#3](https://github.com/SoyErnoModo/aprendeatumodo/pull/3) (`feat(COENXT-309): SEO/GEO P0`):

| Item | Antes | Después |
|---|---|---|
| LD blocks en index.html | 1 | 5 (rich) |
| Sitemap URLs | 5 (4 anchors) | 8 (home + 7 cursos reales) |
| AI bots en robots.txt | 0 | 17 explícitos |
| llms.txt | 404 | nuevo |
| Google Rich Results Course strict check | 0/7 | 7/7 ✅ |

## Changelog

- **2026-05-23** — Skill creado. SKILL.md + 4 references + 1 script + caso canónico aprendeatumodo PR #3.
- **2026-05-25** — URL-as-state para filtros públicos. Nueva sección core en SKILL.md + 2 references nuevos (`url-as-state-filters.md`, `json-ld-per-filter-state.md`). Aplica a modo-landing `/promos` + `/comercios` y promos-hub-site root. Code patterns Next 12 Pages + Next 15 App router. Smoke test pre-merge para PRs de filtros.
- **2026-05-25 (cache)** — `url-as-state-filters.md > §7 Cache SSR`. URL es la cache key. Capas (browser/CDN/ISR/RSC/in-app), header policy 4-clases (`long`/`medium`/`short`/`none`), `unstable_cache` + `revalidateTag` patterns Next 15, cardinality control (whitelist top combos), trade-off vs client-filtering actual, smoke test `cf-cache-status`. SKILL matriz Step 3 sumó 2 capas (cache headers + hit rate). 4 anti-patterns cache añadidos (Vary Cookie/UA, no-cache global, default no-vacío, cardinality explosiva).
- **2026-06-09** — Nuevo `reference/legacy-domain-redirect.md`: deindexar host/path viejo + migrar equity al propio. Reglas: redirect cross-host **absoluto al host canónico** (`CANONICAL_BASE_URL`, no relativo — relativo rompe en subdominio legacy repuntado), no mass-redirect (soft 404), map 1:1 + 410 para muertos, no robots-block del viejo, deindex de host de terceros (Salesforce). Gotcha GSC inspect apex-vs-www (falso "unknown to Google"). Caso canónico modo-landing PR #1539 (`/support/*` → `www.modo.com.ar/ayuda/preguntas-frecuentes`).
- **2026-06-04** — **GEO quantitative core**. Nuevo `scripts/citability_scorer.py` (citability 0-100 por bloque, UA Googlebot, CSR-shell guard, bilingüe, stdlib-only). GEO Score compuesto 0-100 (6 categorías) en SKILL.md Step 3 + nuevo Step 2.5. `validate-jsonld.py` suma deprecated/restricted @type check. Nuevo `reference/platform-source-share.md` (GEO por motor). Fix overclaim: `FAQPage` ya no da rich result Google (gov/health desde ago 2023) — anotado en SKILL + 3 references. Ideas adaptadas de geo-seo-claude + claude-seo (MIT, ver Atribución). Hallazgo en build: `modo.com.ar` home = 0 bloques de contenido a Googlebot (body CSR, #1466) — bloqueador GEO #1.
- **2026-05-27** — Nueva sección core en SKILL.md: **SSR cache-correctness + LCP de animaciones de entrada**. (A) `Cache-Control` en SSR cachea solo en el success path — nunca `notFound`/`redirect`/`preview`/error transitorio (CDN poisoning sobre URL válida). Helper `setCmsCacheHeaders` con TTL único + verify-grep. (B) Fade-in de entrada con `opacity:0` sobre el contenedor del LCP element difiere LCP → arrancar en `opacity:0.6`. 2 anti-patterns añadidos. Caso canónico modo-landing PR #1489.
