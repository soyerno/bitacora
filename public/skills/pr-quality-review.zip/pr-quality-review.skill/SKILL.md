---
name: pr-quality-review
description: Comprehensive PR quality review against team standards. Analyzes PR metadata, code quality, SonarCloud results, architecture, SEO, accessibility, and generates a Slack-ready report. Use when asked to "review PR", "analyze PR", "check PR quality", or given a GitHub PR URL to evaluate.
---

# PR Quality Review Skill

> Hermano del skill `modo-pr-author` (autor) — este skill REVISA PRs ya creados contra el estándar MODO canónico definido en `~/.claude/skills/modo-pr-author/reference/pr-template-modo.md`. Cuando el template cambie, este skill debe re-leer la fuente de verdad.

## When to use
- User asks to review, analyze, or check a PR.
- User provides a GitHub PR URL for evaluation.
- User asks to compare two PRs.
- Auto-invocar cuando se pega URL `github.com/playsistemico/*/pull/N` y se pide feedback.

## Data Collection

```bash
# 1. PR metadata + body
gh pr view {N} --repo {OWNER}/{REPO} --json title,body,headRefName,additions,deletions,files,state,mergeable,mergeStateStatus,reviewDecision

# 2. CI checks
gh pr checks {N} --repo {OWNER}/{REPO}

# 3. SonarCloud (si configurado)
gh api repos/{OWNER}/{REPO}/commits/$(gh pr view {N} --json headRefOid --jq '.headRefOid')/check-runs \
  --jq '.check_runs[] | select(.name | contains("Sonar")) | {conclusion, summary: .output.summary}'

# 4. Diff (sample, no full dump para PRs grandes)
gh pr diff {N} --repo {OWNER}/{REPO} | head -500

# 5. Files cambiados
gh pr view {N} --json files --jq '.files[].path'
```

## Analysis Checklist

### 1. Title & metadata
- [ ] Title formato `type(SCOPE-XXX): subject` (commitlint MODO)
- [ ] Title ≤70 BYTES (no chars — verificar con `echo -n "<title>" | wc -c`, em-dash/flecha multi-byte)
- [ ] Title no termina con `…` (truncado por GitHub)
- [ ] Title en imperativo lowercase, sin punto final
- [ ] Branch name follows convention (`feat/`, `fix/`, `ci/`, `chore/`, `perf/`, `docs/`)

### 2. Secciones canónicas MODO (header check)

Estas 3 son **obligatorias** en todo PR de código de producción:

- [ ] `## 🎯 ¿Qué dolor soluciona?` — problema concreto + medible. Si no hay número/incidente/deuda → PR es vaporware.
- [ ] `## 🛠️ ¿Qué tuvimos que hacer?` — lista numerada de decisiones técnicas con paths reales.
- [ ] `## 🎁 ¿Para qué?` — outcome verificable (métrica objetivo o capacidad nueva).

Adicionales según matriz de obligatoriedad:

- [ ] `## Ticket` arriba del body con link Jira (preferido sobre `## JIRA` al final) — caso canónico PR #1497.
- [ ] `## Milestone · <área/epic>` — si el PR aporta a programa multi-PR.
- [ ] `## Por qué ahora` — timing/urgencia.
- [ ] `## Por qué no <alternativa>` — descarte técnico explícito (≠ "Por qué ahora").
- [ ] `## Fuera de alcance (follow-up)` con prosa — si scope grande, explicar qué queda fuera y por qué.
- [ ] `## ⚠️ Heads-up antes de mergear` — decisiones que el reviewer debe tomar.
- [ ] `## Verificación` compacta (PRs <300L) **O** `## Tests` + `## Performance` con tablas (PRs ≥300L).
- [ ] `## Rollback` — refactors, data migrations, infra (obligatorio cuando aplica).
- [ ] `## Reviewers solicitados` — si cross-team o áreas con dueño.
- [ ] `## Security review` — obligatoria si toca `src/pages/api/`, `next.config.js`, `.github/workflows/`, `helm/`, deps nuevas, auth/tokens/session.
- [ ] `## Evidencia` — screenshots desktop 1280x800 + mobile 375x812 para UI; "N/A — sin cambios visuales" explícito para backend/CI.
- [ ] `## Checklist` MODO con marcas reales (no todo desmarcado, no todo `[x]` ciego).
- [ ] `## Follow-ups` bullets — próximos PRs / tech-debt identificada.

**Quick-grep para detectar headers**:
```bash
gh pr view {N} --json body --jq '.body' | grep -E "^## (🎯|🛠️|🎁|Ticket|Milestone|Por qué|Heads-up|Verificación|Tests|Performance|Rollback|Reviewers|Security|Evidencia|Checklist|Follow-ups|JIRA)"
```

### 3. Variantes por tipo de PR

Aplicar la matriz de obligatoriedad de `~/.claude/skills/modo-pr-author/reference/pr-template-modo.md` según el `type` del title:

| Type | Secciones obligatorias extra |
|---|---|
| `feat` visual | Evidencia con screenshots reales · Tests · Performance si tráfico alto |
| `feat` backend | Verificación o Tests · Security review si toca BFF/api |
| `fix` | Root cause + Fix + Regression test · Heads-up si afectó prod |
| `refactor` | Heads-up obligatorio · Rollback obligatorio · Tests preservados |
| `ci` / `chore` | Evidencia "N/A" explícito · Heads-up si rompe builds · Security review si workflows |
| `docs` | Cuerpo corto OK · Sin Evidencia · Linkear fuentes (Confluence/ADR/RFC) |
| `perf` | Tabla bundle / Web Vitals antes-después obligatoria · Targets numéricos |
| `security` / BFF / infra | Security review obligatoria · Rollback obligatorio · Reviewers cross-team |

### 4. SonarCloud Quality Gate
- [ ] 0 new code smells
- [ ] 0 new bugs
- [ ] 0 security hotspots TO_REVIEW del PR (legacy hotspots se marcan SAFE con justificación)
- [ ] Duplication ≤ 3%
- [ ] Reliability A · Maintainability A · Security A
- [ ] Coverage no regresa (delta ≥0)

### 5. Code Quality (diff scan)
- [ ] No hardcoded credentials / API keys / tokens (debe ser env var)
- [ ] No `console.log/error/warn` en código de producción (MODO usa logger estructurado client + Datadog Browser Logs · ver PR #1497)
- [ ] No placeholders sin completar: `[Change!]`, `<TBD>`, `lorem ipsum`, `XXXXXXXX`
- [ ] No comentarios TODO/FIXME nuevos sin ticket linkeado
- [ ] No hardcoded URLs externas para imágenes/recursos (usar Storyblok / CDN)
- [ ] PropTypes o TypeScript types en todos los props
- [ ] No componentes duplicados / copy-paste (DRY)
- [ ] URLs HTTPS (no `http://` ni siquiera para gob.ar — verificar redirect)

### 6. Architecture & Patterns
- [ ] Sigue patrones existentes (Tailwind primary, no CSS modules en repos Tailwind)
- [ ] Usa design tokens (colores/fuentes del design-system), no hardcoded hex
- [ ] Usa componentes shared existentes (no reinventar)
- [ ] SEO en pages nuevas (`<Head>` con title/description/canonical)
- [ ] Scripts via `next/script` (no `document.createElement`)
- [ ] SSR guards donde se accede `window`/`document`/`navigator`

### 7. Accessibility
- [ ] `alt` descriptivo en todas las imágenes (nunca `alt=""` sin justificar)
- [ ] Elementos interactivos semánticos (`<button>`, `<a>`) no `<div onClick>`
- [ ] No emoji como UI funcional
- [ ] Navegación por teclado funciona
- [ ] Contraste AA cumplido (verify con Lighthouse si UI)

### 8. Testing
- [ ] Componentes nuevos con tests
- [ ] Snapshots actualizados intencionalmente (no como side-effect)
- [ ] No regresiones (suite verde)
- [ ] Regression test en PRs `fix` (reproducir el bug primero, ver memoria `feedback_comercios_sdd_tdd`)
- [ ] No nuevos Jest snapshots (equipo quiere eliminarlos — ver memoria `feedback_no_snapshot_tests`)

### 9. Voice & language (voz rioplatense)
- [ ] Sin buzzwords consultoría: `stakeholders`, `deliverables`, `leverage`, `apetito`, `Si hay apetito`
- [ ] Spanish para PR body, English para código/identifiers
- [ ] Body en voseo, sin formal pasivo ("se implementó una solución")
- [ ] Estimates marcan "con IA" explícito si aparecen tiempos (ver memoria `feedback_estimates_assume_ai`)
- [ ] PRs **no** muestran "Esfuerzo IA" en tablas (ver memoria `feedback_no_ai_effort_in_prs`)

### 10. State & mergeability
- [ ] `mergeable: MERGEABLE`
- [ ] `mergeStateStatus: CLEAN` (no `BLOCKED` por reviews stale)
- [ ] Approval no stale (verificar fecha de approval vs último push)
- [ ] CI todo verde (Sonar, lint, tests, security, bundle)

## Output Format

```markdown
## Análisis PR #{N} — `{title}`

### Status
| Check | Estado |
|---|---|
| Mergeable | {value} |
| CI | {X/Y green} |
| Sonar | {pass/fail · count issues} |
| Reviews | {N approved · stale? Y/N} |

### Secciones canónicas MODO
| Sección | Presente |
|---|---|
| 🎯 ¿Qué dolor? | ✅/❌ |
| 🛠️ ¿Qué hacer? | ✅/❌ |
| 🎁 ¿Para qué? | ✅/❌ |
| Ticket arriba | ✅/❌ |
| Milestone · epic | ✅/❌/N/A |
| Por qué ahora | ✅/❌ |
| Por qué no <alt> | ✅/❌/N/A |
| Fuera de alcance | ✅/❌/N/A |
| Heads-up | ✅/❌/N/A |
| Verificación / Tests | ✅/❌ |
| Security review | ✅/❌/N/A |
| Evidencia | ✅ (shots) / N/A explícito / ❌ |
| Checklist marcado | ✅/❌ |

### Problemas críticos
{numbered list, most severe first}

### Arquitectura / patrones
{bullets sobre desvíos del baseline MODO}

### SEO / Accesibilidad
{bullets}

### Calidad código
{bullets sobre console.log, hardcoded creds, etc.}

### Voz / lenguaje
{buzzwords detectados, copy a corregir}

### Cambios necesarios (priorizados)
{numbered list, blocker → minor}
```

## Comparison Mode

Cuando se comparan dos PRs:
- Side-by-side metrics table (additions, deletions, files, Sonar score)
- File diff (qué archivos hay en uno y no en otro)
- Delta analysis (qué mejoró, qué regresó, qué quedó igual)
- Conclusión: cuál está más cerca de merge-ready y por qué

## PR Fragmentation Suggestion

Cuando un PR es muy grande (>500 added lines o cruza features no relacionadas), sugerir splits.

**Cuándo sugerir**:
- PR mezcla cambios de infra (`_document.js`, navbar) con feature code
- PR contiene componentes que sirven propósitos distintos
- PR modifica shared/core files AND adds new isolated features
- PR tiene >1000 added lines con fronteras funcionales claras

**Cómo sugerir**:
- Identificar 2-4 fragmentos lógicos
- Nombrar cada fragmento con scope (`type(SCOPE): description`)
- Explicar orden de dependencia
- Justificar por qué reduce riesgo

## Slack Format

Cuando se pide formato Slack:
- Misma estructura pero rendea en Slack markdown (no GFM tables, usar texto alineado)
- Emoji sparingly: ❌ fail, ✅ pass, ⚠️ warning
- Cerrar con "Cambios necesarios" numerada
- Keep tables as simple aligned text (no pipes)

## Reference PRs

PRs canónicos como gold standard de estructura — leer antes de revisar PRs nuevos del mismo tipo:

| PR | Tipo | Qué hace bien |
|---|---|---|
| [#1497 logger MODO-core](https://github.com/playsistemico/modo-landing/pull/1497) | feat backend | Ticket arriba · Milestone · Por qué no `<alt>` · Fuera de alcance prosa · Verificación compacta |
| [#1480 security workflow](https://github.com/playsistemico/modo-landing/pull/1480) | ci | Title <70b · Heads-up A/B · Evidencia N/A explícito · Security review checklist |

Detalle de qué hace bien cada uno: `~/.claude/skills/modo-pr-author/examples/`.

## Crosslinks

- `modo-pr-author` — autoría de descripciones. Source-of-truth del template canónico.
- `guardia` — multi-agent parallel review (Sonar + tests + React + security + CI + bundle).
- `modo-code-review-checklist` — quality rules baseline (no console.log, JIRA linked, tokens).
- Memoria `feedback_pr_description_sync` — sync title/body tras push.
- Memoria `feedback_rioplatense_voice` — voz canónica.
- Memoria `feedback_no_apetito` — banned words.

## Source of truth

El template MODO canónico vive en `~/.claude/skills/modo-pr-author/reference/pr-template-modo.md`. Cuando el revisor detecte un PR con estructura que no está en el template (ej. nuevas secciones recurrentes en varios PRs gold-standard), **proponer update al template** en lugar de aceptar drift silencioso.
