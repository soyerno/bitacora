# modo-landing-page-builder

Triple-layer skill MODO para crear páginas Storyblok-managed en **modo-landing** de punta a punta, con los 4 gates de calidad del equipo horneados. Es el harness ejecutable de la capacitación `erno-modo/capacitaciones/storyblok-pages/`.

## Layers
- **Skill** — `SKILL.md` (auto-invocable: "crear página en modo-landing", "nueva página Storyblok", "agregar blok CMS").
- **Agent** — `~/.claude/agents/modo-landing-page-builder.md` (ejecutor con worktree + barrier de gates).
- **Slash** — `/modo-landing-page-builder [slug] [--blok X] [--audit-only]`.
- **Workflow** — `capacitaciones/storyblok-pages/harness/page-builder.workflow.js` (gates en paralelo).

## Qué hace
Orquesta (no duplica) el pipeline real de modo-landing:
diseño SDD + design system → story Storyblok + blok wireado al registry `CMS_COMPONENTS` → TDD red→green → 4 gates (code review+SDD · perf+CSP · a11y+SEO) en paralelo con barrier → deploy alpha a playsistemico.

## Delega a
`sdd-*`, `modo-design-system`, `modo-storyblok`, `test-driven-development`, `guardia`, `frontend-security-checklist`, `modo-seo-geo-audit`, `modo-frontend-deploy`, `modo-pr-author`.

## Reference
- `reference/page-creation-recipe.md` — story + render pipeline.
- `reference/blok-registry-recipe.md` — los 3 puntos de registro + verify-grep.
- `reference/gates-recipe.md` — comando + criterio + evidencia por gate.

## Principios
Worktree siempre · spec antes de código · test antes de implementación · gate con evidencia antes de deploy · no claim sin verify-grep · prod fuera de scope.

## Ancla en código (modo-landing)
- `src/pages/[[...slug]].jsx` — `getServerSideProps` + render del `body`.
- `src/CMS/utils/availableComponents.tsx` — registry `CMS_COMPONENTS`.
- `src/CMS/utils/utils.tsx` — `getCMSComponent`.
- `src/CMS/components/CMSHeroPrimary/` — molde de blok adaptador.
- `.github/workflows/ci-alpha.yaml` — deploy alpha.

## Changelog

- **2026-06-01** — Skill creado como harness de la capacitación `erno-modo/capacitaciones/storyblok-pages/` (PR SoyErnoModo/erno-modo#61). Triple-layer (skill+agent+slash) + Workflow `page-builder.workflow.js` (gates ‖ + barrier pre-deploy). Audit-iterate independiente: 0 findings, claims verificadas contra código real modo-landing. Detalle en `SKILL.md`.

Autor: Hernán De Souza · Sr AI Engineer · MODO.
