# Recipe · Los 4 gates

Cada gate retorna `{ passed: bool, findings: [...], evidence: "..." }`. **El deploy-alpha es un barrier: solo procede si todos `passed`.** Sin evidencia = no pasó (`feedback_no_mentir_pedir_help`).

## Gate 1 · TDD red→green
- **Skill:** `test-driven-development`
- **Comando:** `pnpm test` (o `npx jest <path>` / `pnpm test:specific -t "<Nombre>"`)
- **Passed cuando:** test escrito antes (red visto), verde ahora, RTL semántico, **sin snapshots**, cada scenario de la spec con su `it`.
- **Evidencia:** salida de jest con los tests verdes + el commit del test previo a la implementación.

## Gate 2 · Code review + SDD
- **Skill:** `guardia` + SonarCloud MCP + `sdd-verify`
- **Comando:** `/guardia` (o `pr-quality-review`)
- **Passed cuando:** Quality Gate verde (0 new smells, 0 hotspots, ≤3% dup), sin `console.*`, sin hex, tipos en props; `sdd-verify` OK; tasks tildadas.
- **Evidencia:** link al Quality Gate + reporte de guardia.
- **Ojo:** Sonar corre en olas — un fix puede activar otra regla. No declares done sin el scan final.

## Gate 3 · Performance + CSP
- **Skill:** `chrome-devtools` (lighthouse_audit) + `frontend-security-checklist` Layer 3
- **Comando:** `lighthouse_audit <url>` · `/modo-security-csp <host>`
- **Passed cuando:** LCP/CLS dentro de umbral; CSP/headers OK contra el edge. Si tu blok carga assets de un dominio nuevo → agregalo a la directiva CSP en `next.config.js`.
- **Trampa:** los bloks rinden con `dynamic({ ssr:false })`. Si tu blok es el LCP (hero), evaluá SSR/`priority`.
- **Evidencia:** reporte lighthouse + salida del validador CSP.

## Gate 4 · a11y + SEO/GEO
- **Skill:** `modo-seo-geo-audit` + WCAG
- **Comando:** `/modo-seo-geo-audit`
- **Passed cuando:** sin barreras WCAG (alt descriptivo, roles, foco, contraste con tokens); `seo[0]` seteado; JSON-LD válido (Rich Results); URL-as-state para filtros.
- **Evidencia:** reporte del audit + validación Rich Results.

## Orden
1. TDD (local) → 2. Code review (PR) → 3. a11y+SEO (local/PR) → 4. Perf+CSP (contra alpha).
El Workflow corre 2, 3, 4 en paralelo (TDD ya cerró en fase previa) y hace barrier antes del deploy.
