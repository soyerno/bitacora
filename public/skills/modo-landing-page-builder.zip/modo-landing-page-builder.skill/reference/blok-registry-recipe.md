# Recipe · Wiring de un blok al registry (los 3 puntos)

Si `body` usa un `component` que no está en `CMS_COMPONENTS`, `getCMSComponent` devuelve `undefined` y el blok no rinde. Tres puntos + el string en la story.

## Estructura del blok

`src/CMS/components/CMS<Nombre>/`
- `types.ts` — interface `extends IDefaultFields`, campos de Storyblok.
- `index.tsx` — adaptador fino: `data` → componente de `@playsistemico/modo-ui-lib-web` (o `<section>` con tokens si no hay lib component).
- `<Nombre>.test.tsx` — RTL semántico.

Molde: `src/CMS/components/CMSHeroPrimary/` (adaptador de 30 líneas con `useMemo` para listas).

## Punto 1 · interface — `src/CMS/types.ts`
```ts
import { ICMS<Nombre> } from './components/CMS<Nombre>/types';
export interface IAvailableComponents {
  // ...
  <Nombre>: (data: ICMS<Nombre>) => JSX.Element;
}
```

## Punto 2 · registry — `src/CMS/utils/availableComponents.tsx`
```ts
import CMS<Nombre> from '../components/CMS<Nombre>';
import { ICMS<Nombre> } from '../components/CMS<Nombre>/types';
export const CMS_COMPONENTS: IAvailableComponents = {
  // ...
  <Nombre>: (data: ICMS<Nombre>) => <CMS<Nombre> data={data} />,
};
```

## Punto 3 · el `component` en la story
`{ "component": "<Nombre>", ... }` — exacto, case-sensitive. Mismatch = no rinde, sin error.

## Si el blok referencia otra story
Agregá `<Nombre>.reference` a `storyblokResolveRelations` en `src/CMS/constants/storyblok.ts` (sino la relación llega sin resolver).

## Verify-grep antes de declarar "registrado"
```bash
grep -n "<Nombre>" src/CMS/types.ts src/CMS/utils/availableComponents.tsx
```
Si no aparece en LOS DOS → no está registrado, está en tu cabeza.
