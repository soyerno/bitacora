# Recipe · Crear la página (story + render)

## 1. La story en Storyblok

`full_slug` = ruta (`promos/black-friday` → `/promos/black-friday`). Campos clave:

```
content
 ├─ seo[0]               { title, description }  → CMSSEO
 ├─ seo_structured_data[]  JSON-LD extra (opcional)
 └─ body[]               bloks en orden, cada uno { component, _uid, ...campos }
```

El `component` string de cada blok = la key del registry `CMS_COMPONENTS`. Contrato exacto, case-sensitive.

Crear con `modo-storyblok` (MCP o curl JSON-RPC). Mínimo: `full_slug`, `body[]`, `seo[0]`, **publicar**.

## 2. Cómo se trae y rinde (no lo escribís, entendelo)

`src/pages/[[...slug]].jsx` — `getServerSideProps`:
```js
const { data } = await getStoryblok().get(`cdn/stories/${slug}`, {
  version: 'published',                       // draft solo en low-env + ?preview=true
  resolve_relations: storyblokResolveRelations,
});
// data.story.content.body.map(el => <DynamicCMSComponent element={el} />)
```

`DynamicCMSComponent` es `dynamic(..., { ssr:false })` → ojo perf si tu blok es el LCP.

`getCMSComponent` (`src/CMS/utils/utils.tsx`):
```ts
const component = CMS_COMPONENTS[element.component];
if (component) return component(element);   // undefined si no existe → no rinde
```

## 3. Verificar

```bash
pnpm dev
# ruta publicada:
open http://localhost:3000/<slug>
# draft en low-env:
open "http://localhost:3000/<slug>?preview=true"
```

## Trampas

- **`component` mismatch** (case/typo) → blok no aparece, sin error. Verificá contra `CMS_COMPONENTS`.
- **Story no publicada** → 404 en prod / no aparece sin `?preview=true`.
- **Relación a otra story** (referencia) → agregar `<Blok>.reference` a `storyblokResolveRelations` (`src/CMS/constants/storyblok.ts`).
- **Dev server zombie** → `ps aux | grep "node server"`; matar el huérfano de `.claude/worktrees/*` borrado.
