---
name: modo-landing-page-builder
description: Orquesta crear una página Storyblok-managed en modo-landing de punta a punta — diseño SDD + design system, autoría de story, wiring del blok al registry CMS_COMPONENTS, TDD red→green, los 4 gates (code review + SDD · performance + CSP · a11y + SEO/GEO) en paralelo, y deploy alpha a playsistemico. Auto-invocable cuando el user diga "crear página en modo-landing", "nueva página Storyblok", "agregar un blok CMS", "armá una landing en modo-landing", "/modo-landing-page-builder". ORQUESTA skills existentes (modo-storyblok, modo-design-system, sdd-*, test-driven-development, guardia, frontend-security-checklist, modo-seo-geo-audit, modo-frontend-deploy) — no los duplica. Companion de la capacitación erno-modo/capacitaciones/storyblok-pages/.
---

# modo-landing Page Builder

Crear una página administrada por Storyblok en **modo-landing** (Next.js 12, Pages Router) de punta a punta, con los gates de calidad del equipo horneados. Este skill es el **harness ejecutable** de la capacitación `capacitaciones/storyblok-pages/` en erno-modo.

> **Orquesta, no duplica.** Cada fase delega al skill especializado. Si una fase tiene un skill propio, lo invoca — no reimplementa su lógica.

## Cuándo usar

- Crear una página/landing nueva administrada por Storyblok en modo-landing.
- Agregar un blok CMS nuevo (componente React wireado al registry).
- Editar el `body` de una story existente con bloks nuevos.

## Cuándo NO usar

- Front nuevo a subir a playsistemico desde cero → `modo-frontend-onboarding`.
- Página que NO es CMS-driven (ruta dedicada en `src/pages/`) → frontend skills directos, sin Storyblok.
- Solo deploy de infra → `modo-frontend-deploy`.

## El pipeline real (verificado en código)

```
Storyblok story (full_slug = URL)
   │ getServerSideProps          src/pages/[[...slug]].jsx
   ▼ cdn/stories/<slug> (SSR, resolve_relations)
story.content.body[]
   │ DynamicCMSComponent → getCMSComponent(element)   src/CMS/utils/utils.tsx
   ▼ CMS_COMPONENTS[element.component]                src/CMS/utils/availableComponents.tsx
<CMSBlok data={element}>  ── @playsistemico/modo-ui-lib-web + tokens tailwind
```

Crear página = autorar la story + (si el blok no existe) crear el componente y registrarlo en **3 puntos**.

## Prerrequisitos (chequear ANTES)

- Ambiente modo-landing listo: node 22.22.2, pnpm, `.npmrc` GH Packages (`@playsistemico`), `STORYBLOK_API_KEY`. Ver lección 00.
- Region/space Storyblok confirmado (código usa `region: 'eu'` en `src/CMS/config.ts` — verificá contra tu token).
- Worktree dedicado para el cambio de código (`feedback_git_worktrees`). Nunca el checkout principal.

## Fases

### Fase 0 · Discovery (no asumir)
Recopilá, preguntando si falta: slug/URL de la página, qué bloks la componen, cuáles ya existen vs cuál creás, qué datos consume cada blok nuevo, scope (¿es ruta sensible tipo /comercios → SDD+TDD estricto?).

### Fase 1 · Diseño — `sdd-*` + `modo-design-system`
- `sdd-explore` → mapear bloks reusables (mirá `CMS_COMPONENTS`).
- `sdd-propose` + `sdd-design` + `sdd-spec` → scenarios GIVEN/WHEN/THEN verificables en `openspec/changes/<slug>/`.
- `modo-design-system` → blok nuevo = adaptador fino sobre `modo-ui-lib-web` + tokens tailwind (sin hex).
- Decisión reusar-vs-crear por blok, justificada.

### Fase 2 · Scaffold — `modo-storyblok`
- Crear/editar la story (`full_slug`, `body[]`, `seo[0]`), publicar (o `?preview=true` en low-env).
- Blok nuevo: `src/CMS/components/CMSX/{index.tsx,types.ts}` + registrar en los 3 puntos (ver `reference/blok-registry-recipe.md`).

### Fase 3 · TDD — `test-driven-development`
- Test PRIMERO (RTL semántico, **sin snapshots**), visto fallar (red) → implementación mínima (green) → refactor.
- Cada scenario de la spec = un `it(...)`.

### Fase 4 · Gates en paralelo — Workflow
Para los gates independientes, disparar el Workflow `capacitaciones/storyblok-pages/harness/page-builder.workflow.js` (fan-out). Gates:
1. **Code review + SDD** — `guardia` / SonarCloud (0 smells, 0 hotspots, ≤3% dup) + `sdd-verify`.
2. **Performance + CSP** — `chrome-devtools` lighthouse_audit + `frontend-security-checklist` Layer 3.
3. **a11y + SEO/GEO** — `modo-seo-geo-audit` + WCAG (alt descriptivo, JSON-LD, URL-as-state).

Cada gate retorna `{passed, findings, evidence}`. **Barrier: el deploy-alpha solo procede si TODOS `passed`.** Ver `reference/gates-recipe.md`.

### Fase 5 · Deploy alpha — `modo-frontend-deploy`
- `gh workflow run ci-alpha.yaml -f environment=develop --ref <rama>`.
- Smoke 200 en la ruta. Cerrar perf+CSP contra el alpha.
- **Prod NO** — gate GRC + decisión de equipo, fuera de scope.

### Fase 6 · Verify + cierre
- `sdd-verify`, `sdd-track` (tildar tasks con evidencia).
- PR con `modo-pr-author` (dolor/hicimos/para qué). Commit `type(SCOPE-XXX): Subject`.

## Reglas no negociables

- Sin `console.log/error/warn` en prod · sin hex (tokens) · tipos en props · `alt` descriptivo · sin snapshots.
- No claim "gate verde" sin evidencia (`feedback_no_mentir_pedir_help`). Un gate sin evidencia = no pasó.
- Worktree siempre. SDD bajo `openspec/changes/`.

## Layers

- **Skill** (este archivo) — auto-invocable, describe el flujo.
- **Agent** — `~/.claude/agents/modo-landing-page-builder.md` (ejecutor con worktree).
- **Slash** — `/modo-landing-page-builder`.
- **Workflow** — `capacitaciones/storyblok-pages/harness/page-builder.workflow.js` (gates fan-out).

## Referencias

- `reference/page-creation-recipe.md` — paso a paso de story + render.
- `reference/blok-registry-recipe.md` — los 3 puntos de registro + trampas.
- `reference/gates-recipe.md` — comando + criterio por gate.
- Capacitación: `erno-modo/capacitaciones/storyblok-pages/`.
