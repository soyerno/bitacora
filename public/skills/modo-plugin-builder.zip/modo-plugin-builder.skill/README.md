# modo-plugin-builder

Construir plugins Claude Code MODO con el patrón canónico **triple-layer** (skill auto-invocable + agent worktree-delegable + slash commands) + **symlink architecture** para no duplicar skills.

## Quick start

- Trigger: `/modo-plugin-builder`, "armá un plugin MODO", "promover skill a triple-layer", "convertí esta skill en plugin"
- Output: `~/.claude/plugins/modo-<scope>/` con plugin.json + agent + N commands + skills symlinkeadas + smoke tests verdes
- Ejemplo: "armá un plugin MODO para X" → estructura completa lista para reiniciar Claude Code

## Features

- Triple-layer canónico aplicado consistentemente
- Symlinks de skills (no duplicación, edits propagan)
- Templates para plugin.json / agent.md / command.md / README.md
- Smoke tests one-liner
- Decision criteria: skill suelta vs plugin
- Path traps documentados (node sin nvm en harness, find sin -L)
- 5 plugins canónicos como ejemplos vivos

## Files

- `SKILL.md` — proceso 13 pasos + reglas operativas + anti-patterns + decision criteria
- `README.md` — esta doc
- `reference/`
  - `plugin-json-template.json` — shape mínimo de plugin.json
  - `agent-template.md` — esqueleto agent con frontmatter description rica
  - `command-template.md` — esqueleto slash command con argument-hint
  - `readme-template.md` — esqueleto README del plugin
  - `smoke-tests.md` — tests pre-shipping + one-liner consolidado

## Plugins MODO ya creados (canonical examples)

| Plugin | Agent | Commands | Skills |
|--------|-------|----------|--------|
| modo-sdd | SDD Orchestrator | 5 | 10 sdd-* |
| modo-pr | MODO PR Author | 2 | 1 |
| modo-security | MODO Security Auditor | 2 | 1 |
| modo-content | MODO Content Creator | 4 | 5 |
| modo-ops | MODO Ops Coordinator | 4 | 5 |

**Total**: 5 plugins · 5 agents · 17 commands · 22 skills bundleadas (símbolicas).

## Cross-link

- `skill-creator` — para crear una skill nueva (que después puede ir a un plugin).
- `mcp-builder` — para crear un MCP server (NO un plugin).
- `commit` — para commitear los archivos del plugin si están versionados.
- `modo-pr-author` — para escribir la descripción del PR que ship-ea el plugin.
- `distill-learnings` — corrió este skill, lo creó.

## Changelog

- **2026-05-22** — Creación inicial. Codifica aprendizajes de la sesión que armó los 5 plugins MODO v1 (modo-sdd, modo-pr, modo-security, modo-content, modo-ops). Detalle de aprendizajes en `SKILL.md` secciones "Triple-layer canónico", "Process", "Reglas operativas", "Anti-patterns". Templates listos en `reference/`. Memoria del rollout: `reference_modo_plugins_v1_rollout_2026_05_22`.
