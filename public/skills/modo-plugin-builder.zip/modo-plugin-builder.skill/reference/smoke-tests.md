# Smoke tests para plugins MODO

Tests mínimos a correr antes de declarar un plugin listo. Si alguno falla, NO declarar done.

## Variables

```bash
PLUGIN=modo-<scope>
NODE=/Users/hernan.desouza/.nvm/versions/node/v22.22.2/bin/node
PLUGIN_DIR=~/.claude/plugins/$PLUGIN
```

**Por qué `NODE` con path absoluto**: el agent shell del harness Claude Code no carga nvm. Si corrés `node` directo, devuelve "command not found". Usar absolute path o `bash -lc` (login shell) que sí carga `.zshrc`. Ver memoria `feedback_register_missing_binaries_in_path`.

## Test 1 — plugin.json parsea

```bash
$NODE -e "JSON.parse(require('fs').readFileSync('$PLUGIN_DIR/.claude-plugin/plugin.json','utf8'))" && echo "✓ plugin.json"
```

Si falla → JSON malformed. Validar comillas, comas, structure.

## Test 2 — Symlinks de skills resuelven a SKILL.md

```bash
EXPECTED=<numero-de-skills-bundleadas>
ACTUAL=$(find -L $PLUGIN_DIR/skills -maxdepth 2 -name "SKILL.md" | wc -l | tr -d ' ')
test "$ACTUAL" = "$EXPECTED" && echo "✓ $ACTUAL symlinks ok" || echo "✗ expected $EXPECTED got $ACTUAL"
```

**Trap**: `find` SIN `-L` no sigue symlinks. Siempre usar `-L`.

## Test 3 — Scripts pasan syntax check

```bash
for s in $PLUGIN_DIR/scripts/*.sh; do
  [ -f "$s" ] && bash -n "$s" && echo "✓ $s syntax" || echo "✗ $s SYNTAX FAIL"
done

for s in $PLUGIN_DIR/scripts/*.mjs $PLUGIN_DIR/scripts/*.js; do
  [ -f "$s" ] && $NODE --check "$s" && echo "✓ $s syntax" || echo "✗ $s SYNTAX FAIL"
done
```

## Test 4 — Estructura total esperada

```bash
echo "=== Files in $PLUGIN_DIR ==="
find $PLUGIN_DIR -type f -o -type l | sort
echo ""
echo "Total: $(find $PLUGIN_DIR -type f -o -type l | wc -l)"
```

Estructura mínima esperada:
- `.claude-plugin/plugin.json` (1)
- `README.md` (1)
- `agents/*.md` (≥1)
- `commands/*.md` (≥1)
- `skills/*` (≥1 symlink)
- `scripts/` y `references/` (opcionales)

## Test 5 — Frontmatter de agents/commands

```bash
# Cada agent tiene name + description en frontmatter
for f in $PLUGIN_DIR/agents/*.md; do
  head -10 "$f" | grep -E "^(name|description):" | wc -l | grep -q "^2$" && echo "✓ $f frontmatter" || echo "✗ $f missing frontmatter"
done

# Cada command tiene description + argument-hint
for f in $PLUGIN_DIR/commands/*.md; do
  head -10 "$f" | grep -E "^(description|argument-hint):" | wc -l | grep -q "^2$" && echo "✓ $f frontmatter" || echo "✗ $f missing frontmatter"
done
```

## Test 6 — No paths absolutos hardcoded en agent/commands

```bash
# Los agents/commands deben usar ${CLAUDE_PLUGIN_ROOT}, no /Users/... hardcoded
grep -rn "/Users/" $PLUGIN_DIR/agents/ $PLUGIN_DIR/commands/ 2>/dev/null | grep -v "^Binary" && echo "✗ FOUND hardcoded /Users/ paths" || echo "✓ no hardcoded paths"
```

Excepción: referencias a `~/Documents/Proyectos/<repo>/` para indicar dónde vive un repo destino, pero idealmente abstraído.

## One-liner consolidado

```bash
PLUGIN=modo-<scope>
NODE=/Users/hernan.desouza/.nvm/versions/node/v22.22.2/bin/node
cd ~/.claude/plugins/$PLUGIN && \
$NODE -e "JSON.parse(require('fs').readFileSync('.claude-plugin/plugin.json','utf8'))" && echo "✓ plugin.json" && \
SKILLS=$(find -L skills -maxdepth 2 -name 'SKILL.md' | wc -l | tr -d ' ') && echo "✓ $SKILLS symlinks" && \
for s in scripts/*.sh; do [ -f "$s" ] && bash -n "$s" && echo "✓ $s syntax"; done && \
echo "✓ $(find . -type f -o -type l | wc -l) total files"
```

## Cuándo correr

- **Después de scaffold** — confirmar baseline.
- **Después de cada cambio mayor** — agregar agent, agregar command, agregar skill symlink.
- **Antes de declarar el plugin listo** — gate final.
- **Antes de pedir al user que reinicie Claude Code** — si los tests no pasan, no vale reiniciar.
