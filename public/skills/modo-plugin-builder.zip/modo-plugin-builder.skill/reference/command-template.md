---
description: <1 línea — qué hace el command. Verbo activo en presente. Mencionar el agent al que delega si aplica.>
argument-hint: <args con sintaxis [opcional] <obligatorio>>
---

# /<command-name> — <título corto>

<1-2 líneas explicando el flow de alto nivel.>

## Step 0 — Resolve args / pre-flight

<Parsing de $ARGUMENTS, defaults, validaciones>

Refuse to proceed if:
- <condition 1>
- <condition 2>

## Step 1 — Delegate to <Agent Name> (si aplica)

Launch the **<Agent Name>** agent with:
- `key`: value
- `key`: value

## Step 2 — <Action>

<descripción + commands>

## Step 3 — Confirmation gate (si aplica)

<Cuándo se pide confirmación al user antes de hacer algo>

## Step 4 — Report

Output:
- <result line 1>
- <result line 2>

## Examples

```
/<command>                              # default behavior
/<command> --flag                       # variant
/<command> arg --flag=value             # another variant
```

## Reference

- Agent: `${CLAUDE_PLUGIN_ROOT}/agents/<agent>.md`
- Skill: `${CLAUDE_PLUGIN_ROOT}/skills/<skill>/SKILL.md`
- <other references>
