# modo-<scope>

<1-line description: qué bundlea + qué problema resuelve.>

**Different from <related-plugin>** — <por qué no solapan, en 1 frase>.

## What's inside

```
modo-<scope>/
├── .claude-plugin/plugin.json
├── README.md
├── agents/
│   └── modo-<role>.md             ← <1-line agent purpose>
├── commands/
│   ├── modo-<verb>.md             ← /modo-<verb>     <command purpose>
│   └── modo-<verb-2>.md           ← /modo-<verb-2>   <command purpose>
├── skills/                        ← symlinks to ~/.claude/skills/
│   ├── <skill-a>/
│   └── <skill-b>/
├── scripts/                       ← drop-in executables
│   └── <name>.sh
└── references/                    ← drop-in templates
    └── <name>.yml
```

## Quick start

```
/<command-a> <args>             # canonical use case 1
/<command-b> <args>             # canonical use case 2
```

## What it enforces

| Rule | Source |
|------|--------|
| <rule> | <where it comes from> |
| <rule> | <where it comes from> |

## When to use

- <use case>
- <use case>
- <use case>

## When NOT to use

- <anti-use case>
- <anti-use case>

## Triple-layer pattern

| Layer | Trigger | Purpose |
|-------|---------|---------|
| **Skill** `<skill>` | Auto-invoke on phrase / context | Lightweight, in-context |
| **Agent** `MODO <Role>` | Delegated with worktree | Long-running, full pipeline |
| **Slash** `/<command-a>`, `/<command-b>` | Explicit invocation | Discoverable, scriptable |

## Companion plugins

- `<other-plugin>` — <how it complements>
- `<other-plugin>` — <how it complements>

## Canonical examples

- <real-world usage 1>
- <real-world usage 2>

## Maintenance

The skill lives at `~/.claude/skills/<skill>/` and is symlinked. Edits there propagate. If you fork the skill for plugin-specific tweaks, replace the symlink with a real directory.

## Related memories

- `<memory-key-1>` — <what it covers>
- `<memory-key-2>` — <what it covers>
