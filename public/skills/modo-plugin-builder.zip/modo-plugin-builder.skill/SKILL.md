---
name: modo-plugin-builder
description: Construir plugins Claude Code para el ecosistema MODO siguiendo el patrón triple-layer (skill auto-invocable + agent worktree-delegable + slash commands explícitos) con symlink architecture para no duplicar skills. Auto-invocable cuando el user dice "armá un plugin MODO", "convertí esta skill en plugin", "empaquetá X como plugin", "plugin MODO nuevo", "promover skill a triple-layer", "/modo-plugin-builder". Codifica todo lo aprendido construyendo modo-sdd / modo-pr / modo-security / modo-content / modo-ops (2026-05-22). NO es para plugins genéricos no-MODO (usar skill-creator) ni para MCP servers (usar mcp-builder).
metadata:
  type: skill
  scope: ~/.claude/plugins/
  created: 2026-05-22
  canonical_examples: ["modo-sdd", "modo-pr", "modo-security", "modo-content", "modo-ops"]
---

# modo-plugin-builder

Construir plugins Claude Code MODO con el patrón canónico triple-layer + symlinks + smoke tests.

## Cuándo se usa

Auto-invocar cuando:
- User dice "armá un plugin MODO", "convertí esta skill en plugin", "promover skill a triple-layer", "empaquetá X como plugin"
- User quiere bundlear N skills relacionadas en un plugin focal
- User dice "/modo-plugin-builder" o cualquier alias slash

NO usar para:
- Plugins genéricos no-MODO → `skill-creator` (skill nuevo) o `mcp-builder` (MCP server)
- Skills sueltas que no justifican triple-layer (ver decision criteria abajo)
- Refactor de plugins existentes (esto crea nuevos)

## Decision criteria — ¿skill suelta o plugin con triple-layer?

Antes de armar un plugin, validar que vale la pena. Test:

| Pregunta | Sí → plugin | No → skill suelta |
|----------|-------------|-------------------|
| ¿El trabajo necesita worktree / aislamiento? | ✓ | — |
| ¿Hay paralelismo posible (N sub-tareas)? | ✓ | — |
| ¿Otros usuarios MODO lo van a usar? | ✓ | — |
| ¿Es 1 skill que ya cubre 100% su caso? | — | ✓ |
| ¿Uso esporádico (1× por año)? | — | ✓ |
| ¿Es genérico no-MODO? | — | usar `skill-creator` |

Si N skills relacionadas comparten branding / auth / publishing → bundlear en plugin.

## Triple-layer canónico

Cada plugin MODO sigue esta estructura:

```
~/.claude/plugins/<plugin-name>/
├── .claude-plugin/
│   └── plugin.json                ← name, version, description, author, license, keywords
├── README.md                      ← entry point para humanos
├── agents/
│   └── <agent-name>.md            ← worktree-delegable, descripción rica con triggers
├── commands/
│   ├── <command-1>.md             ← /command-1, argument-hint en frontmatter
│   └── <command-2>.md
├── skills/                        ← SYMLINKS, no copias
│   ├── <skill-a>                  → ~/.claude/skills/<skill-a>
│   └── <skill-b>
├── scripts/                       ← Ejecutables (validators, sync, etc.)
└── references/                    ← Templates (YAML workflows, snippets)
```

**Layer 1 — Skills**: auto-invocables por phrase trigger. Lightweight, in-context.
**Layer 2 — Agent**: delegable con worktree. Long-running, full pipeline, paralelizable.
**Layer 3 — Slash commands**: explícitos, discoverables, scriptables, llamables desde CI.

## Process — paso a paso

### Step 1 — Decidir scope del plugin

Listar las skills candidates. Si son N skills, validar que comparten al menos 2 de:
- Branding system
- Auth method
- Destination/publishing
- Voice/copy rules
- Tool dependencies (MCPs)

Si solo 1 skill cuadra, ese es el bundle (ej. modo-pr = 1 skill `modo-pr-author`).
Si N>5 skills cuadran, probablemente son 2 plugins distintos — partir antes que mega-bundle.

### Step 2 — Naming convention

- Plugin name: `modo-<scope>` (kebab-case). Ej: modo-sdd, modo-pr, modo-content.
- Agent name: `MODO <Role>` (Title Case con espacios). Ej: MODO PR Author, MODO Security Auditor.
- Agent filename: `modo-<role>.md` (kebab). Ej: modo-pr-author.md.
- Commands: `/modo-<verb>` o `/<verb>` cuando el scope ya es claro. Ej: /modo-pr, /sdd.
- Command files: `<command-name>.md` sin prefijo de slash.

### Step 3 — Scaffold

```bash
PLUGIN=modo-<scope>
mkdir -p ~/.claude/plugins/$PLUGIN/{.claude-plugin,skills,agents,commands,scripts,references}
```

### Step 4 — plugin.json

Copy template desde `reference/plugin-json-template.json` y rellenar:
- `name`: kebab-case, matches directory
- `version`: 1.0.0 inicial
- `description`: 1 párrafo (≤500 chars) — qué bundlea, qué agent, qué commands, qué complementa
- `author`: name + email (hernan.desouza@modo.com.ar)
- `license`: MIT (default MODO internal)
- `keywords`: array de 5-8 strings searchable

### Step 5 — Symlink skills (NO copies)

```bash
cd ~/.claude/plugins/$PLUGIN/skills
for s in <skill-a> <skill-b>; do
  ln -sf ~/.claude/skills/$s $s
done
```

**Por qué symlinks**: editar el skill original propaga al plugin sin duplicación. Si necesitás fork plugin-específico, reemplazás el symlink con un real directory después.

**Trap**: `find` por defecto NO sigue symlinks. Para verificar:
```bash
find -L ~/.claude/plugins/$PLUGIN/skills -maxdepth 2 -name "SKILL.md" | wc -l
```

### Step 6 — Escribir el agent

Template en `reference/agent-template.md`. Reglas:

1. **Frontmatter description** debe ser EXHAUSTIVA — es lo que decide cuándo el agent se delega:
   - Triggers en ES/EN
   - Casos canónicos
   - Complementariedad con otros agents (no solapan)
   - Cuándo NO invocar
2. **Identidad** rioplatense, allergic-a explícitos.
3. **Pipeline canónico** numerado, con gates entre fases.
4. **Reglas operativas** load-bearing del flujo (worktree, voz, no-overclaim, etc.).
5. **Outputs garantizados** — qué produce el agent al terminar.
6. **Referencias** con paths `${CLAUDE_PLUGIN_ROOT}/...`.

**${CLAUDE_PLUGIN_ROOT}** es la variable que el harness expande al directorio del plugin. NO hardcodear paths absolutos en agents/commands.

### Step 7 — Escribir los slash commands

Template en `reference/command-template.md`. Reglas:

1. **Frontmatter** con `description` (1 línea) + `argument-hint: <args>`
2. **Step 0 — Resolve args** primero, antes de hacer nada
3. **Step N — Delegate to <agent>** cuando aplica
4. **Examples** al final con 2-3 invocaciones
5. **Reference** a paths `${CLAUDE_PLUGIN_ROOT}/...`

Default: 1 plugin = 1 agent + 2-4 commands. Si necesitás más, repensá scope.

### Step 8 — Scripts ejecutables

Si el plugin viene con drop-ins (validators, sync scripts, etc.):

```bash
cp <source>.sh ~/.claude/plugins/$PLUGIN/scripts/<name>.sh
chmod +x ~/.claude/plugins/$PLUGIN/scripts/<name>.sh
```

Validar syntax:
- Bash: `bash -n <script.sh>`
- Node: `node --check <script.mjs>`

### Step 9 — References (templates)

Templates non-ejecutables (workflows YAML, snippets para copy-paste en otros repos) van a `references/`. Drop-in pattern:

```bash
# El user copia desde el plugin a su repo
cp "${CLAUDE_PLUGIN_ROOT}/references/<template>.yml" .github/workflows/<name>.yml
```

### Step 10 — README

Template en `reference/readme-template.md`. Debe tener:

- 1-line description al principio
- "What's inside" tree (ascii del directorio)
- "Quick start" con 3-4 invocaciones canónicas
- "When to use" + "When NOT to use"
- "Triple-layer pattern" tabla (layer / trigger / purpose)
- "Companion plugins" — cuáles complementan, cuáles solapan
- "Canonical examples" — links a uso real en repos MODO

### Step 11 — Smoke tests

Ejecutar antes de declarar el plugin listo:

```bash
PLUGIN=modo-<scope>
NODE=/Users/hernan.desouza/.nvm/versions/node/v22.22.2/bin/node

# plugin.json parsea
$NODE -e "JSON.parse(require('fs').readFileSync('$HOME/.claude/plugins/$PLUGIN/.claude-plugin/plugin.json','utf8'))"

# Symlinks resuelven a SKILL.md
find -L ~/.claude/plugins/$PLUGIN/skills -maxdepth 2 -name "SKILL.md" | wc -l

# Scripts pasan syntax check
for s in ~/.claude/plugins/$PLUGIN/scripts/*.sh; do bash -n "$s"; done
for s in ~/.claude/plugins/$PLUGIN/scripts/*.mjs; do $NODE --check "$s"; done

# Structure final
find ~/.claude/plugins/$PLUGIN -type f -o -type l | sort
```

Detalles en `reference/smoke-tests.md`.

### Step 12 — Documentar + memoria

1. Agregar entry al `MEMORY.md` del proyecto activo: `- [Plugin modo-X](reference_modo_plugin_X.md) — qué bundlea, qué commands`.
2. Crear memoria `reference_modo_plugin_<name>.md` con: scope, skills bundleadas, agent, commands, casos de uso.
3. Si suma a la suite ya rolleada, actualizar `~/.claude/CLAUDE.md` global con la lista de slash commands disponibles.

### Step 13 — User reinicia Claude Code

El loader descubre plugins nuevos al startup. Decir al user al cierre: *"Reiniciá Claude Code para que el loader registre `/<command>`"*.

## Reglas operativas

1. **Worktree NO aplica a `~/.claude/`** — el directorio global no es git repo por default. La regla absoluta de worktrees aplica a repos MODO (modo-landing, etc.). Para plugins globales, write directo pero backup recomendado si el plugin reemplaza uno existente.

2. **Symlinks > copias** — siempre que sea posible. Excepción: si necesitás fork plugin-específico, reemplazar el symlink con real directory.

3. **No duplicar skills entre plugins** — si dos plugins necesitan la misma skill, symlinkear desde ambos. Update único.

4. **Agent description es marketing del agent** — el harness lee `description` para decidir si delegar. Sobrecargarla con triggers, casos, complementariedad. NO ser conciso acá.

5. **Commands tienen `argument-hint`** — autocomplete del slash menu lo usa.

6. **`${CLAUDE_PLUGIN_ROOT}` no hardcoded paths** — el plugin debe ser portable a otra máquina con solo copiar el directorio.

7. **PATH trap con node en harness** — el agent shell del harness no carga nvm. Para smoke tests dentro de un agent, usar path absoluto: `/Users/hernan.desouza/.nvm/versions/node/v22.22.2/bin/node`. Memoria `feedback_register_missing_binaries_in_path`.

8. **Plugin separation rationale** — antes de bundlear, asegurate que es 1 flujo coherente, no 2 que coinciden parcialmente. Ej: modo-pr (author) ≠ code-guardian (review). Mismo dominio (PRs), flujos distintos.

9. **Sin auto-PR en autores de contenido** — `modo-research-article` por skill rule no auto-PR-ea. Respetar las reglas del skill cuando se bundlea.

10. **Dry-run-first en ops destructivas** — JSM POST, Postman upload, WhatsApp send pasan por dry-run + confirmación. Built-in en agent.

## Smoke tests canónicos (one-liner)

```bash
PLUGIN=modo-<scope>; NODE=/Users/hernan.desouza/.nvm/versions/node/v22.22.2/bin/node; \
cd ~/.claude/plugins/$PLUGIN && \
$NODE -e "JSON.parse(require('fs').readFileSync('.claude-plugin/plugin.json'))" && echo "✓ plugin.json" && \
echo "✓ $(find -L skills -maxdepth 2 -name 'SKILL.md' | wc -l) symlinks ok" && \
for s in scripts/*.sh 2>/dev/null; do bash -n "$s" 2>/dev/null && echo "✓ $s syntax"; done && \
echo "✓ $(find . -type f -o -type l | wc -l) total files"
```

## Anti-patterns conocidos

| Anti-pattern | Por qué duele | Fix |
|---|---|---|
| Copiar skills en vez de symlinkear | Skills divergen, edits no propagan | `ln -sf` |
| Description del agent corta | Harness no delega bien | Sobrecargar con triggers ES/EN |
| Hardcodear paths absolutos | Plugin no portable | `${CLAUDE_PLUGIN_ROOT}` |
| Mega-plugin con 10 skills | Install fail, maintenance hell | Splitear en focales |
| Plugin con 0 agent | Pierde el "delegable con worktree" | Mínimo 1 agent |
| Plugin con 0 commands | Solo invocable implícito, no scriptable | Mínimo 1 slash command |
| Auto-mergear / auto-flip configs | Producción frágil | Dry-run + confirmación |
| Olvidar reiniciar Claude Code | Plugin no aparece en slash menu | Decir al user al final |

## Examples (real, ya en disco)

Los 5 plugins rolleados el 2026-05-22 son ejemplos canónicos. Ver memoria `reference_modo_plugins_v1_rollout_2026_05_22` para inventario completo:

| Plugin | Agent | Commands | Skills | Caso de uso |
|--------|-------|----------|--------|-------------|
| modo-sdd | SDD Orchestrator | 5 | 10 sdd-* | Spec-Driven Development lifecycle |
| modo-pr | MODO PR Author | 2 | 1 | Autoría descripciones de PR |
| modo-security | MODO Security Auditor | 2 | 1 | OWASP 3-layer audit |
| modo-content | MODO Content Creator | 4 | 5 | Decks + RD + design-system + bionic |
| modo-ops | MODO Ops Coordinator | 4 | 5 | JSM + Postman + WhatsApp + promos |

Total: 5 plugins · 5 agents · 17 commands · 22 skills bundleadas (todas symlinkeadas).

## Cross-link con otros skills

- `skill-creator` — para crear una skill nueva desde cero (que después puede ir a un plugin).
- `mcp-builder` — para crear un MCP server (NO un plugin).
- `commit` — para commitear los archivos del plugin si están versionados.
- `modo-pr-author` — para escribir la descripción del PR que ship-ea el plugin.

## Output esperado al user

Después de armar un plugin:

```
✓ ~/.claude/plugins/modo-<name>/ — plugin.json + agent + N commands + M skills (symlinks)
✓ Smoke tests verdes: plugin.json parsea, symlinks resuelven, scripts pasan syntax
✓ Memoria guardada: reference_modo_plugin_<name>.md
✓ MEMORY.md actualizado

Reiniciá Claude Code para que el loader registre /<command>
```
