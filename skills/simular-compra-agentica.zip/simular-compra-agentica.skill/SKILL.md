---
name: simular-compra-agentica
description: Simular o ejecutar una compra agéntica end-to-end usando el POC `modo-checkout-skill` (server :3737 + UI Claude + SDK Container mock + demos HTML). Auto-invocar cuando el usuario pida correr/probar/demostrar el flow agentic (discovery → Intent Mandate → checkout → Cart Mandate → SPT → SDK deeplink → biometric → capture). Triggers (ES/EN) "simular compra agentic", "demo agentic", "checkout end-to-end", "probar el skill MODO checkout", "correr la POC del hackathon", "test e2e happy path", "comprá X talle Y con MODO desde Claude", "agentic purchase demo", "ACP flow", "AP2 mandate flow", "MODO for agents". Proyecto en `/Users/hernan.desouza/Documents/Proyectos/modo/modo-checkout-skill/`.
---

# simular-compra-agentica

Operar el POC end-to-end del rail agentic MODO (`modo-checkout-skill`). Stack: Node + Express + TS (server :3737) · OpenAPI skill para Custom GPT · UI Claude HTML standalone · SDK Container mock (app banco) · 2 suites E2E `.http`. La POC simula el flow ACP-inspired + AP2-inspired sobre el ecosistema MODO real (MCP productivo, V2 Payment Request, Link de Pago, MODO Vault, ~33 bancos, VTEX bridge).

## Mapa de archivos del proyecto

```
modo-checkout-skill/
├── index.html                              # workspace landing (11+ docs · 4 decks · MVP)
├── decks/
│   ├── presentacion-ejecutiva.html         # 9 slides · C-level
│   ├── presentacion-team.html              # 14 slides · técnico
│   └── presentacion-ejecutiva-mvp-fer.html # POC mvp_fer/
├── docs/
│   ├── 00-narrativa-agentic.md             # tesis + moat · empezar acá
│   ├── 01-arquitectura.md                  # vista alto nivel + flujo 7 etapas
│   ├── 02-acp-mapping.md                   # MODO ↔ ACP
│   ├── 03-ap2-mapping.md                   # Intent + Cart mandates
│   ├── 04-roadmap-okrs.md                  # Q2 hackathon → 2027
│   ├── 05-scope-hackathon-24h.md           # 7 tasks owners + horas
│   ├── 06-modelo-negocio.md                # unit economics + TAM/SAM/SOM
│   ├── 07-plan-proyecto.md                 # plan de delivery completo
│   ├── 08-legal-compliance.md              # privacidad · consentimiento · BCRA
│   ├── 09-plan-marketing.md                # GTM
│   ├── 10-hackathon-submission.md          # entregable formal
│   ├── 11-link-de-pago-modo.md             # detalle producto Link de Pago
│   └── 12-flow-secuencia.md                # diagrama de secuencia E2E
├── mvp/
│   ├── server/                             # Node + Express + TS :3737 (routers /v1 + /v2)
│   ├── skill/                              # openapi.yaml + instructions.md (Custom GPT)
│   ├── mcp/                                # MCP server local (alternativa al skill OpenAPI)
│   ├── demo/index.html                     # split 60/40 Claude ↔ app MODO
│   ├── ui-claude/index.html                # UI Anthropic look · payment intent
│   ├── sdk-container-mock/index.html       # app banco partner (push + Secure Payment + Face ID)
│   ├── sdk-bridge/                         # android-snippet.kt + ios-snippet.swift
│   ├── recording/output/                   # webm grabados Playwright
│   └── tests/
│       ├── e2e-happy-path.http             # AP2 + Agentic Commerce · feliz
│       ├── e2e-error-cases.http            # casos de error
│       └── e2e-v2-flow.http                # V2 Payment Request (PSP MODO real)
└── mvp_fer/                                # POC paralelo (Push to Pay · DEBIN · Virtual PAN)
```

## Workflow: levantar y simular una compra E2E

Ejecutar en este orden:

1. **Server MVP** — terminal :3737:
   ```bash
   cd ~/Documents/Proyectos/modo/modo-checkout-skill/mvp/server
   npm install
   npm run dev
   curl http://localhost:3737/health   # → {ok:true}
   ```

2. **Elegir entry point** según el caso:

   | Quiero | Abro |
   |--------|------|
   | Demo visual completa (split chat + app MODO Face ID) | `mvp/demo/index.html` |
   | Look Claude + deeplink SDK Container productivo | `mvp/ui-claude/index.html` |
   | Mock app del banco recibiendo push notif | `mvp/sdk-container-mock/index.html` |
   | Tests programáticos (REST Client VS Code/JetBrains) | `mvp/tests/e2e-happy-path.http` |
   | Custom GPT real (con OAuth a `mcp.modo.com.ar`) | registrar `mvp/skill/openapi.yaml` |

3. **Correr un preset** desde la UI Claude (botón Play):
   - Nike Mercurial talle 42 en Dexter · Galicia 6 cuotas 0%
   - Sony WH-1000XM5 en Frávega · BBVA 30% off
   - Camiseta Argentina con perfil guardado (memory hit)
   - Bad Bunny HNP preview Q1 2027 (cross-merchant futuro)

4. **Validar el deeplink productivo** que emite el server:
   ```
   https://sdk.modo.com.ar/modosdk/securepayment?intent=<base64>&banco=<id>&...
   ```
   El **MODO SDK Container** (Android/iOS) lo resuelve con `MODOSDK.handle(url, …)` dentro de la app del banco partner. Mock visual en `sdk-container-mock/`.

5. **Re-grabar videos E2E** si cambia el flow:
   ```bash
   cd ~/Documents/Proyectos/modo/modo-checkout-skill
   npx tsx mvp/recording/record-e2e.ts
   # → output/01-claude-purchase.webm + 02-sdk-container-notif.webm
   ```

## Endpoints del server `:3737`

Todos los routers cuelgan bajo prefijos `/v1` o `/v2`. Verificable con `grep "app.use" mvp/server/src/index.ts`.

### Sanity
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/health` | GET | Sanity check |

### Merchants — discovery (ACP-inspired)
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/v1/merchants` | GET | Lista de merchants (Dexter · Frávega · stubs) |
| `/v1/merchants/:id/products` | GET | Catálogo de un merchant |
| `/v1/merchants/:id/products/:productId` | GET | Detalle de producto + variants |

### AP2 — mandates firmados
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/v1/ap2/intent` | POST | Crear Intent Mandate · "quiero comprar X" sin commitment |
| `/v1/ap2/intent/:id` | GET | Leer intent |
| `/v1/ap2/intent/:id/sign` | POST | Firmar intent (simulado, sin keys reales) |
| `/v1/ap2/cart` | POST | Crear Cart Mandate · congela precio + cuotas + delivery |
| `/v1/ap2/cart/:id` | GET | Leer cart |
| `/v1/ap2/cart/:id/sign` | POST | Firmar cart |

### Agentic Commerce — checkout + tokens
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/v1/agentic_commerce/checkout_sessions` | POST | Inicia sesión · pre-fill memoria si `user_profile_id` |
| `/v1/agentic_commerce/checkout_sessions/:id` | GET | Leer sesión |
| `/v1/agentic_commerce/checkout_sessions/:id/complete` | POST | Captura — webhook "biometric_confirmed:true" |
| `/v1/agentic_commerce/delegate_payment` | POST | Emite Secure Payment Token + `sdk_deeplink` |
| `/v1/agentic_commerce/payment_tokens/:id` | GET | Estado del token |
| `/v1/agentic_commerce/webhook` | POST | Webhook proxy para callbacks del PSP |
| `/v1/agentic_commerce/agent` | POST | Chat LLM (Anthropic) que orquesta el flow conversacionalmente |
| `/v1/agentic_commerce/agent/status` | GET | Estado del LLM router |
| `/v1/agentic_commerce/agent/:conversation_id` | DELETE | Reset de conversación |

### Memory — user profile
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/v1/memory/profile/:user_id` | GET | Lee perfil (DNI · address · preferred bank · consent) |
| `/v1/memory/profile/:user_id` | POST | Upsert |

### V2 Payment Request (PSP MODO real, simulado local)
| Endpoint | Método | Para qué |
|----------|--------|----------|
| `/v2/payment-requests` | POST | Crea payment request (shape espejado de prod) |
| `/v2/payment-requests/:id` | GET | Estado del PR |
| `/v2/payment-requests/:id/_simulate-status` | POST | Forzar transición de estado (testing) |
| `/.well-known/jwks.json` (router `jwks`) | GET | JWKS público para validar firmas |

### Suites E2E
- [`mvp/tests/e2e-happy-path.http`](../../Documents/Proyectos/modo/modo-checkout-skill/mvp/tests/e2e-happy-path.http) — AP2 + Agentic Commerce, secuencial
- [`mvp/tests/e2e-error-cases.http`](../../Documents/Proyectos/modo/modo-checkout-skill/mvp/tests/e2e-error-cases.http) — paths de error
- [`mvp/tests/e2e-v2-flow.http`](../../Documents/Proyectos/modo/modo-checkout-skill/mvp/tests/e2e-v2-flow.http) — flow V2 PSP completo con `_simulate-status`

## Convención de respuesta al usuario

- **Mostrar el flow paso a paso** — 7 etapas: discovery → intent → init → slots → cart → SPT → capture. Cada paso con request resumido + response highlight.
- **Citar bancos del ecosistema** según la promo activa (Galicia · Santander · BBVA · Macro · Nación · ICBC · Supervielle · Credicoop · etc.) — convención MODO + bancos.
- **Marcar el touchpoint biométrico** explícitamente — es el moat (1 tap · Face ID en app del banco · no UX adicional).
- **Mostrar `sdk_deeplink`** completo cuando aparezca — es el handoff real a producción.
- **Nunca asumir pago real** — la POC siempre devuelve `simulated: true` en `/checkout/capture`. Si el usuario quiere pago real, derivar a `mvp_fer/` (Push to Pay agéntico vía MODO Partner AR).

## Plantilla de respuesta · resumen E2E

```
🛒 Demo agentic purchase · {preset}

1. discovery       → 3 productos · top: {prod_id} ({merchant})
2. intent-mandate  → mandate_id={...}  (signed · expires in 5min)
3. checkout init   → session={...}  · perfil reutilizado ✓
4. delivery slots  → 4 opciones · elegido sábado 10-13
5. cart-mandate    → cart_id={...} · total ${total} · {cuotas}x ${cuota} {banco}
6. SPT             → deeplink: sdk.modo.com.ar/modosdk/securepayment?...
7. capture         → biometric_confirmed:true → order_id={...} (simulated)

⏱ Time: {ms}ms · 0 apps abiertas · 1 toque biométrico
```

## Memory pattern

Primera compra crea perfil con consent · siguientes compras lo reusan:

```bash
# Crear perfil
curl -X POST :3737/v1/memory/profile/user_123 \
  -H 'content-type: application/json' \
  -d '{"dni":"35124789","address":"Av. Santa Fe 1234 CABA","preferred_bank":"galicia","consent_flags":{"checkout":true}}'

# Re-checkout reutilizando
curl -X POST :3737/v1/agentic_commerce/checkout_sessions \
  -H 'content-type: application/json' \
  -d '{"product_id":"nike-mercurial-42","user_profile_id":"user_123"}'
# → "skipForms": true · saluda con el nombre
```

La memoria vive en MODO (no en ChatGPT) → portable a Claude · Perplexity · Cursor cuando se sumen como clientes del MCP.

## Cruce con el ecosistema MODO real

| POC simula | MODO ya tiene (referencia) |
|------------|---------------------------|
| ACP discovery `/v1/merchants/:id/products` | MCP `mcp.modo.com.ar` (productivo · KR 98354260 Q1) |
| AP2 mandates (`/v1/ap2/intent` + `/v1/ap2/cart`) | PoC AP2 (KR `ceb5a87d` Q1) — la POC actual NO firma con keys reales, solo simula |
| SPT + SDK deeplink (`/v1/agentic_commerce/delegate_payment`) | V2 Payment Request + Link de Pago (productivo) |
| Memory profile (`/v1/memory/profile/:user_id`) | Por implementar · scope hackathon → producto Q3 |
| 15-33 bancos | Galicia · Santander · BBVA · Macro · Nación · ICBC · Supervielle · Credicoop · Patagonia · HSBC · Ciudad · Comafi + provinciales (productivo) |
| VTEX bridge (Frávega) | mvp_fer/ explora 3000+ stores LATAM con un toggle VTEX |
| Adapters Dexter / Frávega | Stubs — producción usa V2 Payment Request (`/v2/payment-requests`) |
| Chat LLM `/v1/agentic_commerce/agent` | Anthropic SDK envuelve el flow; en prod corre en el cliente (Custom GPT / Claude) |

## No hacer

- **No** llamar a `mcp.modo.com.ar` productivo desde la POC — todo es local (server :3737). El MCP real lo consume el Custom GPT que se registra con el OpenAPI; la simulación NO requiere creds productivas.
- **No** mezclar este skill con `modo-promos` ni `consultar-promos-modo` — esos son discovery puro de promociones; este es flow de checkout completo. La POC podría llamar al MCP de promos para discovery, pero el adapter actual usa stubs locales.
- **No** confundir POC con producción — el flow simula los handshakes ACP/AP2 pero no firma mandates con keys reales, no ejecuta pagos, no entrega productos. Es demo + arquitectura validada.
- **No** ejecutar `npx tsx mvp/recording/record-e2e.ts` en producción ni con server caído — Playwright tira timeouts y deja procesos colgados; verificar `:3737/health` antes.
- **No** publicar el deeplink `sdk.modo.com.ar/modosdk/securepayment?...` con datos reales — son siempre fixtures simulados (intent base64 contiene fixtures).
- **No** modificar el shape del `payment intent` sin sincronizar con `mvp_fer/export_payment_intent` — ese shape espejado es lo que valida el rail productivo.
- **No** asumir que ACP/AP2 son requisitos productivos hoy — son referencias del ecosistema global hacia donde MODO se alinea; F1+ implementará compatibilidad cuando los protocolos estén estables.

## Troubleshooting rápido

| Síntoma | Probable causa | Fix |
|---------|----------------|-----|
| `:3737` no responde | server caído | `cd mvp/server && npm run dev` |
| OpenAPI no carga en Custom GPT | URL del server no expuesta | usar ngrok o levantar en Vercel preview |
| Deeplink no abre app banco mock | popup blocker | usar UI Claude → "Abrir en app del banco" |
| Memory profile siempre vuelve vacío | sin storage real | la POC usa Map en memoria · reset al reiniciar server |
| Tests `.http` fallan en orden | secuencial · depende del request previo | correr de a uno (REST Client requiere `### @name` para encadenar) |
| Video webm corrupto | Playwright Chromium missing | `npx playwright install chromium` |

## Referencia cruzada

- Skill `modo-promos` → tools MCP de promociones (puede consumirse desde el adapter de discovery en futuras iteraciones).
- Skill `consultar-promos-modo` → respuestas humanas sobre promos; útil si el agente del POC quiere mostrar "qué promos hay con tu Galicia" antes de cerrar la compra.
- Skill `agente-cx-whatsapp` → otro consumidor del rail MODO (vía WhatsApp en vez de ChatGPT). Patrón similar.
- Workspace tofu-comercios → `/comercios` MVP shipped (canonical merchant URLs) que es el surface SEO/GEO sobre el que se monta este checkout.
- Decks `decks/presentacion-ejecutiva.html` (C-level) + `decks/presentacion-team.html` (técnico) para pitch.
- Hackathon · KR `cd125e8c` 2Q26 People · "3 ideas implementables 2027".
