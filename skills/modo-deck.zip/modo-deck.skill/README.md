# modo-deck

Genera presentaciones HTML branded MODO en un solo archivo. 16:9, navegación por teclado, exportable a PDF. Verde `#008859`, Red Hat Display + Quicksand, logo solid green.

## Quick start

**Triggers**:
- Frases naturales: "armá un deck", "make a deck", "presentación MODO", "slides MODO", "deck para PM TL Manager", "pitch deck MODO"
- Auto-invoke en cualquier pedido de presentación interna o externa con identidad MODO.

**Output esperado**:
1. `/tmp/<slug>.html` (preview local).
2. `<worktree>/decks/<estado>/<slug>.html` en el repo `erno-modo`.
3. Entry en `decks/decks.json`.
4. PR a `SoyErnoModo/erno-modo` listo para mergear con `gh pr merge --squash --auto`.
5. URL pública: `https://soyernomodo.github.io/erno-modo/decks/<estado>/<slug>.html`.

**Ejemplo**:
```
user> armá un deck para PM+TL+Manager sobre lectura biónica para usuarios con TDAH
→ Step 0: audience check ✓ (comité mixto)
→ Step 1-3: 14 slides generados con la estructura canónica
→ Step 4: worktree → commit → PR → merge → cleanup
→ URL pública con Giscus + dark mode + lectura biónica habilitados
```

## Features

- **14 slides canónicos** (cover, TL;DR, diagnóstico, timing, 3 pilares, plan, scope, vistas PM/TL/Manager, decisiones, cierre). Ajustable entre 8 y 20.
- **Navegación**: keyboard (`←` `→` `j` `k` `Home` `End` `P` para print, `C` para reacciones), URL hash (`#3` salta al slide 3), botones flotantes.
- **Theme switcher**: auto / claro / oscuro, persistido en localStorage, FOUC-prevented.
- **Lectura biónica** (toggle TDAH-friendly): bold de la primera mitad de cada palabra ≥3 letras, mantiene `code`/`.mono`/`svg` intactos.
- **Giscus**: reacciones + comentarios sin backend, vía GitHub Discussions del repo `erno-modo`.
- **Breadcrumb** fijo top-left con link al home y al índice de decks.
- **Print/PDF**: 1280×720, oculta chrome de navegación automáticamente.
- **Shared assets**: theme + bionic + breadcrumb se heredan del repo, no duplicar inline.
- **Demo interactivo** opcional (slide post-pilares con botones `aria-pressed` que togglean features en vivo).
- **Mockup UI** (navbar-mock, a11y-dropdown, a11y-switch) para previsualizar UX nuevas con CSS, no screenshots.

## Files

- `SKILL.md` — proceso completo: audience check, structure, template fill, save workflow (worktree → PR → merge → cleanup), shared assets, renumbering, demo interactivo, mockup patterns, voice, storytelling, comms discipline, self-review, output checklist.
- `README.md` — esta doc.
- `reference/brand-tokens.md` — CSS variables (verde, tipografía, spacing), nota sobre dark mode auto-injectado.
- `reference/design-rules.md` — non-negotiables (un color budget, no em dashes, no nested cards, Quicksand only for numbers), layout discipline, voice, anti-patterns, shared assets, canvas width, renumbering.
- `reference/slide-recipes.md` — drop-in HTML por tipo de slide (cover, TL;DR, diagnóstico, pillars, plan, scope, vistas, decisiones, cierre, demo interactivo, mockup UI, sample text).
- `assets/template.html` — base self-contained con CSS embebido, JS de navegación, logo SVG symbols, breadcrumb, theme bootstrap, Giscus wiring.
- `assets/logo-solid.svg` / `logo-multicolor.svg` — wordmarks oficiales.
- `scripts/publish-deck.sh` — helper para copiar al repo (rechaza upload si quedan placeholders sin resolver).
- `scripts/promote-deck.sh` — `git mv` entre carpetas de estado (draft → rfc → completo).
- `scripts/add-giscus.py` — retrofit de Giscus a decks ya publicados.

## Reglas críticas resumidas (full en SKILL.md)

- **Audiencia primero**: nunca generar sin saber a quién va (PM / TL / Manager / mixto / partner / equipo).
- **Worktree obligatorio**: nunca commitear directo en el checkout principal de `erno-modo`.
- **Push a main bloqueado**: usar `gh pr merge --squash --auto`.
- **Source of truth**: `decks.json`, no `index.html`.
- **Tiempos "con IA"**: explícito en todas las estimaciones.
- **No "apetito"**: prohibido en cualquier copy.
- **No overclaim**: features QA/POC/draft solo en footnote.
- **Mockups con CSS**: no screenshots para UX nueva (mejor consistencia visual, dark mode, print).
- **Toggles de chrome**: van DENTRO de `.deck-controls__panel`, NUNCA paralelos.

## Cross-link

- `modo-design-system` — para páginas Next.js/Astro con el design system.
- `lectura-bionica` — la feature de bionic reading aplicada a outputs (no a decks específicamente).
- `distill-learnings` — para codificar nuevos aprendizajes de esta skill al final de cada sesión.

## Changelog

- **2026-05-25 · Iteración post `presentacion-mvp-productivo` (continuidad parallax + Hyperframe)**:
  - `reference/slide-recipes.md` `## Parallax background continuity (warm theme · 2026)` — receta nueva: 5 shapes (gold disc + orange dot + mint blob + forest-deep blob + gold dust) en capa `.parallax` que glide a nuevas posiciones por slide via `body[data-slide="N"] .shape-X { transform: ... }`. La continuidad la da el FONDO, no el slide. Body bg cambia 700ms forest↔cream↔green; slide content cross-fade 380ms; cascade interna mínima (3 hijos, 10px rise).
  - `reference/brand-tokens.md` `### Parallax continuity transitions` — pointer al recipe + compatibility matrix (NO view-transitions + NO horizontal slide-panel + NO blur/scale + NO spot mark).
  - `SKILL.md` `## Continuidad entre slides (warm theme · pitch decks)` — trigger phrases del user ("fade es mucho", "quiero algo con continuidad", "cosas que se mueven pero cambian de lugar") + anti-patterns críticos.
  - Memoria: actualizar `reference_pptx_clone_workflow.md` con pointer al patrón parallax + nuevo memory entry [`reference_parallax_continuity_warm_decks`](reference_parallax_continuity_warm_decks.md).
  - Caso canónico: [`presentacion-mvp-productivo.html`](file:///Users/hernan.desouza/Documents/Proyectos/modo/modo-checkout-skill/decks/presentacion-mvp-productivo.html) iteración 3 (fade harsh → horizontal panel → parallax continuity).
- **2026-05-25 · Distill post `presentacion-mvp-productivo` (clonar look-and-feel de PPTX externo)**:
  - `reference/clone-external-deck.md` — workflow nuevo end-to-end: bajar `.pptx` (Drive MCP o `~/Downloads/`) → `unzip` → grep `srgbClr` por slide (NO confiar en `theme1.xml`) → mapear paleta + slide rhythm a tokens semánticos → screenshot con chrome-devtools. Anti-pattern: theme1.xml suele ser Office default en exports de Google Slides. Trap: chrome-devtools MCP bloquea `/tmp/`, usar `$TMPDIR`.
  - `reference/brand-tokens.md` `## Warm theme (2026 brand · forest-dominant)` — variante palette nueva: forest `#00471B` + cream `#FFF8E5` + gold `#FFC738` + orange `#FF5524` + mint `#B0CEC0`. Red Hat Display + Red Hat Text (NO Quicksand). Slide rhythm canónico: hero forest → 2 cream → dark forest → 2 cream → green solid closing.
  - `reference/slide-recipes.md` `## Decorative corner spot (signature warm theme · 2026 brand)` — receta de círculo gold + dot orange en esquina top-right de slides dark, two-tone con un solo `::before` + `box-shadow` con spread negativo. Solo en `.slide.hero | .slide.dark | .slide.green`.
  - `SKILL.md` `## Clonar look-and-feel de un PPTX / Google Slides externo` — cross-link al recipe + 7-step summary + anti-patterns.
  - Memoria: `reference_pptx_clone_workflow.md`.
  - Deck shipped (caso canónico): [`modo-checkout-skill/decks/presentacion-mvp-productivo.html`](file:///Users/hernan.desouza/Documents/Proyectos/modo/modo-checkout-skill/decks/presentacion-mvp-productivo.html) — clonado de `modo-for-agents.pptx` (Google Slides).
- **2026-05-21 · Distill post-deck `home-imagenes-no-video` (perf baseline técnica)**:
  - `reference/slide-recipes.md` `## Tooltip de siglas técnicas (abbr branded)` — recipe nueva con CSS drop-in + glosario canónico de 17 siglas (LCP/FCP/CLS/TTFB/INP/CWV/SSR/CSR/ISR/CMS/AVIF/WebP/SEO/BFF/SDK/PM/TL) + anti-patterns. Doble pattern `title=` (a11y) + `data-tip=` (CSS attr).
  - `reference/slide-recipes.md` `## Slide__body con overflow auto · scrollbar branded` — recipe nueva para slides densos que excepcionalmente necesitan scroll: CSS branded (thumb verde, track gris, 8px, fade indicator) + JS auto-detect (`.is-scrollable` toggleado solo en slides que lo necesitan, no shiftea los demás). Anti-patterns explícitos (overflow:scroll global shiftea layout, sin `min-height: 0` el flex no shrinkea, sin `::-webkit-scrollbar { width }` macOS oculta el scrollbar).
  - `reference/design-rules.md` `## Tooltip de siglas técnicas (cuándo y dónde)` — regla: tooltipear cada ocurrencia en body, NUNCA en chrome (clip por `overflow:hidden`), max 80-120 chars por tooltip.
  - `reference/design-rules.md` `## Slide__body con overflow auto (excepción, no default)` — regla: split en 2 slides es default; scroll es excepción para storytelling que pide contenido junto.
  - Memoria: `reference_modo_deck_tooltip_scroll_patterns.md`.
  - Deck shipped (caso canónico): https://soyernomodo.github.io/erno-modo/decks/draft/home-imagenes-no-video-2026-05-21.html
- **2026-05-20 · Distill post-deck `usa-la-bitacora` (adopción)**:
  - `SKILL.md` `## When to use` — agregada tabla de **Categorías de deck** (Propuesta con decisión / Adopción · invitación / Retro · kickoff / Pitch externo) con structure, cierre típico y recetas clave por cada una.
  - `SKILL.md` `## Feature parity contract` — checklist de 12 features obligatorias en cada deck nuevo + comando bash de auditoría con `grep`. Canon vivo declarado: `decks/completo/nextjs-12-to-16-consolidation.html`. **`comercios-mvp` queda marcado como viejo** (no tiene `#toggle-comments` en nav, no usar como referencia para feature parity).
  - `SKILL.md` `### 4. Save (state-aware) + publish` paso 6 — agregada estrategia de **rebase cuando main avanza durante el laburo** en el worktree (con resolución típica del conflicto en `decks/decks.json` cuando dos PRs agregan al inicio del array, + uso de `--force-with-lease`).
  - `reference/slide-recipes.md` `## 15. Steps · 3 caminos / cómo arrancar` — nueva receta de 3 cards (number Quicksand + título accionable + body + footer separado con comando/CTA). Reemplaza a las slides 8 (timeline) + 13 (decisiones) en decks de adopción donde no hay decisión binaria que pedir.
  - **Cross-skill update**: `modo-design-system/reference/tokens.md` `## Wordmark MODO · text-based vs SVG` — agregada regla genérica de branding (SVG default ≥24px, wordmark text-based para mono/micro/print).
  - Memoria: `feedback_branding_to_design_skill.md` (todo branding MODO → `modo-design-system`), `feedback_modo_deck_canon.md` (canon = nextjs-12-to-16).
  - Deck shipped (ejemplo en uso): https://soyernomodo.github.io/erno-modo/decks/draft/usa-la-bitacora.html
- **2026-05-20 · Distill post-decks de accesibilidad**:
  - SKILL.md `## Renumbering cuando insertás slide mid-deck` — proceso con sed + tabla de progresos para totales 14/15/16/17.
  - SKILL.md `## Demo interactivo` — patrón de buttons con `aria-pressed` que togglean estado real, JS separado del de navegación.
  - SKILL.md `## Mockup patterns` — mockuppear UX con CSS en vez de screenshots; regla heredada de `.deck-controls` (toggles van adentro, no paralelos).
  - `reference/slide-recipes.md` — 3 recetas nuevas: Demo interactivo, Mockup UI, Sample text con preview de bionic/extendida/anchor.
  - `reference/design-rules.md` — Shared assets, Canvas width (`min(1600px, 96vw, calc(92vh * 16 / 9))`), Renumbering tras inserción mid-deck, Demo interactivo en script aparte.
  - `reference/brand-tokens.md` — nota explícita: dark mode NO se define inline, viene de `deck-theme.css`.
  - `assets/template.html` — FOUC script + shared CSS + breadcrumb + width 1600px + Giscus apuntando a `SoyErnoModo/erno-modo` (post-rename).
  - Memoria: `reference_modo_deck_skill_state.md` en MEMORY.md.
- **Pre-2026-05-20** — Versión base con 14 slides canónicos, theme + bionic toggles, Giscus, voice rioplatense, comms discipline, no-overclaim, no-apetito, estimates con IA, status + version en chrome-bottom.
