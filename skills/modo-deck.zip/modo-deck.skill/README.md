# modo-deck

Genera presentaciones HTML branded MODO en un solo archivo. 16:9, navegación por teclado, exportable a PDF. Verde `#008859`, Red Hat Display + Quicksand, logo solid green.

## Quick start

**Triggers**:
- Frases naturales: "armá un deck", "make a deck", "presentación MODO", "slides MODO", "deck para PM TL Manager", "pitch deck MODO"
- Auto-invoke en cualquier pedido de presentación interna o externa con identidad MODO.

**Output esperado**:
1. `/tmp/<slug>.html` (preview local).
2. `<worktree>/decks/<estado>/<slug>.html` en el repo `erno-modo`.
3. Entry en `decks/decks.json`.
4. PR a `SoyErnoModo/erno-modo` listo para mergear con `gh pr merge --squash --auto`.
5. URL pública: `https://soyernomodo.github.io/erno-modo/decks/<estado>/<slug>.html`.

**Ejemplo**:
```
user> armá un deck para PM+TL+Manager sobre lectura biónica para usuarios con TDAH
→ Step 0: audience check ✓ (comité mixto)
→ Step 1-3: 14 slides generados con la estructura canónica
→ Step 4: worktree → commit → PR → merge → cleanup
→ URL pública con Giscus + dark mode + lectura biónica habilitados
```

## Features

- **14 slides canónicos** (cover, TL;DR, diagnóstico, timing, 3 pilares, plan, scope, vistas PM/TL/Manager, decisiones, cierre). Ajustable entre 8 y 20.
- **Navegación**: keyboard (`←` `→` `j` `k` `Home` `End` `P` para print, `C` para reacciones), URL hash (`#3` salta al slide 3), botones flotantes.
- **Theme switcher**: auto / claro / oscuro, persistido en localStorage, FOUC-prevented.
- **Lectura biónica** (toggle TDAH-friendly): bold de la primera mitad de cada palabra ≥3 letras, mantiene `code`/`.mono`/`svg` intactos.
- **Giscus**: reacciones + comentarios sin backend, vía GitHub Discussions del repo `erno-modo`.
- **Breadcrumb** fijo top-left con link al home y al índice de decks.
- **Print/PDF**: 1280×720, oculta chrome de navegación automáticamente.
- **Shared assets**: theme + bionic + breadcrumb se heredan del repo, no duplicar inline.
- **Demo interactivo** opcional (slide post-pilares con botones `aria-pressed` que togglean features en vivo).
- **Mockup UI** (navbar-mock, a11y-dropdown, a11y-switch) para previsualizar UX nuevas con CSS, no screenshots.

## Files

- `SKILL.md` — proceso completo: audience check, structure, template fill, save workflow (worktree → PR → merge → cleanup), shared assets, renumbering, demo interactivo, mockup patterns, voice, storytelling, comms discipline, self-review, output checklist.
- `README.md` — esta doc.
- `reference/brand-tokens.md` — CSS variables (verde, tipografía, spacing), nota sobre dark mode auto-injectado.
- `reference/design-rules.md` — non-negotiables (un color budget, no em dashes, no nested cards, Quicksand only for numbers), layout discipline, voice, anti-patterns, shared assets, canvas width, renumbering.
- `reference/slide-recipes.md` — drop-in HTML por tipo de slide (cover, TL;DR, diagnóstico, pillars, plan, scope, vistas, decisiones, cierre, demo interactivo, mockup UI, sample text).
- `assets/template.html` — base self-contained con CSS embebido, JS de navegación, logo SVG symbols, breadcrumb, theme bootstrap, Giscus wiring.
- `assets/logo-solid.svg` / `logo-multicolor.svg` — wordmarks oficiales.
- `scripts/publish-deck.sh` — helper para copiar al repo (rechaza upload si quedan placeholders sin resolver).
- `scripts/promote-deck.sh` — `git mv` entre carpetas de estado (draft → rfc → completo).
- `scripts/add-giscus.py` — retrofit de Giscus a decks ya publicados.

## Reglas críticas resumidas (full en SKILL.md)

- **Audiencia primero**: nunca generar sin saber a quién va (PM / TL / Manager / mixto / partner / equipo).
- **Worktree obligatorio**: nunca commitear directo en el checkout principal de `erno-modo`.
- **Push a main bloqueado**: usar `gh pr merge --squash --auto`.
- **Source of truth**: `decks.json`, no `index.html`.
- **Tiempos "con IA"**: explícito en todas las estimaciones.
- **No "apetito"**: prohibido en cualquier copy.
- **No overclaim**: features QA/POC/draft solo en footnote.
- **Mockups con CSS**: no screenshots para UX nueva (mejor consistencia visual, dark mode, print).
- **Toggles de chrome**: van DENTRO de `.deck-controls__panel`, NUNCA paralelos.

## Cross-link

- `modo-design-system` — para páginas Next.js/Astro con el design system.
- `lectura-bionica` — la feature de bionic reading aplicada a outputs (no a decks específicamente).
- `distill-learnings` — para codificar nuevos aprendizajes de esta skill al final de cada sesión.

## Changelog

- **2026-05-20 · Distill post-decks de accesibilidad**:
  - SKILL.md `## Renumbering cuando insertás slide mid-deck` — proceso con sed + tabla de progresos para totales 14/15/16/17.
  - SKILL.md `## Demo interactivo` — patrón de buttons con `aria-pressed` que togglean estado real, JS separado del de navegación.
  - SKILL.md `## Mockup patterns` — mockuppear UX con CSS en vez de screenshots; regla heredada de `.deck-controls` (toggles van adentro, no paralelos).
  - `reference/slide-recipes.md` — 3 recetas nuevas: Demo interactivo, Mockup UI, Sample text con preview de bionic/extendida/anchor.
  - `reference/design-rules.md` — Shared assets, Canvas width (`min(1600px, 96vw, calc(92vh * 16 / 9))`), Renumbering tras inserción mid-deck, Demo interactivo en script aparte.
  - `reference/brand-tokens.md` — nota explícita: dark mode NO se define inline, viene de `deck-theme.css`.
  - `assets/template.html` — FOUC script + shared CSS + breadcrumb + width 1600px + Giscus apuntando a `SoyErnoModo/erno-modo` (post-rename).
  - Memoria: `reference_modo_deck_skill_state.md` en MEMORY.md.
- **Pre-2026-05-20** — Versión base con 14 slides canónicos, theme + bionic toggles, Giscus, voice rioplatense, comms discipline, no-overclaim, no-apetito, estimates con IA, status + version en chrome-bottom.
