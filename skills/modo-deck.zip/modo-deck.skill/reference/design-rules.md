# Design rules — MODO deck

Impeccable-style guardrails. Every rule has a reason. Don't break them without one.

## Non-negotiables

1. **One color budget**. Green is an accent, not a fill. Keep green to ≤10% of pixel area per slide. Heading text is `--ink`, body text is `--gray-80`, muted is `--gray-60`. Spans of `--green-default` only on title accents, eyebrows, big metrics (`.num--accent`).
2. **Quicksand is for numbers only**. Body and headings use Red Hat Display. Numbers, indices, big metrics, counters, progress = Quicksand with `tabular-nums`. Never the inverse.
3. **No em dashes**. Use `·` (middle dot) or `:` or rephrase. Em dashes feel like ChatGPT.
4. **Tabular numerals everywhere a number appears**. Counters, percentages, version strings, durations. Without it numbers jiggle across slides.
5. **No nested cards**. A `.card` cannot contain another `.card`. Use `grid-2` / `grid-3` siblings inside the card, or use `pillar-detail__evidence` blocks for grouped content.
6. **No gradients on text**. Gradient text and rainbow accents read as crypto / Gen-AI demo. The only allowed gradient is the cover's subtle `radial-gradient(circle at 90% -10%, rgba(0,136,89,0.04), transparent 50%)` over `--paper-warm`.
7. **No glassmorphism, no neumorphism, no shimmer**. The deck is editorial, not Apple Vision Pro.
8. **No side stripes / vertical accent borders**. The chrome carries the brand. Slides do not need a green left rail.
9. **No hero-metric SaaS template**. A giant number alone in the middle of a slide is lazy. If you use `.num--xl`, anchor it with `pillar-detail` (50/50 split) and supporting evidence cards on the right.
10. **No Inter, no Geist, no Manrope**. The brand fonts are Red Hat Display + Quicksand. Period.

## Layout discipline

- 16:9 only. `aspect-ratio: 16 / 9` is enforced. Don't break it.
- `.slide__body` uses `flex: 1; justify-content: center` — content is vertically centered. Don't override unless you have a reason (cover slides use `justify-content: center` explicitly).
- One headline per slide. If you have two, you have two slides.
- Max one large metric per slide (`.num--xl`). More than one creates a "stats wall" that reads as filler.
- Tables (`.compare`) use left-aligned text. No center-aligned data. First column is the dimension, others are values.
- Eyebrow → heading → body → supporting block. This is the spine. Don't invert it.

## Voice

- Spanish for user-facing copy (slide content). English fine for technical terms (`Next 15`, `RSC`, `bundle`).
- Direct, not promotional. "Subimos Next a 15. Tarda ~1.5 días con IA." not "Embarking on a transformative journey to modernize our stack."
- Numbers over adjectives. "~3 semanas" beats "rápido". "2× baseline" beats "significant increase".
- One claim per sentence. If the sentence has two `y` / `pero` / `además`, split it.
- Mention bancos when relevant. MODO is the network; the bancos asociados (Galicia, Santander, BBVA, Macro, Nación, ICBC, Supervielle, Credicoop, etc.) are the surface. Don't say "MODO solo" if a bank partner is part of the story.

## Atoms con significado fijo (no confundir)

- **`.mono`** — paths, file names, package names, versions, route patterns. Algo que el lector podría escribir en un terminal o un import. Ej: `<span class="mono">/comercios/[slug]</span>`, `<span class="mono">next.config.js</span>`.
- **`em.query`** — queries de búsqueda, términos textuales que un humano escribe en Google / SEO / GEO. Ej: `<em class="query">"modo coto"</em>`. NO usar `<em>` plano para esto: la clase distingue el patrón.
- **`.card--green-tint`** — card destacada del grid. Usar para 1 card de N (la "importante"). Si tinteás 2 de 3 cards, ya no resalta nada.
- **`.card--gray-tint`** — card neutra / "no entra" / backlog. La opuesta de green-tint, mismo principio: 1 por grid.

Si en una slide hay más de un `.card--green-tint`, alguno está decorando, no comunicando. Sacalo o cambialo a card normal.

## Anti-patterns to refuse outright

- Cover slide with a stock photo background.
- "Our mission" / "About us" slide in a technical deck.
- Bullet point lists longer than 5 items. Split into two slides.
- Three-column "values" slide with one-word labels (Innovation / Trust / Speed).
- Confetti, sparkles, or anything that moves on its own.
- Animated number counters that tick from 0.
- Footer with social media icons.
- Page numbers in roman numerals.

## Inline emphasis conventions (no mezclar)

Tres patrones inline con significado distinto. Cada uno tiene un rol semántico:

- **`<em class="query">"texto"</em>`** — queries de usuario, términos de búsqueda. Italic + ink color + comillas. Usar en decks de SEO, GEO, growth, content. Ej: `<em class="query">"comercios con descuento MODO"</em>`.
- **`<span class="mono">texto</span>`** — identificadores técnicos: paths, file names, package names, versiones, env vars, slugs, endpoints. Ej: `<span class="mono">/comercios</span>`, `<span class="mono">Next 12.3.5</span>`.
- **`<strong>texto</strong>`** — énfasis narrativo dentro de un párrafo (lead-in de claim, palabra que carga el argumento). Ej: `<strong>Por qué juntas</strong>: hace que cada release sea más barata`.

Anti-patrón: `.mono` para feature funcional ("MODO Pay" no va con `.mono`), o `<em class="query">` para identificador técnico (`/comercios` no va en cursiva — va con `.mono`).

## Chrome-bottom status (constante en todo el deck)

El `<span>` izquierdo de `.slide__chrome-bottom` (donde va `{{FOOTER_TAG}}`) admite **status + ambiente + version** y se mantiene **constante en TODOS los slides del deck**. Ejemplos: `shipped a QA · alpha a2.414.1`, `Stack consolidation · modo-landing`, `Draft RFC · 2026-05`.

Sirve de watermark inferior: si alguien screenshotea un slide y lo manda por Slack, el screenshot sigue llevando el contexto del deck. **Regla:** si el ambiente cambia mid-deck, partir en dos decks. Nunca alternar el `FOOTER_TAG` entre slides.

## Features no-shipped · footnote, nunca body

Si un slide menciona una feature **no en producción** (QA, POC, draft RFC, behind-flag), va en `.footnote--disclaim` al pie del slide, NUNCA en body principal. El disclaimer entre paréntesis va en `<em>` para que la lectura biónica no lo bold-ee.

```html
<p class="footnote--disclaim">
  <a href="/comercios"><span class="mono">/comercios</span></a>
  <em>(en QA, todavía no live en modo.com.ar)</em>
</p>
```

Excepción: harness / workflow / tooling están activos en cada PR aunque la feature no haya shipped — se pueden citar sin disclaimer pesado.

Antes de cerrar un deck: `grep -E "QA|POC|draft|RFC" <deck.html>` y verificá que toda mención no-shipped está en `.footnote--disclaim`.

## Chrome de UI · dropdown, no flotantes (regla genérica para futuros toggles)

Cualquier feature nuevo de UI chrome del deck (tema, lectura biónica, font-size, contraste, idioma, animación on/off, etc.) se agrega como **una row más** en el dropdown `.deck-controls__panel` del header, NO como botón flotante separado en una esquina.

**Por qué:**
- Botones flotantes compiten con el branding y rompen el grid del header en mobile.
- Múltiples chips desperdigados crean ruido visual y obligan al usuario a buscar el control.
- Un solo trigger discreto + panel ordenado mantiene la jerarquía limpia.

**Cómo:**
- Si el feature necesita open/close (sub-menú, picker), usar `<details>` + `<summary>` nativo. **Nada de JS toggling** para mostrar/ocultar — `hidden` se rompe contra `display: flex` del panel.
- El JS solo monta el chrome una vez al cargar. La lógica de apertura es 100% HTML+CSS.

Patrón actual: `assets/deck-bionic.js` agrupa theme-toggle + bionic-toggle en un `<details class="deck-controls">`. Cualquier feature nuevo se suma como `.deck-controls__row` adentro del panel.

## When in doubt

- Restraint > flourish.
- Cut, don't add.
- If the slide works in black and white, the color is decoration.

## Shared assets (no duplicar inline)

Los decks heredan del repo `erno-modo`:
- `assets/deck-theme.css/.js` — dark mode tokens + toggle auto/claro/oscuro.
- `assets/deck-bionic.css/.js` — lectura biónica + dropdown `.deck-controls`.
- Breadcrumb `<nav class="deck-crumb">` con su CSS inline.

**Anti-patrón**: definir tokens `[data-theme="dark"]` o reglas `body.bionic-on b` o scripts de toggle dentro del `<style>` del deck. Ya están en los shared assets — duplicarlos rompe consistencia y crea bugs al editar.

**Sí está bien** poner inline en el deck: CSS específico del deck (mockups, demos, samples, layouts custom).

## Canvas width

`width: min(1600px, 96vw, calc(92vh * 16 / 9))` — escala bien en monitores grandes (hasta 1600px) preservando 16:9 y respetando viewports chicos. No usar `min(1280px, 100vw)` (el original) — quedaba chico en monitores 4K.

## Renumbering tras inserción mid-deck

Cuando insertás slide K en un deck N-slide, los counters hardcodeados de slides K+1...N quedan stale hasta que el usuario navegue (JS sólo actualiza el activo). Hay que renumerar TODO: counters, --p, chrome-top labels. Ver SKILL.md "Renumbering cuando insertás slide mid-deck" para el proceso con sed.

Dejar el deck con slides mostrando "09/14" y "10/15" mezclados es un bug visible — la audiencia lo nota en 2 segundos.

## Demo interactivo (cuándo y cómo)

Slide opcional, va post-pilares y pre-plan. Botones que togglean estado real en un sample con `aria-pressed` + handlers vanilla. **Lógica del demo en su propio `<script>` separado del de navegación**, así un futuro renumbering/edit no rompe nada.

Anti-patrón: meter el handler dentro del IIFE de navegación (el que maneja `←` `→`). Es ortogonal a navegación, vive aparte.
