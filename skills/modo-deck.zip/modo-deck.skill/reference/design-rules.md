# Design rules — MODO deck

Impeccable-style guardrails. Every rule has a reason. Don't break them without one.

## Non-negotiables

1. **One color budget**. Green is an accent, not a fill. Keep green to ≤10% of pixel area per slide. Heading text is `--ink`, body text is `--gray-80`, muted is `--gray-60`. Spans of `--green-default` only on title accents, eyebrows, big metrics (`.num--accent`).
2. **Quicksand is for numbers only**. Body and headings use Red Hat Display. Numbers, indices, big metrics, counters, progress = Quicksand with `tabular-nums`. Never the inverse.
3. **No em dashes**. Use `·` (middle dot) or `:` or rephrase. Em dashes feel like ChatGPT.
4. **Tabular numerals everywhere a number appears**. Counters, percentages, version strings, durations. Without it numbers jiggle across slides.
5. **No nested cards**. A `.card` cannot contain another `.card`. Use `grid-2` / `grid-3` siblings inside the card, or use `pillar-detail__evidence` blocks for grouped content.
6. **No gradients on text**. Gradient text and rainbow accents read as crypto / Gen-AI demo. The only allowed gradient is the cover's subtle `radial-gradient(circle at 90% -10%, rgba(0,136,89,0.04), transparent 50%)` over `--paper-warm`.
7. **No glassmorphism, no neumorphism, no shimmer**. The deck is editorial, not Apple Vision Pro.
8. **No side stripes / vertical accent borders**. The chrome carries the brand. Slides do not need a green left rail.
9. **No hero-metric SaaS template**. A giant number alone in the middle of a slide is lazy. If you use `.num--xl`, anchor it with `pillar-detail` (50/50 split) and supporting evidence cards on the right.
10. **No Inter, no Geist, no Manrope**. The brand fonts are Red Hat Display + Quicksand. Period.

## Layout discipline

- 16:9 only. `aspect-ratio: 16 / 9` is enforced. Don't break it.
- `.slide__body` uses `flex: 1; justify-content: center` — content is vertically centered. Don't override unless you have a reason (cover slides use `justify-content: center` explicitly).
- One headline per slide. If you have two, you have two slides.
- Max one large metric per slide (`.num--xl`). More than one creates a "stats wall" that reads as filler.
- Tables (`.compare`) use left-aligned text. No center-aligned data. First column is the dimension, others are values.
- Eyebrow → heading → body → supporting block. This is the spine. Don't invert it.

## Voice

- Spanish for user-facing copy (slide content). English fine for technical terms (`Next 15`, `RSC`, `bundle`).
- Direct, not promotional. "Subimos Next a 15. Tarda ~1.5 días con IA." not "Embarking on a transformative journey to modernize our stack."
- Numbers over adjectives. "~3 semanas" beats "rápido". "2× baseline" beats "significant increase".
- One claim per sentence. If the sentence has two `y` / `pero` / `además`, split it.
- Mention bancos when relevant. MODO is the network; the bancos asociados (Galicia, Santander, BBVA, Macro, Nación, ICBC, Supervielle, Credicoop, etc.) are the surface. Don't say "MODO solo" if a bank partner is part of the story.

## Anti-patterns to refuse outright

- Cover slide with a stock photo background.
- "Our mission" / "About us" slide in a technical deck.
- Bullet point lists longer than 5 items. Split into two slides.
- Three-column "values" slide with one-word labels (Innovation / Trust / Speed).
- Confetti, sparkles, or anything that moves on its own.
- Animated number counters that tick from 0.
- Footer with social media icons.
- Page numbers in roman numerals.

## When in doubt

- Restraint > flourish.
- Cut, don't add.
- If the slide works in black and white, the color is decoration.
