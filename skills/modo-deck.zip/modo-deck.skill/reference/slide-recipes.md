# Slide recipes

Drop-in HTML for the 14 standard MODO deck slide types + 1 receta extra (`15. Steps · 3 caminos`) para decks de adopción/invitación. Each recipe is self-contained: paste inside the `<div class="deck" id="deck">` of `template.html` and replace `{{TOKEN}}` placeholders.

`{{N}}` and `{{TOTAL}}` are the current slide number and total (e.g. `02`, `14`). `{{P}}` is the progress fill percentage (`100 * N / TOTAL` rounded).

Add `class="slide active"` (not just `slide`) only on the first slide. The nav script handles the rest.

---

## 1. Cover (slide--cover)

**Storytelling tip:** Establece el contrato con la audiencia. El lede debe responder en una frase "qué estás pidiendo y a quién". Si alguien solo lee el cover, ¿sabe de qué se trata?
**Cantidad:** 1 cover por deck. El `LEDE` máximo 2 oraciones. Campos meta: 3 columnas fijas (Audiencia / Autor / Fecha).

Use as slide 01 and as the closing slide. Variables: `DECK_TITLE`, `EYEBROW`, `TITLE`, `TITLE_ACCENT`, `LEDE`, `AUDIENCE`, `AUTHOR`, `DATE`, `FOOTER_TAG`.

```html
<section class="slide slide--cover active" data-slide>
  <div class="slide__chrome-top">
    <span class="logo"><svg width="80" height="18" aria-label="MODO"><use href="#modo-logo-solid"/></svg></span>
    <span>{{FOOTER_TAG}}</span>
  </div>
  <div class="slide__body" style="justify-content: center;">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h1 class="title">{{TITLE}}<br /><span style="color: var(--green-default)">{{TITLE_ACCENT}}</span>.</h1>
    <p class="lede">{{LEDE}}</p>
  </div>
  <div class="meta">
    <div class="meta__col"><h4>Audiencia</h4><p>{{AUDIENCE}}</p></div>
    <div class="meta__col"><h4>Autor</h4><p>{{AUTHOR}}</p></div>
    <div class="meta__col"><h4>Fecha</h4><p>{{DATE}}</p></div>
  </div>
</section>
```

---

## 2. TL;DR / La recomendación (grid-3)

**Storytelling tip:** Esta slide ES la conclusión del Pyramid Principle. Si la audiencia ve solo esta slide, debe entender qué se propone y por qué vale la pena. Todo lo que sigue es evidencia de soporte.
**Cantidad:** Exactamente 3 stats (ni 2 ni 4). El párrafo `WHY_TOGETHER` máximo 3 líneas.

3-up stat grid above a binding paragraph. Variables: 3× `STAT_LABEL` + `STAT_VALUE` + `STAT_NOTE`, plus `WHY_TOGETHER`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top">
    <span class="logo"><svg width="64" height="14" aria-label="MODO"><use href="#modo-logo-solid"/></svg></span>
    <span>{{N}} · La recomendación</span>
  </div>
  <div class="slide__body">
    <p class="eyebrow">La recomendación</p>
    <h1 class="title" style="font-size: clamp(40px, 5vw, 68px); max-width: 22ch;">{{HEADLINE_PART_1}}<br /><span style="color: var(--green-default)">{{HEADLINE_ACCENT}}</span> {{HEADLINE_PART_2}}.</h1>
    <div class="grid-3" style="margin-top: 40px;">
      <div class="stat"><span class="stat__label">{{LABEL_1}}</span><span class="num num--md stat__value">{{VALUE_1}}</span><p class="muted">{{NOTE_1}}</p></div>
      <div class="stat"><span class="stat__label">{{LABEL_2}}</span><span class="num num--md stat__value">{{VALUE_2}}</span><p class="muted">{{NOTE_2}}</p></div>
      <div class="stat"><span class="stat__label">{{LABEL_3}}</span><span class="num num--md stat__value">{{VALUE_3}}</span><p class="muted">{{NOTE_3}}</p></div>
    </div>
    <p class="body" style="margin-top: 40px; max-width: 80ch;"><strong>Por qué juntas</strong>: {{WHY_TOGETHER}}.</p>
  </div>
  <div class="slide__chrome-bottom">
    <span>{{FOOTER_TAG}}</span>
    <div class="progress"><i style="--p: {{P}}%"></i></div>
    <span class="counter">{{N}} / {{TOTAL}}</span>
  </div>
</section>
```

---

## 3. Diagnóstico / stack hoy (stack-today)

**Storytelling tip:** Responde "¿qué duele hoy?". Debe crear tensión — mostrar el gap entre la situación actual y lo deseable. Sin tensión, el resto del deck no tiene fuerza.
**Cantidad:** 2-3 `stack-block`s. Cada bloque máximo 5 `row-item`s. Si hay más, agrupar en categorías.

Two `stack-block`s top, one full-width block bottom. Variables: per row → label / value, accent color via inline `style`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Diagnóstico</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <p class="body" style="max-width: 70ch; margin-bottom: 24px;">{{INTRO}}</p>
    <div class="stack-today">
      <div class="stack-block">
        <h4>{{BLOCK_1_TITLE}}</h4>
        <div class="row-item"><span class="label"><span class="mono">{{KEY}}</span></span><span class="value">{{VAL}}</span></div>
        <!-- repeat row-item -->
      </div>
      <div class="stack-block">
        <h4>{{BLOCK_2_TITLE}}</h4>
        <!-- row-items -->
      </div>
      <div class="stack-block" style="grid-column: 1 / -1;">
        <h4>{{BLOCK_3_TITLE}}</h4>
        <!-- row-items -->
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 4. Problem detail (50/50, two cards)

**Storytelling tip:** Responde "¿por qué ahora?". Las dos cards deben tener tensión entre sí (urgencia vs oportunidad, riesgo vs ventana). El banner verde cierra con el framing que conecta ambas.
**Cantidad:** Exactamente 2 cards, comparables en estructura. Cada card máximo 3 items o 4 líneas de body. El banner máximo 2 oraciones.

`grid-2` with two `.card` blocks; trailing green banner paragraph. Variables: each card → `CARD_INDEX`, `SUBHEADING`, content.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Timing</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 32px; align-items: stretch;">
      <div class="card">
        <span class="card__index">{{CARD_1_INDEX}}</span>
        <h3 class="subheading">{{CARD_1_SUBHEADING}}</h3>
        <p class="body" style="margin: 0;">{{CARD_1_BODY}}</p>
      </div>
      <div class="card">
        <span class="card__index">{{CARD_2_INDEX}}</span>
        <h3 class="subheading">{{CARD_2_SUBHEADING}}</h3>
        <ul class="checks">
          <li>{{ITEM_1}}</li>
          <li>{{ITEM_2}}</li>
        </ul>
      </div>
    </div>
    <p class="body" style="margin-top: 32px; padding: 20px 24px; background: var(--green-10); border-radius: 14px; color: var(--green-dark); max-width: none;">
      <strong>{{FRAMING_LEAD}}</strong>: {{FRAMING_BODY}}.
    </p>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 5–7. Pillar detail (big number + evidence)

**Storytelling tip:** Cada pilar es un argumento de soporte a la recomendación del slide 02. El `BIG_NUMBER` debe ser la "prueba" del argumento. Si el número no sorprende, o si no conecta con el `HEADLINE`, elegí otro. Los 3 pilares juntos deben responder "¿por qué esta propuesta y no otra?".
**Cantidad:** 3 pilares máximo (1 slide cada uno). Left: 1 big number + body máximo 3 líneas + 2-3 chips. Right: 2 evidence cards, cada una máximo 3 bullets o 4 líneas.

Repeat three times, one per pillar. `pillar-detail` is a 1fr / 1.1fr grid. Left = big metric + chips; right = stacked `pillar-detail__evidence` cards. Variables: `EYEBROW`, `BIG_NUMBER` (e.g. `12 → 15`), `HEADLINE`, `BODY`, chips, evidence h4 + content.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Pilar {{PILLAR_N}}</span><span>{{PILLAR_TOPIC}}</span></div>
  <div class="pillar-detail" style="padding-top: 32px;">
    <div>
      <p class="eyebrow">Pilar {{PILLAR_N}} · {{PILLAR_TOPIC}}</p>
      <div class="num num--xl num--accent">{{BIG_NUMBER}}</div>
      <h2 class="heading" style="font-size: 38px; margin-top: 8px;">{{HEADLINE}}.</h2>
      <p class="body" style="max-width: 50ch;">{{BODY}}</p>
      <div style="margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
        <span class="chip chip--green">{{CHIP_GREEN}}</span>
        <span class="chip">{{CHIP_1}}</span>
        <span class="chip">{{CHIP_2}}</span>
      </div>
    </div>
    <div>
      <div class="pillar-detail__evidence">
        <h4>{{EVIDENCE_1_TITLE}}</h4>
        <ul class="checks">
          <li><strong>{{ITEM_LEAD}}</strong>: {{ITEM_BODY}}.</li>
        </ul>
      </div>
      <div class="pillar-detail__evidence" style="background: var(--green-10); border-color: transparent;">
        <h4 style="color: var(--green-dark);">{{EVIDENCE_2_TITLE}}</h4>
        <p class="body" style="margin: 0;">{{EVIDENCE_2_BODY}}.</p>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 8. Timeline (3 phases + total)

**Storytelling tip:** Responde "¿cómo lo hacemos y en cuánto tiempo?". Las fases deben tener nombres que cuenten la historia de la transformación, no nombres técnicos ("Setup / Migración / Validación" beats "Fase 1 / Fase 2 / Fase 3"). El total es la cifra de cierre del bloque de propuesta.
**Cantidad:** Exactamente 3 fases + 1 total. Body de cada fase máximo 2 líneas. Las 2 notas inferiores (verde + neutral) máximo 1 oración cada una.

`.timeline` grid: 3 `.phase` cards + 1 `.phase__total`. Variables: phase number, weeks, title, body; total label + value.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · El plan</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="timeline">
      <div class="phase">
        <span class="phase__num">01</span>
        <span class="phase__weeks">{{PHASE_1_WEEKS}}</span>
        <h3 class="phase__title">{{PHASE_1_TITLE}}</h3>
        <p class="phase__body">{{PHASE_1_BODY}}</p>
      </div>
      <!-- phase 02, 03 -->
      <div class="phase__total">
        <span class="phase__weeks">{{TOTAL_LABEL}}</span>
        <span class="num num--lg" style="color: var(--green-default); margin: 4px 0;">{{TOTAL_VALUE}}</span>
        <span style="font-size: 12px; letter-spacing: 0.08em; color: var(--green-dark); text-transform: uppercase; font-weight: 600;">{{TOTAL_UNIT}}</span>
        <span style="font-size: 11px; color: var(--gray-60); margin-top: 8px; line-height: 1.4;">{{TOTAL_FOOTNOTE}}</span>
      </div>
    </div>
    <div class="grid-2" style="margin-top: 24px; gap: 20px;">
      <div class="card" style="background: var(--green-10); border-color: transparent; padding: 16px 20px;"><h4 style="font-size: 11px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: var(--green-dark); margin: 0 0 8px;">{{NOTE_GREEN_TITLE}}</h4><p class="body" style="margin: 0; font-size: 13px; color: var(--green-dark);">{{NOTE_GREEN_BODY}}</p></div>
      <div class="card" style="background: var(--gray-3); border-color: transparent; padding: 16px 20px;"><h4 style="font-size: 11px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: var(--dark-gray); margin: 0 0 8px;">{{NOTE_NEUTRAL_TITLE}}</h4><p class="body" style="margin: 0; font-size: 13px;">{{NOTE_NEUTRAL_BODY}}</p></div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 9. Scope (in / out) — grid-2 two-column checks

**Storytelling tip:** Esta slide gestiona expectativas antes de que alguien pregunte "¿y también van a hacer X?". El "NO entra" es tan importante como el "sí entra". Si la lista "no entra" está vacía, alguien va a malinterpretar el scope.
**Cantidad:** Cada columna máximo 6 items. Si hay más de 6 en "sí entra", el scope es demasiado amplio — dividir en fases.

Left card = green subheading + `ul.checks` (positive). Right card = `--gray-3` background + `ul.checks.checks--neutral`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Scope</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 32px; align-items: flex-start;">
      <div class="card">
        <h3 class="subheading" style="color: var(--green-default);">{{IN_TITLE}}</h3>
        <ul class="checks">
          <li>{{IN_ITEM}}</li>
        </ul>
      </div>
      <div class="card" style="background: var(--gray-3); border-color: transparent;">
        <h3 class="subheading" style="color: var(--dark-gray);">{{OUT_TITLE}}</h3>
        <ul class="checks checks--neutral">
          <li>{{OUT_ITEM}}</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 10-12. Vista PM / TL / Manager (compare table)

**Storytelling tip:** Cada vista responde la pregunta que esa persona tiene en la cabeza antes de dar su aprobación. PM: "¿esto mejora la experiencia y la velocidad de entrega?". TL: "¿puedo revertir si algo sale mal?". Manager: "¿qué cuesta, qué riesgo tiene, qué gano?". No mezclar las vistas — cada una habla a una sola audiencia.
**Cantidad:** Tabla máximo 6 filas. Stat cards de Manager: exactamente 3. TL: máximo 4 columnas. Footnote: 1 oración.

`table.compare` with 3 columns (aspect / was / now). For Manager, add `.grid-3` of stat cards on top; for TL, add 4th `Rollback` column.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Vista {{ROLE}}</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">Para el {{ROLE}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <table class="compare" style="margin-top: 24px;">
      <thead><tr><th style="width: 36%;">Aspecto</th><th>Hoy</th><th>Después</th></tr></thead>
      <tbody>
        <tr><td>{{ASPECT}}</td><td class="was">{{WAS}}</td><td class="now">{{NOW}}</td></tr>
      </tbody>
    </table>
    <p class="muted" style="margin-top: 24px;"><span class="sigil"></span>{{FOOTNOTE}}.</p>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

For Manager add above the table:
```html
<div class="grid-3" style="margin-top: 24px;">
  <div class="card"><span class="card__index">{{LABEL}}</span><div class="num num--md" style="margin: 8px 0;">{{VALUE}}</div><p class="body" style="margin: 0;">{{NOTE}}</p></div>
</div>
```

For TL use 4 columns and add `<span class="dot dot--warn"></span>` chips in the risk cell.

---

## 13. Decisiones (ordered list with ownership)

**Storytelling tip:** Esta slide es el corazón del deck. Responde "¿qué necesito de vos antes de arrancar?". Cada decisión debe ser binaria o tener opciones claras. Si no se puede aprobar/rechazar/redirigir en 30 segundos, es demasiado vaga. El order importa: primero la decisión más bloqueante.
**Cantidad:** 2-4 decisiones máximo. Cada una: 1 título accionable + 1-2 líneas de body + 1 owner. Más de 4 decisiones en una reunión es irreal — partir en dos sesiones.

`ol.decisions` auto-numbers 01, 02 ... in green Quicksand. Each item has a subheading, body, and an ownership tag.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Decisiones</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <ol class="decisions" style="margin-top: 32px;">
      <li>
        <h3>{{DECISION_TITLE}}</h3>
        <p class="body" style="margin: 4px 0 0;">{{DECISION_BODY}}.</p>
        <p class="ownership">Owner: {{OWNER}}</p>
      </li>
    </ol>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 14. Cierre

**Storytelling tip:** Cierra el contrato abierto en el cover. El título debe ser una invitación, no una afirmación ("¿Arrancamos?" o "Aguardo su feedback" beats "Conclusión"). El card de soporte da al audiencia el camino a seguir si quieren profundizar fuera de la reunión.
**Cantidad:** 1 slide. Titulo: máximo 6 palabras. Card de soporte: 2-4 links o referencias. Meta columns: exactamente 3 (Autor / Tickets / Repo u equivalente).

Use the cover recipe again with `class="slide slide--cover"` (no `active`), updated title, and a `.card` of "material de soporte" inside the body. Replace the bottom `meta` with `Autor / Tickets / Repo` columns.

---

## Optional · Screenshot slide (showcase de pantalla)

**Storytelling tip:** Cuando hay que mostrar UN producto / UNA pantalla real (POC live, mock de UX, página propia). Captura izquierda 60%, copy + bullets derecha 40%. La imagen debe estar lista, recortada y comprimida — nada de "se ve mal pero se entiende". Si la pantalla no está terminada, no la pongas: mostrá un wireframe en su lugar, o cambiá de slide.
**Cantidad:** 1 imagen por slide. Body párrafo máximo 3 líneas. Lista `ul.checks` máximo 4-5 items con `font-size: 16px`. Imágenes vivir en `assets/<deck-slug>/screen.png` relativas al HTML.

Útil para "POC alive at /comercios", "así se ve la pantalla nueva en QA", demos visuales. Imágenes con `aria-label` descriptivo (no `alt=""`).

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top">
    <span>{{N}} · ruta</span>
    <span><span class="mono">{{ROUTE}}</span> · {{ROUTE_TAG}}</span>
  </div>
  <div class="slide__body">
    <p class="eyebrow"><span class="mono">{{ROUTE}}</span> · {{EYEBROW_SUFFIX}}</p>
    <h2 class="heading" style="margin-bottom: 8px;">{{HEADLINE}}.</h2>
    <div class="screenshot-slide">
      <figure>
        <img src="../../assets/{{DECK_SLUG}}/{{SCREENSHOT}}.png" alt="{{ALT_DESCRIPTIVO}}" />
      </figure>
      <div>
        <p class="body" style="font-size: 17px;">{{COPY_EXPLICATIVO}} Las queries tipo <em class="query">"{{EJEMPLO_QUERY}}"</em> llegan acá.</p>
        <p class="card__label" style="margin-top: 16px;">Qué hay en la pantalla</p>
        <ul class="checks">
          <li>{{ITEM_1}}</li>
          <li>{{ITEM_2}}</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## Optional · Mini-grid 3x2 (workflow / pasos / pilares densos)

**Storytelling tip:** Cuando son **6 pasos de un workflow** o **6 pilares chicos** y no podés cortar a 3. Si son 3 o menos, usá el `.pillar-detail` o el `pillar-grid` normal. La idea es densidad SIN amontonar: cada card cuenta una mini-historia en 1 título corto + 2 líneas. Si necesitás más copy, no es una mini-card.
**Cantidad:** Exactamente 6 cards (3×2). Heading máximo 6 palabras. Body máximo 3 líneas. Card padding reducido (14px 16px).

Útil para "harness de desarrollo" / "pasos del proceso" / "6 garantías" / "lo que ya validamos". Si una card cae fuera del patrón corto, hacé un slide aparte.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · {{SUBTITLE}}</span><span>{{TOP_RIGHT}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading" style="margin-bottom: 6px;">{{HEADLINE}}.</h2>
    <p class="body" style="font-size: 17px; max-width: 80ch; margin-bottom: 14px;">{{INTRO}}</p>
    <div class="mini-grid">
      <div class="card">
        <span class="card__index">01 · {{STEP_TAG}}</span>
        <h3>{{STEP_TITLE}}</h3>
        <p>{{STEP_BODY}}</p>
      </div>
      <!-- repeat × 6 -->
    </div>
    <div style="margin-top: 14px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
      <span class="chip chip--green">{{PROOF_GREEN}}</span>
      <span class="chip">{{PROOF_1}}</span>
      <span class="chip">{{PROOF_2}}</span>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## Optional · Scope con sub-secciones (bloqueantes + backlog)

**Storytelling tip:** Variante del slide 9 (scope sí/no). Acá la columna derecha tiene **sub-grupos** ("bloqueantes para prod" / "fase 2 / backlog"). Cuando "no entra" tiene mucho material y querés ordenarlo por prioridad, sin abrir un slide aparte para cada uno. Si los sub-grupos son más de 2, partir en 2 slides.
**Cantidad:** Card izquierda hasta 6 items. Card derecha máximo 2 sub-grupos × 3-4 items cada uno.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Scope</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 16px; align-items: flex-start;">
      <div class="card">
        <h3 class="subheading" style="color: var(--green-default); font-size: 19px;">{{IN_TITLE}}</h3>
        <ul class="checks">
          <li>{{IN_ITEM}}</li>
        </ul>
      </div>
      <div class="card card--gray-tint">
        <h3 class="subheading" style="font-size: 19px;">{{OUT_TITLE}}</h3>
        <p class="card__index" style="margin: 8px 0 4px;">{{SUBGROUP_1_LABEL}}</p>
        <ul class="checks checks--neutral" style="margin: 0;">
          <li>{{SUB1_ITEM}}</li>
        </ul>
        <p class="card__index" style="margin: 12px 0 4px;">{{SUBGROUP_2_LABEL}}</p>
        <ul class="checks checks--neutral" style="margin: 0;">
          <li>{{SUB2_ITEM}}</li>
        </ul>
      </div>
    </div>
    <p class="muted" style="margin-top: 14px;"><span class="sigil"></span>{{FOOTNOTE}}.</p>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## Optional · Cierre con doble card de soporte

**Storytelling tip:** Variante del cierre normal (#14). Cuando además de pedir aprobación / feedback hay que dejar **dónde está el material** y **a qué equipos opinan antes**. Las 2 cards son: 1) "quiénes opinan antes" con responsables nombrados; 2) "material de soporte" con links a docs / live / tickets. Sigue siendo `slide--cover` para mantener el cierre del contrato narrativo.
**Cantidad:** 2 cards apiladas (stack vertical, no grid). Cada una máximo 3-4 líneas. Meta inferior 3 columnas (Autor / Tickets / Repo).

```html
<section class="slide slide--cover" data-slide>
  <div class="slide__chrome-top">
    <span class="logo"><span class="modo-wordmark modo-wordmark--sm">MODO</span></span>
    <span>{{N}} · cierre</span>
  </div>
  <div class="slide__body" style="justify-content: center;">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h1 class="title">{{TITLE_PART_1}} <span style="color: var(--green-default)">{{ACCENT}}</span>. {{TITLE_PART_2}}</h1>
    <p class="lede">{{LEDE}}</p>
    <div class="card" style="margin-top: 18px; max-width: 760px; padding: 16px 20px;">
      <h3 class="subheading" style="font-size: 17px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gray-60); font-weight: 600; margin-bottom: 8px;">Quiénes opinan antes</h3>
      <p class="body" style="margin: 0; font-size: 16px;"><strong>{{TEAM_1}}</strong> · {{TOPIC_1}} · <strong>{{TEAM_2}}</strong> · {{TOPIC_2}}.</p>
    </div>
    <div class="card" style="margin-top: 10px; max-width: 760px; padding: 14px 20px;">
      <h3 class="subheading" style="font-size: 17px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gray-60); font-weight: 600; margin-bottom: 6px;">Material de soporte</h3>
      <p class="body" style="margin: 0 0 6px; font-size: 16px;"><strong>Live</strong>: <a href="{{LIVE_URL}}" style="color: var(--green-default); text-decoration: underline; font-weight: 600;">{{LIVE_URL_LABEL}}</a></p>
      <p class="body" style="margin: 0; font-size: 16px;"><strong>Docs</strong>: <span class="mono">{{DOCS_PATH}}</span></p>
    </div>
  </div>
  <div class="meta">
    <div class="meta__col"><h4>Autor</h4><p>{{AUTHOR}}</p></div>
    <div class="meta__col"><h4>Tickets</h4><p>{{TICKETS}}</p></div>
    <div class="meta__col"><h4>Repo</h4><p>{{REPO}}</p></div>
  </div>
</section>
```

---

## 15. Steps · 3 caminos / cómo arrancar (adoption decks)

**Storytelling tip:** Responde "¿qué hago esta semana?". Específico para decks de adopción / invitación al equipo (no buscan aprobación formal, buscan ACCIÓN). Cada step es una CTA concreta con un comando/link claro al final. El orden importa: del más fácil ("subí un deck") al más comprometido ("linkeá tu RFC").
**Cantidad:** Exactamente 3 steps (ni 2 ni 4 — 3 es el sweet spot). Cada step: 1 número grande Quicksand + título accionable + body máximo 3 líneas + footer separado con CTA/comando.
**Cuándo usar en vez de timeline/decisiones**: si el deck es invitación al equipo y no hay decisión binaria que pedir. Reemplaza a las slides 08 (timeline) + 13 (decisiones) cuando la pieza no es propuesta con aprobación sino call-to-action.

CSS requerido (agregar al `<style>` del deck):

```css
.steps { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 24px; }
.step {
  background: var(--paper);
  border-radius: 14px;
  padding: 24px;
  border: 1px solid var(--border-soft);
  display: flex;
  flex-direction: column;
  min-height: 240px;
}
.step__num {
  font-family: "Quicksand", sans-serif;
  font-variant-numeric: tabular-nums;
  font-weight: 700;
  font-size: 56px;
  line-height: 1;
  color: var(--green-default);
  letter-spacing: -0.04em;
  margin-bottom: 12px;
}
.step__title { font-size: 20px; font-weight: 600; margin: 0 0 8px; color: var(--ink); line-height: 1.25; }
.step__body { font-size: 16px; line-height: 1.5; color: var(--gray-60); margin: 0 0 12px; }
.step__cmd { margin-top: auto; padding-top: 12px; border-top: 1px solid var(--gray-8); }
```

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Cómo arrancar</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="steps">
      <div class="step">
        <span class="step__num">01</span>
        <h3 class="step__title">{{STEP_1_TITLE}}</h3>
        <p class="step__body">{{STEP_1_BODY}}</p>
        <div class="step__cmd">{{STEP_1_CMD}}</div>
      </div>
      <div class="step">
        <span class="step__num">02</span>
        <h3 class="step__title">{{STEP_2_TITLE}}</h3>
        <p class="step__body">{{STEP_2_BODY}}</p>
        <div class="step__cmd">{{STEP_2_CMD}}</div>
      </div>
      <div class="step">
        <span class="step__num">03</span>
        <h3 class="step__title">{{STEP_3_TITLE}}</h3>
        <p class="step__body">{{STEP_3_BODY}}</p>
        <div class="step__cmd">{{STEP_3_CMD}}</div>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

`STEP_N_CMD` típicamente es un `<span class="mono">/skill-name</span>` o un "PR a `archivo`" o "tecla `C`" — algo que se pueda copiar y ejecutar.

Ejemplo en uso: `decks/draft/usa-la-bitacora.html` slide 08.

---

## 13bis. Harness / proceso (mini-grid 3×2)

**Storytelling tip:** Responde "¿cómo aseguran calidad antes de mergear?" sin tener que defender cada PR. Los 6 pasos cuentan el rigor del workflow: spec, test, levels, E2E, docs, regresión. Es la slide que convence al TL de que el cambio no rompe nada.
**Cantidad:** Exactamente 6 pasos (el tamaño que cabe en 3×2 sin apretar). Heading máximo 4 palabras, body máximo 2 líneas. Chips al pie máximo 3.

Cuándo usarla: decks de propuesta técnica con multi-fase / programa. Si el deck es chico (8–10 slides), saltar y meter el proceso en 1–2 chips dentro de scope/decisiones.

Ejemplos en uso: `decks/completo/comercios-mvp.html` slide 09, `decks/completo/nextjs-12-to-16-consolidation.html` slide 13.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Harness</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <p class="body" style="max-width: 70ch; margin-bottom: 18px;">{{INTRO}}</p>
    <div class="mini-grid">
      <div class="card">
        <span class="card__index">01 · {{STEP_1_LABEL}}</span>
        <h3>{{STEP_1_TITLE}}.</h3>
        <p>{{STEP_1_BODY}}</p>
      </div>
      <!-- repetir 6 cards (01..06) -->
    </div>
    <div style="margin-top: 14px; display: flex; gap: 10px; flex-wrap: wrap;">
      <span class="chip chip--green">{{PROOF_GREEN}}</span>
      <span class="chip">{{PROOF_1}}</span>
      <span class="chip">{{PROOF_2}}</span>
    </div>
    <!-- Opcional: si hay decks hermanos del mismo programa, sumá strip de cross-link -->
    <div class="related-decks">
      <span class="related-decks__label">Decks relacionados</span>
      <a href="{{SIBLING_SLUG}}.html" class="chip chip--green">{{SIBLING_TITLE}}</a>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## Variant 5b–7b. Screenshot tour (reemplaza pillar-detail)

**Storytelling tip:** Cuando la "prueba" del argumento es una pantalla real, no una cifra, el big-number layout se siente vacío. El screenshot lleva el peso narrativo: la audiencia ve la UI primero, después lee qué hay adentro. Cada surface = una slide.
**Cantidad:** 3–4 slides en cadena (una por surface). Imagen domina (1.5fr). Right column: 1 párrafo narrativo + label + checks compactos. Máximo 5 checks por slide.

Asset path: guardá los screenshots en `~/Documents/Proyectos/modo/erno-modo/assets/<slug>/` y referencialos con `../../assets/<slug>/<file>.png` desde el deck.

Ejemplos en uso: `decks/completo/comercios-mvp.html` slides 05–08.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · {{SURFACE}}</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading" style="font-size: 38px; margin-bottom: 18px;">{{HEADLINE}}.</h2>
    <div class="screenshot-slide">
      <figure>
        <img src="../../assets/{{SLUG}}/{{SCREENSHOT_FILE}}" alt="{{ALT}}" />
      </figure>
      <div>
        <p class="body" style="font-size: 17px;">{{NARRATIVE}}</p>
        <p class="card__label">Qué hay en la pantalla</p>
        <ul class="checks">
          <li>{{CHECK_1}}</li>
          <li>{{CHECK_2}}</li>
          <li>{{CHECK_3}}</li>
        </ul>
        <!-- Opcional: footnote si la surface no está live aún -->
        <p class="footnote--disclaim">
          <a href="{{LINK}}"><span class="mono">{{PATH}}</span></a>
          <em>(en QA, todavía no live)</em>
        </p>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## Decks relacionados (sub-componente, NO slide standalone)

**Cuándo:** al pie de la slide de harness o decisiones, **solo si** el deck pertenece a un programa con hermanos publicados. Si es one-off, no usar.
**Cantidad:** 2–5 links. Más de 5 es ruido — partir el programa en dos.

```html
<div class="related-decks">
  <span class="related-decks__label">Decks relacionados</span>
  <a href="{{SIBLING_1_SLUG}}.html" class="chip chip--green">{{SIBLING_1_TITLE}}</a>
  <a href="{{SIBLING_2_SLUG}}.html" class="chip chip--green">{{SIBLING_2_TITLE}}</a>
</div>
```

`href` relativo (sin `decks/<estado>/`) porque los hermanos viven en la misma carpeta. Cross-estado va `../draft/<slug>.html` (desde un `completo` a un `draft`, por ejemplo).

---

## Footnote-disclaim (átomo, mención de features no-shipped)

**Cuándo:** cualquier slide que menciona una feature en QA / POC / draft / RFC / behind-flag. NUNCA en body principal; siempre al pie del slide. El `<em>` evita que la lectura biónica bold-ee el disclaimer.

```html
<p class="footnote--disclaim">
  <a href="{{LINK}}"><span class="mono">/comercios</span></a>
  <em>(en QA, todavía no live en modo.com.ar)</em>
</p>
```

Citar el harness/proceso/tooling **sin** disclaimer (porque está activo en cada PR aunque la feature no haya shipped):
```html
<p class="footnote--disclaim">
  Workflow validado en cada PR del repo · <em>ejemplo de aplicación: <span class="mono">/comercios</span> (en QA)</em>
</p>
```

---

## Pillar-detail · 4 chips (effort + constraints)

**Convención:** primer chip verde = effort/tiempo (siempre con "con IA"). Los 3 siguientes neutros = scope / constraint / rollback. Reemplaza la versión de 3 chips de la recipe original.

```html
<div style="margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
  <span class="chip chip--green">~2 días con IA</span>
  <span class="chip">1 dev + Claude Code</span>
  <span class="chip">Pages Router intacto</span>
  <span class="chip">Rollback &lt;10 min</span>
</div>
```

---

## Manager view · checklist outcomes (colspan="2")

Cuando la Manager view lista outcomes en lugar de (o además de) comparar was/now, mezclar filas was/now con filas `colspan="2"` + status dot:

```html
<table class="compare">
  <thead><tr><th style="width: 36%;">Outcome</th><th>Estado</th><th></th></tr></thead>
  <tbody>
    <tr><td>{{ASPECT_1}}</td><td class="was">{{WAS}}</td><td class="now">{{NOW}}</td></tr>
    <tr><td>{{OUTCOME_1}}</td><td colspan="2"><span class="dot dot--good"></span>{{STATUS}}</td></tr>
    <tr><td>{{OUTCOME_2}}</td><td colspan="2"><span class="dot dot--warn"></span>{{STATUS_WARN}}</td></tr>
  </tbody>
</table>
```

---

## Reusable atoms

**Storytelling tip:** Los átomos son para reforzar, no para decorar. Un `.chip--green` en un pilar dice "esto ya está decidido/probado". Un `.dot--warn` en una tabla dice "ojo acá". Usarlos sin intención narrativa los vacía de significado.
**Cantidad:** Máximo 4 chips por slide. Máximo 2 dots de distinto color por tabla (más colores = ruido).



- `.chip` — pill labels. Modifiers: `chip--green`, `chip--yellow`, `chip--red`, `chip--ghost`.
- `.dot` — 8px status dot. Modifiers: `dot--good`, `dot--warn`, `dot--bad`.
- `.mono` — inline monospace token for file names, package names, versions.
- `.sigil` — small green square accent before muted footnotes.
- `.num--accent` — turns big number green.
- `ul.checks` — green check bullets. `checks--neutral` for grey, `checks--no` for red.
- `.card--green-tint` — card destacada con fondo verde claro y texto verde-dark. Para "una card del grid es la importante" (evidence, stop-the-line, GEO stack). Mejor que inline `style="background: var(--green-10); border-color: transparent;"`.
- `.card--gray-tint` — card neutra con fondo gris-3. Para "no entra" / "pendientes" / contraste neutro.
- `em.query` — query / búsqueda en italic + ink color. Usar para queries SEO, GEO, términos de búsqueda textuales (`<em class="query">"modo coto"</em>`). Distinto a `.mono` que es para paths / files / packages.
- `.screenshot-slide` — wrapper grid 1.5fr/1fr para slides de screenshot + body. Ver recipe arriba.
- `.mini-grid` — grid 3×2 de cards densas. Ver recipe arriba.
- `.card__label` — eyebrow chico dentro de una card, mismo formato que `stat__label`. Usar para "Qué hay en la pantalla" / "Notas" dentro de body de card.
- `.related-decks` + `.related-decks__label` — pill-strip verde-10 al pie del slide para linkear a decks hermanos de un mismo programa. Ver recipe arriba. Solo si hay 2+ hermanos publicados.
- `.footnote--disclaim` — párrafo 12px gris-60 al pie del slide para mencionar features en QA / POC / draft / RFC. NUNCA en body principal. El `<em>` interior evita que la lectura biónica bold-ee el disclaimer.

---

## Demo interactivo (botones que activan la feature en vivo)

**Storytelling tip:** Es la slide donde la audiencia toca la feature en vez de leerla. Va después del último pilar, antes del plan. Los 4-5 botones togglean estado real en un sample inline. Sin librerías, sólo `aria-pressed` + handlers vanilla. Side-effects entre features (ej. toggle A enciende toggle B) muestran cadenas cause-effect que un sólo botón no comunicaría.
**Cantidad:** 4-5 botones máximo. Sample con 3-5 líneas. Indicador "ambiente" opcional (shimmer / ícono que tiembla). Status line abajo del sample.

CSS adicional (poné junto al resto de tu CSS de deck, no en `style` inline):

```css
.demo-sample {
  background: var(--paper);
  border: 1px solid var(--border-soft);
  border-radius: 14px;
  padding: 18px 22px 18px 40px;
  font-size: 14px;
  line-height: 1.6;
  color: var(--gray-80);
}
.demo-sample b { color: var(--ink); font-weight: 700; }
.demo-line { position: relative; margin: 0; padding: 4px 0; border-radius: 6px; }
.demo-sample[data-anchor="on"] .demo-line--current {
  background: linear-gradient(90deg, rgba(0,136,89,0.08), transparent 70%);
}
.demo-sample[data-anchor="on"] .demo-line--current::before {
  content: ""; position: absolute; left: -24px; top: 50%;
  transform: translateY(-50%); width: 8px; height: 8px; border-radius: 999px;
  background: var(--green-default); box-shadow: 0 0 0 4px rgba(0,136,89,0.18);
}
.demo-btn {
  display: flex; align-items: center; justify-content: space-between;
  gap: 12px; width: 100%; padding: 12px 14px; border-radius: 10px;
  background: var(--paper); border: 1px solid var(--border-soft);
  box-shadow: var(--shadow-card);
  font-family: "Red Hat Display", sans-serif; font-size: 13px;
  color: var(--ink); cursor: pointer; text-align: left;
  transition: background 180ms var(--ease), border-color 180ms var(--ease);
}
.demo-btn + .demo-btn { margin-top: 10px; }
.demo-btn:hover { background: var(--gray-3); }
.demo-btn[aria-pressed="true"] {
  background: var(--green-10); border-color: var(--green-default);
  color: var(--green-dark); font-weight: 600;
}
.demo-status { margin-top: 12px; padding: 10px 14px; border-radius: 10px;
  background: var(--gray-3); font-size: 12px; color: var(--gray-80); }
```

HTML del slide:

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Demo en vivo</span><span>click los botones</span></div>
  <div class="slide__body">
    <p class="eyebrow">Demo · activación con botón</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 20px; gap: 32px; align-items: flex-start;">
      <div>
        <h4>Sample</h4>
        <div id="demo-sample" class="demo-sample" data-feature1="off" data-feature2="off">
          <p class="demo-line" data-line>{{LINE_1}}</p>
          <p class="demo-line demo-line--current" data-line>{{LINE_2}}</p>
          <p class="demo-line" data-line>{{LINE_3}}</p>
        </div>
        <div id="demo-status" class="demo-status">Estado: ningún modo activo. Tocá un switch.</div>
      </div>
      <div>
        <h4>Switches</h4>
        <button class="demo-btn" data-feature="feature1" aria-pressed="false">
          <span class="label-line">{{F1_LABEL}}</span>
          <span class="a11y-switch" aria-hidden="true"></span>
        </button>
        <!-- repeat por feature -->
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

JS (al final del body, en su propio `<script>` separado del de navegación):

```js
(function () {
  const sample = document.getElementById('demo-sample');
  if (!sample) return;
  const status = document.getElementById('demo-status');
  const state = { feature1: false, feature2: false };

  function applyFeature1(on) { sample.dataset.feature1 = on ? 'on' : 'off'; }
  function applyFeature2(on) {
    sample.dataset.feature2 = on ? 'on' : 'off';
    // Side-effect ejemplo: feature2 ON auto-triggea feature1
    if (on && !state.feature1) {
      const btn = document.querySelector('.demo-btn[data-feature="feature1"]');
      if (btn) btn.click();
    }
  }
  const handlers = { feature1: applyFeature1, feature2: applyFeature2 };

  function updateStatus() {
    const active = Object.keys(state).filter(k => state[k]);
    status.innerHTML = active.length === 0
      ? 'Estado: ningún modo activo.'
      : 'Activos: <strong>' + active.join(' · ') + '</strong>';
  }

  document.querySelectorAll('.demo-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const f = btn.dataset.feature;
      const next = btn.getAttribute('aria-pressed') !== 'true';
      btn.setAttribute('aria-pressed', String(next));
      state[f] = next;
      handlers[f](next);
      updateStatus();
    });
  });
})();
```

---

## Mockup UI (navbar, dropdown, switches)

**Storytelling tip:** Para slides que proponen un cambio de UX (nuevo navbar item, dropdown, switch en Settings), mockuppear con CSS en vez de pegar screenshots. Mantiene tokens MODO, escala con dark mode, imprime limpio, es editable.
**Cantidad:** 1-2 mockups por slide máximo. Si querés mostrar "antes vs después", usá `grid-2` con un mockup cada lado.

CSS adicional:

```css
.navbar-mock {
  background: var(--paper); border: 1px solid var(--border-soft);
  border-radius: 14px; padding: 14px 18px;
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
}
.navbar-mock__left { display: flex; align-items: center; gap: 16px;
  font-size: 13px; color: var(--ink); font-weight: 600; }
.navbar-mock__right { display: flex; align-items: center; gap: 10px; }
.navbar-btn {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 6px 10px; border-radius: 999px;
  background: var(--gray-3); font-size: 12px; color: var(--gray-80); font-weight: 500;
}
.navbar-btn--active { background: var(--green-10); color: var(--green-dark); font-weight: 600; }
.a11y-dropdown {
  background: var(--paper); border: 1px solid var(--border-soft);
  border-radius: 14px; padding: 8px;
  max-width: 320px; box-shadow: 0 12px 32px rgba(18,18,18,0.08);
}
.a11y-dropdown__item {
  display: flex; align-items: center; justify-content: space-between;
  gap: 12px; padding: 10px 12px; border-radius: 10px;
  font-size: 13px; color: var(--ink);
}
.a11y-dropdown__item + .a11y-dropdown__item { border-top: 1px solid var(--gray-8); }
.a11y-switch {
  width: 32px; height: 18px; border-radius: 999px;
  background: var(--gray-20); position: relative; flex-shrink: 0;
}
.a11y-switch::after {
  content: ""; position: absolute; top: 2px; left: 2px;
  width: 14px; height: 14px; border-radius: 999px; background: var(--paper);
  box-shadow: 0 1px 3px rgba(18,18,18,0.2);
  transition: left 180ms var(--ease);
}
.a11y-switch--on { background: var(--green-default); }
.a11y-switch--on::after { left: 16px; }
```

HTML para navbar mock:

```html
<div class="navbar-mock">
  <div class="navbar-mock__left">{{APP_NAME}} · {{SECTION}}</div>
  <div class="navbar-mock__right">
    <span class="navbar-btn navbar-btn--active">{{TOGGLE_PRIMARY}}</span>
    <span class="navbar-btn">{{TOGGLE_SECONDARY}}</span>
  </div>
</div>
```

HTML para dropdown mock:

```html
<div class="a11y-dropdown">
  <div class="a11y-dropdown__item">
    <span class="label">{{ITEM_LABEL}}</span>
    <span class="a11y-switch a11y-switch--on"></span>
  </div>
  <div class="a11y-dropdown__item">
    <span class="label">{{ITEM_LABEL_2}}</span>
    <span class="a11y-switch"></span>
  </div>
</div>
```

**Regla importante**: si el mockup es para proponer un toggle de chrome del DECK propio (font, idioma, etc.), debe vivir dentro de `.deck-controls__panel` existente (ver SKILL.md "Mockup patterns"). No proponer botones flotantes nuevos paralelos al `.deck-controls`.

---

## Sample text con preview de modo de lectura (biónico / extendido / anclaje)

**Storytelling tip:** Para slides de pilares de accesibilidad o features de lectura, mostrar el efecto en vivo dentro de un párrafo de muestra es 10× más comunicativo que describirlo. Mantiene atención en el feel del feature.
**Cantidad:** 1 sample por slide. Máximo 4 líneas. Texto idealmente del producto real (no lorem ipsum).

```html
<div class="sample">
  <b>Mo</b>do <b>te</b> <b>pe</b>rmite <b>pa</b>gar <b>en</b> <b>cu</b>alquier
  <b>co</b>mercio <b>ad</b>herido <b>us</b>ando <b>la</b> <b>ta</b>rjeta
  <b>de</b> <b>tu</b> <b>ba</b>nco <b>fa</b>vorito.
</div>
```

Para extendida (un solo CSS):

```css
.sample--extendida {
  letter-spacing: 0.04em;
  word-spacing: 0.12em;
  line-height: 1.9;
}
```

Para anclaje (con dot en la línea activa), usar el mismo patrón de `.demo-sample[data-anchor="on"]` arriba.

---

## Tooltip de siglas técnicas (abbr branded)

**Storytelling tip:** Cualquier deck técnico (perf, infra, observability) usa siglas asumidas (LCP, FCP, CLS, TTFB, CWV, SSR, CMS, AVIF, WebP, SEO, PM, TL). El TL las conoce, el Manager no. Sin tooltip, el Manager tiene que googlear o asentir sin entender — pérdida de tiempo y de buy-in.
**Cantidad:** Tooltipear cada ocurrencia en body content. NO en chrome-top (top:28px dentro de slide con `overflow:hidden` clipea el tooltip hacia arriba — la misma sigla ya queda tooltipped en el body del mismo slide).
**A11y:** doble pattern `title="..."` (lectura nativa por screen reader + browser tooltip fallback) + `data-tip="..."` (CSS content attr para estilado custom). No drop-ear `title`.

CSS (poné junto al resto del CSS del deck, no inline):

```css
/* Branded abbr tooltip · siglas técnicas (LCP, FCP, CLS, TTFB, CWV, SSR, CMS, AVIF...) */
abbr.sig {
  position: relative;
  text-decoration: none;
  border-bottom: 1px dotted var(--green-default);
  cursor: help;
  font-variant: inherit;
  color: inherit;
}
abbr.sig:focus { outline: none; }
abbr.sig::after {
  content: attr(data-tip);
  position: absolute;
  left: 50%;
  bottom: calc(100% + 10px);
  transform: translateX(-50%) translateY(4px);
  background: var(--ink);
  color: var(--paper);
  font-family: "Red Hat Display", sans-serif;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.4;
  letter-spacing: 0;
  text-transform: none;
  padding: 8px 12px;
  border-radius: 8px;
  white-space: normal;
  width: max-content;
  max-width: 280px;
  text-align: left;
  box-shadow: 0 8px 24px rgba(18,18,18,0.18);
  border-left: 3px solid var(--green-default);
  opacity: 0;
  pointer-events: none;
  transition: opacity 160ms var(--ease), transform 160ms var(--ease);
  z-index: 10;
}
abbr.sig::before {
  content: "";
  position: absolute;
  left: 50%;
  bottom: calc(100% + 4px);
  transform: translateX(-50%) translateY(4px);
  width: 0; height: 0;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-top: 6px solid var(--ink);
  opacity: 0;
  pointer-events: none;
  transition: opacity 160ms var(--ease), transform 160ms var(--ease);
  z-index: 10;
}
abbr.sig:hover::after,
abbr.sig:focus::after,
abbr.sig:hover::before,
abbr.sig:focus::before {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}
```

HTML inline (cada ocurrencia, no minimal-once):

```html
<p class="body">
  El <abbr class="sig"
       title="Largest Contentful Paint — tiempo hasta que se pinta el elemento más grande del viewport. Core Web Vital."
       data-tip="Largest Contentful Paint — tiempo hasta el elemento más grande del viewport. Core Web Vital.">LCP</abbr>
  del home está 5× sobre el target.
</p>
```

Glosario canónico (reusable cross-decks):

| Sigla | Tooltip |
|---|---|
| LCP | Largest Contentful Paint — tiempo hasta que se pinta el elemento más grande del viewport. Core Web Vital. |
| FCP | First Contentful Paint — tiempo hasta el primer píxel de contenido en pantalla. |
| CLS | Cumulative Layout Shift — suma de saltos visuales del layout durante la carga. Core Web Vital. |
| TTFB | Time To First Byte — primer byte de respuesta del servidor. Mide salud backend/edge. |
| INP | Interaction to Next Paint — tiempo entre input del user y la próxima pintura visible. Reemplaza a FID como Core Web Vital. |
| CWV | Core Web Vitals — set de métricas oficiales de Google (LCP, INP, CLS). Ranking signal desde 2021. |
| SSR | Server-Side Rendering — el HTML se arma en el servidor antes de mandarlo al browser. |
| CSR | Client-Side Rendering — el HTML lo arma JS en el browser después de la carga inicial. |
| ISR | Incremental Static Regeneration — Next.js rebuild on-demand de páginas estáticas. |
| CMS | Content Management System — el headless CMS que sirve el contenido. En MODO es Storyblok. |
| AVIF | AV1 Image File Format — formato moderno con ~80% menos peso que JPEG a calidad equivalente. |
| WebP | Web Picture format — formato de Google, ~25-35% menos peso que JPEG/PNG. |
| SEO | Search Engine Optimization — optimización para buscadores. CWV son ranking signal desde 2021. |
| BFF | Backend For Frontend — capa anti-corruption entre el frontend y APIs upstream. |
| SDK | Software Development Kit — el SDK Container es la app webview de MODO. |
| PM | Product Manager — owner de producto que prioriza qué se construye y por qué. |
| TL | Tech Lead — owner técnico que decide el cómo y desbloquea al equipo. |

Anti-patterns:

- ❌ Tooltipear solo la primera ocurrencia por slide (el user no recuerda si scrollea de vuelta). Tooltipear cada ocurrencia.
- ❌ Tooltipear en chrome-top o chrome-bottom (clip por `overflow:hidden`).
- ❌ Drop-ear `title=""` y dejar solo `data-tip` (rompe screen reader + browser tooltip fallback).
- ❌ Tooltips de 400+ chars (no entra en `max-width: 280px` y queda cortado). Apuntar a 80-120 chars.
- ❌ Usar `abbr` sin `class="sig"` (queda con el `text-decoration: underline dotted` default del browser, no branded).

---

## Slide__body con overflow auto · scrollbar branded

**Storytelling tip:** Si un slide queda denso (3-4 cards + body + heading), en pantallas más chicas que 16:9 el contenido excede el viewport. La opción default es split en 2 slides — pero a veces el storytelling pide que todo viva junto (comparación lado a lado, tabla larga, evidence stack). Para esos casos, scroll dentro del slide con scrollbar branded resuelve sin romper la metáfora.
**Cuándo NO usar:** si el contenido entra en 16:9 estándar, no agregar scroll (queda raro). Default: split en 2 slides. Scroll es excepción.

CSS (poné junto al resto del CSS del deck):

```css
.slide__body {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-height: 0;            /* crítico · sin esto los flex children no shrinkean */
  overflow-y: auto;
  /* Scrollbar branded · Firefox */
  scrollbar-width: thin;
  scrollbar-color: var(--green-default) var(--gray-8);
}
/* Cuando el contenido excede el viewport, top-align + reservar espacio para el scrollbar.
   Solo se aplica cuando hace falta para NO shiftear el layout de los slides que no scrollean. */
.slide__body.is-scrollable {
  justify-content: flex-start;
  margin-right: -12px;
  padding-right: 12px;
}
/* Scrollbar branded · WebKit (Chrome, Safari, Edge).
   Declarar `::-webkit-scrollbar` con width explícito desactiva el modo overlay-hide de macOS. */
.slide__body::-webkit-scrollbar { width: 8px; }
.slide__body::-webkit-scrollbar-track {
  background: var(--gray-8);
  border-radius: 999px;
}
.slide__body::-webkit-scrollbar-thumb {
  background: var(--green-default);
  border-radius: 999px;
  border: 2px solid var(--gray-8);
  background-clip: padding-box;
  min-height: 32px;
}
.slide__body::-webkit-scrollbar-thumb:hover {
  background: var(--green-dark);
  background-clip: padding-box;
}
/* Indicador "hay más contenido" · fade gradient sticky en el bottom.
   Solo aparece si .is-scrollable está activo; desaparece al llegar al final. */
.slide__body.is-scrollable::after {
  content: "";
  position: sticky;
  bottom: 0; left: 0; right: 0;
  height: 48px;
  margin-top: -48px;
  background: linear-gradient(to bottom, transparent, var(--paper-warm) 85%);
  pointer-events: none;
  flex-shrink: 0;
  transition: opacity 200ms var(--ease);
}
.slide__body.is-scrollable.is-bottom::after { opacity: 0; }
```

JS · agregar dentro del IIFE de navegación (el que ya tiene `function go(i)`):

```js
// Auto-detect overflow en el slide__body activo. Togglea `is-scrollable` solo en los
// slides que lo necesitan (no shiftea los demás). Llamado desde go() + resize.
function updateScrollHints() {
  const activeBody = slides[current] && slides[current].querySelector('.slide__body');
  if (!activeBody) return;
  activeBody.scrollTop = 0;
  requestAnimationFrame(() => {
    const overflows = activeBody.scrollHeight - activeBody.clientHeight > 4;
    activeBody.classList.toggle('is-scrollable', overflows);
    activeBody.classList.remove('is-bottom');
  });
}
function onBodyScroll(e) {
  const b = e.target;
  if (!b.classList || !b.classList.contains('is-scrollable')) return;
  const atBottom = b.scrollHeight - b.clientHeight - b.scrollTop < 8;
  b.classList.toggle('is-bottom', atBottom);
}
slides.forEach(s => {
  const body = s.querySelector('.slide__body');
  if (body) body.addEventListener('scroll', onBodyScroll, { passive: true });
});
window.addEventListener('resize', () => {
  clearTimeout(window.__scrollHintsT);
  window.__scrollHintsT = setTimeout(updateScrollHints, 80);
});
```

Y dentro de `function go(i) { ... }`, llamar `updateScrollHints()` al final.

Anti-patterns:

- ❌ Aplicar `overflow-y: scroll` (siempre reserva espacio) en todos los slides — shiftea 8-12px el layout en los que NO scrollean.
- ❌ Olvidar `min-height: 0` en `.slide__body` flex child — sin eso, los flex items no shrinkean por debajo del content size y el overflow no se dispara.
- ❌ Estilar scrollbar sin `::-webkit-scrollbar { width: ...; }` — sin width explícito, macOS mantiene el overlay-hide y la scrollbar no se ve nunca.
- ❌ Hardcodear el track con `var(--paper-warm)` (mismo color que el slide bg) — desaparece el track y solo se ve el thumb flotando. Usar `var(--gray-8)` o más visible.
- ❌ Usar `position: fixed` para el fade indicator — `position: sticky` adentro del scroll container es la solución correcta.
