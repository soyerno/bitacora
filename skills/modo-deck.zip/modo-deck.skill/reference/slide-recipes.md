# Slide recipes

Drop-in HTML for each of the 14 standard MODO deck slide types. Each recipe is self-contained: paste inside the `<div class="deck" id="deck">` of `template.html` and replace `{{TOKEN}}` placeholders.

`{{N}}` and `{{TOTAL}}` are the current slide number and total (e.g. `02`, `14`). `{{P}}` is the progress fill percentage (`100 * N / TOTAL` rounded).

Add `class="slide active"` (not just `slide`) only on the first slide. The nav script handles the rest.

---

## 1. Cover (slide--cover)

**Storytelling tip:** Establece el contrato con la audiencia. El lede debe responder en una frase "qué estás pidiendo y a quién". Si alguien solo lee el cover, ¿sabe de qué se trata?
**Cantidad:** 1 cover por deck. El `LEDE` máximo 2 oraciones. Campos meta: 3 columnas fijas (Audiencia / Autor / Fecha).

Use as slide 01 and as the closing slide. Variables: `DECK_TITLE`, `EYEBROW`, `TITLE`, `TITLE_ACCENT`, `LEDE`, `AUDIENCE`, `AUTHOR`, `DATE`, `FOOTER_TAG`.

```html
<section class="slide slide--cover active" data-slide>
  <div class="slide__chrome-top">
    <span class="logo"><svg width="80" height="18" aria-label="MODO"><use href="#modo-logo-solid"/></svg></span>
    <span>{{FOOTER_TAG}}</span>
  </div>
  <div class="slide__body" style="justify-content: center;">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h1 class="title">{{TITLE}}<br /><span style="color: var(--green-default)">{{TITLE_ACCENT}}</span>.</h1>
    <p class="lede">{{LEDE}}</p>
  </div>
  <div class="meta">
    <div class="meta__col"><h4>Audiencia</h4><p>{{AUDIENCE}}</p></div>
    <div class="meta__col"><h4>Autor</h4><p>{{AUTHOR}}</p></div>
    <div class="meta__col"><h4>Fecha</h4><p>{{DATE}}</p></div>
  </div>
</section>
```

---

## 2. TL;DR / La recomendación (grid-3)

**Storytelling tip:** Esta slide ES la conclusión del Pyramid Principle. Si la audiencia ve solo esta slide, debe entender qué se propone y por qué vale la pena. Todo lo que sigue es evidencia de soporte.
**Cantidad:** Exactamente 3 stats (ni 2 ni 4). El párrafo `WHY_TOGETHER` máximo 3 líneas.

3-up stat grid above a binding paragraph. Variables: 3× `STAT_LABEL` + `STAT_VALUE` + `STAT_NOTE`, plus `WHY_TOGETHER`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top">
    <span class="logo"><svg width="64" height="14" aria-label="MODO"><use href="#modo-logo-solid"/></svg></span>
    <span>{{N}} · La recomendación</span>
  </div>
  <div class="slide__body">
    <p class="eyebrow">La recomendación</p>
    <h1 class="title" style="font-size: clamp(40px, 5vw, 68px); max-width: 22ch;">{{HEADLINE_PART_1}}<br /><span style="color: var(--green-default)">{{HEADLINE_ACCENT}}</span> {{HEADLINE_PART_2}}.</h1>
    <div class="grid-3" style="margin-top: 40px;">
      <div class="stat"><span class="stat__label">{{LABEL_1}}</span><span class="num num--md stat__value">{{VALUE_1}}</span><p class="muted">{{NOTE_1}}</p></div>
      <div class="stat"><span class="stat__label">{{LABEL_2}}</span><span class="num num--md stat__value">{{VALUE_2}}</span><p class="muted">{{NOTE_2}}</p></div>
      <div class="stat"><span class="stat__label">{{LABEL_3}}</span><span class="num num--md stat__value">{{VALUE_3}}</span><p class="muted">{{NOTE_3}}</p></div>
    </div>
    <p class="body" style="margin-top: 40px; max-width: 80ch;"><strong>Por qué juntas</strong>: {{WHY_TOGETHER}}.</p>
  </div>
  <div class="slide__chrome-bottom">
    <span>{{FOOTER_TAG}}</span>
    <div class="progress"><i style="--p: {{P}}%"></i></div>
    <span class="counter">{{N}} / {{TOTAL}}</span>
  </div>
</section>
```

---

## 3. Diagnóstico / stack hoy (stack-today)

**Storytelling tip:** Responde "¿qué duele hoy?". Debe crear tensión — mostrar el gap entre la situación actual y lo deseable. Sin tensión, el resto del deck no tiene fuerza.
**Cantidad:** 2-3 `stack-block`s. Cada bloque máximo 5 `row-item`s. Si hay más, agrupar en categorías.

Two `stack-block`s top, one full-width block bottom. Variables: per row → label / value, accent color via inline `style`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Diagnóstico</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <p class="body" style="max-width: 70ch; margin-bottom: 24px;">{{INTRO}}</p>
    <div class="stack-today">
      <div class="stack-block">
        <h4>{{BLOCK_1_TITLE}}</h4>
        <div class="row-item"><span class="label"><span class="mono">{{KEY}}</span></span><span class="value">{{VAL}}</span></div>
        <!-- repeat row-item -->
      </div>
      <div class="stack-block">
        <h4>{{BLOCK_2_TITLE}}</h4>
        <!-- row-items -->
      </div>
      <div class="stack-block" style="grid-column: 1 / -1;">
        <h4>{{BLOCK_3_TITLE}}</h4>
        <!-- row-items -->
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 4. Problem detail (50/50, two cards)

**Storytelling tip:** Responde "¿por qué ahora?". Las dos cards deben tener tensión entre sí (urgencia vs oportunidad, riesgo vs ventana). El banner verde cierra con el framing que conecta ambas.
**Cantidad:** Exactamente 2 cards, comparables en estructura. Cada card máximo 3 items o 4 líneas de body. El banner máximo 2 oraciones.

`grid-2` with two `.card` blocks; trailing green banner paragraph. Variables: each card → `CARD_INDEX`, `SUBHEADING`, content.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Timing</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 32px; align-items: stretch;">
      <div class="card">
        <span class="card__index">{{CARD_1_INDEX}}</span>
        <h3 class="subheading">{{CARD_1_SUBHEADING}}</h3>
        <p class="body" style="margin: 0;">{{CARD_1_BODY}}</p>
      </div>
      <div class="card">
        <span class="card__index">{{CARD_2_INDEX}}</span>
        <h3 class="subheading">{{CARD_2_SUBHEADING}}</h3>
        <ul class="checks">
          <li>{{ITEM_1}}</li>
          <li>{{ITEM_2}}</li>
        </ul>
      </div>
    </div>
    <p class="body" style="margin-top: 32px; padding: 20px 24px; background: var(--green-10); border-radius: 14px; color: var(--green-dark); max-width: none;">
      <strong>{{FRAMING_LEAD}}</strong>: {{FRAMING_BODY}}.
    </p>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 5–7. Pillar detail (big number + evidence)

**Storytelling tip:** Cada pilar es un argumento de soporte a la recomendación del slide 02. El `BIG_NUMBER` debe ser la "prueba" del argumento. Si el número no sorprende, o si no conecta con el `HEADLINE`, elegí otro. Los 3 pilares juntos deben responder "¿por qué esta propuesta y no otra?".
**Cantidad:** 3 pilares máximo (1 slide cada uno). Left: 1 big number + body máximo 3 líneas + 2-3 chips. Right: 2 evidence cards, cada una máximo 3 bullets o 4 líneas.

Repeat three times, one per pillar. `pillar-detail` is a 1fr / 1.1fr grid. Left = big metric + chips; right = stacked `pillar-detail__evidence` cards. Variables: `EYEBROW`, `BIG_NUMBER` (e.g. `12 → 15`), `HEADLINE`, `BODY`, chips, evidence h4 + content.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Pilar {{PILLAR_N}}</span><span>{{PILLAR_TOPIC}}</span></div>
  <div class="pillar-detail" style="padding-top: 32px;">
    <div>
      <p class="eyebrow">Pilar {{PILLAR_N}} · {{PILLAR_TOPIC}}</p>
      <div class="num num--xl num--accent">{{BIG_NUMBER}}</div>
      <h2 class="heading" style="font-size: 32px; margin-top: 8px;">{{HEADLINE}}.</h2>
      <p class="body" style="max-width: 50ch;">{{BODY}}</p>
      <div style="margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
        <span class="chip chip--green">{{CHIP_GREEN}}</span>
        <span class="chip">{{CHIP_1}}</span>
        <span class="chip">{{CHIP_2}}</span>
      </div>
    </div>
    <div>
      <div class="pillar-detail__evidence">
        <h4>{{EVIDENCE_1_TITLE}}</h4>
        <ul class="checks">
          <li><strong>{{ITEM_LEAD}}</strong>: {{ITEM_BODY}}.</li>
        </ul>
      </div>
      <div class="pillar-detail__evidence" style="background: var(--green-10); border-color: transparent;">
        <h4 style="color: var(--green-dark);">{{EVIDENCE_2_TITLE}}</h4>
        <p class="body" style="margin: 0;">{{EVIDENCE_2_BODY}}.</p>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 8. Timeline (3 phases + total)

**Storytelling tip:** Responde "¿cómo lo hacemos y en cuánto tiempo?". Las fases deben tener nombres que cuenten la historia de la transformación, no nombres técnicos ("Setup / Migración / Validación" beats "Fase 1 / Fase 2 / Fase 3"). El total es la cifra de cierre del bloque de propuesta.
**Cantidad:** Exactamente 3 fases + 1 total. Body de cada fase máximo 2 líneas. Las 2 notas inferiores (verde + neutral) máximo 1 oración cada una.

`.timeline` grid: 3 `.phase` cards + 1 `.phase__total`. Variables: phase number, weeks, title, body; total label + value.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · El plan</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="timeline">
      <div class="phase">
        <span class="phase__num">01</span>
        <span class="phase__weeks">{{PHASE_1_WEEKS}}</span>
        <h3 class="phase__title">{{PHASE_1_TITLE}}</h3>
        <p class="phase__body">{{PHASE_1_BODY}}</p>
      </div>
      <!-- phase 02, 03 -->
      <div class="phase__total">
        <span class="phase__weeks">{{TOTAL_LABEL}}</span>
        <span class="num num--lg" style="color: var(--green-default); margin: 4px 0;">{{TOTAL_VALUE}}</span>
        <span style="font-size: 12px; letter-spacing: 0.08em; color: var(--green-dark); text-transform: uppercase; font-weight: 600;">{{TOTAL_UNIT}}</span>
        <span style="font-size: 11px; color: var(--gray-60); margin-top: 8px; line-height: 1.4;">{{TOTAL_FOOTNOTE}}</span>
      </div>
    </div>
    <div class="grid-2" style="margin-top: 24px; gap: 20px;">
      <div class="card" style="background: var(--green-10); border-color: transparent; padding: 16px 20px;"><h4 style="font-size: 11px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: var(--green-dark); margin: 0 0 8px;">{{NOTE_GREEN_TITLE}}</h4><p class="body" style="margin: 0; font-size: 13px; color: var(--green-dark);">{{NOTE_GREEN_BODY}}</p></div>
      <div class="card" style="background: var(--gray-3); border-color: transparent; padding: 16px 20px;"><h4 style="font-size: 11px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: var(--dark-gray); margin: 0 0 8px;">{{NOTE_NEUTRAL_TITLE}}</h4><p class="body" style="margin: 0; font-size: 13px;">{{NOTE_NEUTRAL_BODY}}</p></div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 9. Scope (in / out) — grid-2 two-column checks

**Storytelling tip:** Esta slide gestiona expectativas antes de que alguien pregunte "¿y también van a hacer X?". El "NO entra" es tan importante como el "sí entra". Si la lista "no entra" está vacía, alguien va a malinterpretar el scope.
**Cantidad:** Cada columna máximo 6 items. Si hay más de 6 en "sí entra", el scope es demasiado amplio — dividir en fases.

Left card = green subheading + `ul.checks` (positive). Right card = `--gray-3` background + `ul.checks.checks--neutral`.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Scope</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <div class="grid-2" style="margin-top: 32px; align-items: flex-start;">
      <div class="card">
        <h3 class="subheading" style="color: var(--green-default);">{{IN_TITLE}}</h3>
        <ul class="checks">
          <li>{{IN_ITEM}}</li>
        </ul>
      </div>
      <div class="card" style="background: var(--gray-3); border-color: transparent;">
        <h3 class="subheading" style="color: var(--dark-gray);">{{OUT_TITLE}}</h3>
        <ul class="checks checks--neutral">
          <li>{{OUT_ITEM}}</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 10-12. Vista PM / TL / Manager (compare table)

**Storytelling tip:** Cada vista responde la pregunta que esa persona tiene en la cabeza antes de dar su aprobación. PM: "¿esto mejora la experiencia y la velocidad de entrega?". TL: "¿puedo revertir si algo sale mal?". Manager: "¿qué cuesta, qué riesgo tiene, qué gano?". No mezclar las vistas — cada una habla a una sola audiencia.
**Cantidad:** Tabla máximo 6 filas. Stat cards de Manager: exactamente 3. TL: máximo 4 columnas. Footnote: 1 oración.

`table.compare` with 3 columns (aspect / was / now). For Manager, add `.grid-3` of stat cards on top; for TL, add 4th `Rollback` column.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Vista {{ROLE}}</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">Para el {{ROLE}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <table class="compare" style="margin-top: 24px;">
      <thead><tr><th style="width: 36%;">Aspecto</th><th>Hoy</th><th>Después</th></tr></thead>
      <tbody>
        <tr><td>{{ASPECT}}</td><td class="was">{{WAS}}</td><td class="now">{{NOW}}</td></tr>
      </tbody>
    </table>
    <p class="muted" style="margin-top: 24px;"><span class="sigil"></span>{{FOOTNOTE}}.</p>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

For Manager add above the table:
```html
<div class="grid-3" style="margin-top: 24px;">
  <div class="card"><span class="card__index">{{LABEL}}</span><div class="num num--md" style="margin: 8px 0;">{{VALUE}}</div><p class="body" style="margin: 0;">{{NOTE}}</p></div>
</div>
```

For TL use 4 columns and add `<span class="dot dot--warn"></span>` chips in the risk cell.

---

## 13. Decisiones (ordered list with ownership)

**Storytelling tip:** Esta slide es el corazón del deck. Responde "¿qué necesito de vos antes de arrancar?". Cada decisión debe ser binaria o tener opciones claras. Si no se puede aprobar/rechazar/redirigir en 30 segundos, es demasiado vaga. El order importa: primero la decisión más bloqueante.
**Cantidad:** 2-4 decisiones máximo. Cada una: 1 título accionable + 1-2 líneas de body + 1 owner. Más de 4 decisiones en una reunión es irreal — partir en dos sesiones.

`ol.decisions` auto-numbers 01, 02 ... in green Quicksand. Each item has a subheading, body, and an ownership tag.

```html
<section class="slide" data-slide>
  <div class="slide__chrome-top"><span>{{N}} · Decisiones</span><span>{{SUBTITLE}}</span></div>
  <div class="slide__body">
    <p class="eyebrow">{{EYEBROW}}</p>
    <h2 class="heading">{{HEADLINE}}.</h2>
    <ol class="decisions" style="margin-top: 32px;">
      <li>
        <h3>{{DECISION_TITLE}}</h3>
        <p class="body" style="margin: 4px 0 0;">{{DECISION_BODY}}.</p>
        <p class="ownership">Owner: {{OWNER}}</p>
      </li>
    </ol>
  </div>
  <div class="slide__chrome-bottom"><span>{{FOOTER_TAG}}</span><div class="progress"><i style="--p: {{P}}%"></i></div><span class="counter">{{N}} / {{TOTAL}}</span></div>
</section>
```

---

## 14. Cierre

**Storytelling tip:** Cierra el contrato abierto en el cover. El título debe ser una invitación, no una afirmación ("¿Arrancamos?" o "Próximos pasos si hay apetito" beats "Conclusión"). El card de soporte da al audiencia el camino a seguir si quieren profundizar fuera de la reunión.
**Cantidad:** 1 slide. Titulo: máximo 6 palabras. Card de soporte: 2-4 links o referencias. Meta columns: exactamente 3 (Autor / Tickets / Repo u equivalente).

Use the cover recipe again with `class="slide slide--cover"` (no `active`), updated title, and a `.card` of "material de soporte" inside the body. Replace the bottom `meta` with `Autor / Tickets / Repo` columns.

---

## Reusable atoms

**Storytelling tip:** Los átomos son para reforzar, no para decorar. Un `.chip--green` en un pilar dice "esto ya está decidido/probado". Un `.dot--warn` en una tabla dice "ojo acá". Usarlos sin intención narrativa los vacía de significado.
**Cantidad:** Máximo 4 chips por slide. Máximo 2 dots de distinto color por tabla (más colores = ruido).



- `.chip` — pill labels. Modifiers: `chip--green`, `chip--yellow`, `chip--red`, `chip--ghost`.
- `.dot` — 8px status dot. Modifiers: `dot--good`, `dot--warn`, `dot--bad`.
- `.mono` — inline monospace token for file names, package names, versions.
- `.sigil` — small green square accent before muted footnotes.
- `.num--accent` — turns big number green.
- `ul.checks` — green check bullets. `checks--neutral` for grey, `checks--no` for red.
