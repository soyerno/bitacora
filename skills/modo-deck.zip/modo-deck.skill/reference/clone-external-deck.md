# Clone external deck look-and-feel (PPTX / Google Slides → HTML deck)

Cuando hay que armar un deck HTML que mantenga el visual de un PPTX/Google Slides existente (típicamente un deck de marca compartido por leadership/brand), seguir este workflow para extraer paleta + fonts + rhythm sin hacerlo a ojo.

## Cuándo usar

- User dice "que tenga el mismo estilo visual que [URL de Google Slides]" o "matcheá la presentación X".
- Hay que clonar un deck de marca C-level / leadership en HTML.
- Existe un PPTX canónico y querés un deck HTML hermano que se vea idéntico.

## Workflow

### Step 1 — Obtener el .pptx

**Si es Google Slides**: usar `mcp__claude_ai_Google_Drive__get_file_metadata` con el fileId (sale del URL `docs.google.com/presentation/d/<ID>/`). El metadata trae `mimeType` y `fileExtension`. Si es `application/vnd.openxmlformats-officedocument.presentationml.presentation` (`.pptx`), descargar con `mcp__claude_ai_Google_Drive__download_file_content`.

**Si es PPTX local**: ya está. Ubicar el path.

Antes de descargar, si el user ya tuvo el archivo abierto recientemente puede estar en `~/Downloads/<nombre>.pptx` — verificar primero con `find ~/Downloads -name "*.pptx"` (ahorra el round-trip de Drive y evita 401 por sesión expirada del MCP).

### Step 2 — Extraer el XML del PPTX

```bash
mkdir -p /tmp/pptx-extract && cd /tmp/pptx-extract
unzip -o ~/Downloads/<nombre>.pptx >/dev/null
ls ppt/slides/ ppt/theme/
```

Un PPTX es un ZIP de XML. Los slides están en `ppt/slides/slide{1..N}.xml`. El theme global (default Office, raramente útil) está en `ppt/theme/theme1.xml`. Los slide masters (más útiles cuando hay coherencia visual) están en `ppt/slideMasters/`. Las imágenes en `ppt/media/`.

### Step 3 — Extraer colores reales por slide

El theme1.xml suele ser el "Office Theme" default si el PPTX fue exportado desde Google Slides. **Los colores reales viven en cada slide XML como `<a:srgbClr val="HHHHHH"/>`**. Ignorar el theme y grep slide por slide:

```bash
for i in 1 2 3 4 5 6 7 8 9; do
  echo "=== slide$i ==="
  python3 -c "
import re
data = open('/tmp/pptx-extract/ppt/slides/slide$i.xml').read()
colors = sorted(set(re.findall(r'srgbClr val=\"([0-9A-Fa-f]{6})\"', data)))
print('colors:', colors)
bg = re.search(r'<p:bg>.*?</p:bg>', data)
if bg: print('bg:', bg.group()[:250])
sizes = sorted(set(re.findall(r'sz=\"(\d+)\"', data)), key=int, reverse=True)[:6]
print('text-sizes (top6):', sizes)
"
done
```

Output canónico (ejemplo de `modo-for-agents.pptx`):
```
=== slide1 === colors: ['00471B', '008859', '9E9E9E', 'B0CEC0', 'FF5524', 'FFC738', 'FFF8E5', 'FFFFFF']
              bg: 00471B (forest)
=== slide2 === colors: ['00471B', '008859', '263144', '9E9E9E', 'FF5524', 'FFF8E5']
              bg: FFF8E5 (cream)
...
```

Cada slide te da:
- **bg color** del slide → input directo para `.slide.<variant> { background: }`
- **Set de colores usados** → la paleta global (unión de todos los slides)
- **Text sizes** (en cents — 9000 = 90pt, 4200 = 42pt) → indica el type scale relativo

### Step 4 — Extraer fonts

```bash
python3 -c "
import re
data = open('/tmp/pptx-extract/ppt/slides/slide1.xml').read()
fonts = sorted(set(re.findall(r'typeface=\"([^\"]+)\"', data)))
print('fonts:', fonts)
"
```

Si aparecen fonts no-Google (Calibri, Arial), descartar — son fallbacks de Office. Las fonts reales aparecen como las definidas explícitamente (Red Hat Display, Quicksand, Inter, etc.).

### Step 5 — Identificar el slide rhythm

Listar bg color por slide en orden → eso te da el ritmo:

```
slide1: forest    → hero dark
slide2: cream     → content light
slide3: cream     → content light
slide4: forest    → dark feature
slide5: cream     → content light
slide6: cream     → content light
slide7: green     → closing solid
slide8: forest    → cierre dark
```

Replicar exactamente el rhythm en las clases del deck HTML (`.slide.hero`, `.slide`, `.slide.dark`, `.slide.green`, etc.).

### Step 6 — Mapear a tokens del deck HTML

Tomar los colores extraídos y crear el `:root` con nombres semánticos (no hex pelado):

```css
:root {
  --modo-forest: #00471B;   /* bg dark */
  --modo-cream: #FFF8E5;    /* bg light */
  --modo-gold: #FFC738;     /* accent sobre dark */
  --modo-orange: #FF5524;   /* accent sobre light */
  /* ... */
}
```

Después, **dos contextos**: light-by-default + override en `.slide.hero, .slide.dark, .slide.green { --accent: var(--modo-gold); --text: var(--modo-cream); ... }`. Eso te da theme-switching automático slide-por-slide sin duplicar reglas.

### Step 7 — Verificar visualmente

Abrir el deck en Chrome y screenshotear slides clave:

```
mcp__chrome-devtools__new_page url=file://.../deck.html
mcp__chrome-devtools__take_screenshot filePath=/var/folders/.../slide1.png
mcp__chrome-devtools__press_key key=ArrowRight
mcp__chrome-devtools__take_screenshot ...
```

**Nota path screenshots**: `/tmp/` está bloqueado por sandbox del MCP. Usar `/var/folders/.../T/` (TMPDIR real de macOS) o un workspace-root válido.

Comparar contra los slide masters del PPTX (mirar el .pptx en Keynote/PowerPoint). Si hay deriva — colores apagados, fonts genéricas, rhythm desincronizado — volver al step 3 y re-extraer.

## Anti-patterns

- **Confiar en el theme1.xml**: en PPTX exportados de Google Slides es el default Office. Los colores reales están por-slide, no en el theme.
- **A-ojo / paleta inventada**: si el user pidió "matcheá el visual de X", inventar la paleta te aleja del look real. Extraer.
- **Ignorar el slide rhythm**: dos decks pueden tener la misma paleta pero feel distinto por el orden de dark/light slides. El rhythm es parte de la marca.
- **Sobre-stylizar (gradientes, sombras agresivas)** cuando el original es flat: el PPTX te dice flat o gradient — respetar. Decks de marca MODO 2026 son flat solid colors, cero gradientes.
- **`/tmp/` para screenshots**: el sandbox del chrome-devtools MCP lo bloquea. Usar la carpeta de workspace o `$TMPDIR`.

## Quick ref

Comando único para inventariar todo un PPTX:

```bash
PPTX=~/Downloads/<nombre>.pptx
mkdir -p /tmp/pptx && cd /tmp/pptx && unzip -o "$PPTX" >/dev/null
N=$(ls ppt/slides/slide*.xml | wc -l | tr -d ' ')
echo "Slides: $N"
for f in ppt/slides/slide*.xml; do
  python3 -c "
import re,sys
data=open('$f').read()
colors=sorted(set(re.findall(r'srgbClr val=\"([0-9A-Fa-f]{6})\"',data)))
bg=re.search(r'<p:bg>.*?<a:srgbClr val=\"([0-9A-Fa-f]{6})',data)
bg=bg.group(1) if bg else 'inherit'
fonts=sorted(set(re.findall(r'typeface=\"([^\"]+)\"',data)))
print(f'$f → bg={bg} colors={colors} fonts={fonts}')
"
done
```

## Reference example

Caso canónico **2026-05-25**: `modo-checkout-skill/decks/presentacion-mvp-productivo.html` — clonado desde `modo-for-agents.pptx` (Google Slides original). Extracción dio:
- Palette: forest `#00471B` · cream `#FFF8E5` · gold `#FFC738` · orange `#FF5524` · green `#008859` · mint `#B0CEC0`
- Fonts: Red Hat Display + Red Hat Text
- Rhythm: hero forest → 2 cream → dark forest → 2 cream → green solid
- Signature: gold circle + orange spot decorative en slides dark (extraído del PPTX como shapes `ellipse` sin gradFill)

El deck terminado se ve en [presentacion-mvp-productivo.html](file:///Users/hernan.desouza/Documents/Proyectos/modo/modo-checkout-skill/decks/presentacion-mvp-productivo.html). Recipe documentado en este archivo.
