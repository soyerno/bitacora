# MODO brand tokens

Source: `modo-landing/tailwind.config.js` + `@playsistemico/modo-ui-lib-web`.

Drop the `:root` block as-is into any HTML deck and reference via `var(--token)`.

## CSS variables (copy-paste)

```css
:root {
  /* Green (primary) */
  --green-default: #008859;   /* PaymentDefault — main brand */
  --green-dark: #00471B;      /* PaymentDark — text on green tint */
  --green-10: #DCF5E7;        /* light tint, info cards */
  --green-20: #CCF6ED;        /* secondary tint */

  /* Yellow (rewards accent, sparingly) */
  --yellow-rewards: #FFC738;  /* PrimaryRewards */
  --yellow-soft: #FFE69B;

  /* Warning / negative */
  --red-warn: #FE5E5E;

  /* Tinted neutrals */
  --paper: #FFFFFF;
  --paper-warm: #FAFAF7;      /* slide background */
  --gray-3: #F8F8F8;          /* lightest fill */
  --gray-8: #ECECEC;          /* dividers, progress track */
  --gray-20: #D0D0D0;         /* borders */
  --gray-60: #777777;         /* muted body, captions */
  --dark-gray: #717171;       /* alt muted */
  --gray-80: #333333;         /* body text */
  --ink: #121212;             /* headings, primary text */

  /* Tokens */
  --border-soft: rgba(18, 18, 18, 0.06);
  --shadow-card: 0 1px 2px rgba(18,18,18,0.04), 0 8px 24px rgba(18,18,18,0.05);
  --ease: cubic-bezier(0.25, 1, 0.5, 1);
}
```

## Typography

- **Body / headings**: `"Red Hat Display"` (weights 400, 500, 600, 700, 800, 900)
- **Numbers, big metrics, indices**: `"Quicksand"` (weights 500, 600, 700) with `font-variant-numeric: tabular-nums`
- **Mono**: system stack — `ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`
- Always enable `font-variant-numeric: tabular-nums` anywhere a number changes between slides (counters, progress, metrics).

Type scale (already in template.html):
- `h1.title` — clamp(36px, 4.4vw, 64px), Quicksand 700
- `h2.heading` — clamp(28px, 3vw, 44px), Quicksand 700
- `h3.subheading` — 20px, Red Hat 600
- `p.lede` — 22px, gray-80
- `p.body` — 16px, gray-80
- `p.muted` — 13px, gray-60
- `.num--xl` — clamp(80px, 9vw, 140px), Quicksand 700
- `.num--lg` — clamp(48px, 5vw, 72px)
- `.num--md` — clamp(32px, 3.4vw, 48px)

## Spacing / radii

- Slide padding: `64px 80px` (cover: `80px`)
- Card padding: `24px`
- Radii: `14px` for cards, `999px` for chips, `4px` for mono inline
- Borders: `1px solid var(--border-soft)`

## Motion

- Easing: `cubic-bezier(0.25, 1, 0.5, 1)` (exposed as `--ease`)
- Duration: `180ms` (UI), `200ms` (transitions), `360ms` (progress bar fill)
- Never use bouncy or overshoot easings. No spring physics.

## Color usage budget

- Green (`--green-default`): accents only — title spans, eyebrows, num--accent, progress fill, chips. **≤10% of pixel area.**
- Yellow (`--yellow-rewards`): warning dots / "watch this" chips. Almost never as fill of large surfaces.
- Red (`--red-warn`): negative deltas, regressions. Never primary CTA.
- Everything else is the tinted neutral palette.

## Logo

- Default: `assets/logo-solid.svg` — all paths fill `#008859`. Use this 95% of the time.
- Alt: `assets/logo-multicolor.svg` — original rainbow variant. Reserve for product / SDK contexts.
- Both are embedded as `<symbol>` in `template.html` (`#modo-logo-solid` and `#modo-logo-multi`).
- Always pair with `aria-label="MODO"`.

## Tinted card variants (added 2026-05 post comercios-mvp)

Two helpers para destacar una card del grid sin romper la grilla:

- `.card--green-tint` — fondo `--green-10`, texto `--green-dark`. La "card importante" del grid (evidence, stop-the-line, GEO stack). Usar **una sola por slide**: si dos cards llevan tint, ninguna resalta.
- `.card--gray-tint` — fondo `--gray-3`, texto neutro. La opuesta: "no entra" / "pendientes" / contraste neutro frente a una verde.

Reemplazan el patrón inline `style="background: var(--green-10); border-color: transparent;"` que aparecía repetido en los decks. Si necesitás un tinte distinto (raro), seguí usando inline-style, pero solo si el tinte es one-off para esa slide específica.

## Dark mode (NO definir inline)

Los tokens de dark mode (`[data-theme="dark"]` y `[data-theme="auto"] + prefers-color-scheme: dark`) viven en `assets/deck-theme.css` del repo `erno-modo` y se cargan via shared assets. **Nunca redefinirlos inline en el deck** — duplicaría lo que ya provee la shared CSS y rompería consistencia entre decks.

Si necesitás un token NUEVO específico del deck (ej. un color de marca puntual para un slide), agregalo a `:root` inline pero solo para light. Para que respete dark, va al CSS compartido (PR aparte).

Tokens extra que provee `deck-theme.css` y NO están en el `:root` base:
- `--modo-bank-yellow: #FFC738` (para slides que mencionan bancos asociados)
- `--coral: #FF7A73` (chips de alerta secundaria)

## Warm theme (2026 brand · forest-dominant)

Variante "warm" usada cuando el deck necesita matchear los Google Slides / PPTX de MODO 2026 (decks de marca recientes: `modo-for-agents`, presentaciones C-level). Difiere del light/dark default porque el **bg dominante es forest verde oscuro**, no blanco, y los acentos son gold + orange-red en vez de green único.

```css
:root {
  --modo-forest: #00471B;       /* bg dark slides */
  --modo-forest-deep: #0A2914;  /* console / panels embedded */
  --modo-green: #008859;        /* bg slide cierre solid */
  --modo-mint: #B0CEC0;         /* mutes sobre forest */
  --modo-cream: #FFF8E5;        /* bg light slides + texto sobre forest */
  --modo-cream-warm: #FFF0E8;   /* panels embedded en cream */
  --modo-gold: #FFC738;         /* accent primario sobre forest */
  --modo-gold-deep: #CCA000;
  --modo-orange: #FF5524;       /* accent primario sobre cream */
  --modo-ink: #263144;          /* texto secundario sobre cream */
  --modo-ink-soft: #4A6070;
}
```

**Tipografía warm theme**: `Red Hat Display` (titulares) + `Red Hat Text` (body). NO `Quicksand` (esa va con el light theme histórico).

**Slide rhythm pattern** (canónico, replicado del PPTX de marca):
1. Hero forest (portada) — bg `--modo-forest`, kicker gold, titular cream con `.hl` gold
2-3. Content cream — bg `--modo-cream`, titular forest con `.hl` green/orange
4. Dark feature — bg `--modo-forest`, para slides técnicos densos (MCP, arquitectura)
5-6. Content cream
7. Closing green — bg `--modo-green` solid, titular cream con `.hl` gold

Alternar dark→light→light→dark→light→light→solid-green. Nunca dos forest seguidos sin un cream entremedio (cansa la vista del audience).

**Decorative spot mark** (signature visual de los decks warm): círculo gold `#FFC738` 96px en esquina top-right + spot orange `#FF5524` 44px desfasado. Solo en slides dark/green:

```css
.slide.hero::before, .slide.dark::before, .slide.green::before {
  content: ""; position: absolute; right: 6vw; top: 6vh;
  width: 96px; height: 96px;
  background: var(--modo-gold);
  border-radius: 50%;
  opacity: 0.85;
  box-shadow: -120px 80px 0 -52px var(--modo-orange);
  pointer-events: none;
}
```

**Wordmark flip**: en slides forest/green el `.modo-brand .wordmark` flippea de green→gold. JS minimal: toggle `body.dark-active` según clase del slide activo (`.hero | .dark | .green`).

**Cuándo usar warm theme vs default**: warm SOLO para decks pitch/branded/cierre de feature que se alinean con presentaciones C-level recientes. Para decks técnicos internos (PM/TL review), seguir con light default (`brand-tokens.md` top). No mezclar warm + light en un mismo deck.

### Parallax continuity transitions (warm theme · 2026)

Para decks warm que necesitan transición premium entre slides (pitch/leadership), usar el patrón **parallax background continuity**: 5 shapes flotando que glide a nuevas posiciones por slide, mientras el body bg fade-cambia de forest/cream/green. La continuidad la da el FONDO, no el slide.

Receta completa: `slide-recipes.md` `## Parallax background continuity (warm theme · 2026)`.

Compatibilidad: NO combinar con view-transitions, horizontal slide-panel, blur/scale fade, o spot mark decorativo (`::before` en slides). Son patrones que compiten. Parallax reemplaza todos los anteriores en su slide.
