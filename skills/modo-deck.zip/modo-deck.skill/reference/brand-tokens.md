# MODO brand tokens

Source: `modo-landing/tailwind.config.js` + `@playsistemico/modo-ui-lib-web`.

Drop the `:root` block as-is into any HTML deck and reference via `var(--token)`.

## CSS variables (copy-paste)

```css
:root {
  /* Green (primary) */
  --green-default: #008859;   /* PaymentDefault — main brand */
  --green-dark: #00471B;      /* PaymentDark — text on green tint */
  --green-10: #DCF5E7;        /* light tint, info cards */
  --green-20: #CCF6ED;        /* secondary tint */

  /* Yellow (rewards accent, sparingly) */
  --yellow-rewards: #FFC738;  /* PrimaryRewards */
  --yellow-soft: #FFE69B;

  /* Warning / negative */
  --red-warn: #FE5E5E;

  /* Tinted neutrals */
  --paper: #FFFFFF;
  --paper-warm: #FAFAF7;      /* slide background */
  --gray-3: #F8F8F8;          /* lightest fill */
  --gray-8: #ECECEC;          /* dividers, progress track */
  --gray-20: #D0D0D0;         /* borders */
  --gray-60: #777777;         /* muted body, captions */
  --dark-gray: #717171;       /* alt muted */
  --gray-80: #333333;         /* body text */
  --ink: #121212;             /* headings, primary text */

  /* Tokens */
  --border-soft: rgba(18, 18, 18, 0.06);
  --shadow-card: 0 1px 2px rgba(18,18,18,0.04), 0 8px 24px rgba(18,18,18,0.05);
  --ease: cubic-bezier(0.25, 1, 0.5, 1);
}
```

## Typography

- **Body / headings**: `"Red Hat Display"` (weights 400, 500, 600, 700, 800, 900)
- **Numbers, big metrics, indices**: `"Quicksand"` (weights 500, 600, 700) with `font-variant-numeric: tabular-nums`
- **Mono**: system stack — `ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`
- Always enable `font-variant-numeric: tabular-nums` anywhere a number changes between slides (counters, progress, metrics).

Type scale (already in template.html):
- `h1.title` — clamp(36px, 4.4vw, 64px), Quicksand 700
- `h2.heading` — clamp(28px, 3vw, 44px), Quicksand 700
- `h3.subheading` — 20px, Red Hat 600
- `p.lede` — 22px, gray-80
- `p.body` — 16px, gray-80
- `p.muted` — 13px, gray-60
- `.num--xl` — clamp(80px, 9vw, 140px), Quicksand 700
- `.num--lg` — clamp(48px, 5vw, 72px)
- `.num--md` — clamp(32px, 3.4vw, 48px)

## Spacing / radii

- Slide padding: `64px 80px` (cover: `80px`)
- Card padding: `24px`
- Radii: `14px` for cards, `999px` for chips, `4px` for mono inline
- Borders: `1px solid var(--border-soft)`

## Motion

- Easing: `cubic-bezier(0.25, 1, 0.5, 1)` (exposed as `--ease`)
- Duration: `180ms` (UI), `200ms` (transitions), `360ms` (progress bar fill)
- Never use bouncy or overshoot easings. No spring physics.

## Color usage budget

- Green (`--green-default`): accents only — title spans, eyebrows, num--accent, progress fill, chips. **≤10% of pixel area.**
- Yellow (`--yellow-rewards`): warning dots / "watch this" chips. Almost never as fill of large surfaces.
- Red (`--red-warn`): negative deltas, regressions. Never primary CTA.
- Everything else is the tinted neutral palette.

## Logo

- Default: `assets/logo-solid.svg` — all paths fill `#008859`. Use this 95% of the time.
- Alt: `assets/logo-multicolor.svg` — original rainbow variant. Reserve for product / SDK contexts.
- Both are embedded as `<symbol>` in `template.html` (`#modo-logo-solid` and `#modo-logo-multi`).
- Always pair with `aria-label="MODO"`.

## Tinted card variants (added 2026-05 post comercios-mvp)

Two helpers para destacar una card del grid sin romper la grilla:

- `.card--green-tint` — fondo `--green-10`, texto `--green-dark`. La "card importante" del grid (evidence, stop-the-line, GEO stack). Usar **una sola por slide**: si dos cards llevan tint, ninguna resalta.
- `.card--gray-tint` — fondo `--gray-3`, texto neutro. La opuesta: "no entra" / "pendientes" / contraste neutro frente a una verde.

Reemplazan el patrón inline `style="background: var(--green-10); border-color: transparent;"` que aparecía repetido en los decks. Si necesitás un tinte distinto (raro), seguí usando inline-style, pero solo si el tinte es one-off para esa slide específica.

## Dark mode (NO definir inline)

Los tokens de dark mode (`[data-theme="dark"]` y `[data-theme="auto"] + prefers-color-scheme: dark`) viven en `assets/deck-theme.css` del repo `erno-modo` y se cargan via shared assets. **Nunca redefinirlos inline en el deck** — duplicaría lo que ya provee la shared CSS y rompería consistencia entre decks.

Si necesitás un token NUEVO específico del deck (ej. un color de marca puntual para un slide), agregalo a `:root` inline pero solo para light. Para que respete dark, va al CSS compartido (PR aparte).

Tokens extra que provee `deck-theme.css` y NO están en el `:root` base:
- `--modo-bank-yellow: #FFC738` (para slides que mencionan bancos asociados)
- `--coral: #FF7A73` (chips de alerta secundaria)
