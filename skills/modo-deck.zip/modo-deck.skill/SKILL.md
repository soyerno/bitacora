---
name: modo-deck
description: "Armá presentaciones HTML branded MODO (verde #008859, Red Hat Display + Quicksand, logo solid green). Deck 16:9, navegación por teclado, exportable a PDF. Use cuando el usuario pida: 'armá un deck', 'make a deck', 'presentación MODO', 'slides MODO', 'ppt MODO', 'deck MODO', 'presentación para PM TL Manager', 'pitch deck MODO'. Auto-invocar para cualquier presentación interna o externa con identidad MODO."
---

Generates single-file HTML presentations with the MODO brand system. Output is one self-contained `.html` with embedded CSS, JS, fonts (Google Fonts CDN), and SVG logo symbols. No build step, no frameworks.

## When to use

- Internal stakeholder decks: Product Manager / Tech Lead / Manager reviews.
- Technical proposals to leadership (programa, RFC, ADR walkthrough).
- Pitches a comercios, bancos asociados, partners.
- Sprint kickoffs, retros con format ejecutivo, demos de POC.
- Cualquier momento donde haga falta una "pieza" con identidad MODO que se pueda mandar por Slack, imprimir a PDF, o presentar en pantalla 1280×720.

Do **not** use for: marketing assets externos (eso va por brand-guidelines), slides de partners no-MODO, decks de equipos sin identidad MODO.

## Step 0 — Audience check (MANDATORY, no-skippable)

**Antes de generar nada**, preguntá explícitamente quién es la audiencia. No avances hasta tener la respuesta. El ángulo, vocabulario, nivel de detalle y estructura cambian radicalmente.

Usá `AskUserQuestion` con estas opciones (ajustables):

- **Product Manager** — foco UX, métricas de producto, velocity, impact
- **Tech Lead / dev senior** — scope técnico, breaking changes, riesgos, rollback
- **Manager / leadership** — costo, riesgo, ROI, decisión a tomar
- **Comité mixto (PM + TL + Manager)** — combina las 3 vistas (vistaPM, vistaTL, vistaManager como slides separadas)
- **Partner externo / banco asociado** — registro brand, mención de bancos asociados, sin jerga interna
- **Equipo extendido (kick-off, retro, demo)** — informal, foco en acción + ownership

Si ninguna calza, preguntá una segunda vez para refinar. **No improvises la audiencia.**

Cuando la respuesta esté confirmada, recién ahí pedí el resto de los inputs.

## Required inputs (después de audiencia confirmada)

Pedí todo en un solo turno (no de a uno):

1. **Tema / título del deck** (1 frase).
2. **Decisión que se está pidiendo** (1 frase). Lo que la audiencia tiene que aprobar / vetar / discutir.
3. **2–4 números o stats de soporte** (porcentajes, semanas, versiones, cifras de baseline). Sin números, las slides quedan vacías.
4. **Estado**: `draft` / `rfc` / `completo` (default `draft` si no aclara). Define carpeta del repo + badge en index.
5. **Slug** kebab-case (default = derivado del título).

Outputs opcionales si el usuario los da: footer tag (e.g. "stack consolidation · modo-landing"), fecha, autor.

**Path de output**: NO preguntar. Siempre `/tmp/<slug>.html` (preview) + `~/Documents/Proyectos/modo/modo-decks/decks/<estado>/<slug>.html` (repo).

## Process

### 1. Load context

Read these three files in parallel before generating anything:

- `~/.claude/skills/modo-deck/reference/brand-tokens.md` — CSS variables and type scale.
- `~/.claude/skills/modo-deck/reference/design-rules.md` — guardrails (no em dashes, color budget, anti-patterns).
- `~/.claude/skills/modo-deck/reference/slide-recipes.md` — copy-pasteable HTML per slide type.

### 2. Decide structure

Default = 14 slides matching the standard MODO deck layout (see "Slide structure" below). Adjust between 8 and 20 based on scope. Never under 8 (incoherent) or over 20 (loses audience).

For a quick proposal (audiencia chica, 1 decisión), 8–10 slides:
- cover · TL;DR · diagnóstico · 1 pilar detail · plan · scope · decisiones · cierre.

For full PM/TL/Manager review, 14 slides (the canonical structure).

### 3. Fill template

Read `~/.claude/skills/modo-deck/assets/template.html` (already has all the CSS, JS, both logo `<symbol>`s, and an empty `.deck` div).

For each slide, copy the relevant recipe from `slide-recipes.md`, replace `{{TOKEN}}`s with real content, compute `--p` (progress percentage = `100 * slideN / totalSlides` rounded), and insert inside the `.deck` div.

First slide must have `class="slide slide--cover active"` (the `active` is critical — initial visibility).

### 4. Save (state-aware) + publish to repo (MANDATORY)

Todo deck generado debe tener **estado declarado** y subirse al repo `SoyErnoModo/modo-decks` (checkout principal en `/Users/hernan.desouza/Documents/Proyectos/modo/modo-decks/`).

**REGLA CRÍTICA · worktree obligatorio**: NUNCA commitear directo en el checkout principal. Siempre crear worktree hermano para cada deck:

```bash
export PATH="/opt/homebrew/bin:$PATH"
PRINCIPAL="/Users/hernan.desouza/Documents/Proyectos/modo/modo-decks"
git -C "$PRINCIPAL" pull --rebase origin main
git -C "$PRINCIPAL" worktree add "../modo-decks-<slug>" -b "deck/<slug>"
WORKTREE="/Users/hernan.desouza/Documents/Proyectos/modo/modo-decks-<slug>"
# Trabajar en $WORKTREE: cp del HTML, update index.html, commit, push origin deck/<slug>
# Después: merge a main del principal o PR via gh
# Cleanup: git -C "$PRINCIPAL" worktree remove "../modo-decks-<slug>"
```

Si por alguna razón NO se puede crear worktree (ej. branch ya existe sin merge), avisar al user antes de tocar el checkout principal.

**Estados:**

| Estado | Cuándo | Carpeta destino | Badge |
|---|---|---|---|
| `draft` | Primera versión, sin review externo. Working draft del autor. | `decks/draft/` | amarillo |
| `rfc` | Compartido para feedback formal. Esperando inputs de otros equipos antes de cerrar decisión. | `decks/rfc/` | azul |
| `completo` | Decisión tomada / presentación dada / shipped. Histórico. | `decks/completo/` | verde |

**Workflow:**

1. Preguntá al user: "¿estado del deck? draft / rfc / completo" (default `draft` si no aclara).
2. Naming: filename siempre `<slug-kebab>.html` (sin prefijo de estado — el estado se infiere de la carpeta).
3. Save a **dos paths**:
   - `/tmp/<slug>.html` (preview rápido — abrir local)
   - `~/Documents/Proyectos/modo/modo-decks/decks/<estado>/<slug>.html` (repo oficial)
4. Update `~/Documents/Proyectos/modo/modo-decks/index.html` agregando entry nueva en la lista, con:
   - Status badge correspondiente
   - Title + description + audiencia + fecha + N slides
   - Link a `decks/<estado>/<slug>.html`
   - Actualizar contadores de tabs (`<span class="count">N</span>`).
5. Commit + push al repo:
   ```
   git add decks/<estado>/<slug>.html index.html
   git commit -m "feat(decks): add <title> · <estado>"
   git push origin main
   ```
6. Confirmá al user con: path local del preview + URL pública `https://soyernomodo.github.io/modo-decks/decks/<estado>/<slug>.html` + link al index.

**Transiciones de estado** (cuando user pide promover):

- `draft → rfc`: `git mv decks/draft/<slug>.html decks/rfc/<slug>.html` + update badge en `index.html` + commit `chore(decks): promote <slug> draft → rfc`.
- `rfc → completo`: idem con `decks/rfc/` → `decks/completo/`.
- `draft → completo` (skip RFC): idem directo. Solo si el deck es informativo o ya hubo feedback informal.

**No subir** si:
- Deck contiene info confidencial no compartible (NDA, secrets, datos de cliente sin anonimizar). En ese caso solo `/tmp/` + avisar al user.
- User pide explícitamente "no subir" o "no commitear".

**Si falla `git push`** (network, auth): dejá los archivos en local, mostrá al user el comando exacto para push manual.

## Slide structure (default 14)

| # | Type | Purpose |
|---|------|---------|
| 01 | cover | título + audiencia + autor + fecha |
| 02 | TL;DR / la recomendación | 3 stats + bind paragraph |
| 03 | diagnóstico | stack / contexto hoy con stack-blocks |
| 04 | timing / por qué juntas | grid-2 cards + framing banner |
| 05 | pilar 01 detail | big number + evidence (50/50) |
| 06 | pilar 02 detail | big number + evidence (50/50) |
| 07 | pilar 03 detail | big number + evidence (50/50) |
| 08 | el plan en fases | timeline 3 phases + total |
| 09 | scope (sí / no) | grid-2 in vs out, checks |
| 10 | vista PM | compare table, foco velocity / UX |
| 11 | vista TL | compare table 4 cols con riesgo + rollback |
| 12 | vista Manager | grid-3 stat cards + compare table |
| 13 | decisiones | ordered list con ownership |
| 14 | cierre | cover-style con material de soporte |

## Anti-patterns (refuse outright)

- Gradient text or rainbow accents.
- Cards nested inside cards.
- Em dashes (use `·` or rephrase).
- Side-stripe / vertical accent border on slides.
- Glassmorphism, neumorphism, glow shadows.
- Hero-metric SaaS template (giant number alone in the middle).
- Inter / Geist / Manrope fonts. We use Red Hat Display + Quicksand.
- Stock photos on cover slides.
- Bullet lists > 5 items per slide.
- Animated counters or sparkles.
- More than 10% pixel area in green per slide.

See `reference/design-rules.md` for the full list.

## Nav features (already wired in template)

Keyboard:
- `→` / `j` / `Space` / `PageDown` — siguiente
- `←` / `k` / `PageUp` — anterior
- `Home` — primer slide
- `End` — último slide
- `P` — `window.print()` (genera PDF con `@media print` 1280×720)
- `C` / `Esc` — toggle drawer de reacciones (Giscus)

URL: `#3` salta al slide 3. `history.replaceState` mantiene el hash sincronizado al navegar.

Click: las flechas del nav floating en bottom-right. Botón 💬 abre el drawer de reacciones.

## Reacciones y comentarios (Giscus)

Cada deck publicado en `soyernomodo.github.io/modo-decks/` puede recibir 👍/❤️/🚀 y comentarios sin backend propio — la data vive en GitHub Discussions del repo (categoría **Announcements**).

**Cableado en el template:**
- Drawer derecho lazy-loaded (no carga el iframe hasta el primer toggle)
- Thread por deck con `data-mapping="specific"` + `data-term="{{DECK_SLUG}}"` → la discusión sigue al deck cuando se promueve `draft → rfc → completo`
- Print/PDF lo oculta automáticamente
- Botón 💬 en `.deck__nav` + tecla `c`

**Cuando generes un deck nuevo:**
- Reemplazá `{{DECK_SLUG}}` por el slug del deck (mismo valor que pasás a `publish-deck.sh`). El script `publish-deck.sh` rechaza el upload si encuentra placeholders sin resolver.
- Si querés un deck sin reacciones (ej. interno sensible), borrá el bloque `<aside id="deck-reactions">`, el `<script>` que lo controla, y el botón `#toggle-comments`.

**Retrofit a decks ya publicados:**
```bash
~/.claude/skills/modo-deck/scripts/add-giscus.py \
  ~/Documents/Proyectos/modo/modo-decks/decks/<estado>/<slug>.html
# Idempotente: si ya tiene Giscus, no hace nada. Slug = basename sin .html.
```

**Pre-requisitos (one-time, ya hechos):**
- Discussions habilitadas en `SoyErnoModo/modo-decks` ✅
- App Giscus instalada con acceso al repo (https://github.com/apps/giscus/installations/new)
- Repo public, categoría `Announcements` (id `DIC_kwDOSjBmA84C9erl`), repo-id `R_kgDOSjBmAw`

## Voice (rioplatense engineer · no técnico inflado)

Escribir como un ingeniero rioplatense le explica algo a otro en un café: directo, claro, vos en vez de tú, sin marketing fluff y sin jerga inflada. La audiencia es argentina y muchas veces no técnica, entonces el tono es conversacional pero preciso.

- **Vos, no tú** — siempre. "Si querés", "te paso el detalle", "vos decidís". Nunca "puedes" / "tú decides" / "deberías".
- **Verbos rioplatenses sobre formales**: "tirar" / "meter" / "arrancar" / "bajar" / "subir" / "agarrar" / "limpiar" en vez de "ejecutar" / "implementar" / "iniciar" / "desplegar". "Le vamos a meter mano a X" beats "Procederemos a intervenir en X".
- **Frases comunes ok** (con moderación, no caricaturizar): "hay que", "tal cual", "está bien así", "no es para tanto", "vamos al hueso", "lo más limpio es", "lo más simple es". Una por slide alcanza.
- **Spanish para copy de slides**. English solo para términos técnicos que ya son estándar interno: `Next 15`, `RSC`, `bundle`, `LCP`, `PR`, `deploy`, `CI`. Si hay un equivalente claro en castellano, usalo.
- **Borrar buzzwords inflados**: nada de "stakeholders" (decí "los equipos involucrados" o nombralos), "deliverables" (decí "lo que entregamos"), "alignment" (decí "alinear"), "leveragear" (no existe en español, decí "aprovechar"), "agile-friendly", "best-in-class", "next-gen". Si te suena a LinkedIn, sacalo.
- **Directo y técnico, pero accesible**. "Subimos Next a 15 y queda más rápido" beats "Embarking on a modernization journey" pero también beats "Implementamos un upgrade del framework Next.js a la versión 15.x con el objetivo de optimizar performance".
- **Números sobre adjetivos**. "~3 semanas" beats "rápido". "37 entidades" beats "muchas".
- **Hablar de "red MODO"** o **"ecosistema MODO"** sin listar bancos. La marca ya implica al ecosistema. Solo nombrar bancos cuando son sujeto directo de la slide. Nada de listas tipo "Galicia, Santander, BBVA, etc." — ruido sin valor.
- **Una claim por oración**. Si tiene `y` / `pero` / `además` dos veces, partila.
- **Sin pomposidad ni falsa humildad**. "Lo armé en 2 días" beats "Tras un proceso de investigación exhaustiva, logramos completar la primera iteración". "No tengo todo definido todavía" beats "Existen aún algunas decisiones pendientes".

**Test rápido:** leelo en voz alta. Si te suena a presentación de consultora o a copy de LinkedIn, reescribilo como se lo contarías a un colega del equipo.

## Storytelling and concision

Cada deck es una historia, no un dump de información. Pyramid principle (Minto): la respuesta primero, evidencia después.

**Estructura narrativa por defecto:**
1. Cover · contexto y audiencia (1 slide)
2. The recommendation · qué pedimos en 1 frase + 3 numeros que la sustentan (1 slide)
3. The problem · qué duele hoy, con evidencia (2-3 slides)
4. The proposal · qué proponemos, scope, lo que NO entra (2-3 slides)
5. The decision · qué necesitamos del comité y de qué owners depende cada paso (1 slide)
6. Cierre · busca aprobación, no anuncia (1 slide)

Si el deck supera 14 slides sin tener una decisión clara por slide, se está dispersando. Cortalo.

**Concision (regla 5/3/1):**
- Máximo 5 viñetas por slide (hard limit, ver Anti-patterns). 3 ideal.
- Máximo 3 líneas por viñeta.
- Máximo 1 idea por viñeta. Si tiene `y` o `,` con cláusula subordinada → partila.

**Anti-verbosidad checklist:**
- [ ] ¿Cada slide tiene un titular accionable, no descriptivo? ("Subimos Next a 15" beats "Análisis de Next.js")
- [ ] ¿Cada número va con su unidad y su contexto? ("~3 semanas con IA" beats "3 semanas")
- [ ] ¿Las cards son comparables horizontalmente? Si dos cards al lado tienen estructura distinta, alguien lo va a leer mal.
- [ ] ¿Hay una sola CTA por slide? Si hay dos CTAs, una debe ser primaria.
- [ ] ¿El cierre nombra owners por decisión, no responsables genéricos?

## Comms discipline (CRÍTICO · cuidar la conversación)

Los decks **buscan aprobación, no anuncian implementación**. Atropellar a otros equipos rompe trust y bloquea futuras aprobaciones.

**Prohibido en cierre / slide final:**
- "Aprobado el cambio, lo implemento esta semana"
- "Arrancamos el lunes"
- "Creo los tickets esta semana"
- Cualquier frase que asuma aprobación que la audiencia todavía no dio.

**Esperado en cierre / slide final:**
- "Antes de avanzar, necesito feedback de [X equipos]"
- "Si hay apetito, el próximo paso es agendar review con [owners], no abrir tickets"
- "Este deck propone, no decide"
- Lista explícita de **quiénes deberían opinar antes**: brand, marketing, legal, compliance, mobile (release freezes), QA, design system owners, SRE/Helm owners, analytics, content, SEO — según corresponda al tema.

**En las decisiones (slide de "decisiones que necesitamos"):**
- Owner por decisión: indicar PM / TL / Manager / Brand / Legal — no presumir que el TL decide solo.
- Diferenciar "decisión que se pide en esta reunión" vs "trabajo de validación que sigue después".

**Tono general:**
- Reconocer trabajo de otros equipos cuando se cruza con el propio (ej. "promoshub team owns X, queremos coordinar con ellos").
- Usar "propongo" / "necesito alinear" / "busco feedback" en vez de "vamos a" / "voy a hacer".
- Cuando algo lo decidiste vos solo, decilo: "el TL ya validó X" o "ya hablé con Y, ok de su lado".

Si dudás del tono en algún slide, leelo en voz alta como si fueras el PM / Manager. Si suena a "ya lo decidí, vengo a contarte", reescribilo.

## Reference example

`examples/nextjs-migration.html` es el deck canon de 14 slides que generó esta skill. Úsalo como referencia visual cuando dudes del tono o spacing.

## Self-review (correr antes de cerrar el deck)

Antes de declarar el deck listo, leelo de punta a punta como si fueras el manager más escéptico de la sala. Para cada slide pregúntate:

1. **¿Pasa el test de los 5 segundos?** Un decisor que abre el deck y mira solo el titular de cada slide, ¿se queda con la historia completa?
2. **¿Hay slide que sobre?** Si la eliminás, ¿la historia sigue de pie? Si sí, sacala.
3. **¿Hay slide que falte?** ¿Qué pregunta evidente queda sin responder?
4. **¿El cierre busca aprobación o anuncia ejecución?** Si dice "voy a hacer X esta semana" → mal. Reescribir.
5. **¿Mencioné los equipos que se cruzan?** Brand, Legal, Mobile, QA, SRE, PM. Si el cambio toca a alguno y no aparece, agregarlo.
6. **¿Cada número está respaldado por una fuente que puedo nombrar si me lo preguntan?** Si no, sacarlo o reemplazarlo por una observación cualitativa.
7. **¿Nombré bancos puntuales donde corresponde?** Solo cuando son el sujeto directo del slide (promo exclusiva, integración específica). No listar por inercia.

## Output checklist before saving

- [ ] `<title>` setteado al tema del deck.
- [ ] Primer `<section class="slide ...">` tiene `active` en la className.
- [ ] Cada slide tiene `data-slide` (lo necesita el JS para contar).
- [ ] Cada slide (excepto cover/cierre) tiene `slide__chrome-bottom` con `counter` `{{N}} / {{TOTAL}}` y `progress` con `--p` calculado.
- [ ] Eyebrows en green default, headings en ink, body en gray-80, muted en gray-60.
- [ ] Logo: usar `<span class="modo-wordmark">MODO</span>` (cover/cierre, 36px) y `<span class="modo-wordmark modo-wordmark--sm">MODO</span>` (chrome-top, 22px). El SVG solid traza mal cuando se monocroma; el wordmark CSS con Quicksand es la opción confiable.
- [ ] Cero em dashes (`—`) en el HTML.
- [ ] Cero gradientes en texto.
- [ ] Cada `.num` lleva `tabular-nums` (ya viene en la clase).
- [ ] Total de slides ≥ 8 y ≤ 20.
