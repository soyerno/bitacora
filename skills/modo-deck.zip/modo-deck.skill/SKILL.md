---
name: modo-deck
description: "Armá presentaciones HTML branded MODO (verde #008859, Red Hat Display + Quicksand, logo solid green). Deck 16:9, navegación por teclado, exportable a PDF. Use cuando el usuario pida: 'armá un deck', 'make a deck', 'presentación MODO', 'slides MODO', 'ppt MODO', 'deck MODO', 'presentación para PM TL Manager', 'pitch deck MODO'. Auto-invocar para cualquier presentación interna o externa con identidad MODO."
---

Generates single-file HTML presentations with the MODO brand system. Output is one self-contained `.html` with embedded CSS, JS, fonts (Google Fonts CDN), and SVG logo symbols. No build step, no frameworks.

## When to use

- Internal stakeholder decks: Product Manager / Tech Lead / Manager reviews.
- Technical proposals to leadership (programa, RFC, ADR walkthrough).
- Pitches a comercios, bancos asociados, partners.
- Sprint kickoffs, retros con format ejecutivo, demos de POC.
- Decks de adopción / invitación al equipo (fomentar el uso de una tool, skill o proceso). No buscan aprobación formal, buscan ACCIÓN — usar receta `15. Steps · 3 caminos` en vez de `8. Timeline` + `13. Decisiones`.
- Cualquier momento donde haga falta una "pieza" con identidad MODO que se pueda mandar por Slack, imprimir a PDF, o presentar en pantalla 1280×720.

Do **not** use for: marketing assets externos (eso va por brand-guidelines), slides de partners no-MODO, decks de equipos sin identidad MODO.

### Categorías de deck (impacta structure)

| Categoría | Cuándo | Slides | Cierre típico | Recetas clave |
|---|---|---|---|---|
| **Propuesta con decisión** | PM/TL/Manager review, RFC walkthrough | 14 (8-20) | "Decisiones · aguardo feedback" + owners | 8 (timeline) + 10-12 (vistas) + 13 (decisiones) |
| **Adopción / invitación** | Fomentar uso de tool/skill/proceso en el equipo | 10 (8-12) | "Esta semana, hacé X" + material de soporte | 15 (steps · 3 caminos) reemplaza 8 + 13 |
| **Retro / kickoff** | Cierre de sprint, kick-off informal | 8 (6-10) | "Próximos pasos" | grid-3 + chips + ownership |
| **Pitch externo** | Comercios, bancos, partners | 12 (10-16) | "CTA + contacto" | sin jerga interna, mencionar bancos asociados explícitos |

## Step 0 — Audience check (MANDATORY, no-skippable)

**Antes de generar nada**, preguntá explícitamente quién es la audiencia. No avances hasta tener la respuesta. El ángulo, vocabulario, nivel de detalle y estructura cambian radicalmente.

Usá `AskUserQuestion` con estas opciones (ajustables):

- **Product Manager** — foco UX, métricas de producto, velocity, impact
- **Tech Lead / dev senior** — scope técnico, breaking changes, riesgos, rollback
- **Manager / leadership** — costo, riesgo, ROI, decisión a tomar
- **Comité mixto (PM + TL + Manager)** — combina las 3 vistas (vistaPM, vistaTL, vistaManager como slides separadas)
- **Partner externo / banco asociado** — registro brand, mención de bancos asociados, sin jerga interna
- **Equipo extendido (kick-off, retro, demo)** — informal, foco en acción + ownership

Si ninguna calza, preguntá una segunda vez para refinar. **No improvises la audiencia.**

Cuando la respuesta esté confirmada, recién ahí pedí el resto de los inputs.

## Required inputs (después de audiencia confirmada)

Pedí todo en un solo turno (no de a uno):

1. **Tema / título del deck** (1 frase).
2. **Decisión que se está pidiendo** (1 frase). Lo que la audiencia tiene que aprobar / vetar / discutir.
3. **2–4 números o stats de soporte** (porcentajes, semanas, versiones, cifras de baseline). Sin números, las slides quedan vacías.
4. **Estado**: `draft` / `rfc` / `completo` (default `draft` si no aclara). Define carpeta del repo + badge en index.
5. **Slug** kebab-case (default = derivado del título).

Outputs opcionales si el usuario los da: footer tag (e.g. "stack consolidation · modo-landing"), fecha, autor.

**Path de output**: NO preguntar. Siempre `/tmp/<slug>.html` (preview) + `~/Documents/Proyectos/modo/erno-modo/decks/<estado>/<slug>.html` (repo).

## Process

### 1. Load context

Read these three files in parallel before generating anything:

- `~/.claude/skills/modo-deck/reference/brand-tokens.md` — CSS variables and type scale.
- `~/.claude/skills/modo-deck/reference/design-rules.md` — guardrails (no em dashes, color budget, anti-patterns).
- `~/.claude/skills/modo-deck/reference/slide-recipes.md` — copy-pasteable HTML per slide type.

### 2. Decide structure

Default = 14 slides matching the standard MODO deck layout (see "Slide structure" below). Adjust between 8 and 20 based on scope. Never under 8 (incoherent) or over 20 (loses audience).

For a quick proposal (audiencia chica, 1 decisión), 8–10 slides:
- cover · TL;DR · diagnóstico · 1 pilar detail · plan · scope · decisiones · cierre.

For full PM/TL/Manager review, 14 slides (the canonical structure).

### 3. Fill template

Read `~/.claude/skills/modo-deck/assets/template.html` (already has all the CSS, JS, both logo `<symbol>`s, and an empty `.deck` div).

For each slide, copy the relevant recipe from `slide-recipes.md`, replace `{{TOKEN}}`s with real content, compute `--p` (progress percentage = `100 * slideN / totalSlides` rounded), and insert inside the `.deck` div.

First slide must have `class="slide slide--cover active"` (the `active` is critical — initial visibility).

### 4. Save (state-aware) + publish to repo (MANDATORY)

Todo deck generado debe tener **estado declarado** y subirse al repo `SoyErnoModo/erno-modo` (checkout principal en `/Users/hernan.desouza/Documents/Proyectos/modo/erno-modo/`).

**REGLA CRÍTICA · worktree obligatorio**: NUNCA commitear directo en el checkout principal. Siempre crear worktree hermano para cada deck:

```bash
export PATH="/opt/homebrew/bin:$PATH"
PRINCIPAL="/Users/hernan.desouza/Documents/Proyectos/modo/erno-modo"
git -C "$PRINCIPAL" pull --rebase origin main
git -C "$PRINCIPAL" worktree add "../erno-modo-<slug>" -b "deck/<slug>"
WORKTREE="/Users/hernan.desouza/Documents/Proyectos/modo/erno-modo-<slug>"
# Trabajar en $WORKTREE: cp del HTML, update index.html, commit, push origin deck/<slug>
# Después: merge a main del principal o PR via gh
# Cleanup: git -C "$PRINCIPAL" worktree remove "../erno-modo-<slug>"
```

Si por alguna razón NO se puede crear worktree (ej. branch ya existe sin merge), avisar al user antes de tocar el checkout principal.

**Estados:**

| Estado | Cuándo | Carpeta destino | Badge |
|---|---|---|---|
| `draft` | Primera versión, sin review externo. Working draft del autor. | `decks/draft/` | amarillo |
| `rfc` | Compartido para feedback formal. Esperando inputs de otros equipos antes de cerrar decisión. | `decks/rfc/` | azul |
| `completo` | Decisión tomada / presentación dada / shipped. Histórico. | `decks/completo/` | verde |

**Workflow:**

1. Preguntá al user: "¿estado del deck? draft / rfc / completo" (default `draft` si no aclara).
2. Naming: filename siempre `<slug-kebab>.html` (sin prefijo de estado — el estado se infiere de la carpeta).
3. Save a **dos paths**:
   - `/tmp/<slug>.html` (preview rápido — abrir local)
   - `<WORKTREE>/decks/<estado>/<slug>.html` (NO en el principal — ver worktree obligatorio arriba)
4. Update **`decks/decks.json`** (NO `index.html` — `index.html` ya lee de `decks.json` dinámicamente). Agregar entry nueva al principio del array `decks`:
   ```json
   {
     "id": "<slug>",
     "title": "<title>",
     "desc": "<descripción 1-2 oraciones>",
     "href": "decks/<estado>/<slug>.html",
     "status": "<estado>",
     "audience": "<audiencia>",
     "date": "2026-MM-DD",
     "slides": <N>,
     "topics": ["<tag1>", "<tag2>"],
     "featured": true
   }
   ```
5. Commit + push branch al repo:
   ```
   git add decks/<estado>/<slug>.html decks/decks.json
   git commit -m "feat(decks): add <title> · <estado>"
   git push -u origin deck/<slug>
   ```
6. **Push directo a main está bloqueado** por la policy del harness. Crear PR y mergear via `gh`:
   ```
   gh pr create --title "feat(decks): add <slug> · <estado>" --body "..."
   gh pr merge <PR-NUM> --squash --auto
   ```
   El `--auto` hace que se mergee solo cuando los checks de CI pasen (si los hay).

   **Si `main` avanzó durante el laburo en el worktree** (otros PRs mergearon mientras vos trabajabas), tu branch sale "detrás" y el diff contra `origin/main` muestra deletes falsos de archivos que no tocaste. Antes del PR (o tras `git push`), rebasear:
   ```bash
   git fetch origin main
   git rebase origin/main
   # Si hay conflicto típico en decks/decks.json (dos PRs agregaron entry al inicio del array),
   # resolver manualmente: dejar el deck más nuevo arriba, el otro abajo. Luego:
   git add decks/decks.json
   git rebase --continue
   git push --force-with-lease origin deck/<slug>
   ```
   **Cuándo usar `--force-with-lease`** vs `--force`: siempre `--force-with-lease` — solo sobrescribe si el remote está exactamente como lo viste por última vez. Te protege de pisar cambios concurrentes en tu branch (improbable pero posible si compartís el branch).
7. **Cleanup worktree después del merge**:
   ```
   git -C "$PRINCIPAL" worktree remove "../erno-modo-<slug>" --force
   git -C "$PRINCIPAL" branch -D deck/<slug>
   git -C "$PRINCIPAL" pull origin main
   ```
8. Confirmá al user con: path local del preview + URL pública `https://soyernomodo.github.io/erno-modo/decks/<estado>/<slug>.html` + número del PR mergeado. GH Pages tarda ~30s en reconstruir; podés verificar con `curl -sI <url>`.

**Transiciones de estado** (cuando user pide promover):

- `draft → rfc`: `git mv decks/draft/<slug>.html decks/rfc/<slug>.html` + update badge en `index.html` + commit `chore(decks): promote <slug> draft → rfc`.
- `rfc → completo`: idem con `decks/rfc/` → `decks/completo/`.
- `draft → completo` (skip RFC): idem directo. Solo si el deck es informativo o ya hubo feedback informal.

**No subir** si:
- Deck contiene info confidencial no compartible (NDA, secrets, datos de cliente sin anonimizar). En ese caso solo `/tmp/` + avisar al user.
- User pide explícitamente "no subir" o "no commitear".

**Si falla `git push`** (network, auth): dejá los archivos en local, mostrá al user el comando exacto para push manual.

## Slide structure (default 14, opcional 15 con harness)

| # | Type | Purpose |
|---|------|---------|
| 01 | cover | título + audiencia + autor + fecha |
| 02 | TL;DR / la recomendación | 3 stats + bind paragraph |
| 03 | diagnóstico | stack / contexto hoy con stack-blocks |
| 04 | timing / por qué juntas | grid-2 cards + framing banner |
| 05 | pilar 01 detail | big number + evidence (50/50) |
| 06 | pilar 02 detail | big number + evidence (50/50) |
| 07 | pilar 03 detail | big number + evidence (50/50) |
| 08 | el plan en fases | timeline 3 phases + total |
| 09 | scope (sí / no) | grid-2 in vs out, checks |
| 10 | vista PM | compare table, foco velocity / UX |
| 11 | vista TL | compare table 4 cols con riesgo + rollback |
| 12 | vista Manager | grid-3 stat cards + compare table |
| 13 | (opcional) harness / proceso | mini-grid 3×2 con 6 pasos del workflow + chips de evidencia |
| 14 | decisiones | ordered list con ownership |
| 15 | cierre | cover-style con material de soporte |

**Cuándo sumar la slide 13 de harness:**

- Decks de **propuesta técnica** con multi-fase / programa de varios PRs.
- Cuando la audiencia (TL / Manager) va a preguntar "¿cómo aseguran calidad antes de mergear?".
- Buen lugar para responder rigor de proceso: SDD, TDD, tests por nivel (unit / integration / E2E), docs vivas, regresión.

Si el deck es chico (8–10 slides), saltar la slide de harness y resumir el proceso en 1–2 chips dentro del scope o decisiones.

**Cuándo NO usar el layout pillar-detail estándar y reemplazar por screenshot-tour:**

- Sprint review / demo de POC / shipping checkpoint.
- La "prueba" del argumento es una pantalla real, no una cifra.
- Reemplaza las slides 05/06/07 (pilares) por 3–4 slides screenshot-tour, una por surface.
- Cada screenshot-tour pesa una surface + qué hay en la pantalla + checks compactos. Ver recipe en `slide-recipes.md`.

## Anti-patterns (refuse outright)

- Gradient text or rainbow accents.
- Cards nested inside cards.
- Em dashes (use `·` or rephrase).
- Side-stripe / vertical accent border on slides.
- Glassmorphism, neumorphism, glow shadows.
- Hero-metric SaaS template (giant number alone in the middle).
- Inter / Geist / Manrope fonts. We use Red Hat Display + Quicksand.
- Stock photos on cover slides.
- Bullet lists > 5 items per slide.
- Animated counters or sparkles.
- More than 10% pixel area in green per slide.

See `reference/design-rules.md` for the full list.

## Nav features (already wired in template)

Keyboard:
- `→` / `j` / `Space` / `PageDown` — siguiente
- `←` / `k` / `PageUp` — anterior
- `Home` — primer slide
- `End` — último slide
- `P` — `window.print()` (genera PDF con `@media print` 1280×720)
- `C` / `Esc` — toggle drawer de reacciones (Giscus)

URL: `#3` salta al slide 3. `history.replaceState` (no `pushState`) mantiene el hash sincronizado al navegar — el back-button del browser sale del deck en vez de retroceder slide-por-slide. **Mantener replaceState**: cualquier refactor que lo cambie a pushState rompe esa expectativa.

Click: las flechas del nav floating en bottom-right. Botón 💬 abre el drawer de reacciones.

**Selector del controller**: el script enumera slides con `document.querySelectorAll('[data-slide]')`, NO con `.slide`. Una `<section class="slide">` sin atributo `data-slide` no se cuenta (counter desincronizado). Cualquier slide nueva DEBE llevar el atributo (sin valor — basta `data-slide`).

**Dual counter (global + per-slide)**: cada navegación actualiza `#counter` (dentro de `.deck__nav`) Y `.slide__chrome-bottom .counter` del slide activo. Mismo formato padded `01 / 14`. Cover y cierre típicamente no llevan chrome-bottom por diseño — solo se actualiza el global, sin error.

**`active` en el HTML, no solo en JS**: la primera slide debe nacer con `class="slide ... active"` en el HTML emitido. El controller corre post-DOMContentLoaded; sin la clase inicial hay un blink en blanco en el primer paint. Es por eso que `slide-recipes.md` siempre marca la cover con `slide--cover active`.

**Decisiones explícitas de chrome (no agregar sin discutirlo · estado del arte 2026-05):**

- **Sin TOC overlay** — los decks pesan 8–20 slides, la counter + hash navigation alcanza. Un TOC agrega cognitive load para un beneficio marginal.
- **Sin botón fullscreen** — `F11` del browser ya lo hace, sumar otro botón es ruido.
- **Sin swipe touch / side dots** — los decks son 16:9 para pantalla / proyector / PDF, no mobile-first. El presenter usa teclado o mouse.
- **Sin "press F" hint inicial** — cluttering de un overlay al cargar que el presenter ya conoce.
- **Sin auto-advance ni reload-to-restart** — el deck es navegado a mano siempre.
- **Sin `prefers-reduced-motion` guard explícito** — el deck casi no tiene animaciones (progress bar 360ms, drawer slide 220ms). No hace falta hoy. Si en el futuro entran transiciones más visibles entre slides, ahí sí evaluar.

Cualquier feature de chrome que se sume va como **row nueva dentro de `.deck-controls__panel`** (dropdown del header), no como botón flotante suelto. Ver regla genérica abajo.

**Accesibilidad — Preferencias de lectura (dropdown en header):** el template wirea `assets/deck-bionic.css` + `assets/deck-bionic.js`. El JS detecta el `.theme-toggle` existente y lo agrupa con el toggle de Lectura biónica adentro de un dropdown nativo `<details class="deck-controls">` en el header (icono de engranaje arriba a la derecha). Abrir/cerrar es **HTML+CSS puro** (`<details>`/`<summary>`) — sin handlers de click, click-outside ni Escape en JS. Cuando Bio está `on`, agrega `body.bionic-on` y envuelve el prefijo (~50%) de cada palabra en `<b class="bionic">` con `font-weight: 700`. Persiste estado en `localStorage` (`modo-decks-bionic`). Skipea `script/style/code/pre/svg/.mono/.theme-toggle/.deck-bionic-toggle/.deck-controls/[data-bionic="skip"]` — no rompe paths, versiones ni iconos. Para excluir un bloque ad-hoc, agregale `data-bionic="skip"`.

**Por qué un dropdown y no botones sueltos** (regla genérica para futuros features de chrome): dos chips chiquitos al lado del título compiten con el branding y rompen el grid del header en mobile. Un solo trigger discreto + panel desplegable mantiene navegación limpia, y `<details>` da accesibilidad nativa (Tab + Enter abre). **Cualquier feature nuevo de UI chrome (font-size, contraste, animación toggle, idioma, etc.) se agrega como una row más en `.deck-controls__panel`, NUNCA como botón flotante nuevo.** Si el feature necesita estado open/close, usar `<details>` + CSS — nada de JS toggling.

## Assets compartidos (live al deploy) · preview standalone

Los decks NO empaquetan su propio CSS/JS de chrome. Linkean cuatro assets que se sirven desde Pages cuando el deck está publicado:

- `assets/deck-theme.css` + `assets/deck-theme.js` — toggle auto/claro/oscuro + bootstrap pre-paint en `<head>`.
- `assets/deck-bionic.css` + `assets/deck-bionic.js` — dropdown `.deck-controls` con preferencias de lectura.

**Producción**: los assets viven en `~/Documents/Proyectos/modo/erno-modo/assets/`. Cuando un deck se publica a `decks/<estado>/<slug>.html` en ese repo, los paths relativos `../../assets/*` del template resuelven al servir desde root del repo / Pages.

**Skill local (vendoreado)**: el skill mantiene una **copia espejo** de los cuatro assets en `~/.claude/skills/modo-deck/assets/` (junto al `template.html`). Sirve para:
- Previews standalone (ver más abajo): el deck levanta chrome completo sin depender de erno-modo.
- Auditar / editar los assets mientras se diseña una slide nueva.

> **Atención · drift potencial**: las copias son snapshots. Si tocás los assets en cualquiera de los dos lados, hay que sincronizar. Para eso existe `scripts/sync-assets.sh`:
> ```
> sync-assets.sh           # check (default): reporta drift, exit 1 si hay
> sync-assets.sh diff      # check + diff línea por línea para decidir
> sync-assets.sh pull      # repo → skill (skill copia producción)
> sync-assets.sh push      # skill → repo (producción adopta lo local; después commit en erno-modo)
> ```
> El script NO hace auto-resolución cuando hay drift — muestra mtime + size para que decidas. `publish-deck.sh` corre `sync-assets.sh check` automáticamente y advierte (sin bloquear) si encuentra divergencia.

**Implicancia 1 · assets son globales (regla genérica):** cualquier cambio a esos cuatro archivos aplica a TODOS los decks publicados al toque del próximo deploy de Pages. **Nunca hacer overrides per-deck** (ni inline `<style>` redefiniendo `.deck__nav`, ni copia del JS embebida en el HTML del deck). Si una slide pide algo que rompe el chrome compartido, abrir change al asset y discutirlo — no parche local.

**Implicancia 2 · preview en `/tmp/` con chrome roto** (default): el template emite `<link href="../../assets/deck-theme.css">` etc. En `/tmp/<slug>.html` esos paths no resuelven. El deck igual abre y se navega con teclado, pero theme toggle / lectura biónica / reacciones no funcionan.

**Preview standalone con chrome completo** (opcional · cuando necesitás validar el dropdown y la lectura biónica antes de publicar):

```bash
# Variante A · symlink-de-una-vez en /tmp (recomendado)
ln -sfn ~/.claude/skills/modo-deck/assets /tmp/assets-modo-deck
# Editar el template del deck en /tmp/<slug>.html y reemplazar:
#   ../../assets/  →  assets-modo-deck/
# Una sola línea sed por archivo:
sed -i '' 's|\.\./\.\./assets/|assets-modo-deck/|g' /tmp/<slug>.html
open /tmp/<slug>.html

# Variante B · carpeta autocontenida (para compartir el preview por zip)
mkdir -p /tmp/<slug>-preview && cp ~/.claude/skills/modo-deck/assets/{deck-theme,deck-bionic}.{css,js} /tmp/<slug>-preview/
cp /tmp/<slug>.html /tmp/<slug>-preview/index.html
sed -i '' 's|\.\./\.\./assets/|./|g' /tmp/<slug>-preview/index.html
open /tmp/<slug>-preview/index.html
```

**Importante**: el deck que después se publica al repo (`~/Documents/Proyectos/modo/erno-modo/decks/<estado>/<slug>.html`) DEBE conservar las rutas originales `../../assets/*`. Si vas a usar la variante B sobre el archivo que ya estaba en `/tmp/`, hacelo SOLO sobre la copia, no sobre `/tmp/<slug>.html` directamente. El script `publish-deck.sh` valida los paths antes de copiar al repo (ver más abajo).

**Diagnóstico de drift asset ↔ skill** (chequear si el dropdown no agrupa): si al abrir el deck en el repo ves dos botones flotantes sueltos (theme + bionic) en vez del dropdown único, hay un mismatch de naming entre los dos scripts:

- `deck-theme.js` debe montar el botón con `className = 'theme-toggle'` (selector que busca el dropdown).
- `deck-bionic.js` busca `#theme-toggle` o `.theme-toggle` para envolverlo en `.deck-controls`.

Si `deck-theme.js` está montando con `'deck-theme-toggle'` (prefijo `deck-`), el dropdown nunca encuentra el toggle de tema y cae al fallback `.deck-bionic-toggle--standalone`. Ese fallback solo tiene `justify-self: end` (válido en grid containers) — al appendearse a `document.body` (que no es grid) el botón cae al final del body flow, fuera de pantalla. Fixearlo en el asset, no en el deck. **Verificado al 2026-05-20**: el repo tiene este mismatch (`deck-theme.js` usa `deck-theme-toggle`); cuando se arregle, los decks shipeados pasan a mostrar el dropdown sin tocarlos.

## Reacciones y comentarios (Giscus)

Cada deck publicado en `soyernomodo.github.io/erno-modo/` puede recibir 👍/❤️/🚀 y comentarios sin backend propio — la data vive en GitHub Discussions del repo (categoría **Announcements**).

**Cableado en el template:**
- Drawer derecho lazy-loaded (no carga el iframe hasta el primer toggle)
- Thread por deck con `data-mapping="specific"` + `data-term="{{DECK_SLUG}}"` → la discusión sigue al deck cuando se promueve `draft → rfc → completo`
- Print/PDF lo oculta automáticamente
- Botón 💬 en `.deck__nav` + tecla `c`

**Cuando generes un deck nuevo:**
- Reemplazá `{{DECK_SLUG}}` por el slug del deck (mismo valor que pasás a `publish-deck.sh`). El script `publish-deck.sh` rechaza el upload si encuentra placeholders sin resolver.
- Si querés un deck sin reacciones (ej. interno sensible), borrá el bloque `<aside id="deck-reactions">`, el `<script>` que lo controla, y el botón `#toggle-comments`.

**Retrofit a decks ya publicados:**
```bash
~/.claude/skills/modo-deck/scripts/add-giscus.py \
  ~/Documents/Proyectos/modo/erno-modo/decks/<estado>/<slug>.html
# Idempotente: si ya tiene Giscus, no hace nada. Slug = basename sin .html.
```

**Pre-requisitos (one-time, ya hechos):**
- Discussions habilitadas en `SoyErnoModo/erno-modo` ✅
- App Giscus instalada con acceso al repo (https://github.com/apps/giscus/installations/new)
- Repo public, categoría `Announcements` (id `DIC_kwDOSjBmA84C9erl`), repo-id `R_kgDOSjBmAw`

## Voice (rioplatense engineer · no técnico inflado)

Escribir como un ingeniero rioplatense le explica algo a otro en un café: directo, claro, vos en vez de tú, sin marketing fluff y sin jerga inflada. La audiencia es argentina y muchas veces no técnica, entonces el tono es conversacional pero preciso.

- **Vos, no tú** — siempre. "Si querés", "te paso el detalle", "vos decidís". Nunca "puedes" / "tú decides" / "deberías".
- **Verbos rioplatenses sobre formales**: "tirar" / "meter" / "arrancar" / "bajar" / "subir" / "agarrar" / "limpiar" en vez de "ejecutar" / "implementar" / "iniciar" / "desplegar". "Le vamos a meter mano a X" beats "Procederemos a intervenir en X".
- **Frases comunes ok** (con moderación, no caricaturizar): "hay que", "tal cual", "está bien así", "no es para tanto", "vamos al hueso", "lo más limpio es", "lo más simple es". Una por slide alcanza.
- **Spanish para copy de slides**. English solo para términos técnicos que ya son estándar interno: `Next 15`, `RSC`, `bundle`, `LCP`, `PR`, `deploy`, `CI`. Si hay un equivalente claro en castellano, usalo.
- **Borrar buzzwords inflados**: nada de "stakeholders" (decí "los equipos involucrados" o nombralos), "deliverables" (decí "lo que entregamos"), "alignment" (decí "alinear"), "leveragear" (no existe en español, decí "aprovechar"), "agile-friendly", "best-in-class", "next-gen". Si te suena a LinkedIn, sacalo.
- **Directo y técnico, pero accesible**. "Subimos Next a 15 y queda más rápido" beats "Embarking on a modernization journey" pero también beats "Implementamos un upgrade del framework Next.js a la versión 15.x con el objetivo de optimizar performance".
- **Números sobre adjetivos**. "~3 semanas" beats "rápido". "37 entidades" beats "muchas".
- **Hablar de "red MODO"** o **"ecosistema MODO"** sin listar bancos. La marca ya implica al ecosistema. Solo nombrar bancos cuando son sujeto directo de la slide. Nada de listas tipo "Galicia, Santander, BBVA, etc." — ruido sin valor.
- **Una claim por oración**. Si tiene `y` / `pero` / `además` dos veces, partila.
- **Sin pomposidad ni falsa humildad**. "Lo armé en 2 días" beats "Tras un proceso de investigación exhaustiva, logramos completar la primera iteración". "No tengo todo definido todavía" beats "Existen aún algunas decisiones pendientes".

**Test rápido:** leelo en voz alta. Si te suena a presentación de consultora o a copy de LinkedIn, reescribilo como se lo contarías a un colega del equipo.

## Storytelling and concision

Cada deck es una historia, no un dump de información. Pyramid principle (Minto): la respuesta primero, evidencia después.

**Estructura narrativa por defecto:**
1. Cover · contexto y audiencia (1 slide)
2. The recommendation · qué pedimos en 1 frase + 3 numeros que la sustentan (1 slide)
3. The problem · qué duele hoy, con evidencia (2-3 slides)
4. The proposal · qué proponemos, scope, lo que NO entra (2-3 slides)
5. The decision · qué necesitamos del comité y de qué owners depende cada paso (1 slide)
6. Cierre · busca aprobación, no anuncia (1 slide)

Si el deck supera 14 slides sin tener una decisión clara por slide, se está dispersando. Cortalo.

**Concision (regla 5/3/1):**
- Máximo 5 viñetas por slide (hard limit, ver Anti-patterns). 3 ideal.
- Máximo 3 líneas por viñeta.
- Máximo 1 idea por viñeta. Si tiene `y` o `,` con cláusula subordinada → partila.

**Tiempos / estimaciones siempre con IA · explícito en el copy:**
- Toda cifra de tiempo (semanas, días, sprints) en un deck **asume desarrollo asistido por IA** (Claude Code + skills MODO). Hacelo explícito con `con IA` en el copy — no es detalle de implementación, es premisa.
- Dónde aparece: heading del plan, chrome-top del plan, total caption del timeline, cards de costo dev en la vista Manager, eyebrow del plan ("estimación con IA").
- Ejemplos correctos: `~4 semanas con IA`, `1-2 días con IA + 1 dev`, `Cuatro semanas con IA · 1 FE + design pairing`, eyebrow `estimación con IA`.
- Si comparás contra baseline manual, marcá ambas: `~3 sem con IA vs ~6-8 sem manual`.
- No reemplazar por "con Claude" o "con Claude Code" — `con IA` es lo genérico y a prueba de cambios de tooling.
- **Why:** sin la aclaración el lector mide la cifra contra su mental model de capacity manual y o la sub-estima como ambiciosa o la sobre-estima como inflada. Las dos lecturas son malas para la propuesta.

**Anti-verbosidad checklist:**
- [ ] ¿Cada slide tiene un titular accionable, no descriptivo? ("Subimos Next a 15" beats "Análisis de Next.js")
- [ ] ¿Cada número va con su unidad y su contexto? ("~3 semanas con IA" beats "3 semanas")
- [ ] ¿Las cards son comparables horizontalmente? Si dos cards al lado tienen estructura distinta, alguien lo va a leer mal.
- [ ] ¿Hay una sola CTA por slide? Si hay dos CTAs, una debe ser primaria.
- [ ] ¿El cierre nombra owners por decisión, no responsables genéricos?

## Comms discipline (CRÍTICO · cuidar la conversación)

Los decks **buscan aprobación, no anuncian implementación**. Atropellar a otros equipos rompe trust y bloquea futuras aprobaciones.

**Prohibido en cierre / slide final:**
- "Aprobado el cambio, lo implemento esta semana"
- "Arrancamos el lunes"
- "Creo los tickets esta semana"
- Cualquier frase que asuma aprobación que la audiencia todavía no dio.

**Esperado en cierre / slide final:**
- "Antes de avanzar, necesito feedback de [X equipos]"
- "Aguardo su feedback para agendar review con [owners], no abrir tickets"
- "Este deck propone, no decide"
- Lista explícita de **quiénes deberían opinar antes**: brand, marketing, legal, compliance, mobile (release freezes), QA, design system owners, SRE/Helm owners, analytics, content, SEO — según corresponda al tema.

**Palabra prohibida · "apetito":**
- No usar `apetito` ni `si hay apetito` en ningún slide, eyebrow, heading, card, body, PR description o commit message. Es jerga importada del inglés ("appetite for X") y para audiencia argentina suena casual / borderline marketing.
- Reemplazos canónicos:
  - `Si hay apetito, agendamos review` → `Aguardo su feedback para agendar la review`
  - `Si hay apetito, abro tickets` → `Aguardo el feedback de este comité para abrir los tickets`
  - `Si hay apetito en este comité, X` → `Con su feedback, X` / `Aguardo el feedback del comité para X`
  - `Fase 2 · si hay apetito` → `Fase 2 · sujeta a feedback`
  - `Siguiente paso si hay apetito` → `Siguiente paso · aguardo su feedback`
- Before closing any deck PR: `grep apetito` → cero ocurrencias.

**En las decisiones (slide de "decisiones que necesitamos"):**
- Owner por decisión: indicar PM / TL / Manager / Brand / Legal — no presumir que el TL decide solo.
- Diferenciar "decisión que se pide en esta reunión" vs "trabajo de validación que sigue después".

**No overclaim · features que no están live en producción:**
- **Regla:** features en QA, POC, draft, RFC, behind-flag o WIP **nunca** van como justificación load-bearing del argumento. Si se mencionan, va **solo en footnote** con disclaimer explícito del estado (ej. "en QA, todavía no live", "POC interna", "draft RFC sin merge").
- **Test rápido:** si removés la mención de la feature no-shipped y el argumento se cae, era load-bearing → buscá otra justificación (workflow activo, métrica live, tooling probado en producción).
- **Sí se puede citar** el harness/proceso/tooling aunque no haya feature shipped — porque está activo en cada PR del repo. **No se puede** citar los outputs específicos que todavía no llegaron a prod.
- **Ejemplo concreto** (2026-05-20): `/comercios` está en QA, no live en modo.com.ar. No se cita como "el harness que ya validó /comercios" en un deck de propuesta. Como mucho: "ejemplo de aplicación del workflow, en QA" en una nota al pie.

**Tono general:**
- Reconocer trabajo de otros equipos cuando se cruza con el propio (ej. "promoshub team owns X, queremos coordinar con ellos").
- Usar "propongo" / "necesito alinear" / "busco feedback" en vez de "vamos a" / "voy a hacer".
- Cuando algo lo decidiste vos solo, decilo: "el TL ya validó X" o "ya hablé con Y, ok de su lado".

Si dudás del tono en algún slide, leelo en voz alta como si fueras el PM / Manager. Si suena a "ya lo decidí, vengo a contarte", reescribilo.

## Reference example

`examples/nextjs-migration.html` es el deck canon de 14 slides que generó esta skill. Úsalo como referencia visual cuando dudes del tono o spacing.

En el repo en producción, **`decks/completo/nextjs-12-to-16-consolidation.html`** es el canon vivo (más nuevo, máximo feature-set). Comparar contra él cuando dudes si una feature debería estar. **`comercios-mvp.html` es viejo** y no tiene el botón `#toggle-comments` en el nav — no usar como referencia para feature parity.

## Feature parity contract (chequear antes de pushear)

Cada deck nuevo DEBE incluir las siguientes features. Si una falta, queda atrás del canon. Verificable con `grep`:

| Feature | Pattern para verificar | Notas |
|---|---|---|
| `deck-crumb` breadcrumb top-left | `class="deck-crumb"` (1) | Vuelve al index del repo |
| Theme toggle (auto/claro/oscuro) | `deck-theme.css` (1) + `deck-theme.js` (1) | Bootstrap antes del primer paint anti-flash |
| Preferencias de lectura (dropdown header) | `deck-bionic.css` (1) + `deck-bionic.js` (1) | Auto-monta `<details class="deck-controls">` agrupando theme-toggle + Bio. Open/close 100% HTML+CSS |
| Bootstrap del tema (anti-flash) | `localStorage.getItem("modo-decks-theme")` (1) | Inline `<script>` antes del CSS |
| Botón `#toggle-comments` en nav | `id="toggle-comments"` (1) | EN `.deck__nav`, no solo tecla `C`. |
| Drawer de reacciones (Giscus) | `id="deck-reactions"` (1) | `data-term="{{slug}}"` reemplazado por slug real |
| Logo solid (default) | `id="modo-logo-solid"` (1) | Siempre. `modo-logo-multi` es opcional, solo product/SDK contexts |
| Hash URL sync | `history.replaceState` (1) | Permite `#3` salta al slide 3 |
| Print rules (3) | `@media print` (3) | Una para `.slide`, una para `.deck-crumb`, una para `.deck-reactions` |
| Keyboard shortcuts | tecla handler en `addEventListener('keydown')` | `←→jk Space PageUp/Down Home End P` (nav) + `C Esc` (drawer) |
| Counter sincronizado | `.slide__chrome-bottom .counter` querySelector en JS | El JS actualiza el counter del slide activo |
| Cero placeholders sin resolver | `grep -E '\{\{[A-Z_]+\}\}'` → cero matches | Incluye `{{DECK_SLUG}}`, `{{P}}`, `{{N}}`, `{{TOTAL}}` |

Comando rápido para auditar un deck nuevo contra el canon:

```bash
FILE="decks/draft/<slug>.html"
for p in 'class="deck-crumb"' 'deck-theme.css' 'deck-bionic.css' 'deck-theme.js' 'deck-bionic.js' 'id="toggle-comments"' 'id="deck-reactions"' 'id="modo-logo-solid"' 'localStorage.getItem("modo-decks-theme")' 'history.replaceState'; do
  echo "$(grep -c "$p" "$FILE") x  $p"
done
# Todos deben dar 1. Sumar: 3 x @media print
```

## Self-review (correr antes de cerrar el deck)

Antes de declarar el deck listo, leelo de punta a punta como si fueras el manager más escéptico de la sala. Para cada slide pregúntate:

1. **¿Pasa el test de los 5 segundos?** Un decisor que abre el deck y mira solo el titular de cada slide, ¿se queda con la historia completa?
2. **¿Hay slide que sobre?** Si la eliminás, ¿la historia sigue de pie? Si sí, sacala.
3. **¿Hay slide que falte?** ¿Qué pregunta evidente queda sin responder?
4. **¿El cierre busca aprobación o anuncia ejecución?** Si dice "voy a hacer X esta semana" → mal. Reescribir.
5. **¿Mencioné los equipos que se cruzan?** Brand, Legal, Mobile, QA, SRE, PM. Si el cambio toca a alguno y no aparece, agregarlo.
6. **¿Cada número está respaldado por una fuente que puedo nombrar si me lo preguntan?** Si no, sacarlo o reemplazarlo por una observación cualitativa.
7. **¿Nombré bancos puntuales donde corresponde?** Solo cuando son el sujeto directo del slide (promo exclusiva, integración específica). No listar por inercia.

## Cross-link entre decks de un mismo programa

Cuando un deck pertenece a un **programa con varios decks** (ej. consolidación stack: nextjs-12-to-16, storyblok-cms-build-time, cicd-dx-maduracion, etc.), agregá al pie de la slide de harness o decisiones un pill-strip `.related-decks` con anchors `chip--green` a los decks hermanos. Mantiene navegación entre piezas del programa sin tener que volver al index.

```html
<div class="related-decks">
  <span class="related-decks__label">Decks relacionados</span>
  <a href="<slug-hermano>.html" class="chip chip--green">Título del hermano</a>
  <a href="<otro-slug>.html" class="chip chip--green">Otro deck del programa</a>
</div>
```

CSS ya está en el template (verde-10 background, padding 10/18, radius 12). El strip cae natural debajo del último bloque de contenido del slide.

**No usar** este strip en decks one-off sin hermanos — sería ruido. Si el programa nace con un solo deck, dejar el hueco para sumar el strip cuando crezca.

## Status + version en chrome-bottom (deck shipped a entorno)

El `<span>` izquierdo del `.slide__chrome-bottom` (donde va `{{FOOTER_TAG}}`) admite **status + ambiente + version** para decks de features que ya cruzaron la línea de QA / staging / prod. Ejemplo de ambos decks completos:

- `shipped a QA · alpha a2.414.1` (comercios-mvp)
- `Stack consolidation · modo-landing` (nextjs-12-to-16-consolidation)

**Regla:** ese span se mantiene **constante en todo el deck** (mismo texto en cada slide, copiado tal cual). Si el ambiente cambia mid-deck, partir en dos decks. Sirve de "watermark" inferior para que cualquier slide screenshoteada y compartida fuera de contexto siga llevando el estado.

## Mención de features no-shipped (footnote pattern)

Si un slide menciona una feature que **no está en producción todavía** (QA, POC interno, draft RFC, behind-flag), va en footnote chiquita al pie, con clase `.footnote--disclaim`:

```html
<p class="footnote--disclaim">
  <a href="<link>"><span class="mono">/comercios</span></a>
  <em>(en QA, todavía no live en modo.com.ar)</em>
</p>
```

CSS ya en template: `font-size: 12px; color: var(--gray-60);`. La cursiva del disclaimer va con `<em>` para que la lectura biónica no la bold-ee de más.

**Regla operativa:** antes de cerrar un deck, `grep -E "QA|POC|draft|RFC" <deck.html>` y verificar que toda mención no-shipped está en `.footnote--disclaim`, no en body principal. Cita en body solo lo que está live.

## Convenciones de inline emphasis (queries vs identificadores técnicos)

- **`<em class="query">"…"`** — queries de usuario / términos de búsqueda. Va con comillas + cursiva. Ej: `<em class="query">"comercios con descuento MODO"</em>`. Usar en decks de SEO, GEO, growth, content.
- **`<span class="mono">…</span>`** — identificadores técnicos (paths, file names, package names, versiones, env vars, slugs). Ej: `<span class="mono">/comercios</span>`, `<span class="mono">Next 12.3.5</span>`.

Nunca mezclar: un nombre de feature funcional va con `<strong>` o sin envolver, no con `.mono`. Un endpoint o ruta va con `.mono`, no con cursiva.

## Output checklist before saving

- [ ] `<title>` setteado al tema del deck.
- [ ] Primer `<section class="slide ...">` tiene `active` en la className.
- [ ] Cada slide tiene `data-slide` (lo necesita el JS para contar).
- [ ] Cada slide (excepto cover/cierre) tiene `slide__chrome-bottom` con `counter` `{{N}} / {{TOTAL}}` y `progress` con `--p` calculado.
- [ ] Eyebrows en green default, headings en ink, body en gray-80, muted en gray-60.
- [ ] Logo: usar `<span class="modo-wordmark">MODO</span>` (cover/cierre, 36px) y `<span class="modo-wordmark modo-wordmark--sm">MODO</span>` (chrome-top, 22px). El SVG solid traza mal cuando se monocroma; el wordmark CSS con Quicksand es la opción confiable.
- [ ] Cero em dashes (`—`) en el HTML.
- [ ] Cero gradientes en texto.
- [ ] Cada `.num` lleva `tabular-nums` (ya viene en la clase).
- [ ] Total de slides ≥ 8 y ≤ 20.
- [ ] `assets/deck-theme.css` + `assets/deck-theme.js` wireados (toggle de tema auto/claro/oscuro).
- [ ] `assets/deck-bionic.css` + `assets/deck-bionic.js` wireados (preferencias de lectura en dropdown header).
- [ ] Cero placeholders sin resolver (`{{DECK_SLUG}}`, `{{N}}`, `{{TOTAL}}`, etc.). `publish-deck.sh` rechaza el upload si los detecta.
- [ ] Si es propuesta técnica con multi-fase → sumá slide harness (mini-grid 3×2) antes de decisiones.
- [ ] Si es sprint review / demo POC → usá screenshot-tour en lugar de pillar-detail.
- [ ] Eyebrows o totales con cifra de tiempo llevan `· con IA` o `· estimación asistida por IA`. Sin la marca, el lector mide la cifra contra capacity manual y la mal-interpreta.
- [ ] Si el deck pertenece a un programa con decks hermanos, sumá strip `.related-decks` al pie de harness o decisiones.
- [ ] El `<span>` izquierdo de `slide__chrome-bottom` es consistente en TODOS los slides del deck (status + version constante).
- [ ] Toda mención de feature en QA / POC / draft / RFC está en `.footnote--disclaim` con `(en QA, todavía no live)` o equivalente. `grep -E "QA|POC|draft|RFC"` para verificar.
- [ ] Queries de usuario en `<em class="query">"…"</em>`, paths/versiones en `<span class="mono">…</span>`. No mezclar.
- [ ] **Navegación**: features nuevos de chrome (toggles, controles, preferencias) se agregan a `.deck-controls__panel`, NO como botones flotantes nuevos. Usá `<details>`+`<summary>` para cualquier open/close si surge una variante.

## Renumbering cuando insertás slide mid-deck (proceso mecánico)

Si después de generar un deck N-slide agregás un slide en posición K, hay que renumerar las K+1 ... N. La JS auto-actualiza el contador del slide activo, pero los counters hardcodeados de slides NO visitados quedan stale hasta que el usuario navegue. Resultado: deck mostrando "08 / 15" en una slide y "09 / 16" en la siguiente.

**Proceso (4 pasos con sed)**:

```bash
FILE=/tmp/<slug>.html

# 1. Bump total (e.g. 15 → 16)
sed -i '' 's|/ 15</span>|/ 16</span>|g' "$FILE"

# 2. Renumerar contadores afectados (un sed por slide · cada --p original es único)
sed -i '' 's|--p: 60%"></i></div><span class="counter">09 / 16|--p: 63%"></i></div><span class="counter">10 / 16|' "$FILE"
# ... repetir para cada slide posterior

# 3. Bump labels chrome-top de slides afectadas
sed -i '' 's|<span>10 · Scope</span>|<span>11 · Scope</span>|' "$FILE"
# ... etc

# 4. Verificar: grep 'class="counter">' file → debe haber N-1 counters secuenciales 02 ... N
```

**Tabla de progresos** (calculado `round(100 * N / TOTAL)`):

| Total | --p % por slide 2 a Total-1 |
|---|---|
| 14 | 14, 21, 29, 36, 43, 50, 57, 64, 71, 79, 86, 93 |
| 15 | 13, 20, 27, 33, 40, 47, 53, 60, 67, 73, 80, 87, 93 |
| 16 | 13, 19, 25, 31, 38, 44, 50, 56, 63, 69, 75, 81, 88, 94 |
| 17 | 12, 18, 24, 29, 35, 41, 47, 53, 59, 65, 71, 76, 82, 88, 94 |

Slide 01 (cover) y último (cierre) no llevan progress bar.

## Demo interactivo (botones que activan la feature en vivo)

Patrón para slides post-pilares: 4-5 botones que togglean estado real en un sample inline, sin librerías. La audiencia puede tocar durante la presentación y entender el feel del feature.

**Cuándo usarlo**: después del último pilar, antes del plan. No usar para TL;DR, scope, decisiones, vistas.

**Esquema base** (receta full en `slide-recipes.md` "Demo interactivo"):
1. Layout `grid-2`: sample a la izquierda (con indicador "movimiento ambiente"), botones a la derecha.
2. Estado: objeto `state = { f1: false, f2: false, ... }` mantenido por JS al final del `<body>`.
3. Buttons con `data-feature="<key>"` + `aria-pressed="false"` (a11y nativa).
4. Click handler: toggle `aria-pressed`, llamar handler de la feature, actualizar status line.
5. CSS: `.demo-btn[aria-pressed="true"]` cambia bg a `--green-10` y muestra el switch como "on".
6. Side-effects entre features (ej. acelerómetro ON → auto-trigger reduced motion) muestran cadenas cause-effect.

**Anti-patrón**: NO meter la lógica del demo en el script principal del deck (el de navegación). Ponela en su propio bloque `<script>` separado para que un futuro renumber/edit no la rompa.

## Mockup patterns (navbar, dropdown, UI previews)

Para slides que muestran UX nueva, **mockuppear con CSS** en vez de usar screenshots. Razones: tipografía + tokens MODO consistentes, escala bien con dark mode, se imprime limpio, mantenible. Receta full en `slide-recipes.md` "Mockup UI".

**Regla heredada del módulo `.deck-controls`**: si proponés un nuevo toggle/feature de chrome para el deck (font-size, idioma, contraste, etc.), mockuppear que vive dentro de `.deck-controls__panel` existente, NUNCA como botón flotante nuevo ni navbar paralelo. Dos chips chiquitos al lado del título rompen el grid del header en mobile.

## Clonar look-and-feel de un PPTX / Google Slides externo

Cuando el user pide "que tenga el mismo estilo visual que [URL Google Slides]" o pasa un PPTX de marca para matchear, NO ir a ojo. Extraer paleta + fonts + slide rhythm del archivo real.

Receta full en `reference/clone-external-deck.md`. Resumen:

1. Bajar el `.pptx` (Google Drive MCP `get_file_metadata` + `download_file_content`, o `~/Downloads/` si ya lo tenía abierto).
2. `unzip` el pptx en `/tmp/pptx-extract/` — un PPTX es un ZIP de XML.
3. Grep `<a:srgbClr val="HHHHHH"/>` por slide en `ppt/slides/slide*.xml` (NO confiar en `theme1.xml` — suele ser Office default en exports de Google Slides).
4. Grep `typeface=` para fonts.
5. Listar bg color por slide → ese es el slide rhythm (dark/light/dark/...).
6. Mapear a tokens semánticos en `:root` y override por variant de slide.
7. Screenshot con chrome-devtools y comparar contra el PPTX en Keynote.

**Anti-pattern crítico**: confiar en `theme1.xml`. En PPTX exportados desde Google Slides ese theme es Office default y NO refleja los colores reales. Los colores reales viven en cada slide.

**Trap path screenshot**: el chrome-devtools MCP bloquea `/tmp/` por sandbox. Usar `$TMPDIR` (`/var/folders/.../T/`) o un workspace root válido.

Si el PPTX usa una paleta que NO es la light histórica MODO (cream + forest dark + gold + orange en vez de white + green), seguramente es el **warm theme 2026** — ver `reference/brand-tokens.md` sección "Warm theme".

## Continuidad entre slides (warm theme · pitch decks)

**Patrón opt-in**, NUNCA auto-aplicar. El user lo pide explícito (palabras como "continuidad", "fade es mucho", "que se mueva el fondo") o nombra la receta. Si no lo pidió, no proponerlo.

Receta: `reference/slide-recipes.md` `## Parallax background continuity (warm theme · 2026)`. HTML + CSS + JS + choreography rules ahí. Resumen:
- 5 shapes en capa `.parallax` (gold disc + orange dot + mint blob + forest-deep blob + gold dust).
- Cada slide define posición/scale/opacity nuevas por shape via `body[data-slide="N"] .shape-X { transform: ... }`. Transition `1100ms` en transforms → GLIDE entre slides.
- Body bg fade `700ms` entre forest/cream/green según slide variant.
- Slide content cross-fade `380ms`. Cascade interna mínima (3 hijos, 10px).
- Reemplaza spot mark + sheen + view-transitions + horizontal slide-panel cuando se usa (no apilarlos).

## Mejorar deck existente (clone & upgrade)

Cuando el user pide "crea la versión mejorada de X.html" sobre un deck propio MODO viejo (cyan/green Quicksand) → upgrade al warm theme 2026 preservando contenido íntegro. Receta full en `reference/slide-recipes.md` `## Mejorar deck existente`. Resumen:

1. Leer original completo. Preservar todos los slides + stats + tablas + listas. NO recortar contenido.
2. Single-file output (drop dependencies externas tipo `../../modo-decks/assets/deck-theme.css`).
3. Naming `<original>-mejorada.html` en misma carpeta. NO sobrescribir original.
4. Aplicar warm theme tokens (`reference/brand-tokens.md` `## Warm theme`).
5. Slide rhythm alternancia hero/cream/dark/green. Si el original era 100% cream, dar ritmo.
6. Bg images opt-in en hero + cierre. Reutilizar assets locales del proyecto. No inventar.
7. Decorative spot mark + wordmark flip + hash deep-link compat (#1 + #slide-1).
8. NO agregar parallax continuity ni features no pedidas.

## Bg images en slides (slide-bg recipe)

Cuando el user pide "poné imágenes de fondo" / "background images" en slides puntuales (típicamente hero + cierre), usar `.slide-bg` element con variantes `.right-half` o `.full-darken`. Receta full en `reference/slide-recipes.md` `## Slide-bg image layer`. Trap crítico:

- `.slide > * { position: relative; z-index: 2; }` PISA `position: absolute; inset: 0;` del `.slide-bg` → colapsa a height: 0 → bg invisible.
- Fix: selector `:not(.slide-bg)`.

Patrones canónicos: PNG en `decks/assets/bg-<nombre>.png`, paths relativos, opacity 0.55 + linear-gradient overlay para legibilidad.

## Video POV synthesis (Playwright + ffmpeg)

Opt-in. Cuando el user dice "creá un video del flujo" / "POV demo" / "video de la experiencia E2E" para slides agénticos / flow demos sin grabación real. Receta full en `reference/slide-recipes.md` `## POV video synthesis`. Resumen:

- HTML self-playing en `decks/video-pov-<slug>.html` con timeline `setTimeout` por acto.
- `scripts/record-pov-video.mjs` con Playwright `recordVideo` (NO Puppeteer — su `page.screencast` headless throttles y corta duración a la mitad).
- ffmpeg conversión a MP4 (h264, yuv420p, crf 20, +faststart) + GIF preview (palette).
- Gate `window.__NO_LOOP__ = true` via `addInitScript` para evitar que el reload-loop del HTML corte la grabación.

Output canónico: `entregable/videos/<slug>.{mp4,gif,webm}`.
