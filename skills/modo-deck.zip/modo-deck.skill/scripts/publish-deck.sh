#!/usr/bin/env bash
# publish-deck.sh — sube un deck al repo erno-modo con estado declarado.
# Uso:
#   ./publish-deck.sh <preview-path> <slug> <estado> [<title>] [<description>] [<audiencia>] [<n-slides>]
#
# Ej:
#   ./publish-deck.sh /tmp/foo.html mi-deck draft "Mi deck" "lo que propongo" "PM + TL" 12

set -euo pipefail

PREVIEW="${1:?preview path required}"
SLUG="${2:?slug required}"
STATE="${3:?state required (draft|rfc|completo)}"
TITLE="${4:-$SLUG}"
DESC="${5:-(sin descripción)}"
AUDIENCE="${6:-Equipo MODO}"
NSLIDES="${7:-?}"

case "$STATE" in
  draft|rfc|completo) ;;
  *) echo "✗ Estado inválido: $STATE (usar draft|rfc|completo)"; exit 1 ;;
esac

[ -f "$PREVIEW" ] || { echo "✗ Preview no existe: $PREVIEW"; exit 1; }

# Salvaguarda: el deck no puede llegar a Pages con placeholders {{X}} sin resolver
# (especialmente {{DECK_SLUG}}, que comparte el thread de Giscus si no se reemplaza).
if grep -qE '\{\{[A-Z_]+\}\}' "$PREVIEW"; then
  echo "✗ Preview tiene placeholders sin resolver (ej: {{DECK_SLUG}}, {{TITLE}}, ...). Re-generá el deck con valores reales antes de publicar."
  grep -nE '\{\{[A-Z_]+\}\}' "$PREVIEW" | head -5
  exit 1
fi

# Salvaguarda: el deck DEBE referenciar los assets con ../../assets/ (resuelve a
# erno-modo/assets/* cuando el deck vive en decks/<estado>/<slug>.html).
# Si se hizo preview standalone con assets-modo-deck/ o ./, hay que revertirlo.
for asset in deck-theme.css deck-theme.js deck-bionic.css deck-bionic.js; do
  if ! grep -qE "\.\./\.\./assets/$asset" "$PREVIEW"; then
    echo "✗ Preview no referencia ../../assets/$asset (probablemente quedó modificado por un preview standalone)."
    echo "  Reemplazá los paths antes de publicar: sed -i '' 's|assets-modo-deck/|../../assets/|g; s|./deck-|../../assets/deck-|g' $PREVIEW"
    exit 1
  fi
done

# Aviso (no bloquea): si los assets vendoreados en el skill divergen del repo,
# el preview standalone que vio el autor NO espeja lo que va a renderizar Pages.
# Hay un sync-assets.sh para resolverlo.
SYNC_SCRIPT="$(dirname "$0")/sync-assets.sh"
if [ -x "$SYNC_SCRIPT" ]; then
  if ! "$SYNC_SCRIPT" check >/dev/null 2>&1; then
    echo "⚠ Aviso: assets del skill ≠ assets del repo. El preview standalone que viste puede no espejar lo que va a renderizar Pages."
    echo "  Para resolver:  $SYNC_SCRIPT diff   (luego pull o push según corresponda)"
    echo "  Continuo con el publish — los assets del repo son los que mandan en producción."
  fi
fi

REPO="$HOME/Documents/Proyectos/modo/erno-modo"
[ -d "$REPO/.git" ] || { echo "✗ Repo erno-modo no encontrado en $REPO"; exit 1; }

DEST_REL="decks/$STATE/$SLUG.html"
DEST_ABS="$REPO/$DEST_REL"
mkdir -p "$(dirname "$DEST_ABS")"
cp "$PREVIEW" "$DEST_ABS"

cd "$REPO"
git add "$DEST_REL"

# Sugerir update a index.html (el agente lo hace por separado para no romper structure)
echo ""
echo "✓ Deck copiado a $DEST_ABS"
echo ""
echo "Próximos pasos (manual):"
echo "  1. Editar $REPO/index.html — agregar entry con badge '$STATE'"
echo "  2. Actualizar contadores de tabs"
echo "  3. git add index.html"
echo "  4. git commit -m \"feat(decks): add $SLUG · $STATE\""
echo "  5. git push origin main"
echo ""
echo "Public URL (después de push, ~30s wait GH Pages):"
echo "  https://soyernomodo.github.io/erno-modo/$DEST_REL"
