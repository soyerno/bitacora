#!/usr/bin/env python3
"""
add-giscus.py — inyecta el drawer de Giscus en un deck ya publicado.

Idempotente: si ya tiene Giscus, no hace nada.
El slug del deck se infiere del nombre de archivo (basename sin .html).

Uso:
    add-giscus.py <path/al/deck.html> [<path2.html> ...]
    add-giscus.py --dry-run <path>
"""
import sys
from pathlib import Path

CSS_BLOCK = """  .deck-reactions {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    width: min(480px, 92vw);
    background: var(--paper);
    box-shadow: -8px 0 32px rgba(18,18,18,0.18);
    z-index: 200;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 220ms var(--ease);
  }
  .deck-reactions.is-open { transform: translateX(0); }
  .deck-reactions__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 20px;
    border-bottom: 1px solid var(--gray-3);
    font-family: "Quicksand", sans-serif;
    font-size: 14px;
    color: var(--ink);
  }
  .deck-reactions__head button {
    background: transparent;
    border: none;
    width: 32px;
    height: 32px;
    border-radius: 999px;
    cursor: pointer;
    color: var(--gray-60);
    font-size: 20px;
    line-height: 1;
  }
  .deck-reactions__head button:hover { background: var(--gray-3); color: var(--ink); }
  .deck-reactions__body { flex: 1; overflow-y: auto; padding: 16px 20px; }
  @media print { .deck-reactions, #toggle-comments { display: none !important; } }
"""

NAV_BUTTON = '''  <button id="toggle-comments" aria-label="Reacciones y comentarios" title="Reacciones (c)">
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto; display:block;"><path d="M14 9.5a2 2 0 0 1-2 2H6l-3 3v-9.5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v4.5z"/></svg>
  </button>
'''

DRAWER_TEMPLATE = '''<aside id="deck-reactions" class="deck-reactions" aria-label="Reacciones y comentarios" hidden>
  <header class="deck-reactions__head">
    <strong>Reacciones &amp; comentarios</strong>
    <button id="close-comments" aria-label="Cerrar" title="Cerrar (Esc / c)">×</button>
  </header>
  <div id="giscus-mount" class="deck-reactions__body" data-loaded="0" data-term="__SLUG__"></div>
</aside>

<script>
(function () {
  const drawer = document.getElementById('deck-reactions');
  const mount = document.getElementById('giscus-mount');
  const toggle = document.getElementById('toggle-comments');
  const close = document.getElementById('close-comments');
  if (!drawer || !mount || !toggle) return;
  function openDrawer() {
    drawer.hidden = false;
    drawer.classList.add('is-open');
    if (mount.dataset.loaded === '0') {
      const s = document.createElement('script');
      s.src = 'https://giscus.app/client.js';
      s.async = true;
      s.crossOrigin = 'anonymous';
      const attrs = {
        'data-repo': 'SoyErnoModo/erno-modo',
        'data-repo-id': 'R_kgDOSjBmAw',
        'data-category': 'Announcements',
        'data-category-id': 'DIC_kwDOSjBmA84C9erl',
        'data-mapping': 'specific',
        'data-term': mount.dataset.term,
        'data-strict': '1',
        'data-reactions-enabled': '1',
        'data-emit-metadata': '0',
        'data-input-position': 'bottom',
        'data-theme': 'light',
        'data-lang': 'es',
        'data-loading': 'lazy',
      };
      Object.entries(attrs).forEach(([k, v]) => s.setAttribute(k, v));
      mount.appendChild(s);
      mount.dataset.loaded = '1';
    }
  }
  function closeDrawer() {
    drawer.classList.remove('is-open');
    setTimeout(() => { drawer.hidden = true; }, 200);
  }
  toggle.addEventListener('click', () => drawer.classList.contains('is-open') ? closeDrawer() : openDrawer());
  close.addEventListener('click', closeDrawer);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'c' || e.key === 'C') { e.preventDefault(); drawer.classList.contains('is-open') ? closeDrawer() : openDrawer(); }
    else if (e.key === 'Escape' && drawer.classList.contains('is-open')) { closeDrawer(); }
  });
})();
</script>
'''


def patch(html: str, slug: str) -> tuple[str, list[str]]:
    """Devuelve (html_modificado, lista de cambios aplicados)."""
    changes: list[str] = []

    if "giscus.app" in html or "deck-reactions" in html:
        return html, []

    # 1. CSS — antes del último </style>
    last_style_close = html.rfind("</style>")
    if last_style_close == -1:
        raise ValueError("no se encontró </style> — formato de deck inesperado")
    html = html[:last_style_close] + CSS_BLOCK + html[last_style_close:]
    changes.append("CSS drawer")

    # 2. Botón en la nav — antes del </nav> que cierra .deck__nav
    nav_end = html.find("</nav>", html.find('class="deck__nav"'))
    if nav_end == -1:
        raise ValueError("no se encontró <nav class=\"deck__nav\"> — formato inesperado")
    html = html[:nav_end] + NAV_BUTTON + html[nav_end:]
    changes.append("nav button")

    # 3. Drawer + script — antes del </body>
    body_close = html.rfind("</body>")
    if body_close == -1:
        raise ValueError("no se encontró </body>")
    drawer = DRAWER_TEMPLATE.replace("__SLUG__", slug)
    html = html[:body_close] + drawer + "\n" + html[body_close:]
    changes.append("drawer + script")

    return html, changes


def main() -> int:
    args = sys.argv[1:]
    dry = False
    if args and args[0] == "--dry-run":
        dry = True
        args = args[1:]
    if not args:
        print(__doc__, file=sys.stderr)
        return 2

    rc = 0
    for arg in args:
        path = Path(arg).resolve()
        if not path.is_file() or path.suffix != ".html":
            print(f"✗ skip (no es .html): {path}")
            rc = 1
            continue
        slug = path.stem
        original = path.read_text(encoding="utf-8")
        try:
            patched, changes = patch(original, slug)
        except ValueError as e:
            print(f"✗ {path.name}: {e}")
            rc = 1
            continue
        if not changes:
            print(f"· skip (ya tiene Giscus): {path.name}")
            continue
        if dry:
            print(f"would patch {path.name} (slug={slug}): {', '.join(changes)}")
        else:
            path.write_text(patched, encoding="utf-8")
            print(f"✓ {path.name} (slug={slug}): {', '.join(changes)}")
    return rc


if __name__ == "__main__":
    sys.exit(main())
