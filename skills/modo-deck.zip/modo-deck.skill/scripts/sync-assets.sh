#!/usr/bin/env bash
# sync-assets.sh — chequea / sincroniza los assets compartidos del chrome de decks
# entre el repo erno-modo (autoritativo en Pages) y el skill modo-deck (vendoreado).
#
# Los 4 archivos tienen que ser idénticos entre las dos ubicaciones, si no:
#   - El repo manda al deploy de Pages (lo que ve el público).
#   - El skill manda al preview standalone (lo que ves vos editando).
# Drift = preview miente vs producción. Mal.
#
# Uso:
#   sync-assets.sh                  # check mode (default) — reporta drift, exit 1 si hay
#   sync-assets.sh check            # idem
#   sync-assets.sh pull             # repo → skill (escribir local lo que está en producción)
#   sync-assets.sh push             # skill → repo (escribir producción lo que está local)
#   sync-assets.sh diff             # check + muestra diff línea por línea
#
# Convención: si los dos lados difieren y no sabés cuál es el bueno, el script
# muestra mtime + size para que decidas. No hace auto-resolución.

set -euo pipefail

REPO_ASSETS="$HOME/Documents/Proyectos/modo/erno-modo/assets"
SKILL_ASSETS="$HOME/.claude/skills/modo-deck/assets"

ASSETS=(deck-theme.css deck-theme.js deck-bionic.css deck-bionic.js)

MODE="${1:-check}"

if [ ! -d "$REPO_ASSETS" ]; then
  echo "✗ Repo erno-modo no encontrado en $REPO_ASSETS"
  exit 1
fi
if [ ! -d "$SKILL_ASSETS" ]; then
  echo "✗ Skill modo-deck no encontrado en $SKILL_ASSETS"
  exit 1
fi

# ── helpers ────────────────────────────────────────────────────────────────────
human_mtime() {
  if stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S' "$1" 2>/dev/null; then return; fi
  stat -c '%y' "$1" 2>/dev/null | cut -d. -f1
}

human_size() {
  if stat -f '%z' "$1" 2>/dev/null; then return; fi
  stat -c '%s' "$1" 2>/dev/null
}

drift_files=()
missing_repo=()
missing_skill=()

check_one() {
  local file="$1"
  local r="$REPO_ASSETS/$file"
  local s="$SKILL_ASSETS/$file"

  if [ ! -f "$r" ]; then missing_repo+=("$file"); return; fi
  if [ ! -f "$s" ]; then missing_skill+=("$file"); return; fi

  if ! cmp -s "$r" "$s"; then
    drift_files+=("$file")
  fi
}

for f in "${ASSETS[@]}"; do
  check_one "$f"
done

# ── modes ──────────────────────────────────────────────────────────────────────
case "$MODE" in
  check|diff)
    if [ ${#missing_repo[@]} -eq 0 ] && [ ${#missing_skill[@]} -eq 0 ] && [ ${#drift_files[@]} -eq 0 ]; then
      echo "✓ Assets en sync (${#ASSETS[@]} archivos idénticos entre repo y skill)"
      exit 0
    fi

    echo "✗ Drift detectado entre repo y skill:"
    echo ""
    echo "  Repo:  $REPO_ASSETS"
    echo "  Skill: $SKILL_ASSETS"
    echo ""

    if (( ${#missing_repo[@]} )); then
      for f in "${missing_repo[@]}"; do
        echo "  · $f — FALTA en repo (existe solo en skill)"
      done
    fi
    if (( ${#missing_skill[@]} )); then
      for f in "${missing_skill[@]}"; do
        echo "  · $f — FALTA en skill (existe solo en repo)"
      done
    fi
    if (( ${#drift_files[@]} )); then
      for f in "${drift_files[@]}"; do
        r="$REPO_ASSETS/$f"
        s="$SKILL_ASSETS/$f"
        printf "  · %-20s · repo: %s (%sB) · skill: %s (%sB)\n" \
          "$f" "$(human_mtime "$r")" "$(human_size "$r")" \
          "$(human_mtime "$s")" "$(human_size "$s")"
        if [ "$MODE" = "diff" ]; then
          echo "    ── diff $f ──"
          diff -u "$r" "$s" | sed 's/^/    /' | head -40
          echo ""
        fi
      done
    fi

    echo ""
    echo "Para resolver:"
    echo "  sync-assets.sh pull   # traer del repo al skill (skill copia producción)"
    echo "  sync-assets.sh push   # llevar del skill al repo (producción adopta lo local)"
    echo "  sync-assets.sh diff   # ver diff línea por línea antes de decidir"
    exit 1
    ;;

  pull)
    if [ ${#missing_repo[@]} -gt 0 ]; then
      echo "✗ No puedo pull: faltan archivos en repo: ${missing_repo[*]}"
      exit 1
    fi
    for f in "${ASSETS[@]}"; do
      cp "$REPO_ASSETS/$f" "$SKILL_ASSETS/$f"
    done
    echo "✓ pull OK · ${#ASSETS[@]} archivos copiados de repo → skill"
    ;;

  push)
    if [ ${#missing_skill[@]} -gt 0 ]; then
      echo "✗ No puedo push: faltan archivos en skill: ${missing_skill[*]}"
      exit 1
    fi
    for f in "${ASSETS[@]}"; do
      cp "$SKILL_ASSETS/$f" "$REPO_ASSETS/$f"
    done
    echo "✓ push OK · ${#ASSETS[@]} archivos copiados de skill → repo"
    echo ""
    echo "Recordá commitear los assets nuevos en erno-modo para que el deploy de Pages los vea:"
    echo "  cd ~/Documents/Proyectos/modo/erno-modo && git add assets/deck-*.{css,js} && git commit"
    ;;

  -h|--help|help)
    grep '^# ' "$0" | sed 's/^# //'
    exit 0
    ;;

  *)
    echo "✗ Modo inválido: $MODE (usar check | pull | push | diff)"
    exit 1
    ;;
esac
