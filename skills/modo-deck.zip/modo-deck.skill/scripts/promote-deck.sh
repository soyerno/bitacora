#!/usr/bin/env bash
# promote-deck.sh — promueve un deck de un estado a otro (mueve archivo + sugiere update de index).
# Uso:
#   ./promote-deck.sh <slug> <from-state> <to-state>
#
# Ej: ./promote-deck.sh modo-design-system-skill draft rfc

set -euo pipefail

SLUG="${1:?slug required}"
FROM="${2:?from state required (draft|rfc|completo)}"
TO="${3:?to state required (draft|rfc|completo)}"

for s in "$FROM" "$TO"; do
  case "$s" in
    draft|rfc|completo) ;;
    *) echo "✗ Estado inválido: $s"; exit 1 ;;
  esac
done

REPO="$HOME/Documents/Proyectos/modo/erno-modo"
SRC="decks/$FROM/$SLUG.html"
DEST="decks/$TO/$SLUG.html"

cd "$REPO"
[ -f "$SRC" ] || { echo "✗ Source no existe: $SRC"; exit 1; }

mkdir -p "decks/$TO"
git mv "$SRC" "$DEST"

echo "✓ Movido: $SRC → $DEST"
echo ""
echo "Próximos pasos:"
echo "  1. Editar index.html: cambiar badge de '$SLUG' de '$FROM' a '$TO' + href a 'decks/$TO/$SLUG.html'"
echo "  2. Actualizar contadores de tabs"
echo "  3. git add index.html"
echo "  4. git commit -m \"chore(decks): promote $SLUG $FROM → $TO\""
echo "  5. git push origin main"
