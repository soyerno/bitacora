#!/usr/bin/env bash
# resolve-owner.sh — Fase 1 del gate: busca el dueño de un repo/superficie en el mapa local.
# Uso:
#   resolve-owner.sh <repo-o-superficie>   → busca (substring, case-insensitive)
#   resolve-owner.sh                        → lista todo el mapa
# Salida: filas matcheadas. status=confirmar se trata como UNKNOWN (resolver vía Confluence o preguntar).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAP="${SCRIPT_DIR}/../reference/ownership-map.md"

if [[ ! -f "${MAP}" ]]; then
  echo "ERROR: no encuentro el mapa en ${MAP}" >&2
  exit 1
fi

QUERY="${1:-}"

# Extrae filas de datos de las tablas markdown: empiezan con "| ", tienen >=8 campos,
# y no son el header (col1 == "repo-o-superficie") ni el separador (col1 ~ "---").
parse_rows() {
  awk -F'|' '
    /^\| / {
      # limpiar espacios de col 2 (primer campo real tras el "|" inicial)
      key=$2; gsub(/^[ \t]+|[ \t]+$/, "", key)
      if (key == "" || key == "repo-o-superficie" || key ~ /^-+$/) next
      print
    }
  ' "${MAP}"
}

print_row() {
  # recibe una fila pipe-delimited y la imprime legible
  awk -F'|' '{
    for (i=2;i<=9;i++){ gsub(/^[ \t]+|[ \t]+$/, "", $i) }
    printf "  superficie : %s\n", $2
    printf "  squad      : %s\n", $3
    printf "  tribu      : %s\n", $4
    printf "  chapter    : %s\n", $5
    printf "  slack      : %s\n", $6
    printf "  contactos  : %s\n", $7
    printf "  status     : %s\n", $8
    printf "  nota       : %s\n", $9
    if ($8 == "confirmar") {
      printf "  >> UNKNOWN: hipótesis sin verificar. Resolver vía Confluence (espacios TechMODO/PEOP) o preguntar al user antes de comunicar.\n"
    }
    print ""
  }'
}

if [[ -z "${QUERY}" ]]; then
  echo "=== Mapa de ownership completo ==="
  echo ""
  parse_rows | while IFS= read -r row; do print_row <<<"${row}"; done
  exit 0
fi

echo "=== Búsqueda: '${QUERY}' ==="
echo ""
MATCHES="$(parse_rows | grep -i -- "${QUERY}" || true)"

if [[ -z "${MATCHES}" ]]; then
  echo "  Sin match en el mapa local para '${QUERY}'."
  echo "  >> UNKNOWN. Fase 1 continúa: CODEOWNERS → Confluence (mcp__claude_ai_Atlassian__search) → planilla contactos → preguntar al user."
  echo "  >> NO inventar dueño. Al confirmarse, persistir en reference/ownership-map.md con status=confirmado."
  exit 0
fi

while IFS= read -r row; do print_row <<<"${row}"; done <<<"${MATCHES}"
