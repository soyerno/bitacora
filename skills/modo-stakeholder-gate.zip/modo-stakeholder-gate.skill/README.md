# modo-stakeholder-gate

Gate de proceso MODO: no avanzar en pasos críticos sin comunicar + validar con el squad/tribu/chapter dueño del feature.

## Problema que resuelve

En MODO el ownership es de las personas que mantienen el feature. Levantar una iniciativa y tocar código/tracking/infra de otro squad sin avisar genera fricción. Este skill codifica el "parar → identificar dueño → comunicar → validar" antes de tocar, en modo **pregunta-y-espera** (no bloquea por la fuerza; asiste la disciplina).

## Cómo se usa

Auto-invocable al detectar un paso crítico (tracking, código de otro squad, infra compartida, feature flags, contratos de API). O explícito: `/validar-owner`, `/stakeholder-gate`, "quién es el dueño de", "con quién valido esto".

3 fases:
1. **Identificar** dueño → `scripts/resolve-owner.sh <repo>` (mapa local) → fallback Confluence/planilla/CODEOWNERS → preguntar.
2. **Comunicar** → draft de Slack (voz rioplatense, `reference/slack-message-templates.md`).
3. **Validar** → registrar ack (quién/cuándo/link) antes de avanzar.

## Archivos

```
modo-stakeholder-gate/
├── SKILL.md                              # lógica del gate, triggers, 3 fases
├── README.md                             # este archivo
├── reference/
│   ├── org-structure.md                  # tribu/squad/chapter + rol→contacto + fuentes Confluence
│   ├── ownership-map.md                  # mapa local repo→dueño (learning loop)
│   └── slack-message-templates.md        # plantillas voz rioplatense
└── scripts/
    └── resolve-owner.sh                  # busca dueño en el mapa local
```

## Learning loop

El mapa arranca con ownership `confirmar` (sin verificar). Cada vez que el user confirma un dueño, se persiste en `ownership-map.md` con `status=confirmado` + fecha. El mapa mejora con el uso. Nunca se inventa ownership: `confirmar` = UNKNOWN.

## Relación con otros skills

- `modo-planner` — el gate es la fase de "stakeholder validation" que el planner puede invocar antes de implementar.
- `modo-pr-author` — comparte el glosario rioplatense para los mensajes.
- `amplitude-analytics` — cuando el paso crítico es tracking, el gate valida la taxonomía con Data; el skill de amplitude implementa.

Fuente del pedido: Hernán De Souza, 2026-05-27 — flujo para no tener fricciones con los sectores dueños de cada feature.
