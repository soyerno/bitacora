# Estructura organizacional MODO — referencia

Fuente: Confluence (cloudId `17e75179-15ce-48f2-954d-ec6946aca61c`). Releído 2026-05-27.

## Definiciones canónicas

Fuente: [Organización de Equipos](https://play-sistemico.atlassian.net/wiki/spaces/TechMODO/pages/4246274052) (espacio TechMODO). MODO usa el modelo ágil de Spotify con agregados.

| Unidad | Qué es | Ejemplos MODO |
|--------|--------|---------------|
| **Chapter** | Horizontal de la org funcional. Agrupa especialistas. Responsables de hiring, alocación, performance y desarrollo de las personas. | Ingeniería, Producto, UXUI, Comercial, Data, Seguridad, CS |
| **Squad** | Lidera un producto o parte del funnel. Dueño de uno o varios KPIs. Idealmente 6–12 personas interdisciplinarias. | PTM Presencial, PTM Online, Promociones, Vidrieras de Beneficios, Pagos con QR, Loyalty |
| **Tribu** | Conjunto de squads sobre productos/funnel relacionados. | PTM, Customer Journey, Promercios, Beneficios |
| **Guild** | Personas de distintas tribus/squads/chapters con interés común. | Frontend, Backend, Terraform, DEI |
| **Task Force** | Personas de distintos chapters dando outsourcing a partners. | — |
| **Pack** | Equipo armado para un proyecto puntual punta a punta. | — |

Squads **verticales** = objetivos de negocio. Squads **horizontales** = soporte (ej. Platform, SRE, CloudOps).

Liderazgo (de [MODO Agile](https://play-sistemico.atlassian.net/wiki/spaces/PEOP/pages/5208571940)): todo moder está asignado a un chapter **y** a un squad. El manager pertenece al mismo chapter. Un director de chapter puede estar en la tribu o no.

## Mapeo rol → a-quién-involucrar

Fuente: [Comunicar e Involucrar Chapters](https://play-sistemico.atlassian.net/wiki/spaces/GDI/pages/6032359603) (espacio GDI — el doc es de gestión de incidentes, pero el mapeo de roles aplica para validar cualquier iniciativa cross-squad).

| Chapter | A quién involucrar |
|---------|--------------------|
| **Ingeniería** | persona de guardia del squad impactado + Engineering Manager |
| **Producto** | PM del squad impactado |
| **Integraciones** | responsable definido por el squad |
| **CX** | referente del squad impactado + responsable definido por el chapter |
| **Marketing** | responsable definido por el chapter |
| **Data** | dueño de los data marts del dominio / taxonomía de eventos (Chapter Data) |

## Fuentes para resolver ownership (orden de la Fase 1)

1. **Mapa local** — `../reference/ownership-map.md` (este skill). Lo más rápido si está `confirmado`.
2. **CODEOWNERS** del repo — `gh api repos/playsistemico/<repo>/contents/CODEOWNERS --jq '.content' | base64 -d` o buscar en el checkout.
3. **Confluence en vivo** — `mcp__claude_ai_Atlassian__search` con el nombre del producto/funnel. Espacios útiles: `TechMODO`, `PEOP`, `GDI`, espacios por tribu (`Beneficios`, `MOB`, etc.).
4. **Planilla de contactos por tribu/squad** (incidentes, pero reusable): https://docs.google.com/spreadsheets/d/1WnSDVBGdR1PpB02BFg8ceE166eeER2tEZHvNXutQIjY
5. **BambooHR orgchart**: https://modo.bamboohr.com/employees/orgchart.php
6. **Jira** — los tickets de alta (HD-*) y de tags (`tf-aws-tags`) suelen declarar `Squad / Chapter / Tribu`. Útil para inferir dónde cae alguien.
7. **Preguntar al user** — último recurso, pero preferible a inventar.

## Notas de uso

- El cloudId de play-sistemico es fijo: `17e75179-15ce-48f2-954d-ec6946aca61c`. Reusarlo en todos los calls Atlassian sin gastar un call en `getAccessibleAtlassianResources`.
- La planilla de contactos requiere acceso Google; si el MCP de Google Drive no la lee, pedirle el contacto al user o caer al orgchart.
