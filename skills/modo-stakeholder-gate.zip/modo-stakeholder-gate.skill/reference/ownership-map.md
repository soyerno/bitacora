# Mapa de ownership — repo/superficie → squad/tribu/chapter

Mapa local consultado por `scripts/resolve-owner.sh` en la Fase 1 del gate. **Learning loop**: cada dueño confirmado por el user se persiste acá con status `confirmado` + fecha. Nada se inventa — lo no verificado queda `confirmar`.

Formato de fila (pipe-delimited, greppable):

```
| repo-o-superficie | squad | tribu | chapter | canal-slack | contactos | status | nota |
```

- `status`: `confirmado` (validado por el user/Confluence) · `confirmar` (hipótesis o sin verificar — NO usar como verdad).
- `contactos`: nombres + rol. Vacío si no se sabe.
- `canal-slack`: `#canal` o vacío.

## Repos del workspace

| repo-o-superficie | squad | tribu | chapter | canal-slack | contactos | status | nota |
|---|---|---|---|---|---|---|---|
| modo-landing | ? | ? | Ingeniería | ? | ? | confirmar | landing principal modo.com.ar; Hernán contribuye pero el squad dueño no está verificado |
| promos-hub-site | ? | Promercios? | Ingeniería | ? | ? | confirmar | hub de promos; tribu candidata Promercios/Beneficios, sin verificar |
| aprendeatumodo | ? | ? | ? | ? | Hernán De Souza (Sr AI Eng) | confirmar | superficie mayormente de Hernán (Lovable→prod); ownership formal sin definir |
| modo-landing-sdk-ui-lib | ? | ? | Ingeniería | ? | ? | confirmar | UI lib SDK (atoms) |
| modo-ui-lib-web | ? | ? | Ingeniería | ? | ? | confirmar | design system que consume modo-landing |
| tofu-comercios | ? | ? | ? | ? | Hernán De Souza | confirmar | workspace UCP /comercios |

## Superficies / dominios transversales

| repo-o-superficie | squad | tribu | chapter | canal-slack | contactos | status | nota |
|---|---|---|---|---|---|---|---|
| tracking / amplitude / eventos | Data Platform | ? | Data | #modo-amplitude / #data-chapter | Data Platform Leads (aprobador) | confirmado | confirmado 2026-05-27 (Hernán + Confluence DP1). Proceso: pedir en #modo-amplitude tópico "Amplitude" → Data Platform evalúa y agrega a whitelist. Respetar [Estándar de Eventos en Amplitude](https://play-sistemico.atlassian.net/wiki/spaces/DP1/pages/5981601821). Usar wrapper `@playsistemico/analytics-sdk` (src/providers/amplitude.ts), NO instrumentar a mano |
| /promos (routing istio) | ? | Promercios? | Ingeniería + CloudOps | ? | ? | confirmar | repos canónicos: payment-k8s-services, helm-charts, dso-twin |
| /comercios | ? | ? | ? | ? | ? | confirmar | board Jira COENXT |
| CSP / security headers | Cyber | ? | Seguridad | ? | ? | confirmar | cambios de CSP validan con chapter Seguridad/Cyber |
| infra runtime / helm / k8s | SRE / Platform | ? | CloudOps | ? | ? | confirmar | squads horizontales de soporte |
| @playsistemico/* (paquetes compartidos) | ? | ? | Ingeniería | ? | ? | confirmar | dep bumps afectan a múltiples consumidores; involucrar guild frontend/backend |

## Cómo actualizar (learning loop)

Cuando el user confirma un dueño:
1. Editar la fila correspondiente: completar squad/tribu/chapter/canal/contactos.
2. Cambiar `status` a `confirmado`.
3. Agregar fecha en `nota` (`confirmado 2026-05-27 por Hernán`).
4. Si la superficie no existía, agregar fila nueva.

> Toda fila `confirmar` es una **hipótesis sin verificar**. El gate la trata como UNKNOWN: hay que resolver vía Confluence o preguntar antes de comunicar. Nunca comunicar a un squad asumido.
