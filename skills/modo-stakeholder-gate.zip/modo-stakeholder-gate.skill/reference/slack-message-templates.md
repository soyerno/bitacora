# Plantillas de Slack — comunicar e involucrar al squad dueño

Voz rioplatense (voseo, directo, sin buzzwords). Glosario: `~/.claude/skills/modo-pr-author/reference/rioplatense-glossary.md`. El skill draftea, el user manda. No publicar sin OK explícito.

## Estructura base (Fase 2)

```
Hola <equipo/persona> 👋

Estamos por <QUÉ: 1 línea concreta> en <DÓNDE: repo/superficie>.

Contexto: <POR QUÉ: la iniciativa / objetivo>.

Impacto sobre lo que mantienen: <qué les toca / qué no>.

Antes de avanzar quería pasarlo por ustedes que son los que lo mantienen.
¿Lo ven bien, le cambiarían algo, o hay alguien más que debería estar al tanto?

Gracias 🙌
```

## Variante — agregar tracking (involucra Data)

```
Hola <Data / Analytics> 👋

Queremos instrumentar analytics en <superficie> (eventos: <lista corta>).
La idea es <objetivo: medir X / armar funnel Y>.

Antes de escribir los track() quería validar la taxonomía con ustedes:
- Naming propuesto: <event_name_1>, <event_name_2>
- Propiedades: <prop1, prop2>

¿El naming respeta la convención? ¿Suman o sacan algún evento?
No quiero meter eventos que después rompan los dashboards.

Gracias 🙌
```

## Variante — tocar código/superficie de otro squad

```
Hola <squad> 👋

Necesito <cambio concreto> en <repo/módulo> que ustedes mantienen.
Motivo: <iniciativa>.

Lo que cambia: <resumen del diff / comportamiento>.
Lo que NO toco: <para bajar ansiedad>.

¿Me dan el OK para avanzar o prefieren que lo encaremos distinto?
Si hay un owner puntual del módulo, pásenmelo así lo sumo al PR.

Gracias 🙌
```

## Variante — infra compartida (CSP / helm / CI/CD / istio)

```
Hola <squad dueño + CloudOps/Cyber según aplique> 👋

Voy a tocar <CSP / next.config / workflow / chart> de <repo>.
Motivo: <iniciativa>.

Cambio puntual: <qué header/regla/job>.
Riesgo que veo: <bajo/medio + por qué>.

¿Lo validan antes de que abra el PR? Si quieren lo revisamos juntos.

Gracias 🙌
```

## Registro de la respuesta (Fase 3)

Cuando llega el ack, registrar (en `openspec/changes/<slug>/stakeholder-validation.md` o memoria):

```markdown
## Validación de stakeholders — <feature>

- **Iniciativa**: <qué>
- **Superficie**: <repo/superficie>
- **Dueño identificado**: <squad/tribu/chapter> — fuente: <mapa local / Confluence / user>
- **Comunicado en**: #<canal> — <fecha> — <link al thread>
- **Validó**: <nombre, rol> — <fecha>
- **Veredicto**: aprobado / aprobado-con-cambios (<cuáles>) / pendiente / objetado
- **Notas**: <ajustes pedidos, gente sumada>
```

Si se avanza SIN ack (urgencia):

```markdown
- **Gate salteado**: SÍ — decisión asumida por <quién> el <fecha>. Razón: <urgencia/etc>. Pendiente comunicar a <squad> post-hoc.
```
