---
name: modo-stakeholder-gate
description: 'Gate de proceso MODO que valida comunicación + aprobación con el squad/tribu/chapter dueño de un feature ANTES de avanzar en un paso crítico (agregar tracking, tocar código de otro squad, cambiar infra compartida, feature flags). Modo "pregunta y espera": para, muestra el checklist de 3 fases (Identificar dueño → Comunicar intención por Slack → Validar ack) y espera confirmación antes de tocar código. Auto-invocable cuando se detecta un paso crítico o cuando el user dice (ES/EN) "validar owner", "quién es el dueño de este feature", "con quién valido esto", "tengo que avisarle al squad", "armemos el flujo de validación", "antes de avanzar validemos", "/validar-owner", "/stakeholder-gate", "/gate". Fuentes de ownership: mapa local (reference/ownership-map.md) + Confluence org en vivo (espacios TechMODO/PEOP/GDI) + planilla de contactos + BambooHR orgchart. Salida: registro de validación (quién/cuándo/link al thread) + mapa actualizado (learning loop). Cross-project: aplica a todos los repos MODO.'
---

# modo-stakeholder-gate

Gate de proceso para no avanzar en pasos críticos sin comunicar y validar con el squad/tribu/chapter dueño del feature. En MODO el ownership es de las personas que mantienen el feature — pisarlo sin avisar genera fricción. Este skill codifica el "parar, identificar, comunicar, validar" antes de tocar.

> **Por qué existe** (pedido del user, 2026-05-27): "cuando levanto una iniciativa o pienso en hacer algo tengo que comunicarlo y validarlo con la persona de la tribu/squad/chapter responsable de ese feature porque son las personas que lo mantienen [...] necesito que cuando vamos a avanzar en pasos críticos me ayudes a validar si pasamos por el proceso, comunicamos, validamos, y armemos un flujo que nos permita no tener fricciones con esos sectores".

## Comportamiento: "pregunta y espera" (NO bloqueante por la fuerza)

Al detectar un paso crítico:
1. **Paro** antes de hacer el Edit/Write.
2. Muestro el **checklist de 3 fases** con lo que ya sé resuelto.
3. **Espero la confirmación del user** de que comunicamos + validamos (o que explícitamente decide saltar el gate, lo cual queda registrado).

No es un hook que frene a la fuerza. Es disciplina asistida. El user confirma.

## Cuándo se invoca (triggers de paso crítico)

Auto-invocar cuando el trabajo en curso toca:

| Trigger | Quién se involucra (típico) |
|---------|------------------------------|
| Agregar/modificar **tracking** (Amplitude, Firebase, GTM, eventos, A/B) | Chapter **Data** (taxonomía/naming de eventos) + squad dueño de la superficie |
| Editar código en **repo/superficie de otro squad** | Eng del squad dueño (guardia + Engineering Manager) + PM del squad |
| Tocar **infra compartida** (CSP, `next.config`, CI/CD, helm, istio, sops) | Squad dueño del repo + CloudOps/Platform si es infra runtime |
| **Feature flag / remote config** nuevo | Squad dueño + quien administra Remote Config |
| Cambiar **endpoints/BFF/contratos de API** que consume otro equipo | Squad dueño del BFF/API + consumidores |
| Migración/dep bump que afecta **paquete compartido** (`@playsistemico/*`) | Chapter Ingeniería + guild relevante (frontend/backend) |

Triggers explícitos: `/validar-owner`, `/stakeholder-gate`, `/gate`, "quién es el dueño de", "con quién valido", "tengo que avisarle al squad", "antes de avanzar validemos".

**NO invocar** cuando: trabajo dentro de un repo/feature que el user mantiene y no toca tracking/infra/contratos compartidos; fix one-shot trivial; refactor interno sin impacto cross-squad; ya validaste en el mismo turn.

## Las 3 fases del gate

### Fase 1 — Identificar al dueño

Resolver squad / tribu / chapter + contactos nombrados + canal de Slack. Orden de búsqueda:

1. **Mapa local** — `reference/ownership-map.md`. Si el repo/superficie está mapeado con status `confirmado`, usarlo directo.
2. **CODEOWNERS** del repo (`gh api repos/playsistemico/<repo>/contents/CODEOWNERS` o buscar en el checkout).
3. **Confluence en vivo** (MCP `mcp__claude_ai_Atlassian__search`) — espacios `TechMODO`, `PEOP` (MODO Agile), por nombre del producto/funnel. cloudId `17e75179-15ce-48f2-954d-ec6946aca61c`.
4. **Planilla de contactos** por tribu/squad — ver `reference/org-structure.md`.
5. **BambooHR orgchart** — https://modo.bamboohr.com/employees/orgchart.php
6. **Preguntar al user** — si nada resuelve, NO inventar. Preguntar quién es el dueño. Es info load-bearing: un dueño equivocado = fricción, justo lo que el gate evita.

Mapeo rol→contacto (de [Comunicar e Involucrar Chapters](https://play-sistemico.atlassian.net/wiki/spaces/GDI/pages/6032359603)):
- **Ingeniería**: guardia del squad impactado + Engineering Manager
- **Producto**: PM del squad
- **CX**: referente del squad + responsable del chapter
- **Data**: dueño de la taxonomía de eventos / data marts del dominio

**Learning loop**: cuando el user confirma un dueño no mapeado, persistirlo en `reference/ownership-map.md` con status `confirmado` + fecha. La próxima vez sale directo.

### Fase 2 — Comunicar la intención

Draftear el mensaje de Slack al canal del squad dueño. Voz rioplatense (ver `~/.claude/skills/modo-pr-author/reference/rioplatense-glossary.md`). Plantillas en `reference/slack-message-templates.md`. El mensaje incluye:
- **Qué** querés hacer (1 línea concreta).
- **Dónde** (repo/superficie/feature).
- **Por qué** (la iniciativa / el objetivo).
- **Impacto** sobre lo que ellos mantienen.
- **Pedido explícito**: validación / objeciones / a quién más sumar.

El skill **draftea** el mensaje. El user lo manda (o el skill lo manda vía MCP Slack si el user lo pide explícito). No mandar a un canal sin confirmación del user — publicar es acción outward-facing.

### Fase 3 — Validar el ack

No avanzar hasta confirmar respuesta. Registrar:
- Quién validó (nombre + rol).
- Cuándo.
- Link al thread de Slack.
- Veredicto: aprobado / aprobado-con-cambios / pendiente / objetado.

Guardar el registro en la carpeta del change activo (`openspec/changes/<slug>/stakeholder-validation.md`) si existe, o en memoria del proyecto. Deja trail auditable.

Si el user decide avanzar **sin** el ack (urgencia, etc.), registrarlo explícito como decisión asumida — no esconderlo.

## Flujo operativo (qué hago al dispararse)

```
1. Detecto paso crítico → PARO antes del Edit/Write.
2. scripts/resolve-owner.sh <repo-o-superficie>   → Fase 1 desde mapa local
3. Si UNKNOWN → busco en Confluence + planilla → si sigue UNKNOWN, pregunto al user
4. Drafteo mensaje de Slack (Fase 2) con plantilla
5. Muestro checklist al user y ESPERO:
   [ ] Dueño identificado: <squad/contacto/canal>
   [ ] Mensaje comunicado en #<canal>
   [ ] Validación recibida: <quién/cuándo/link>
6. User confirma → registro Fase 3 + (si nuevo) actualizo ownership-map.md → AHORA sí avanzo
```

## Caso canónico — amplitude en aprendeatumodo

Trigger: "agregar amplitude y analytics a aprende a tu modo" = paso crítico (tracking).
- Fase 1: tracking ⇒ involucrar chapter **Data** (dueños de taxonomía/naming de eventos) + confirmar quién mantiene el Amplitude project de aprendeatumodo. aprendeatumodo es superficie mayormente de Hernán, pero los eventos fluyen a Data → validar taxonomía con Data antes de instrumentar.
- Fase 2: mensaje al canal de Data/Analytics: "queremos instrumentar X eventos en aprendeatumodo, acá la taxonomía propuesta, ¿la validan o ajustan naming?".
- Fase 3: ack de Data sobre el naming → recién ahí se escriben los `track()`.

## Archivos del skill

- `reference/org-structure.md` — definiciones tribu/squad/chapter/guild + mapeo rol→contacto + links Confluence + planilla + orgchart.
- `reference/ownership-map.md` — mapa local repo/superficie → squad/tribu/chapter/canal/contactos/status. Learning loop lo llena.
- `reference/slack-message-templates.md` — plantillas voz rioplatense para las 3 fases.
- `scripts/resolve-owner.sh` — dado un repo/superficie, busca en el mapa local e imprime el dueño o UNKNOWN.

## Reglas

1. **No inventar ownership.** Es load-bearing. UNKNOWN > adivinar. Preguntar al user antes de asumir un dueño.
2. **No mandar a un canal de Slack sin confirmación.** Draftear sí, publicar requiere OK explícito del user.
3. **Registrar siempre** quién validó / cuándo / link. Y si se saltea el gate, registrar la decisión asumida.
4. **Learning loop**: cada dueño confirmado se persiste en `ownership-map.md`. El mapa mejora con el uso.
5. **Gate ≠ pedir permiso para todo.** Solo dispara en pasos críticos cross-squad. Trabajo propio sin impacto compartido no pasa por el gate.
