# Quality Gates por fase

Cada fase tiene que pasar **todos** los gates antes de avanzar. Si falla uno, el plan se marca `BLOCKED` y se reporta al main thread.

## Gate Fase 0 — Triage
- [ ] `triage.md` existe con verdict explícito
- [ ] Si verdict = `EJECUTAR_DIRECTO` → handoff line presente
- [ ] Si verdict = `PLAN`/`PLAN ligero` → riesgos listados

## Gate Fase 1 — Discovery
- [ ] `discovery.md` con Intent + Constraints
- [ ] Memoria ruflo consultada (al menos 1 query namespace=`obsidian-vault`)
- [ ] Si origen = PRD → `modo-tech-architect` corrido
- [ ] Open questions explícitas (no asumir)

## Gate Fase 2 — Context
- [ ] `context.md` lista archivos/APIs tocados
- [ ] Si toca BFF/proxy → `api-usage-analyzer` corrido
- [ ] Si toca página indexable → revisó `docs/seo/`
- [ ] Si tiene impacto medible → Amplitude metric identificada

## Gate Fase 3 — Spec
- [ ] `proposal.md`, `design.md`, `tasks.md` existen
- [ ] Decisiones arquitectónicas → ADR en `docs/adr/`
- [ ] Tasks son TDD-first (test viene antes que impl)
- [ ] Si toca `/comercios/*` → SDD completo (no shortcuts)

## Gate Fase 4 — Plan ejecutable
- [ ] Tabla `task | jira-id | worktree | agent | estimate` completa
- [ ] Estimates marcados "con IA"
- [ ] Worktree map asignado a cada task (regla `feedback_git_worktrees`)
- [ ] Jira issues creados con scope correcto (COENXT/EXA/…)
- [ ] Dependencias entre tasks explícitas

## Gate Fase 5 — Orquestación (sólo si se ejecuta)
- [ ] Swarm inicializado con anti-drift config
- [ ] Cada agent corre con `isolation: "worktree"`
- [ ] Claims asignados (no race conditions)
- [ ] Monitor stream activo

## Gate Fase 6 — Verify
- [ ] `sdd-verify` corrido por cada task
- [ ] `pnpm lint && pnpm build` verde en cada worktree
- [ ] Tests verdes
- [ ] `modo-code-review-checklist` aplicado
- [ ] Si toca React → `react-doctor`
- [ ] Si toca UI → screenshots desktop 1280x800 + mobile 375x812

## Gate Fase 7 — Archive
- [ ] `sdd-archive` ejecutado (specs movidas a `openspec/specs/`)
- [ ] `distill-learnings` corrido si hubo aprendizajes no triviales
- [ ] Memoria ruflo persistida con tag `mpf-plan` + `<change-slug>`
- [ ] Si tocó skills MODO públicos → `erno-modo-sync-all`
