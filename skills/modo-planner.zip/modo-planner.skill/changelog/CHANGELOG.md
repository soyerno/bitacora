# modo-planner changelog

## 2026-05-20 — v0.1 inicial

**Creación del MODO Planning Framework (MPF).**

Estructura armada:
- `SKILL.md` con 7 fases (triage → discovery → context → SDD → plan → swarm → verify → archive)
- `templates/triage.md` y `templates/plan.md` como outputs canónicos
- `checklists/quality-gates.md` con gates obligatorios por fase
- `reference/agent-mapping.md` con la tabla de decisión "qué subagent_type por task"
- `~/.claude/agents/modo-planner.md` (agent delegable `MODO Planner`)
- `~/.claude/plugins/work-pilot/commands/plan.md` (slash command `/plan`)

Reglas duras enforced:
- Worktrees SIEMPRE
- SDD obligatorio en `/comercios/*`
- TDD-first en `tasks.md`
- Estimates "con IA"
- Voz rioplatense
- Sin "apetito"
- Commit scope COENXT (/comercios) o EXA (default)
- Orchestrator-first (triage decide PLAN vs EJECUTAR_DIRECTO)

Memoria persistente:
- ruflo `obsidian-vault` key `modo-planner-framework`
- proyecto memory `reference_modo_planner_framework.md` + entry en `MEMORY.md`

Aprendizajes genéricos extraídos:
- Patrón triple-layer: skill auto-invocable + agent delegable + slash command en plugin existente
- Slash commands en `~/.claude/plugins/<plugin>/commands/` se descubren automáticamente, no requieren entry en `plugin.json`
- Triggers ES/EN duales en `description` del skill maximizan auto-invocación
