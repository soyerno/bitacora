---
name: modo-planner
description: 'MODO Planning Framework (MPF). Orquesta planificación end-to-end para cualquier feature/change en MODO combinando brainstorming → discovery → SDD → Jira → swarm orchestration → verify → archive. Auto-invocable cuando el usuario dice (ES/EN) "planificar X", "armar un plan", "necesito un plan", "organizar este trabajo", "nuevo feature", "crear RFC", "crear PRD", "breakdown a sprints", "cómo encaramos esto", "/modo-planner", "/plan". También auto-invocar cuando el contexto trae un PRD/RFC nuevo o cuando el scope cruza ≥3 archivos o múltiples repos del workspace MODO. Salida canónica: openspec/changes/<change>/ + Jira tasks + worktree map + ruflo swarm config.'
---

# MODO Planning Framework (MPF)

Skill canónico para planificar trabajo en el workspace MODO. **No implementa código** — produce el plan que después ejecutan otros agentes (vía `ruflo-swarm` o `Senior Project Manager`).

## Cuándo invocar este skill

**SÍ** invocar cuando:
- El user dice cualquier trigger del frontmatter
- Aterriza un PRD, RFC o brief nuevo
- El scope cruza ≥3 archivos, ≥2 repos del workspace, o requiere decisión arquitectónica
- Hay riesgo de drift o de mega-agent monolítico (regla `feedback_orchestrator_first`)
- El user va a `/comercios/*` (regla `feedback_comercios_sdd_tdd` → SDD+TDD obligatorio)

**NO** invocar cuando:
- ≤15 min de trabajo o 1 archivo (regla orquestador-first → ejecutar directo)
- Bugfix obvio con scope ya conocido
- Refactor mecánico tipo rename

## Reglas duras (MODO)

1. **Worktrees SIEMPRE** (`feedback_git_worktrees`). Todo agent que escribe se lanza con `isolation: "worktree"`.
2. **Commit convention**: `type(SCOPE-XXX): subject` con scope Jira (EXA, COENXT, etc.).
3. **SDD obligatorio en `/comercios/*`**: `sdd-explore → sdd-propose → sdd-design → sdd-tasks → sdd-apply → sdd-verify → sdd-archive`.
4. **Voz rioplatense en docs externos** (`feedback_rioplatense_voice`).
5. **No overclaim**: nada en QA/POC/draft entra como justificación load-bearing (`feedback_no_overclaim_unshipped`).
6. **Estimates "con IA"** (`feedback_estimates_assume_ai`) — toda cifra de tiempo asume Claude Code + skills MODO.
7. **GPG PATH fix** antes de commits firmados (`feedback_gpg_path_fix`): `export PATH="/opt/homebrew/bin:$PATH"`.
8. **Sin "apetito"** (`feedback_no_apetito`) en copy externo.

## Pipeline (7 fases)

### Fase 0 — Triage (1-2 min)

Decidir si MPF aplica. Output: `triage.md` con verdict + razón.

```markdown
# Triage: <título>
- Scope estimado: <archivos / repos / decisión arquitectónica?>
- Veredicto: [PLAN | EJECUTAR_DIRECTO]
- Razón: <una línea>
- Si EJECUTAR_DIRECTO: terminar acá, devolver al main thread.
```

### Fase 1 — Discovery (entender el qué)

Combinar:
1. **Skill `brainstorming`** → explorar intent, edge cases, what could go wrong
2. **`mcp__ruflo__memory_search`** namespace=`obsidian-vault` query=`<topic>` smart=true limit=10 → buscar precedentes, RFCs previos, decisiones
3. Si hay PRD/RFC en `docs/` → cargarlo
4. Si arranca de PRD vacío → **agent `modo-tech-architect`** (consulta APIs MODO + Confluence + GitHub)

Output: `discovery.md` (Intent + Constraints + Precedentes + Open questions).

### Fase 2 — Context (entender dónde encaja)

- Codebase mapping → **skill `graphify`** si hay `graphify-out/`, sino `Agent subagent_type=Explore`
- APIs / BFF / proxies → **skill `api-usage-analyzer`** (genera code-wiki)
- SEO / indexing → si afecta páginas indexables, leer `docs/seo/`
- Analytics → **MCP `Amplitude`** (`get_events`, `get_charts`, `query_chart`) para impacto medible
- Jira contexto → **MCP `Atlassian`** (`searchJiraIssuesUsingJql`) para tickets relacionados

Output: `context.md` con snapshot del estado actual + archivos/APIs tocados + tickets relacionados.

### Fase 3 — Spec formal (SDD)

Secuencia obligatoria para todo lo que pase el triage:

1. **Skill `sdd-explore`** → relevar specs existentes
2. **Skill `sdd-propose`** → `openspec/changes/<change>/proposal.md` (intent + scope + approach)
3. **Skill `sdd-design`** → `design.md` (architecture + tradeoffs)
4. **Skill `sdd-tasks`** → `tasks.md` (lista TDD-first, una task por archivo testeable)
5. Si hay decisión arquitectónica → **skill `architecture-decision-records`** (ADR en `docs/adr/`)

Output: estructura completa en `openspec/changes/<slug>/`.

### Fase 4 — Plan ejecutable

- **Sprint breakdown** → `Agent subagent_type="Sprint Prioritizer"` con `tasks.md` como input
- **Jira tasks** → `MCP Atlassian createJiraIssue` por cada task, con:
  - Project: derivar del path (`/comercios/*` → COENXT; default → EXA)
  - Summary: `feat(SCOPE-XXX): <subject>`
  - Description: link al spec + AC del task
- **Worktree map** → asignar cada task a un worktree dedicado (regla `feedback_git_worktrees`)
- **Estimates "con IA"** explícito en el plan

Output: `plan.md` con tabla `task | jira-id | worktree | agent-type | estimate-ai`.

### Fase 5 — Orquestación (entregar al swarm)

Sólo si el user pide ejecución. Sino terminar acá con `plan.md` como deliverable.

- `mcp__ruflo__swarm_init` con anti-drift config del plan
- `mcp__ruflo__claims_claim` por cada task (agents claiming work)
- `mcp__ruflo__agent_spawn` con `isolation: "worktree"` por agent
- Usar `Agent subagent_type="Agents Orchestrator"` como conductor del swarm

Output: swarm activo + monitor stream.

### Fase 6 — Track & verify

Monitoreo continuo (si se está ejecutando):

- `mcp__ruflo__progress_check` periódico
- **Skill `sdd-verify`** por task completado
- **Skill `modo-code-review-checklist`** + **`react-doctor`** sobre cada PR generado
- **Skill `guardia`** para review profundo en PRs de alto riesgo

### Fase 7 — Archive & learn

Al completar el change:

1. **Skill `sdd-archive`** → mover spec a `openspec/specs/` y borrar `changes/`
2. **Skill `distill-learnings`** → codificar aprendizajes en los skills tocados
3. `mcp__ruflo__memory_store` namespace=`obsidian-vault` upsert=true → guardar snapshot del project
4. Si tocó skills MODO públicos → **skill `erno-modo-sync-all`** para sync a la bitácora

## Sub-comandos

Parsear el argument del invocation:

### Sin args / `<intent en lenguaje natural>`
Ejecutar pipeline completo desde Fase 0.

### `triage <intent>`
Ejecutar sólo Fase 0 y devolver verdict.

### `status`
Listar planes activos en `openspec/changes/*` + estado de cada uno + memoria `mcp__ruflo__memory_search` con tag=`mpf-plan`.

### `resume <change-slug>`
Cargar `openspec/changes/<slug>/` + continuar desde la última fase incompleta.

### `from-prd <path-to-prd>`
Saltar Fase 1.1, cargar el PRD, ir directo a discovery con `modo-tech-architect`.

### `from-jira <JIRA-ID>`
Cargar ticket vía `mcp__claude_ai_Atlassian__getJiraIssue` y usar como intent.

## Memoria y outputs

- Cada plan se persiste en `mcp__ruflo__memory_store` con `tags=["mpf-plan", "<repo>", "<change-slug>"]`
- Estructura de filesystem por plan:

```
openspec/changes/<change-slug>/
├── triage.md
├── discovery.md
├── context.md
├── proposal.md     (sdd-propose)
├── design.md       (sdd-design)
├── tasks.md        (sdd-tasks)
├── plan.md         (worktree + jira map)
└── verify-log.md   (Fase 6)
```

## Templates

Ver:
- `templates/triage.md` — template Fase 0
- `templates/plan.md` — template Fase 4 (tabla canónica)
- `checklists/quality-gates.md` — gates por fase
- `reference/agent-mapping.md` — qué agent usar para qué task

## Integración con otros skills

| Skill / Agent | Fase | Para qué |
|---|---|---|
| `brainstorming` | 1 | explorar intent antes de spec |
| `modo-tech-architect` | 1 | si arranca de PRD |
| `ruflo memory_search` | 1, 7 | precedentes + persistencia |
| `graphify` | 2 | mapear codebase |
| `api-usage-analyzer` | 2 | mapear APIs |
| `Amplitude` MCP | 2 | impacto medible |
| `Atlassian` MCP | 2, 4 | Jira context + creación |
| `sdd-*` | 3, 6, 7 | spec / verify / archive |
| `architecture-decision-records` | 3 | ADRs |
| `Sprint Prioritizer` agent | 4 | sprint breakdown |
| `ruflo swarm` | 5 | ejecución multi-agent |
| `Agents Orchestrator` agent | 5 | conductor del swarm |
| `sdd-verify` | 6 | quality gate |
| `modo-code-review-checklist` | 6 | review |
| `guardia` | 6 | review profundo |
| `distill-learnings` | 7 | aprendizajes a skills |
| `erno-modo-sync-all` | 7 | publicar bitácora |

## Anti-patterns (no hacer)

- ❌ Saltar Fase 0 (siempre triage primero)
- ❌ Spec sin Discovery → produce specs en el aire
- ❌ Jira tasks sin worktree map → viola `feedback_git_worktrees`
- ❌ Sprint breakdown sin "con IA" en estimates (`feedback_estimates_assume_ai`)
- ❌ Mega-prompt monolítico al swarm → violar `feedback_orchestrator_first`
- ❌ Saltar Fase 7 → los aprendizajes se pierden
