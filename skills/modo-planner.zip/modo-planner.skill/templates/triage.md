# Triage: <título corto>

**Fecha**: <YYYY-MM-DD>
**Origen**: <PRD | RFC | Jira <ID> | Slack | Conversación directa>
**Repo(s)**: <modo-landing | promos-hub-site | modo-ui-lib-web | …>

## Scope estimado
- Archivos tocados (estimado): <N>
- Repos cruzados: <N>
- Decisión arquitectónica: [SÍ | NO]
- API nueva / cambio de contrato: [SÍ | NO]
- Toca `/comercios/*`: [SÍ | NO]   <!-- si SÍ → SDD obligatorio -->

## Veredicto
- [ ] **EJECUTAR_DIRECTO** — termina acá, vuelve al main thread
- [ ] **PLAN (MPF completo)** — continuar a Fase 1 Discovery
- [ ] **PLAN ligero** — saltar Fase 5/6, parar en `plan.md`

## Razón (una línea)
<por qué este veredicto>

## Riesgos detectados (si los hay)
- <riesgo 1>
- <riesgo 2>

## Si EJECUTAR_DIRECTO — handoff
- Próxima acción concreta: <…>
- Quién/qué la hace: <claude main thread | agent X | user>
