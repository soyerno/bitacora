# Plan ejecutable: <change-slug>

**Origen Jira (epic)**: <COENXT-XXX | EXA-XXX>
**Repo principal**: <…>
**Worktrees base**: `/Users/hernan.desouza/Documents/Proyectos/modo/<repo>-worktrees/<change-slug>-*`

> Estimates **asumen Claude Code + skills MODO** (regla `feedback_estimates_assume_ai`).

## Tabla de tasks

| # | Task | Jira ID | Worktree | Agent type | Estimate (con IA) | Depende de |
|---|------|---------|----------|------------|-------------------|------------|
| 1 | <…> | COENXT-XXX | `<repo>-wt-1` | `ruflo-core:coder` + sdd-apply | 30m | — |
| 2 | <…> | COENXT-XXX | `<repo>-wt-2` | `Frontend Developer` | 1h | 1 |
| 3 | <…> | COENXT-XXX | `<repo>-wt-3` | `Backend Architect` | 45m | 1 |
| 4 | tests | COENXT-XXX | `<repo>-wt-4` | `Test Results Analyzer` | 30m | 2,3 |
| 5 | review | — | n/a | `guardia` | 15m | 2,3,4 |

**Total con IA**: ~<X>h

## Worktree convention

```bash
cd /Users/hernan.desouza/Documents/Proyectos/modo/<repo>
git worktree add ../<repo>-worktrees/<change-slug>-wt-N -b feat/<change-slug>-<task-slug>
```

## Quality gates

- [ ] Cada task: TDD-first (test rojo → impl → verde)
- [ ] `pnpm lint && pnpm build` antes de PR (regla `feedback_local_ci_parity`)
- [ ] `pnpm test` por worktree
- [ ] Commit firmado (GPG PATH fix) con scope Jira
- [ ] PR description con voz rioplatense
- [ ] SonarCloud Quality Gate pasa
- [ ] `modo-code-review-checklist` antes de merge

## Riesgos y rollback

| Riesgo | Probabilidad | Mitigación |
|--------|--------------|-----------|
| <…> | low/med/high | <…> |

## Handoff a Fase 5 (swarm)

```bash
# Opcional — sólo si user pide ejecución
mcp__ruflo__swarm_init topology=mesh maxAgents=<N>
mcp__ruflo__claims_claim taskId=<change-slug>-1 agentId=<…>
# … etc por cada task
```

## Aprendizajes esperados (Fase 7)

- <qué queremos aprender de este change>
- <a qué skill se codifica el aprendizaje>
