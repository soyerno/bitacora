# SDD Design heuristics (Fase 3 · design.md)

> Patterns destilados de SDDs ya ejecutados. Leer antes de escribir `design.md` para no reinventar.

## H1 · Supersede via paradigm pivot

**Trigger**: existe un RFC/spec previo que diagnostica bien el problema pero su solución optimiza el formato equivocado.

**Heurística**: **no mejorás la solución existente — pivoteás el paradigma**. Marcás el RFC viejo como `superseded` y citás explícito por qué. La diagnóstica del RFC viejo sigue siendo valiosa (no la tirás); solo su respuesta queda atrás.

**Ejemplo canónico** (erno-modo · bitacora-reader-experience 2026-05-28):
- RFC R20 "Decks responsivos" diagnosticó correcto: tráfico mobile desde Slack/WA/X ve slide 16:9 enano.
- Su respuesta: hacer slides responsive (canvas adaptativo por viewport, swipe, tap-zones).
- Pivot: contenido que se *lee* (no se *presenta*) → reemplazar slide por scroll-read.
- R20 superseded para web; sobrevive como base del exportador PDF on-demand.

**Anti-pattern**: pelearse con un RFC viejo intentando mejorarlo en el formato original. Si la mejora se acumula demasiado → pivoteá el paradigma.

**Cómo citar en `design.md`**:
```markdown
## Supersede
- **RFC <ID> "<título>"**: superseded para <scope>. Sobrevive solo como <subset compatible>.
```

## H2 · Anti-rewrite via schema extension opcional

**Trigger**: ya hay 2+ JSON/data sources con role de "source of truth". Tentación de consolidar en uno nuevo.

**Heurística**: **manifest layered**. Creás un nuevo manifest **encima** que referencia los existentes por ID, no los reemplaza. Cuando necesitás campos nuevos en uno de los originals → agregás campos **opcionales** (preservan invariants + tooling viejo no rompe).

**Ejemplo canónico** (D1+D16 bitácora-reader):
- `decks.json` + `rd.json` + `bitacora.json` son source of truth per-item (constraint del user).
- Solución: `lectura.json` nuevo como manifest de tracks que referencia entries por `id` con prefix (`decks:`, `rd:`, `bitacora:`).
- Cuando bitácora necesita trazar promotion a lección → campo opcional `bitacora.items[].promoted_to[]` en el shape existente.

**Test rápido**:
- ¿Romper este shape rompe tooling existente? Si sí → campo opcional + validator soft-fail durante migración.
- ¿Hay ≥2 places que escriben este JSON? Si sí → no consolidar, layered.

**Anti-pattern**: migración full a un manifest único "por elegancia". Costo de migración + drift hidden + viola sources of truth.

## H3 · Reader/Renderer unificado parametrizado por `data-type`

**Trigger**: 3+ tipos de contenido (lección, research, nota, ...) con shell visual común y diferencias chicas de comportamiento.

**Heurística**: **un solo shell HTML + JS, parametrizado por atributo semántico**. NO crees 3 templates paralelos.

```html
<article data-type="leccion|research|nota">
  <!-- mismo CSS, mismo JS init -->
</article>
```

CSS lee `[data-type="X"]` para mostrar/ocultar (`[data-type="leccion"] .next-lesson { display: flex }`). JS detecta `data-type` y activa solo los módulos aplicables (bionic para todos, next-lesson solo lección, learn-objectives validator solo lección).

**Ejemplo canónico** (D3+D15 bitácora-reader): bionic toggle + reading progress + glossary tooltips activos en `leccion|research|nota`. Learn-objectives + next-lesson curricular activos solo en `leccion`. Un solo `reader.js`, comportamiento parametrizado.

**Anti-pattern**: 3 readers paralelos (`leccion.js`, `research.js`, `nota.js`) → drift garantizado, bug fix en uno no llega al otro.

## H4 · Coexistencia vs subsunción (timeline + curriculum)

**Trigger**: dos modos legítimos de consumir el mismo dominio (cronológico vs curado, journal vs curriculum, raw vs processed).

**Heurística**: **coexisten + bridge**. No subsumas uno bajo el otro. Bridge bidireccional por:
1. Vocabulario común (tags compartidos).
2. Promotion path (uno crece a otro, queda rastro).
3. Bidir links (banner "esto creció a Y" + badge "origen en X").
4. URLs separadas: no romper deeplinks ya indexados.

**Ejemplo canónico** (D14 bitácora-reader): bitácora (timeline append-only diario) coexiste con `/lectura/` (curriculum por tracks). Bridging por tags + `promoted_to[]` campo. Stories de bitácora que maduran se promueven a lección **sin** borrar la story original.

**Anti-pattern**: meter bitácora bajo `/lectura/bitacora/` → mezcla journal con curriculum, rompe URLs históricos.

## H5 · Story promotion como flow editorial (no automático)

**Trigger**: contenido fluye de un formato (digest/draft/idea) a otro (lección/spec/feature).

**Heurística**: **promotion es decisión editorial humana, no automática**. Definí criterios explícitos (ej. "story aparece >2 veces en distintos días con tag estable" + "topic mapea a track existente" + "tiene 'qué vas a aprender' claro"). Mínimo ≥2 de N criterios. Documentá el workflow en un template del skill o del change.

**Ejemplo canónico** (D14 + `templates/leccion-from-bitacora.md`): criterios de promoción + steps de transformación + anti-patrón "una lección por story".

**Anti-pattern**: auto-promote por threshold simple (ej. "tag aparece 3 veces → es lección"). Promociones prematuras o promiscuas matan la curación.

## H6 · Audit-iterate antes del commit grande

**Trigger**: SDD ya escrito en primera pasada, listo para commit + ejecución.

**Heurística**: **re-inventariar** la realidad del repo **después** del primer pase, no antes. Discovery inicial puede missar artefactos ya presentes (CSS reusable, plantillas mid-integradas, schemas con campos no usados). Sin re-pase, el SDD genera trabajo duplicado.

**Ejemplo canónico** (bitácora-reader 2026-05-28):
- Primer pase: SDD asumió bitácora era scroll básico + bionic había que implementarlo.
- Re-pase post-commit: descubrió `bitacora/_template.html` ya cargaba `research-article.css` + `assets/deck-bionic.css` existía canónico. **50% del trabajo de Wave 4 ya hecho.**
- Sin re-pase, Wave 4 hubiera duplicado CSS y reescrito bionic.

**Cuándo hacer el re-pase**:
- Cuando el SDD toca múltiples directorios y el discovery focalizó en 1.
- Cuando hay assets versionados (CSS, JS, templates) que pudieron evolucionar entre sesiones.
- Cuando el corpus es grande y el primer inventario fue muestreo, no exhaustivo.

**Comando práctico**: `grep -r "<key-asset-name>" <repo>` + `ls <suspected-shared-dir>` antes de Wave 1.

**Anti-pattern**: tratar el SDD como inmutable post-commit. Es vivo — D-decisions discovered mid-flight son normales (skill `sdd-track` cubre el sync).

## Cómo aplicar en un design.md nuevo

Al escribir `design.md`, recorrer estas 7 heurísticas como checklist:

- [ ] ¿Hay RFC/spec previo que esto supersede via pivot? (H1) → documentar
- [ ] ¿Tentación de rewrite de schema? (H2) → considerar layered + campos opcionales
- [ ] ¿Múltiples tipos con shell común? (H3) → `data-type` parametrizado
- [ ] ¿Dos modos legítimos de consumir? (H4) → coexistencia + bridge, no subsunción
- [ ] ¿Hay promotion path entre formatos? (H5) → criterios editoriales explícitos
- [ ] ¿Sé el estado real del repo o estoy asumiendo? (H6) → re-inventario antes de commit grande
- [ ] ¿Corpus 10-30 items conversibles? (H7) → parallel sub-agents en worktree, audit-iterate al volver

## H7 · Parallel sub-agent batches con audit-iterate post-commit

**Trigger**: SDD tiene N items conversibles (lecciones, archivos, datos) con misma forma + corpus chico (10-30 items).

**Heurística**: dividí en **batches paralelos por sub-agent**, cada uno en **worktree dedicado**. NO swarm via ruflo (RD03 cayó). Usá el built-in `Agent` tool con `subagent_type="Content Creator"` (o equivalente por dominio) y `isolation="worktree"`. Lanzá los batches en **un solo mensaje con múltiples tool calls** para que corran concurrentes.

**Pattern canónico** (Wave 3 bitácora-reader 2026-05-28):

```
Parent setup:
  git worktree add -b feat/<topic>-batch-a .claude/worktrees/batch-a <parent-branch>
  git worktree add -b feat/<topic>-batch-b .claude/worktrees/batch-b <parent-branch>
  git worktree add -b feat/<topic>-batch-c .claude/worktrees/batch-c <parent-branch>

Parent launches (single message, parallel):
  Agent(subagent_type="Content Creator", isolation="worktree", run_in_background=true,
        prompt="...workdir=batch-a, targets=[5 lecciones], gold-standard=<pilot>, D13 checklist, ...")
  Agent(... batch-b ...)
  Agent(... batch-c ...)

Parent waits for notifications.

Per sub-agent completed:
  1. Independent audit (grep/python NOT trust self-report counts)
  2. Cleanup stubs (sub-agents can't `rm` if their harness lacks Bash)
  3. Run validators
  4. Commit at parent level

Parent post all done:
  git merge --no-ff feat/<topic>-batch-a -m "merge: batch A"
  git merge --no-ff feat/<topic>-batch-b -m "merge: batch B"
  git merge --no-ff feat/<topic>-batch-c -m "merge: batch C"
  (in the consolidating worktree)
```

**Per-batch sub-agent prompt MUST include**:
- Workdir absolute path + branch name (already created).
- Gold-standard reference file (pilot/exemplar).
- Editorial checklist (D13-equivalent).
- Per-item workflow + per-item validation greps.
- Final batch validation + commit format.
- Honest gap requirement (no claim done if validation skipped).

**Sub-agent harness reality (verified Wave 3 x3)**:
- Content Creator default agent **DOES NOT have Bash** in worktree-isolated mode.
- Sub-agent **CAN** Read/Write/Edit but NOT `rm`, `git commit`, `python3 script.py`.
- Workaround: sub-agent overwrites `.draft.html` (or equivalent) with a stub/redirect comment. Parent runs `rm` post-audit.
- DO NOT assume sub-agent has Bash even if you tell it "you DO have Bash" in the prompt. Verify by sub-agent's first action.

**Cost data** (Wave 3 reference):
- 5 lecciones batch: ~200k tokens · ~12-14min wall.
- 8 lecciones batch: ~300k tokens · ~22min wall.
- 3 batches paralelos: ~720k total · ~22min wall (longest batch dominates).

**Quality outcome**:
- 19/19 lecciones passed independent audit (HTML parse 0, hierarchy clean, no banned words).
- Lighthouse mobile sample 3/3 lecciones: a11y 100, best 100, SEO 100 (agentic varies 78-96).
- Audit-iterate cazó: glossary count mis-reported by sub-agent, voseo signal mis-counted (sub-agent uses narrow detector, real density higher than reported), stub-file leakage (sub-agent overwrites instead of deletes).

**Anti-pattern**: single-agent doing all N items sequentially. Loses 60-80% wall time vs parallel sub-agents. Token cost similar — parent does coordination only.

**Cuándo NO usar parallel sub-agents**:
- Items have inter-dependencies (item B needs output of item A) → sequential.
- Items < 5 (parent agent does them directly, faster setup).
- Editorial voice highly variable per item (need single curator's eye) → sequential.
- Corpus > 50 (token cost explodes, batch into multi-wave instead).
