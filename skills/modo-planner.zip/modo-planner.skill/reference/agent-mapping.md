# Agent mapping — qué delegar a quién

Tabla de decisión para Fase 4 (asignar `agent type` por task).

## Por tipo de trabajo

| Tipo de task | Agent recomendado | Skill complementario |
|--------------|-------------------|----------------------|
| Frontend page/component nuevo | `Frontend Developer` | `modo-design-system`, `vercel-react-best-practices` |
| Backend / BFF / API | `Backend Architect` | `api-usage-analyzer`, `openapi-spec-generation` |
| Database / schema | `Database Optimizer` | — |
| DevOps / CI / Helm | `DevOps Automator` | `helm-k8s-best-practices`, `cicd-pipeline-optimization` |
| Tests | `API Tester` / `Test Results Analyzer` | `test-driven-development` |
| Security | `Security Engineer` | `frontend-security-checklist`, `csp-hardening` |
| Perf | `Performance Benchmarker` | `bundle-size-optimization` |
| UI design / mockup | `UI Designer` / `UX Architect` | `ui-ux-pro-max`, `impeccable` |
| Copy / docs | `Technical Writer` | `writing-clearly-and-concisely`, `doc-coauthoring` |
| Code review | `Code Reviewer` + `guardia` | `modo-code-review-checklist` |
| Spec writing | `sdd-spec` skill via launcher | `sdd-propose`, `sdd-design`, `sdd-tasks` |
| Implementation (small) | `ruflo-core:coder` | `sdd-apply` |
| Implementation (premium) | `Senior Developer` | — |
| Sprint breakdown | `Sprint Prioritizer` | — |
| Cross-functional coord | `Project Shepherd` / `Senior Project Manager` | — |
| Pipeline conduction | `Agents Orchestrator` | — |

## Por área MODO

| Área | Agent / Skill canónico |
|------|------------------------|
| `/comercios/*` | SDD obligatorio + `modo-design-system` + `Frontend Developer` |
| `/promos/*` | route es istio, ver `project_promos_istio_routing` — coordinar con backend |
| Blog / SSR | `project_blog_ssr_root_cause` — atento al gate `!loading` en ThemeProviderSDK |
| SEO | ver `project_seo_architecture` y `project_indexing_issues` |
| Analytics | Amplitude MCP + `amplitude-analytics` skill |
| ToFu UCP | `project_tofu_ucp_workspace` — usar `BUILD-AGENT.md` autónomo |
| WhatsApp CX agent | `agente-cx-whatsapp` skill |
| Checkout agentic | `simular-compra-agentica` skill |

## Reglas de asignación

1. **Una task = un agent = un worktree** (no compartir worktree entre agents)
2. **Sub-agents en caveman mode** para inter-agent (regla CLAUDE.md global)
3. **Spec-first**: ningún agent implementa sin `tasks.md` aprobado en Fase 3
4. **Review obligatorio**: toda task de impl tiene una task de `guardia`/`Code Reviewer` que depende de ella
5. **Anti mega-agent**: si una task tiene >3 sub-tasks → re-orquestar, no agrandar el agent
