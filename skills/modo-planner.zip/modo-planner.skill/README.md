# modo-planner

MODO Planning Framework (MPF) — convierte intent vago en plan ejecutable end-to-end con SDD, worktrees, Jira y swarm orchestration.

## Quick start

- **Trigger manual**: `/plan <intent>` o `/modo-planner <intent>`
- **Trigger auto** (ES/EN): "planificar X", "armar plan", "nuevo feature", "crear RFC/PRD", "breakdown a sprints", "cómo encaramos esto", o PRD/RFC aterriza en contexto, o scope ≥3 archivos / ≥2 repos.
- **Delegado**: `Agent(subagent_type="MODO Planner", isolation="worktree", prompt=…)`
- **Output**: `openspec/changes/<slug>/{triage,discovery,context,proposal,design,tasks,plan,verify-log}.md` + Jira tasks + worktree map + memoria ruflo tag `mpf-plan`.

Ejemplo:
```
/plan armar la página /comercios/bancos con SSR + JSON-LD
```
→ Triage → Discovery → Context → SDD → Plan tangible. Termina ahí o sigue a orquestación según pidas.

## Features

- Triple entry point: skill auto-invocable + agent delegable + slash command `/plan`
- 7 fases con quality gates por fase (no avanza si fallan)
- Sub-comandos: `triage`, `status`, `resume <slug>`, `from-prd <path>`, `from-jira <ID>`
- Enforce reglas duras MODO (worktrees, SDD en `/comercios`, TDD, estimates "con IA", voz rioplatense, sin "apetito", commit scope COENXT/EXA)
- Integración nativa con `brainstorming`, `modo-tech-architect`, `sdd-*`, `graphify`, `api-usage-analyzer`, Amplitude MCP, Atlassian MCP, `ruflo-swarm`, `guardia`, `distill-learnings`, `erno-modo-sync-all`
- Persistencia cross-session: ruflo namespace `obsidian-vault` + memoria de proyecto
- Anti mega-agent: triage decide PLAN vs EJECUTAR_DIRECTO

## Files

- `SKILL.md` — framework completo (7 fases + reglas + sub-comandos + mapping)
- `README.md` — esta doc
- `templates/triage.md` — output canónico Fase 0
- `templates/plan.md` — output canónico Fase 4 (tabla worktree+Jira+agent+estimate)
- `checklists/quality-gates.md` — gates por fase
- `reference/agent-mapping.md` — qué subagent_type usar por task
- `changelog/CHANGELOG.md` — historial de cambios
- `examples/` — flows de ejemplo

## Integración con otros entry points

| Entry point | Path | Para qué |
|-------------|------|----------|
| Skill | `~/.claude/skills/modo-planner/SKILL.md` | Auto-invocable por triggers, también `/modo-planner` |
| Agent | `~/.claude/agents/modo-planner.md` (subagent_type `MODO Planner`) | Delegable vía Agent tool con isolation=worktree |
| Slash | `~/.claude/plugins/work-pilot/commands/plan.md` (`/plan`) | Entry point explícito user-facing |

## Changelog

- **2026-05-20** — Creación del framework. 7 fases, triple entry point, integración con stack MODO completo. Patrón canónico para futuros frameworks de planificación. (Detalle en SKILL.md.)
