# Golden examples

Páginas en producción que ejemplifican correctamente cada pattern. El skill las usa como referencia.

| Pattern | Golden file | Notes |
|---|---|---|
| listing | `modo-landing/src/pages/comercios/index.tsx` | MVP 2026-05, BFF + Storyblok editorial. Hero verde + featured 4-col + grid + mosaic + app banner. |
| detail | `modo-landing/src/pages/comercios/[slug].tsx` | Merchant detail con sidebar, FAQ, related. |
| landing | `modo-landing/src/pages/modo-en-tu-comercio.tsx` | Landing institucional (revisar) |
| faq | `modo-landing/src/pages/ayuda/` | Topic-based FAQ |
| bank | `modo-landing/src/pages/promos-banco/` | Bank-themed listing |

## Cómo agregar un nuevo golden

1. Confirmar que la página pasa `validate-tokens.sh` con 0 violations.
2. Confirmar que está en producción (`modo.com.ar/<slug>`).
3. Agregar entry a la tabla con path absoluto al workspace.
4. Si introduce un patrón nuevo, actualizar `reference/page-patterns.md`.
5. Si introduce un anti-pattern aceptable (uso especial), documentar en `reference/tokens.md` allowlist.

## Validación continua

Run trimestral:

```bash
~/.claude/skills/modo-design-system/scripts/extract-tokens.sh
~/.claude/skills/modo-design-system/scripts/validate-tokens.sh \
  modo-landing/src/pages/comercios/index.tsx \
  modo-landing/src/pages/comercios/\[slug\].tsx
```

Si snapshot cambió → re-generar `reference/tokens.md` con los valores nuevos y bump skill version.
