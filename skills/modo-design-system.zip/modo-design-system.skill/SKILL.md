---
name: modo-design-system
description: "SDK/skill MODO-específico para generar páginas Next.js/Astro one-shot con el design system MODO (Quicksand + Red Hat Display, verde #008859, brand tokens canónicos). Auto-invocar cuando el usuario pida crear página/landing/feature en cualquier repo del workspace MODO (modo-landing, promos-hub-site, modoplus-hub-site, modo-landing-astro). Triggers (ES/EN): 'nueva página MODO', 'crear /xxx', 'página comercios', 'landing MODO', 'feature page', 'promos-hub page', 'new modo page', 'modo landing page', 'add route'. Enforces brand rules, JSON-LD obligatorio, NavFooterLayout, ISR, validación de tokens hardcoded. Iterativo: graba aprendizajes en changelog/."
license: Internal · MODO Play Digital S.A.
---

# MODO Design System Skill

SDK interno para devs frontend de MODO. Convierte un brief de página (slug + propósito + datos) en archivos completos production-grade que respetan el design system MODO.

## Mission

Eliminar drift de branding entre repos. Cualquier dev frontend que pida "necesito página X" debe obtener:

1. Página completa con tokens canónicos (cero hex hardcoded fuera de allowlist).
2. SEO + JSON-LD obligatorios.
3. Layout chrome (NavFooter) consistente.
4. ISR/SSG correcto según repo target.
5. Tests + lint pasando.

Sin re-prompts sobre colores, fuentes, spacing, motion.

## When to use

Auto-invocar cuando el cwd está en uno de los repos del workspace MODO **y** el usuario pide:

- "crear página /<slug>"
- "nueva landing"
- "nueva feature page"
- "página para <feature>"
- "add route", "scaffold page", "build page"
- "página tipo /comercios"
- "landing MODO institucional"

NO usar para: backend, scripts, configs, docs, components aislados sin página contenedora.

## Hard rules (cero excepciones sin `// modo-ds:disable`)

### Tipografía

| Family | Tw class | Uso |
|---|---|---|
| **Quicksand** (700) | `font-quicksand` | H1, H2, H3, H4, stat values, featured card titles |
| **Red Hat Display** (400/500/600/700) | `font-red-hat` o herencia | Body, callout, caption, links, forms |

PROHIBIDO: `font-sans` default, Inter, Roboto, Arial, system-ui, Geist, Space Grotesk.

### Colores (TOKENS, no hex literal)

- Brand verde MODO: `bg-primary-PaymentDefault` (#008859), `bg-primary-PaymentDark` (#00471B).
- Brand azul send: `bg-primary-SendDefault` (#0049C4), `bg-primary-SendDark` (#0D3F92).
- Rewards: `bg-promotions-PrimaryRewards` (#FFC738), `bg-sdk-promos-yellow-dark` (#E7A600).
- Texto: `text-primary-black` (#121212), `text-tertiary-darkGray` (#717171), `text-primary-white` (#FFFFFF).
- Surfaces: `bg-sdk-surface-primary` (#F3F4F9).

**PROHIBIDO**: `bg-green-500`, `text-gray-500`, `#hex` literal (excepto en gradient inline o radii finos).

### Spacing + container

- Container canónico: `mx-auto max-w-[1260px] px-4 lg:px-6`.
- Hero padding: `pb-14 pt-10 lg:pb-20 lg:pt-14`.
- Section gap: `py-6 lg:py-10` (interior), `mb-10` (entre secciones).
- Solo tokens Tailwind (`p-4 m-6 gap-3`) o vars (`px-xsm py-sm`).

### Typography display

- H1 hero: `font-quicksand text-[32px] font-bold leading-[1.08] lg:text-[56px]` + inline `letterSpacing: '-0.025em'`.
- H2 section: `font-quicksand text-[19px] font-bold leading-tight` + inline `letterSpacing: '-0.018em'`.
- H2 card title: `font-quicksand text-[22px] font-bold leading-[1.1] lg:text-[26px]` + `-0.022em`.
- Stat value: `font-quicksand text-2xl lg:text-[32px] font-bold leading-none` + `-0.025em`.

### Radii

| Token | Px | Uso |
|---|---|---|
| `rounded-s` | 8 | inputs, small chips |
| `rounded-m` | 12 | buttons regulares |
| `rounded-l` | 16 | cards medianas |
| `rounded-xl` | 24 | cards grandes |
| `rounded-[10px]` | 10 | inputs hero (patrón observado) |
| `rounded-[14px]` | 14 | cards principales (patrón observado) |
| `rounded-full` | — | chips, badges, pill buttons |

### Motion

- Smooth ease (default): `[transition-timing-function:cubic-bezier(0.25,1,0.5,1)]`.
- Sharp ease (botones/inputs): `[cubic-bezier(0.4,0,0.4,1)]`.
- Durations: `duration-[120ms]` micro, `duration-200` normal, `duration-300` images.

### Layout obligatorio

Toda page envuelta en `NavFooterLayout` con `getNavFooterData` en `getStaticProps`. Excepción: pages de error (404, 500) y handlers (account_link_*).

### SEO obligatorio

Toda page usa `<PageSeo data={seoData} />` con:

- `seoData.seo` (title, description, url, og)
- `seoData.jsonLd` array que incluye **siempre**: `MODO_ORGANIZATION_JSONLD` + `MODO_WEBSITE_JSONLD` + Breadcrumb específico + tipo de Schema.org acorde al contenido.

### ISR

- Listings: `revalidate: 3600` (1h).
- Detail pages: `revalidate: 3600` + `fallback: 'blocking'`.
- Páginas institucionales estáticas: sin revalidate (build-time).

## Workflow when invoked

0. **Worktree check (MANDATORY)**: antes de generar archivos, verificar que el cwd NO sea el checkout principal del repo. Si lo es, parar y avisar al user:
   ```
   No estoy en un worktree dedicado. Crear primero:
     git -C <repo-principal> pull --rebase origin main
     git -C <repo-principal> worktree add ../<repo>-<slug> -b feat/<slug>
     cd ../<repo>-<slug>
   ```
   Confirmar antes de proceder. Nunca generar páginas directo en `main` del checkout principal.

1. **Detectar repo + stack**: leer `~/.claude/skills/modo-design-system/manifests/repo-targets.json`, matchear cwd → stack (next12-pages / next14-app / next15-app / astro5).
2. **Brief check** (AskUserQuestion si falta algo):
   - tipo: `listing` | `detail` | `landing` | `faq` | `bank-page`
   - slug (ruta final)
   - data source (BFF / static / Storyblok)
   - tema visual (default green / Patagonia / brand banco)
   - copy hero (title + subtitle + eyebrow)
3. **Cargar reference + template**:
   - `reference/tokens.md`, `reference/typography-scale.md`, `reference/page-patterns.md`
   - `templates/page-<tipo>.tsx.tmpl` correspondiente al stack
4. **Generar files**:
   - `src/pages/<slug>/index.tsx` (Pages Router) o `app/<slug>/page.tsx` (App Router) o `src/pages/<slug>.astro`.
   - `src/components/<Feature>/{Hero,Grid,Card}.tsx`
   - `src/utils/<feature>/jsonld.ts`
   - `src/data/<feature>/api.ts` (stub si no hay BFF)
5. **Validar**: correr `scripts/validate-tokens.sh <generated_files>` → reportar hex hardcoded / fonts no permitidas / falta de NavFooter / falta de JSON-LD.
6. **Recordar al user**: `pnpm lint && pnpm build` antes de commit; commit convention `feat(SCOPE-XXX): <subject>`.
7. **Grabar aprendizaje**: si el user pide algo no contemplado, agregarlo a `changelog/learnings.md` para futuras invocaciones.

## Iterative learning loop

Cada vez que se genera una página:

1. Append entry a `changelog/runs.jsonl` con: timestamp, repo, slug, tipo, tokens detectados fuera de DS, correcciones aplicadas post-generación por el user.
2. Si el user hace ≥3 ediciones manuales al mismo patrón, abrir issue en `changelog/learnings.md` con propuesta de update al template.
3. Snapshots de design system se versionan en `changelog/ds-snapshots/` (run trimestral con `scripts/extract-tokens.sh`).

## Targets multi-repo

Ver `manifests/repo-targets.json`. Stack matrix:

| Repo | Stack | Router | Tailwind | Template |
|---|---|---|---|---|
| modo-landing | Next 12 | Pages | v3 | `*.next12.tmpl` |
| promos-hub-site | Next 15 | App | v4 | `*.next15.tmpl` |
| modoplus-hub-site | Next 14 | App | v3 | `*.next14.tmpl` |
| modo-landing-astro | Astro 5 | File-routes | v4 | `*.astro.tmpl` |
| modo-landing-sdk-ui-lib | Lib | — | v4 | N/A (no pages) |

## Anti-patterns (refuse outright)

- Generar página sin NavFooterLayout (excepto error pages).
- Generar página sin JSON-LD Organization + WebSite + Breadcrumb.
- Usar `bg-green-500` o cualquier color Tailwind default.
- Hardcodear `font-family: Inter` o similar.
- Containers > `1260px`.
- `console.log` en código generado.
- Comentarios que expliquen el qué (solo el porqué, si no es obvio).
- Botones sin `aria-label` cuando son icon-only.
- Imágenes sin `alt` (descriptivo) o `aria-hidden="true"` (decorativas).
- `style={{}}` para spacing/colors (solo aceptado para gradients inline y letter-spacing display).

## Output style

Caveman mode en updates inter-fase. Código generado: normal, completo, production-grade. Comentarios solo cuando aportan contexto no obvio (constraint, workaround, decisión arquitectural).
