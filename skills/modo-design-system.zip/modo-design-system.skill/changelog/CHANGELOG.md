# Changelog · modo-design-system skill

Skill semver. Bump major si cambia el contrato (templates), minor si suma reference/template, patch si fix doc.

## [1.0.0] — 2026-05-20

### Added
- SKILL.md con triggers ES/EN + hard rules.
- `reference/tokens.md` — extracción canónica de colores/spacing/fonts/breakpoints/motion.
- `reference/typography-scale.md` — mapeo Tailwind classes → uso semántico.
- `reference/page-patterns.md` — 5 patrones canónicos (listing, detail, landing, faq, bank).
- `reference/components-inventory.md` — lib `@playsistemico/modo-ui-lib-web` 1.32.1 + locales.
- `reference/brand-voice.md` — copy rules rioplatense, antipatterns.
- `templates/page-listing.next12.tmpl` — basado en `/comercios/index.tsx`.
- `templates/page-detail.next12.tmpl` — basado en `/comercios/[slug].tsx`.
- `templates/hero-verde.tsx.tmpl` — hero reusable.
- `templates/featured-grid.tsx.tmpl` — 4-col tones.
- `templates/app-banner-cta.tsx.tmpl` — banner App Store/Google Play.
- `templates/jsonld-helpers.ts.tmpl` — Collection/ItemList/Breadcrumb/FAQ builders.
- `scripts/validate-tokens.sh` — detecta hex hardcoded, fonts banned, falta NavFooter/JSON-LD.
- `scripts/extract-tokens.sh` — snapshot fuentes verdad para detección de drift.
- `manifests/repo-targets.json` — mapping repo → stack → template variant (5 repos).

### Fuentes verdad usadas
- `modo-landing/tailwind.config.js` (482 líneas)
- `modo-landing/src/styles/globals.css` (CSS vars layer)
- `modo-landing/src/pages/_document.js` (font CDN)
- `modo-ui-lib-web/src/theme/{colors,typography,spacing,breakpoints,shadow,borders,fonts}.scss`

### Brand confirmado
- Display: **Quicksand** (400/500/700)
- Body: **Red Hat Display** (400/500/600/700/900)
- Primary: verde MODO `#008859`
- Accent: azul send `#0049C4`
- Rewards: amarillo `#FFC738`

### Templates pendientes (futuras versions)
- `page-landing.next12.tmpl`
- `page-faq.next12.tmpl`
- `page-bank.next12.tmpl`
- `*.next14.tmpl` (modoplus-hub-site)
- `*.next15.tmpl` (promos-hub-site, App Router)
- `*.astro.tmpl` (modo-landing-astro)

---

## Roadmap

### [1.1.0] — F2 (próximo sprint)
- Page-landing + page-faq + page-bank templates Next 12.
- Auto-validation hook PostToolUse en `.claude/settings.json` del workspace.
- Examples bank con 3 goldens reales.

### [1.2.0] — F3
- Templates Next 15 App Router (promos-hub-site).
- Templates Next 14 App Router (modoplus-hub-site).
- Astro 5 templates.

### [1.3.0] — F4
- Aprendizaje automatizado: post-skill-run hook que registra correcciones manuales del user en `runs.jsonl` → genera issue auto en `learnings.md` si patrón repite ≥3 veces.
- Storyblok content-type generator (`getXxxContent` helpers).
- BFF stub generator (`api.ts`).

### [2.0.0] — F5
- Multi-banco theme switching automático (UI Patagonia, Galicia, Macro, BBVA, etc.).
- SDK publicable como `@playsistemico/modo-design-skill` (npm GitHub Packages) — distribuible al equipo frontend completo.
- Integración con `pnpm modo-page` CLI wrapper (genera scaffolding sin Claude).
