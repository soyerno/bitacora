# Learnings · iterative improvement log

Cada vez que el user corrige algo después de generar página → entry acá. Si patrón repite ≥3 veces → propuesta de update a template.

## Patrones detectados (open)

_(vacío — se llena con uso real)_

## Patrones aplicados (closed)

_(vacío)_

## Anti-patrones detectados (refuse list)

### A001 · Falta de letter-spacing display

- **Detectado**: 2026-05-20 (durante design del skill inicial)
- **Síntoma**: H1/H2 hero sin `style={{ letterSpacing: '-0.025em' }}` se ven "blandos", no MODO.
- **Fix**: enforced en template y validate-tokens (futuro check).
- **Status**: cerrado en v1.0.0.

### A002 · `bg-green-500` o equivalente Tailwind default

- **Detectado**: 2026-05-20
- **Síntoma**: dev usa palette default de Tailwind en vez de tokens MODO.
- **Fix**: `validate-tokens.sh` rule `TW_DEFAULT_COLOR`.
- **Status**: cerrado en v1.0.0.

## Cómo agregar learning

```
### A0NN · <título-corto>

- **Detectado**: YYYY-MM-DD
- **Trigger**: <slug de la página + qué pidió el user>
- **Síntoma**: <qué generó el skill mal>
- **Fix aplicado**: <qué hicimos>
- **Update template**: <sí/no — en qué versión>
- **Status**: open|closed-vX.Y.Z
```
