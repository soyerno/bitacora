#!/usr/bin/env bash
# validate-tokens.sh — verifica que un archivo generado respete el design system MODO
# Uso: ./validate-tokens.sh <file1> [file2 ...]
#
# Detecta:
#   1. Hex colors hardcoded fuera de allowlist
#   2. Font families prohibidas (Inter, Roboto, Arial, system-ui, etc)
#   3. Tailwind classes default prohibidas (text-gray-N, bg-blue-N, etc)
#   4. Falta de NavFooterLayout en pages
#   5. Falta de JSON-LD Organization + WebSite + Breadcrumb
#   6. console.log/error/warn
#
# Exit: 0 = clean, 1 = violations

set -u

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 <file1> [file2 ...]"
  exit 2
fi

violations=0
report() {
  local file="$1"
  local line="$2"
  local kind="$3"
  local msg="$4"
  echo "  $file:$line  [$kind]  $msg"
  violations=$((violations + 1))
}

# Allowlist hex literals (case insensitive)
allowed_hex='rgba\(255,?\s*255,?\s*255|rgba\(0,?\s*0,?\s*0|rgba\(18,?\s*18,?\s*18|rgba\(255,?\s*199,?\s*56|rgba\(0,?\s*73,?\s*196|rgba\(0,?\s*106,?\s*69|var\(--'

for file in "$@"; do
  [ -f "$file" ] || { echo "  skip (not file): $file"; continue; }

  echo "Validating $file..."

  # 1. Hex hardcoded — busca #RRGGBB o #RGB que NO esté precedido por rgba/var/comment
  while IFS=: read -r line content; do
    # Skip if hex aparece dentro de un rgba/var allowed o linea es comentario puro
    if echo "$content" | grep -Eqi "$allowed_hex"; then
      continue
    fi
    # Skip pure-comment lines
    if echo "$content" | grep -Eq '^\s*(\*|//|/\*)'; then
      continue
    fi
    # Hex literal #abc o #abcdef
    hex=$(echo "$content" | grep -oE '#[0-9a-fA-F]{3,8}' | grep -v '#ffffff\|#000000\|#FFFFFF\|#000\|#fff' || true)
    if [ -n "$hex" ]; then
      report "$file" "$line" "HEX_HARDCODED" "found hex: $hex (use sdk-* or primary-* tokens)"
    fi
  done < <(grep -nE '#[0-9a-fA-F]{3,8}' "$file" 2>/dev/null || true)

  # 2. Fonts prohibidas
  if grep -nE "(font-family|fontFamily).*(Inter|Roboto|Arial|system-ui|Geist|Space Grotesk|Helvetica)" "$file" 2>/dev/null; then
    line=$(grep -nE "(font-family|fontFamily).*(Inter|Roboto|Arial|system-ui|Geist|Space Grotesk|Helvetica)" "$file" | head -1 | cut -d: -f1)
    report "$file" "$line" "FONT_BANNED" "use 'Quicksand' (display) or 'Red Hat Display' (body)"
  fi

  # 3. Tailwind default colors prohibidos
  if grep -nE 'class[Nn]ame="[^"]*\b(text|bg|border)-(gray|blue|green|red|yellow|purple|pink|orange)-[0-9]+\b' "$file" 2>/dev/null; then
    line=$(grep -nE 'class[Nn]ame="[^"]*\b(text|bg|border)-(gray|blue|green|red|yellow|purple|pink|orange)-[0-9]+\b' "$file" | head -1 | cut -d: -f1)
    report "$file" "$line" "TW_DEFAULT_COLOR" "use sdk-*, primary-*, tertiary-* or promotions-* tokens"
  fi

  # 4. NavFooterLayout (solo si es página, no componente ni utils)
  if echo "$file" | grep -qE '/pages/[^/]+/(index|\[.*\])\.(tsx|jsx)$'; then
    if ! grep -q 'NavFooterLayout' "$file"; then
      report "$file" "1" "MISSING_LAYOUT" "page must wrap content in <NavFooterLayout>"
    fi
  fi

  # 5. JSON-LD obligatorio en pages
  if echo "$file" | grep -qE '/pages/.*\.(tsx|jsx)$'; then
    missing_jsonld=""
    grep -q 'MODO_ORGANIZATION_JSONLD' "$file" || missing_jsonld="$missing_jsonld Organization"
    grep -q 'MODO_WEBSITE_JSONLD' "$file" || missing_jsonld="$missing_jsonld WebSite"
    grep -qE 'BreadcrumbList|build.*Breadcrumb' "$file" || missing_jsonld="$missing_jsonld Breadcrumb"
    if [ -n "$missing_jsonld" ]; then
      report "$file" "1" "MISSING_JSONLD" "page must include JSON-LD:$missing_jsonld"
    fi
  fi

  # 6. console.*
  if grep -nE 'console\.(log|error|warn|info|debug)' "$file" 2>/dev/null; then
    line=$(grep -nE 'console\.(log|error|warn|info|debug)' "$file" | head -1 | cut -d: -f1)
    report "$file" "$line" "CONSOLE" "remove console.* before commit"
  fi

  # 7. style={{}} para color/bg (excepto allowed: gradient inline + letter-spacing)
  if grep -nE 'style=\{\{[^}]*(backgroundColor|color):[^}]*#[0-9a-fA-F]' "$file" 2>/dev/null; then
    line=$(grep -nE 'style=\{\{[^}]*(backgroundColor|color):[^}]*#[0-9a-fA-F]' "$file" | head -1 | cut -d: -f1)
    report "$file" "$line" "INLINE_COLOR" "use Tailwind class instead of inline style for color/bg"
  fi
done

echo ""
if [ "$violations" -eq 0 ]; then
  echo "✓ Clean — 0 violations"
  exit 0
else
  echo "✗ $violations violation(s) found"
  echo ""
  echo "Fix or escape with comment: // modo-ds:disable"
  exit 1
fi
