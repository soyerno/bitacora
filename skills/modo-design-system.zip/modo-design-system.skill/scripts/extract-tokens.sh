#!/usr/bin/env bash
# extract-tokens.sh — re-extrae tokens MODO desde fuentes verdad, guarda snapshot

set -e

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$SKILL_DIR/changelog/ds-snapshots"
mkdir -p "$OUT_DIR"

DATE=$(date +%Y-%m-%d)
OUT="$OUT_DIR/$DATE.json"

WORKSPACE="/Users/hernan.desouza/Documents/Proyectos/modo/modo-landing-workspace"
TW="$WORKSPACE/modo-landing/tailwind.config.js"
GLOBALS="$WORKSPACE/modo-landing/src/styles/globals.css"
DOC="$WORKSPACE/modo-landing/src/pages/_document.js"
COLORS="$WORKSPACE/modo-ui-lib-web/src/theme/colors.scss"

[ -f "$TW" ] || { echo "Missing $TW"; exit 1; }
[ -f "$GLOBALS" ] || { echo "Missing $GLOBALS"; exit 1; }

TW_HASH=$(shasum -a 256 "$TW" | awk '{print $1}')
GL_HASH=$(shasum -a 256 "$GLOBALS" | awk '{print $1}')
COL_HASH=$([ -f "$COLORS" ] && shasum -a 256 "$COLORS" | awk '{print $1}' || echo "missing")
FONTS_LINE=$(grep -oE 'family=[^"]*' "$DOC" 2>/dev/null | head -1 || echo "")
CSS_VAR_COUNT=$(grep -cE '^\s*--' "$GLOBALS" 2>/dev/null || echo "0")

cat > "$OUT" <<JSON
{
  "snapshotDate": "$DATE",
  "sources": {
    "tailwindConfig": { "path": "$TW", "sha256": "$TW_HASH" },
    "globalsCss":     { "path": "$GLOBALS", "sha256": "$GL_HASH", "cssVarCount": $CSS_VAR_COUNT },
    "uiLibColors":    { "path": "$COLORS", "sha256": "$COL_HASH" },
    "document":       { "path": "$DOC", "fontsCdn": "$FONTS_LINE" }
  },
  "extractedAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
JSON

echo "Snapshot: $OUT"
PREV=$(ls -t "$OUT_DIR"/*.json 2>/dev/null | grep -v "$DATE" | head -1)
[ -n "$PREV" ] && diff "$PREV" "$OUT" || echo "(no previous snapshot)"
