# Components inventory

## Internal lib · `@playsistemico/modo-ui-lib-web` v1.32.1

Source: `modo-landing-workspace/modo-ui-lib-web/src/`. Importable desde GitHub Packages.

| Component | Variantes | Cuándo usar |
|---|---|---|
| `Button` | primary, secondary, ghost, link | Cualquier acción primaria/secundaria |
| `ButtonForward` | — | CTA con flecha (descargá app) |
| `ButtonIcon` | — | Icon-only botones |
| `Chip` | default, green, yellow, red, ghost | Filtros, tags, status |
| `Collapsible` | — | FAQ items, secciones plegables |
| `BannerAsset` | — | Banner editorial con imagen |
| `BannerIcon` | — | Banner con icono central |
| `BannerSimpleWithImage` | — | Banner CTA con thumbnail |
| `BannerSimpleWithoutImage` | — | Banner texto-only |
| `HeroPrimary` | — | Hero principal de landing |
| `HeroSecondary` | — | Hero secundario / sub-section |
| `HeroTitle` | — | Solo título grande (sub-componente) |
| `Icon` | catálogo en `/icons` | Icon system MODO |
| `LayoutContainer` | — | Wrapper con max-width responsivo |
| `Navbar` | — | Top navigation MODO |
| `Footer` | — | Footer MODO con links + logos |
| `PromotionCard` | — | Card de promo (estándar promos-hub) |
| `SectionBannerIcon` | — | Sección banner + icono |
| `SectionBlog` | — | Sección listado blog/articles |
| `SectionCarousel` | — | Carousel horizontal items |
| `SectionCollapsible` | — | Sección FAQ accordion |
| `SectionDual` | — | Sección 2-col (text + media) |
| `SectionGrid` | — | Sección grid N-col |
| `SectionRounded` | — | Sección con borders redondeados visibles |
| `SectionShapes` | — | Sección con shapes decorativas |
| `SectionVideo` | — | Sección con video player |
| `ThemeProvider` | — | Wrapper para theme switching (Patagonia, etc) |

**Prioridad**: SI el componente existe en la lib → úsalo. NO re-implementar localmente.

## Local helpers · `modo-landing/src/components/Shared/`

| Component | Path | Uso |
|---|---|---|
| `PageSeo` | `Shared/PageSeo` | SEO meta + JSON-LD wrapper |
| `Breadcrumb` | `Shared/Breadcrumb` | Breadcrumb visible (no solo JSON-LD) |
| `HeadWithSeo` | `Shared/HeadWithSeo` | Legacy — preferir PageSeo |
| `JsonLd` | `Shared/JsonLd` | Renderer puro de schema.org |
| `Logo` | `Shared/Logo` | MODO logo SVG |
| `Nav` | `Shared/Nav` | Navigation local (preferir Navbar de lib) |
| `Buttons` / `Buttonsv2` | `Shared/Buttons*` | Legacy buttons — preferir lib Button |
| `Typo` | `Shared/Typo` | Wrappers tipográficos legacy |
| `Pagination` | `Shared/Pagination` | Paginador para listings |
| `BlogMarkdown` | `Shared/BlogMarkdown` | Renderer Markdown blog |

## Feature components (modo-landing)

| Feature | Path | Components |
|---|---|---|
| Comercios | `components/Comercios/` | MerchantCard, MerchantGrid, MerchantHero, MerchantSidebar, HeroMerchantRotator, RubroChips, BankChip, PromoCard, FaqAccordion |
| Promos | `components/Promos/` (verificar) | — |
| CMS chrome | `CMS/NavFooterLayout` | Layout principal con nav + footer |

## Import canónico (Pages Router, Next 12)

```tsx
import NavFooterLayout from '../../CMS/NavFooterLayout';
import PageSeo, { PageSeoData } from '../../components/Shared/PageSeo';
import Breadcrumb from '../../components/Shared/Breadcrumb';
import { Button, Chip } from '@playsistemico/modo-ui-lib-web';
import { CANONICAL_BASE_URL, MODO_ORGANIZATION_JSONLD, MODO_WEBSITE_JSONLD } from '../../utils/seo';
import { getNavFooterData } from '../../CMS/utils/utils';
```

## Path aliases (tsconfig)

```
@Promotions/*  → src/promotionsTS/*
@Hooks/*       → src/hooks/*
@/CMS/*        → src/CMS/*
```

## Imágenes / assets canónicos

| Asset | Path |
|---|---|
| Logo verde solid | `/static/images/MODO_logo.svg` |
| Logo blanco | `/static/images/MODO_logo_white.svg` |
| Favicon | `/static/images/favicon.ico` |
| App Store badge | `APP_STORE_BADGE` (export desde `data/comercios/images`) |
| Google Play badge | `GOOGLE_PLAY_BADGE` (id.) |
