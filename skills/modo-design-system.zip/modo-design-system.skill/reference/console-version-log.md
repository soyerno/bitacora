# Console version log · recipes cross-stack

Pattern para que cada frontend MODO loguee `<name> v<version>` en browser console al cargar. Sirve para soporte (qué versión está viendo el user), Datadog RUM correlation, debugging cross-env.

## Filosofía

- **Build-time inject de strings**, no `import pkg from "./package.json"` en client code (bundlea TODO el JSON, leaks deps/scripts).
- **Una sola fuente**: leer `package.json` en config server-side, exponer 2 strings al client.
- **Libs NO logean**. Solo apps. Si una lib quiere identificarse, expone `export const VERSION` y la app consumidora decide loguear.
- **`globalThis`, no `window`/`global`** (ESLint unicorn rule MODO).

## Next 12 (Pages Router)

**`next.config.js`** — env block inyecta strings build-time:

```js
const pkg = require('./package.json');

module.exports = {
  env: {
    NEXT_PUBLIC_APP_NAME: pkg.name,
    NEXT_PUBLIC_APP_VERSION: pkg.version,
    // ...resto
  },
};
```

**`src/pages/_app.js`** — `useEffect` once:

```js
useEffect(() => {
  console.info(
    `${process.env.NEXT_PUBLIC_APP_NAME} v${process.env.NEXT_PUBLIC_APP_VERSION}`
  );
}, []);
```

## Next 15 / 16 (App Router)

**Patrón**: client component dedicado + import directo de pkg.json (TS `resolveJsonModule: true` ya activo en Next templates).

**`src/app/_version-logger.tsx`** — nuevo archivo:

```tsx
"use client";

import { useEffect } from "react";

import pkg from "../../package.json";

export default function VersionLogger() {
  useEffect(() => {
    console.info(`${pkg.name} v${pkg.version}`);
  }, []);

  return null;
}
```

**`src/app/layout.tsx`** — render junto a otros `_*-client.tsx`:

```tsx
import VersionLogger from "./_version-logger";

// dentro de <body>
<VersionLogger />
```

Nota: import de `package.json` en client component bundlea el JSON. Si pesa o tiene info sensible, usar el patrón Next 12 (env block + `process.env.NEXT_PUBLIC_*`).

### Next 16 — variantes recomendadas

Next 16 GA (octubre 2025) trae Turbopack default + React 19.2 + `next.config.ts` typed. Tres opciones, de mejor a peor según el caso:

**Opción A · server-only log via `<script>` en layout (recomendada Next 16)**

Cero client JS, cero hydration, cero bundle hit. El log corre en cuanto el HTML aterriza en el browser:

```tsx
// src/app/layout.tsx
import pkg from "../../package.json";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `console.info(${JSON.stringify(`${pkg.name} v${pkg.version}`)});`,
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
```

- ✅ `import pkg` corre server-side en build; **NO** bundlea el JSON al client.
- ✅ El `<script>` queda inline en el HTML del root layout — log antes de que React hidrate.
- ⚠️ Si el repo tiene CSP estricto sin `'unsafe-inline'` en `script-src`, usar el client-component pattern de arriba o agregar `nonce`. Frontends MODO en general ya tienen `'unsafe-inline'` en CSP report-only — verificar con `frontend-security-checklist` Layer 3.

**Opción B · `next.config.ts` typed env block (mismo patrón que Next 12)**

Si querés mantener el log atado a `process.env.NEXT_PUBLIC_*` (consistente con Datadog RUM wiring de promos-hub-site):

```ts
// next.config.ts (Next 16 recomienda config TypeScript)
import type { NextConfig } from "next";
import pkg from "./package.json" with { type: "json" };

const config: NextConfig = {
  env: {
    NEXT_PUBLIC_APP_NAME: pkg.name,
    NEXT_PUBLIC_APP_VERSION: pkg.version,
  },
};

export default config;
```

```tsx
// src/app/_version-logger.tsx — sin import del JSON
"use client";

import { useEffect } from "react";

export default function VersionLogger() {
  useEffect(() => {
    console.info(`${process.env.NEXT_PUBLIC_APP_NAME} v${process.env.NEXT_PUBLIC_APP_VERSION}`);
  }, []);
  return null;
}
```

`with { type: "json" }` (import attributes) es soportado a partir de Node 22 LTS + TypeScript 5.3. Si tu repo usa `tsx`/Turbopack con un toolchain viejo, fallback a `import pkg from "./package.json"` (sin attribute) — Next 16 lo sigue aceptando para configs.

**Opción C · client component pattern Next 15 (sigue funcionando)**

El bloque "Next 15 / 16 (App Router)" de arriba (con `_version-logger.tsx` + `import pkg from "../../package.json"`) sigue siendo válido en Next 16. Sin cambios. Sólo elegir A o B si querés evitar bundlear el JSON al client.

### Cuándo elegir cuál (Next 16)

| Constraint | Opción |
|---|---|
| CSP permite `'unsafe-inline'` o tenés nonce | **A** (server-only, cero client JS) |
| Datadog RUM ya lee `NEXT_PUBLIC_APP_VERSION` | **B** (env block, reusa el var) |
| CSP estricto sin nonce + sin RUM wiring | **C** (client component, bundlea JSON) |

## Vite (React)

**`vite.config.ts`** — `define` con strings JSON.stringify'd:

```ts
import { defineConfig } from "vite";
import pkg from "./package.json";

const APP_NAME = "<repo-name>"; // hardcode si pkg.json name es genérico

export default defineConfig({
  // ...
  define: {
    __APP_NAME__: JSON.stringify(APP_NAME),
    __APP_VERSION__: JSON.stringify(pkg.version),
  },
});
```

**`tsconfig.node.json`** (el que `include: ["vite.config.ts"]`) — debe tener `resolveJsonModule: true`. **NO es heredado automáticamente** por `moduleResolution: "bundler"`.

```jsonc
{
  "compilerOptions": {
    "moduleResolution": "bundler",
    "resolveJsonModule": true  // <-- mandatory si importás package.json
  }
}
```

**`src/vite-env.d.ts`** — declara globals:

```ts
/// <reference types="vite/client" />

declare const __APP_NAME__: string;
declare const __APP_VERSION__: string;
```

**`src/main.tsx`** — log antes del render:

```ts
console.info(`${__APP_NAME__} v${__APP_VERSION__}`);

createRoot(document.getElementById("root")!).render(<App />);
```

## Astro

**`src/layouts/BaseLayout.astro`** — frontmatter importa pkg (server-side, NO se bundlea al client), pasa strings al script inline via `define:vars`:

```astro
---
import pkg from '../../package.json';

const appName = pkg.name;
const appVersion = pkg.version;
---

<head>
  <!-- ... -->

  <script is:inline define:vars={{ appName, appVersion }}>
    console.info(`${appName} v${appVersion}`);
  </script>
</head>
```

Astro `astro/tsconfigs/base.json` ya incluye `resolveJsonModule: true` — el strict preset lo hereda. Sin config extra.

## Anti-patterns

- ❌ Importar `package.json` directo en client `_app.js` / `main.tsx` → bundlea deps + scripts (~10-50KB extra, leak superficie).
- ❌ Loguear desde libs (`@playsistemico/*`) en cada import → contamina consola del host.
- ❌ Usar `window.__APP_VERSION__` global → choca con DataDog `version` config (que YA usa `NEXT_PUBLIC_APP_VERSION` en promos-hub-site).
- ❌ Loguear en cada `useEffect` sin dep array `[]` → spam en cada render.
- ❌ Cambiar manualmente `version` en `package.json` para "testear el log" — los repos MODO usan semantic-release, los bumps son auto.

## Libs pattern (separado)

Apps logean su propia versión. Libs internas (`@playsistemico/modo-ui-lib-web`, `@playsistemico/modo-landing-web-ui-lib`) deben exportar `VERSION` constant desde su index, y la app consumidora decide si la logea:

```ts
// en lib: src/index.ts
export const VERSION = '__LIB_VERSION__'; // build-time inject desde su rollup/tsup config
```

```ts
// en app consumidora:
import { VERSION as UI_LIB_VERSION } from '@playsistemico/modo-ui-lib-web';
console.info(`modo-ui-lib-web v${UI_LIB_VERSION}`);
```

Razón: log on-import en lib = noise garantizado en cualquier host. Opt-in desde host = control fino.

## Caso canónico

Implementación cross-stack 2026-05-26 — 4 apps MODO en paralelo:

| App | Stack | Worktree | Output |
|---|---|---|---|
| modo-landing | Next 12 Pages | `.claude/worktrees/console-log-version` | `modo-landing v2.421.0` |
| promos-hub-site | Next 15 App Router | `.claude/worktrees/console-log-version` | `promos-hub-site v0.352.0` |
| aprendeatumodo | Vite | `.claude/worktrees/console-log-version` | `aprendeatumodo v0.0.0` ⚠️ |
| modo-landing-astro | Astro | (in-place, pre-init) | `modo-landing-astro v0.0.1` |

aprendeatumodo v0.0.0 porque pkg.name es leftover Lovable (`vite_react_shadcn_ts`) y semantic-release nunca corrió. Workaround: hardcodear `APP_NAME` en `vite.config.ts`.

**Update 2026-05-28** — modo-landing PR #1510 (`chore/console-log-version`) shipped el pattern Next 12 (Pages Router). Cuando la migración Next 16 (integration branch `feat/EXA-nextjs-12-to-16-migration`) aterrice en `main`, portar a Opción A (server-only `<script>` en root layout) — el `env` block en `next.config.ts` ya está disponible si preferís Opción B para reusar el var con Datadog RUM init.
