# Console version log · recipes cross-stack

Pattern para que cada frontend MODO loguee `<name> v<version>` en browser console al cargar. Sirve para soporte (qué versión está viendo el user), Datadog RUM correlation, debugging cross-env.

## Filosofía

- **Build-time inject de strings**, no `import pkg from "./package.json"` en client code (bundlea TODO el JSON, leaks deps/scripts).
- **Una sola fuente**: leer `package.json` en config server-side, exponer 2 strings al client.
- **Libs NO logean**. Solo apps. Si una lib quiere identificarse, expone `export const VERSION` y la app consumidora decide loguear.
- **`globalThis`, no `window`/`global`** (ESLint unicorn rule MODO).

## Next 12 (Pages Router)

**`next.config.js`** — env block inyecta strings build-time:

```js
const pkg = require('./package.json');

module.exports = {
  env: {
    NEXT_PUBLIC_APP_NAME: pkg.name,
    NEXT_PUBLIC_APP_VERSION: pkg.version,
    // ...resto
  },
};
```

**`src/pages/_app.js`** — `useEffect` once:

```js
useEffect(() => {
  console.info(
    `${process.env.NEXT_PUBLIC_APP_NAME} v${process.env.NEXT_PUBLIC_APP_VERSION}`
  );
}, []);
```

## Next 15 (App Router)

**Patrón**: client component dedicado + import directo de pkg.json (TS `resolveJsonModule: true` ya activo en Next templates).

**`src/app/_version-logger.tsx`** — nuevo archivo:

```tsx
"use client";

import { useEffect } from "react";

import pkg from "../../package.json";

export default function VersionLogger() {
  useEffect(() => {
    console.info(`${pkg.name} v${pkg.version}`);
  }, []);

  return null;
}
```

**`src/app/layout.tsx`** — render junto a otros `_*-client.tsx`:

```tsx
import VersionLogger from "./_version-logger";

// dentro de <body>
<VersionLogger />
```

Nota: import de `package.json` en client component bundlea el JSON. Si pesa o tiene info sensible, usar el patrón Next 12 (env block + `process.env.NEXT_PUBLIC_*`).

## Vite (React)

**`vite.config.ts`** — `define` con strings JSON.stringify'd:

```ts
import { defineConfig } from "vite";
import pkg from "./package.json";

const APP_NAME = "<repo-name>"; // hardcode si pkg.json name es genérico

export default defineConfig({
  // ...
  define: {
    __APP_NAME__: JSON.stringify(APP_NAME),
    __APP_VERSION__: JSON.stringify(pkg.version),
  },
});
```

**`tsconfig.node.json`** (el que `include: ["vite.config.ts"]`) — debe tener `resolveJsonModule: true`. **NO es heredado automáticamente** por `moduleResolution: "bundler"`.

```jsonc
{
  "compilerOptions": {
    "moduleResolution": "bundler",
    "resolveJsonModule": true  // <-- mandatory si importás package.json
  }
}
```

**`src/vite-env.d.ts`** — declara globals:

```ts
/// <reference types="vite/client" />

declare const __APP_NAME__: string;
declare const __APP_VERSION__: string;
```

**`src/main.tsx`** — log antes del render:

```ts
console.info(`${__APP_NAME__} v${__APP_VERSION__}`);

createRoot(document.getElementById("root")!).render(<App />);
```

## Astro

**`src/layouts/BaseLayout.astro`** — frontmatter importa pkg (server-side, NO se bundlea al client), pasa strings al script inline via `define:vars`:

```astro
---
import pkg from '../../package.json';

const appName = pkg.name;
const appVersion = pkg.version;
---

<head>
  <!-- ... -->

  <script is:inline define:vars={{ appName, appVersion }}>
    console.info(`${appName} v${appVersion}`);
  </script>
</head>
```

Astro `astro/tsconfigs/base.json` ya incluye `resolveJsonModule: true` — el strict preset lo hereda. Sin config extra.

## Anti-patterns

- ❌ Importar `package.json` directo en client `_app.js` / `main.tsx` → bundlea deps + scripts (~10-50KB extra, leak superficie).
- ❌ Loguear desde libs (`@playsistemico/*`) en cada import → contamina consola del host.
- ❌ Usar `window.__APP_VERSION__` global → choca con DataDog `version` config (que YA usa `NEXT_PUBLIC_APP_VERSION` en promos-hub-site).
- ❌ Loguear en cada `useEffect` sin dep array `[]` → spam en cada render.
- ❌ Cambiar manualmente `version` en `package.json` para "testear el log" — los repos MODO usan semantic-release, los bumps son auto.

## Libs pattern (separado)

Apps logean su propia versión. Libs internas (`@playsistemico/modo-ui-lib-web`, `@playsistemico/modo-landing-web-ui-lib`) deben exportar `VERSION` constant desde su index, y la app consumidora decide si la logea:

```ts
// en lib: src/index.ts
export const VERSION = '__LIB_VERSION__'; // build-time inject desde su rollup/tsup config
```

```ts
// en app consumidora:
import { VERSION as UI_LIB_VERSION } from '@playsistemico/modo-ui-lib-web';
console.info(`modo-ui-lib-web v${UI_LIB_VERSION}`);
```

Razón: log on-import en lib = noise garantizado en cualquier host. Opt-in desde host = control fino.

## Caso canónico

Implementación cross-stack 2026-05-26 — 4 apps MODO en paralelo:

| App | Stack | Worktree | Output |
|---|---|---|---|
| modo-landing | Next 12 Pages | `.claude/worktrees/console-log-version` | `modo-landing v2.421.0` |
| promos-hub-site | Next 15 App Router | `.claude/worktrees/console-log-version` | `promos-hub-site v0.352.0` |
| aprendeatumodo | Vite | `.claude/worktrees/console-log-version` | `aprendeatumodo v0.0.0` ⚠️ |
| modo-landing-astro | Astro | (in-place, pre-init) | `modo-landing-astro v0.0.1` |

aprendeatumodo v0.0.0 porque pkg.name es leftover Lovable (`vite_react_shadcn_ts`) y semantic-release nunca corrió. Workaround: hardcodear `APP_NAME` en `vite.config.ts`.
