# Brand voice — copy rules

> Para todo texto user-facing en páginas MODO. Aplica a hero, copy de cards, microcopy de botones, error states, empty states.

## Reglas duras

1. **Español rioplatense con voseo**. "Pagá / activá / descargá / mirá", no "Paga / activa / descarga / mira".
2. **Sin buzzwords corporativos**. PROHIBIDO: "stakeholders", "deliverables", "leverage", "synergy", "value proposition", "ecosistema disruptivo".
3. **Sin signos !!!**. Un punto basta. Excepción: copy CTA de muy alta urgencia (raro).
4. **Sin emojis** en copy de producto (sí ok en redes, en deck interno).
5. **Frases cortas**. Máximo 12-14 palabras por frase en copy de hero/card. Lede subtitle máximo 22 palabras.
6. **Plain Spanish**. Sin "experiencia disruptiva", "solución integral", "valor agregado".
7. **Concreto > abstracto**. "30% de descuento en Coto los miércoles" > "Beneficios exclusivos en supermercados".
8. **Sin claim falso**. Si decís "el más grande", tenés que tener data pública para probarlo.
9. **Plural ARG**. "Banco Galicia, Banco Macro, BBVA", no "Banco Galicia, Bancos Macro, BBVA Argentina S.A.".

## Test rápido

Leelo en voz alta. ¿Suena a vos hablándole a tu vieja? Pasa. ¿Suena a consultora? No pasa.

## Patrones de copy validados

### Hero title (H1)

Foco: **acción + beneficio**. Vos como sujeto.

✅ "Pagá con MODO. Ahorrá en miles de comercios."
✅ "Recargá tu SUBE desde tu banco."
✅ "Cobrá con MODO en tu comercio. Sin terminal."
❌ "Una experiencia de pago disruptiva." (vacío)
❌ "MODO: la solución integral de pagos." (vendor pitch)

### Hero subtitle

Foco: **3 hechos concretos**, idealmente con números.

✅ "Descuentos exclusivos y cuotas sin interés todos los días, en supermercados, gastronomía, indumentaria y más."
❌ "Descubrí el ecosistema MODO." (no dice nada)

### Eyebrow chip

Foco: **dato verificable**, corto, en frase nominal.

✅ "Más de 2.500 comercios adheridos"
✅ "Hasta 31 mayo"
✅ "Gastronomía"
❌ "Increíble oportunidad" (vacío)

### CTA primario

Foco: **verbo + objeto**. Imperativo voseo.

✅ "Activá MODO"
✅ "Descargá la app"
✅ "Ver todas las promos"
❌ "Empezar ahora" (genérico)
❌ "Click aquí" (nunca)

### Stats label

Foco: **sustantivo plural** corto, lowercase.

✅ "comercios adheridos"
✅ "bancos con promo"
✅ "de descuento máximo"
❌ "Comercios Adheridos" (Title Case innecesario)
❌ "+2.500 comercios" (el número va aparte)

### App banner CTA

✅ "¿Todavía no tenés MODO?"
✅ "Activá MODO desde la app de tu banco. Sin sumar otra app. Sin trámites."
❌ "Descargá nuestra app revolucionaria." (vendor)

## MODO + bancos en narrativa

- En **JSON-LD**: listar las 37 BankOrCreditUnion completas (datos estructurados → SEO).
- En **prose de página**: decir "red MODO" o "ecosistema MODO" sin listar nombres (ruido para usuario).
- Excepción: páginas dedicadas tipo `/promos-banco/<slug>` — ahí sí mencionar el banco específico.

## Estilo signo

- Separador en listas: `·` (interpunto), no `—` (em dash).
- Rangos: `9–18 h`, `lunes a viernes` (no "Mon-Fri").
- Moneda: `$3.000`, no `ARS 3000` ni `$3,000`.
- Porcentajes: `30%`, no `30 %`.
- Fechas: `31 de mayo` o `31/05`, no `May 31`.

## Errores comunes a evitar

| Mal | Bien |
|---|---|
| "MODO es una solución..." | "Pagá con MODO." |
| "Estamos lanzando..." | "Ya está disponible." |
| "Una nueva experiencia" | "Descuentos en Coto." |
| "Próximamente" | (no usar — confirmar fecha o no decir) |
| "Click aquí" | "Ver detalles" |
| "Más info" | "Cómo funciona" |
| "Estimado usuario" | "Hola" / "Hola Hernán" |
