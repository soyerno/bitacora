# Page patterns — recetas canónicas

> Patrones observados en producción (modo-landing). Cada uno tiene template asociado en `templates/`.

## Pattern 1 · Listing programático (ej. `/comercios`, `/promos`)

**Cuándo**: catálogo enumerable con N items, filtros opcionales, ISR.

**Estructura**:

```
NavFooterLayout(navFooter)
  PageSeo({ Organization, WebSite, Collection, Breadcrumb, ItemList })
  ├── Hero verde (bg-primary-PaymentDefault, py heavy)
  │   ├── Eyebrow chip (white border, dot reward yellow)
  │   ├── H1 quicksand bold (-0.025em letter-spacing)
  │   ├── Subtitle text-base lg:text-[17px] white/90
  │   ├── Search form (rounded-[10px] input + amarillo button)
  │   ├── Stats divider (border-t white/25 pt-6)
  │   └── Side card rotator (lg:block only)
  ├── RubroChips (filter row, sticky opcional)
  └── max-w-[1260px] container
      ├── Featured section (4-col grid, tones: green/blue/dark/yellow)
      ├── All items section (Grid + count)
      ├── Editorial mosaic (2×4 photos)
      └── App banner CTA gradient (PaymentDefault → PaymentDark)
```

**Data**:
- `getStaticProps`: `Promise.all([getAllItems(), getNavFooterData(), getStoryblokEditorial()])`
- `revalidate: 3600`
- Editorial Storyblok overrides defaults inline

**SEO mínimo**:
- `Organization` + `WebSite` (siempre)
- `CollectionPage` (tipo principal)
- `BreadcrumbList` (Home → Listing)
- `ItemList` (con `itemListElement` enumerando los N items)

**Template**: `templates/page-listing.next12.tmpl`

---

## Pattern 2 · Detail page (ej. `/comercios/[slug]`)

**Cuándo**: ficha individual de un item del listing, paths estáticos pre-generados.

**Estructura**:

```
NavFooterLayout(navFooter)
  PageSeo({ Organization, WebSite, LocalBusiness|Product|Service, Breadcrumb, Offer*, FAQPage })
  Breadcrumb (visible, encima del hero)
  MerchantHero (gradient brand color, logo + name + best promo chip)
  Container max-w-[1260px] grid (lg:grid-cols-[1fr_360px])
    main:
      ├── Description section (Red Hat 16/22)
      ├── Promos grid (PromoCard array)
      ├── FAQ accordion (FAQPage JSON-LD coordinated)
      └── Related items grid (4-col)
    sidebar:
      ├── Channels (web/app/store list)
      ├── Banks aceptados
      └── CTA descargá MODO (sticky lg:top-24)
```

**Data**:
- `getStaticPaths`: `paths: items.map(slug)`, `fallback: 'blocking'`
- `getStaticProps`: `Promise.all([getItemBySlug, getRelated, getNavFooter, getEditorial])`
- `revalidate: 3600`

**SEO mínimo**:
- `Organization` + `WebSite`
- Schema apropiado al tipo (`LocalBusiness`, `Product`, `Service`, `Article`)
- `BreadcrumbList` con 3 niveles (Home → Listing → Item)
- `Offer` array si hay promos
- `FAQPage` si hay accordion

**Template**: `templates/page-detail.next12.tmpl`

---

## Pattern 3 · Landing institucional (ej. `/modo-en-tu-comercio`, `/pagar`)

**Cuándo**: storytelling vertical, CTA descargá, mix de secciones editoriales.

**Estructura**:

```
NavFooterLayout
  PageSeo({ Organization, WebSite, Service|Product, Breadcrumb })
  Hero asimétrico (foto right, copy left, CTA app badges)
  Secciones modulares (cualquier orden):
    ├── Section "cómo funciona" (3 pasos numbered)
    ├── Section "beneficios" (icon grid)
    ├── Section testimonios o "para vos" (carousel)
    ├── Section bancos asociados (logo grid)
    ├── Section FAQ
    └── Section CTA final (App Store + Google Play)
```

**Data**:
- Mayormente static (`getStaticProps` sin revalidate o ISR largo).
- Copy desde Storyblok opcionalmente.

**Template**: `templates/page-landing.next12.tmpl`

---

## Pattern 4 · FAQ page (ej. `/ayuda/<topic>`)

**Cuándo**: lista pregunta/respuesta indexada en Google AI overviews.

**Estructura**:

```
NavFooterLayout
  PageSeo({ Organization, WebSite, FAQPage, Breadcrumb })
  Breadcrumb visible
  Hero compacto (h1 + descripción)
  Search input (filtra preguntas in-page)
  FAQ accordion (sticky h2 por categoría)
  CTA footer "no encontraste lo que buscabas"
```

**SEO crítico**: `FAQPage` con `mainEntity: [{ Question, acceptedAnswer }]` para cada item.

**Template**: `templates/page-faq.next12.tmpl`

---

## Pattern 5 · Bank-specific page (ej. `/promos-banco/<slug>`)

**Cuándo**: página dedicada a promos de un banco asociado.

**Diferencia clave**: theme switching via `<html data-theme="<Bank>">` y override de `--sdk-colors-*`.

**Estructura**:
- Similar al listing pattern, pero hero usa colors del banco.
- Logo del banco prominente (asociación + MODO mark).
- Filtro por categoría + listing.

**Template**: `templates/page-bank.next12.tmpl`

---

## Patrón común a todos: chrome canónico

### Hero verde reusable

```tsx
<section className="relative overflow-hidden bg-primary-PaymentDefault px-4 pb-14 pt-10 text-primary-white lg:px-6 lg:pb-20 lg:pt-14">
  {/* Ambient gradient backdrop (always) */}
  <div
    aria-hidden="true"
    className="pointer-events-none absolute inset-0"
    style={{
      background:
        'radial-gradient(ellipse 900px 500px at 90% 0%, rgba(255,199,56,0.22), transparent 60%), radial-gradient(ellipse 700px 400px at 10% 100%, rgba(255,255,255,0.14), transparent 60%)',
    }}
  />
  <div className="relative mx-auto grid max-w-[1260px] items-center gap-8 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-12">
    {/* Left: eyebrow + h1 + subtitle + CTA + stats */}
    {/* Right: rotator / asset (lg:block only) */}
  </div>
</section>
```

### Stats divider

```tsx
<div className="mt-8 flex flex-wrap gap-6 border-t border-white/25 pt-6 lg:gap-10">
  {stats.map(s => (
    <div key={s.label}>
      <div
        className={`font-quicksand text-2xl font-bold leading-none lg:text-[32px] ${
          s.highlight ? 'text-promotions-PrimaryRewards' : 'text-primary-white'
        }`}
        style={{ letterSpacing: '-0.025em' }}
      >{s.value}</div>
      <div className="mt-1 text-xs text-white/80">{s.label}</div>
    </div>
  ))}
</div>
```

### Featured 4-col tones

Tonos disponibles + cuándo usar:
- `green` — destacado principal, mayor jerarquía
- `blue` — categoría send/transferencia
- `dark` (gradient) — premium / cuotas
- `yellow` — rewards / urgencia / vence pronto

### App banner CTA

```tsx
<div className="mt-10 flex flex-col gap-4 rounded-[14px] bg-gradient-to-br from-primary-PaymentDefault to-primary-PaymentDark p-6 text-primary-white lg:flex-row lg:items-center lg:justify-between lg:p-8">
  <div>
    <h3 className="font-quicksand text-xl font-bold" style={{ letterSpacing: '-0.02em' }}>
      ¿Todavía no tenés MODO?
    </h3>
    <p className="mt-1 text-[13.5px] text-white/65">Activá MODO desde la app de tu banco.</p>
  </div>
  <div className="flex flex-wrap gap-2">
    <a href="https://apps.apple.com/ar/app/modo/id1521919765" aria-label="Descargar MODO en App Store">
      <img src={APP_STORE_BADGE} alt="App Store" className="h-10" />
    </a>
    <a href="https://play.google.com/store/apps/details?id=ar.com.modo" aria-label="Descargar MODO en Google Play">
      <img src={GOOGLE_PLAY_BADGE} alt="Google Play" className="h-10" />
    </a>
  </div>
</div>
```
