# Page patterns — recetas canónicas

> Patrones observados en producción (modo-landing). Cada uno tiene template asociado en `templates/`.

## Pattern 1 · Listing programático (ej. `/comercios`, `/promos`)

**Cuándo**: catálogo enumerable con N items, filtros opcionales, ISR.

**Estructura**:

```
NavFooterLayout(navFooter)
  PageSeo({ Organization, WebSite, Collection, Breadcrumb, ItemList })
  ├── Hero verde (bg-primary-PaymentDefault, py heavy)
  │   ├── Eyebrow chip (white border, dot reward yellow)
  │   ├── H1 quicksand bold (-0.025em letter-spacing)
  │   ├── Subtitle text-base lg:text-[17px] white/90
  │   ├── Search form (rounded-[10px] input + amarillo button)
  │   ├── Stats divider (border-t white/25 pt-6)
  │   └── Side card rotator (lg:block only)
  ├── RubroChips (filter row, sticky opcional)
  └── max-w-[1260px] container
      ├── Featured section (4-col grid, tones: green/blue/dark/yellow)
      ├── All items section (Grid + count)
      ├── Editorial mosaic (2×4 photos)
      └── App banner CTA gradient (PaymentDefault → PaymentDark)
```

**Data**:
- `getStaticProps`: `Promise.all([getAllItems(), getNavFooterData(), getStoryblokEditorial()])`
- `revalidate: 3600`
- Editorial Storyblok overrides defaults inline

**SEO mínimo**:
- `Organization` + `WebSite` (siempre)
- `CollectionPage` (tipo principal)
- `BreadcrumbList` (Home → Listing)
- `ItemList` (con `itemListElement` enumerando los N items)

**Template**: `templates/page-listing.next12.tmpl`

---

## Pattern 2 · Detail page (ej. `/comercios/[slug]`)

**Cuándo**: ficha individual de un item del listing, paths estáticos pre-generados.

**Estructura**:

```
NavFooterLayout(navFooter)
  PageSeo({ Organization, WebSite, LocalBusiness|Product|Service, Breadcrumb, Offer*, FAQPage })
  Breadcrumb (visible, encima del hero)
  MerchantHero (gradient brand color, logo + name + best promo chip)
  Container max-w-[1260px] grid (lg:grid-cols-[1fr_360px])
    main:
      ├── Description section (Red Hat 16/22)
      ├── Promos grid (PromoCard array)
      ├── FAQ accordion (FAQPage JSON-LD coordinated)
      └── Related items grid (4-col)
    sidebar:
      ├── Channels (web/app/store list)
      ├── Banks aceptados
      └── CTA descargá MODO (sticky lg:top-24)
```

**Data**:
- `getStaticPaths`: `paths: items.map(slug)`, `fallback: 'blocking'`
- `getStaticProps`: `Promise.all([getItemBySlug, getRelated, getNavFooter, getEditorial])`
- `revalidate: 3600`

**SEO mínimo**:
- `Organization` + `WebSite`
- Schema apropiado al tipo (`LocalBusiness`, `Product`, `Service`, `Article`)
- `BreadcrumbList` con 3 niveles (Home → Listing → Item)
- `Offer` array si hay promos
- `FAQPage` si hay accordion

**Template**: `templates/page-detail.next12.tmpl`

---

## Pattern 3 · Landing institucional (ej. `/modo-en-tu-comercio`, `/pagar`)

**Cuándo**: storytelling vertical, CTA descargá, mix de secciones editoriales.

**Estructura**:

```
NavFooterLayout
  PageSeo({ Organization, WebSite, Service|Product, Breadcrumb })
  Hero asimétrico (foto right, copy left, CTA app badges)
  Secciones modulares (cualquier orden):
    ├── Section "cómo funciona" (3 pasos numbered)
    ├── Section "beneficios" (icon grid)
    ├── Section testimonios o "para vos" (carousel)
    ├── Section bancos asociados (logo grid)
    ├── Section FAQ
    └── Section CTA final (App Store + Google Play)
```

**Data**:
- Mayormente static (`getStaticProps` sin revalidate o ISR largo).
- Copy desde Storyblok opcionalmente.

**Template**: `templates/page-landing.next12.tmpl`

---

## Pattern 4 · FAQ page (ej. `/ayuda/<topic>`)

**Cuándo**: lista pregunta/respuesta indexada en Google AI overviews.

**Estructura**:

```
NavFooterLayout
  PageSeo({ Organization, WebSite, FAQPage, Breadcrumb })
  Breadcrumb visible
  Hero compacto (h1 + descripción)
  Search input (filtra preguntas in-page)
  FAQ accordion (sticky h2 por categoría)
  CTA footer "no encontraste lo que buscabas"
```

**SEO crítico**: `FAQPage` con `mainEntity: [{ Question, acceptedAnswer }]` para cada item.

**Template**: `templates/page-faq.next12.tmpl`

---

## Pattern 5 · Bank-specific page (ej. `/promos-banco/<slug>`)

**Cuándo**: página dedicada a promos de un banco asociado.

**Diferencia clave**: theme switching via `<html data-theme="<Bank>">` y override de `--sdk-colors-*`.

**Estructura**:
- Similar al listing pattern, pero hero usa colors del banco.
- Logo del banco prominente (asociación + MODO mark).
- Filtro por categoría + listing.

**Template**: `templates/page-bank.next12.tmpl`

---

## Patrón común a todos: chrome canónico

### Hero verde reusable

```tsx
<section className="relative overflow-hidden bg-primary-PaymentDefault px-4 pb-14 pt-10 text-primary-white lg:px-6 lg:pb-20 lg:pt-14">
  {/* Ambient gradient backdrop (always) */}
  <div
    aria-hidden="true"
    className="pointer-events-none absolute inset-0"
    style={{
      background:
        'radial-gradient(ellipse 900px 500px at 90% 0%, rgba(255,199,56,0.22), transparent 60%), radial-gradient(ellipse 700px 400px at 10% 100%, rgba(255,255,255,0.14), transparent 60%)',
    }}
  />
  <div className="relative mx-auto grid max-w-[1260px] items-center gap-8 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-12">
    {/* Left: eyebrow + h1 + subtitle + CTA + stats */}
    {/* Right: rotator / asset (lg:block only) */}
  </div>
</section>
```

### Stats divider

```tsx
<div className="mt-8 flex flex-wrap gap-6 border-t border-white/25 pt-6 lg:gap-10">
  {stats.map(s => (
    <div key={s.label}>
      <div
        className={`font-quicksand text-2xl font-bold leading-none lg:text-[32px] ${
          s.highlight ? 'text-promotions-PrimaryRewards' : 'text-primary-white'
        }`}
        style={{ letterSpacing: '-0.025em' }}
      >{s.value}</div>
      <div className="mt-1 text-xs text-white/80">{s.label}</div>
    </div>
  ))}
</div>
```

### Featured 4-col tones

Tonos disponibles + cuándo usar:
- `green` — destacado principal, mayor jerarquía
- `blue` — categoría send/transferencia
- `dark` (gradient) — premium / cuotas
- `yellow` — rewards / urgencia / vence pronto

### App banner CTA

```tsx
<div className="mt-10 flex flex-col gap-4 rounded-[14px] bg-gradient-to-br from-primary-PaymentDefault to-primary-PaymentDark p-6 text-primary-white lg:flex-row lg:items-center lg:justify-between lg:p-8">
  <div>
    <h3 className="font-quicksand text-xl font-bold" style={{ letterSpacing: '-0.02em' }}>
      ¿Todavía no tenés MODO?
    </h3>
    <p className="mt-1 text-[13.5px] text-white/65">Activá MODO desde la app de tu banco.</p>
  </div>
  <div className="flex flex-wrap gap-2">
    <a href="https://apps.apple.com/ar/app/modo/id1521919765" aria-label="Descargar MODO en App Store">
      <img src={APP_STORE_BADGE} alt="App Store" className="h-10" />
    </a>
    <a href="https://play.google.com/store/apps/details?id=ar.com.modo" aria-label="Descargar MODO en Google Play">
      <img src={GOOGLE_PLAY_BADGE} alt="Google Play" className="h-10" />
    </a>
  </div>
</div>
```

## Pattern 6 · Course/Material detail con carousel de módulos

Detalle de pieza educativa donde el contenido se divide en módulos y se renderea como **carousel paginado** (un módulo a la vez) en vez de scroll continuo.

**Trigger**: pieza con `<h3>Módulo N>` repetidos, lectura larga (>5 min), perfil pedagógico.

**Caso canónico**: `aprendeatumodo/src/pages/CoursePage.tsx` + `src/components/courses/CourseModuleCarousel.tsx` (2026-05-22).

### Layout completo

```
┌────────────────────────────────────────────────────┐
│ Navbar MODO (fixed top, h-24, z-50)                │
├────────────────────────────────────────────────────┤
│ Sticky course header (top-24, z-30)                │
│ ← Volver · 🛡 Título curso · Curso N de M · X min  │
│ ▓▓▓▓░░░░░░░░░░  course-level progress              │
├────────────────────────────────────────────────────┤
│ Sticky module bar (top-{course_header_height})     │
│ ◀ Módulo N de M · • • • · ▶  + reading time        │
├────────────────────────────────────────────────────┤
│ Slide container (rounded-[20px] bg-primary-white)  │
│                                                    │
│ MÓDULO N DE M (eyebrow uppercase verde)            │
│ ¿Por qué importa esto? (h2 font-quicksand display) │
│ Subtitle Red Hat (caption)                         │
│                                                    │
│ Body · Prose / Callout / Tile / Step               │
└────────────────────────────────────────────────────┘
```

### Estructura de data (shape pattern)

NO parsear `React.Children` ni hacer DOM walk. Refactorear cada `*CourseContent.tsx` a exportar **data**:

```ts
// src/components/courses/types.ts
export interface CourseModule {
  id: string;
  number: number;
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  minutes: number;
  content: React.ReactNode; // JSX listo
}

export interface CourseContentShape {
  intro?: React.ReactNode;
  modules: CourseModule[];
  outro?: React.ReactNode;
}
```

```ts
// src/components/courses/SecurityCourseContent.tsx
export const securityCourseContent: CourseContentShape = {
  intro: <Callout tone="info" emoji="🛡">En este material vas a aprender…</Callout>,
  modules: [
    {
      id: "por-que-importa",
      number: 1,
      title: "¿Por qué importa esto?",
      subtitle: "La seguridad digital es cosa de todos",
      icon: Lightbulb,
      minutes: 2,
      content: (
        <>
          <Prose>Cada vez usamos más el celu…</Prose>
          <Callout tone="warning">…</Callout>
        </>
      ),
    },
    // …N módulos
  ],
};
```

**Beneficios vs DOM walk**:
- Type-safe
- Reading time per módulo trivial (no calcular post-render)
- Carousel 100% controlado (no `Children.toArray` hacks)
- Tests más fáciles (mock data, no mock JSX)

**Costo**: refactor N archivos legacy. Amortizado por primitives compartidos (`Prose`, `Tile`, `Step`, `Callout`, `SubHeading` en `moduleStyles.tsx`).

### Carousel features obligatorias

| Feature | Implementation |
|---------|----------------|
| URL state | `?modulo=N` via React Router `useNavigate({ replace: false })` para back/forward browser |
| State init | `useMemo` desde `location.search`, clamp a rango válido |
| Keyboard nav | ← → Home End sobre el region `[aria-roledescription="carrusel"]` |
| Focus management | `<h2>` del slide `tabIndex={-1}` + `.focus({ preventScroll: true })` en cada change |
| Live region | `role="status" aria-live="polite"` con "Mostrando Módulo N de M: <title>" |
| `prefers-reduced-motion` | Hook `usePrefersReducedMotion` → desactiva transition |
| Print mode | `@media print` renderea TODOS los módulos (override carousel hide) |
| CTA final | Último módulo del último curso → "Volver al listado". Otros → "Siguiente curso: <title>" |

### A11y contract del carousel

```tsx
<section
  role="region"
  aria-roledescription="carrusel"
  aria-label={`Módulos del curso ${courseTitle}`}
>
  {modules.map((m, i) => (
    <article
      key={m.id}
      role="group"
      aria-roledescription="diapositiva"
      aria-label={`Módulo ${m.number} de ${total}: ${m.title}`}
      hidden={i !== current}
    >
      {m.content}
    </article>
  ))}
  <div role="status" aria-live="polite" className="sr-only">
    {announceText}
  </div>
</section>
```

### Sticky no pisa footer (IntersectionObserver pattern)

El sticky course header puede coexistir visualmente con el Footer al final del scroll (overlap no-geométrico pero visual). Pattern para hide elegante:

```tsx
const footerSentinelRef = useRef<HTMLDivElement | null>(null);
const [footerVisible, setFooterVisible] = useState(false);

useEffect(() => {
  const node = footerSentinelRef.current;
  if (!node) return;
  const obs = new IntersectionObserver(
    ([entry]) => setFooterVisible(entry.isIntersecting),
    { rootMargin: "0px", threshold: 0 }
  );
  obs.observe(node);
  return () => obs.disconnect();
}, []);

// En el JSX:
<div className="relative">  {/* sticky context wrapper */}
  <div
    className={`sticky top-24 z-30 … transition-opacity duration-300 ${
      footerVisible ? "opacity-0 pointer-events-none" : "opacity-100"
    }`}
    aria-hidden={footerVisible ? "true" : undefined}
  >
    {/* sticky content */}
  </div>
  <main>…</main>
</div>
{/* Sentinel triggerea el hide cuando entra al viewport */}
<div ref={footerSentinelRef} aria-hidden="true" className="h-px" />
<Footer />
```

**Por qué `opacity-0` y NO `translate-y-full`**: el sticky tiene `top-24` (96px). `translate-y-full` solo lo mueve por su altura (~80px), dejando un sliver de 16px visible. Opacity es clean.

### `scroll-padding-top` compensa fixed bars

Cuando hay barras fijas (Navbar + sticky header), hash anchors quedan tapados. Fix global en `index.css`:

```css
html {
  scroll-behavior: smooth;
  /* Navbar h-24 (96px) + sticky course header (~80px) ≈ 176px */
  scroll-padding-top: 11rem;
}
```

Aplica a:
- Hash anchor click (`<a href="#x">`)
- `scrollIntoView({ block: "start" })`
- Browser autocomplete jump to field

### Tokens canónicos en Tailwind v4 — pitfall

CSS vars HSL legacy (`--modo-green-dark: 150 100% 14%`) **no resuelven bien** cuando se usan via `bg-modo-green-dark` en Tailwind v4. axe reporta el computed color como blendeado con el padre (`#008a4c` en lugar del esperado `#00471B`).

**Workaround**: usar los tokens canónicos directos (`bg-primary-PaymentDark`, `bg-primary-PaymentDefault`, etc.) que están declarados con hex sólido en `@theme inline`. Reservar los `bg-modo-*` legacy solo para casos donde no haya equivalente canónico.

Caso canónico: AboutSection banner promos · cambio `bg-modo-green-dark/80` → `bg-primary-PaymentDark` para que pase contrast AA.

## Anti-pattern · CTA verde repintado por `group-hover` del card padre

**Síntoma**: dentro de un `<Card className="group ...">`, un CTA tipo "Ver material" usa `variant="modo-secondary"` (blanco/verde) + `group-hover:bg-primary-PaymentDefault group-hover:text-primary-white` para volverse verde al hacer hover sobre el card padre.

**Por qué es anti-pattern**:
- El verde aparece "antes de tiempo" — cuando el cursor entra al área del card pero no al botón, comunicando un estado de interacción que no se está produciendo.
- Confunde la jerarquía: el card y el CTA pelean por la affordance.
- Sobre-anima en cards que ya tienen `hover:-translate-y-0.5 hover:border-tertiary-Gray20 hover:shadow-sm` — demasiada superficie en movimiento.

**Patrón correcto · CTA primario permanente**: usar `variant="modo-primary"` (verde por default + `hover:bg-primary-PaymentDark` propio) sin `group-hover` alguno.

```tsx
// ❌ NO
<Card className="group ...">
  ...
  <Button
    variant="modo-secondary"
    asChild
    className="w-full group-hover:bg-primary-PaymentDefault group-hover:text-primary-white group-hover:ring-primary-PaymentDefault transition-all"
  >
    <Link to={`/curso/${slug}`}>Ver material</Link>
  </Button>
</Card>

// ✅ SÍ
<Card className="group ...">
  ...
  <Button variant="modo-primary" asChild className="w-full">
    <Link to={`/curso/${slug}`}>Ver material</Link>
  </Button>
</Card>
```

**Qué SÍ podés repintar con `group-hover`**:
- `CardTitle` cambiando `text-*` a verde (cambio sutil, refuerza affordance del card como link area).
- `border-tertiary-Gray8 → border-tertiary-Gray20` del card.
- `shadow-sm` + `translate-y-0.5` del card.

**Qué NO repintes con `group-hover`**:
- CTAs primarios (botones de acción principal — confunde estado).
- Iconos del CTA primario.
- Backgrounds de tarjetas internas con jerarquía propia.

**Test rápido**: ¿el elemento que cambia ES el target de la acción, o un decorador? Solo decoradores se pintan en `group-hover`. Targets reales viven con su propio `hover:`.

**Caso canónico**: aprendeatumodo `CoursesSection.tsx` línea 290 (commit en branch `feat/accessibility-wcag-aa`, 2026-05-22).

## Ancho canónico content · `max-w-[1216px]`

El Navbar de `@playsistemico/modo-landing-web-ui-lib` usa `max-w-[1216px]` en su pill principal (1152px renderizado en viewport 1280, con 64px padding lateral). Para coherencia visual horizontal con el chrome del sitio:

**Regla:** todo container content de proyectos MODO con la lib externa Navbar/Footer debe usar `max-w-[1216px] mx-auto px-4` (NO `container mx-auto px-4` solo, que en Tailwind v4 da `width: 100%` con breakpoints sin max-width determinístico).

```tsx
// ✅ Correcto · alineado con Navbar MODO
<div className="max-w-[1216px] mx-auto px-4">
  ...content
</div>

// ❌ Incorrecto · Tailwind v4 `container` resuelve a 100% width
<div className="container mx-auto px-4">
  ...content
</div>
```

Excepciones:
- Brand shapes decorativas (absolute positioned) pueden sobresalir hacia los bordes del viewport.
- Backgrounds full-bleed (e.g., `bg-primary` del About section) van en el `<section>` padre — el max-w-[1216px] es solo del container interno.

**Caso canónico:** aprendeatumodo (2026-05-23) · 5 sections del home + course detail (article + course header pill + sticky module bar) todos con `max-w-[1216px]` para matchear el Navbar.

## Anti-pattern · Tailwind v4 `container` sin custom config

En Tailwind v4 sin `tailwind.config.ts` que defina `theme.container.maxWidth`, la utility `container` resuelve a:
- `width: 100%`
- Responsive breakpoints (sm/md/lg/xl/2xl) con max-width incremental
- En viewport ≥1280px (xl): max-width = 1280px (≠ 1216 del Navbar MODO)

**Fix:** usar `max-w-[1216px] mx-auto` explícito (NO `container mx-auto`).

## Course detail header · in-flow pill al top del article

Patrón refinado del Course detail (`/curso/:slug`) tras iteración con user feedback:

```tsx
<main className="max-w-[1216px] mx-auto px-4 sm:px-6 pt-32 md:pt-36 pb-8 md:pb-12">
  <article className="max-w-[1216px] mx-auto">
    {/* Course header · pill in-flow (NO fixed, NO sticky) al top del article.
        Scrollea con el contenido y desaparece naturalmente.
        Reaparece en cada navegación de módulo (Carousel hace
        scrollIntoView al #course-title). */}
    <div
      className="bg-primary-white rounded-[20px] shadow-[0_4px_12px_rgba(0,0,0,0.08)] border border-tertiary-Gray8 overflow-hidden mb-6"
      role="region"
      aria-label={`Encabezado del curso ${course.title}`}
    >
      <div className="px-4 sm:px-6 py-3 sm:py-3.5">
        <div className="flex items-center gap-3 md:gap-4">
          <Button variant="modo-secondary" size="sm" asChild className="h-9">
            <Link to="/#cursos">← Volver</Link>
          </Button>
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="p-2 rounded-2xl bg-sdk-brand-green-green-10 flex-shrink-0">
              <Icon className="h-5 w-5 text-primary-PaymentDark" />
            </div>
            <div className="min-w-0">
              <h1
                id="course-title"
                className="font-quicksand font-bold text-base md:text-lg text-primary-black truncate scroll-mt-32 md:scroll-mt-36"
                style={{ letterSpacing: "-0.018em" }}
              >
                {course.title}
              </h1>
              <p className="font-red-hat text-xs text-tertiary-darkGray">
                Curso N de M · ~X min total
              </p>
            </div>
          </div>
        </div>
        {/* Course-level progress bar */}
        <div className="mt-3 h-1 bg-tertiary-Gray8 rounded-full overflow-hidden" role="progressbar">
          <div
            className="h-full bg-primary-PaymentDefault transition-[width] duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>

    <CourseModuleCarousel ... />
  </article>
</main>
```

**Reglas:**
- Header in-flow (NO fixed/sticky) → scroll lo lleva out of view naturalmente
- `<h1 id="course-title">` con `scroll-mt-32 md:scroll-mt-36` → cuando Carousel hace `scrollIntoView` al cambiar módulo, el `scroll-margin-top` compensa el Navbar fixed (h-24) + gap
- `<main pt-32 md:pt-36>` compensa el Navbar fixed (no necesita compensar header porque está in-flow)
- Sticky module bar abajo (del CourseModuleCarousel) sigue siendo `fixed bottom-0` con mismo `max-w-[1216px]`

**Diferencia con Pattern 6 original:** ese decía `<h2>` del slide con `scroll-mt-24` (cuando el header era sticky/fixed). Esta versión es in-flow → menos magia, scroll natural, scroll-margin solo en el id target del scrollIntoView del Carousel.
