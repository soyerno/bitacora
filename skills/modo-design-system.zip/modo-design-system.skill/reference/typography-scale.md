# Typography scale — Tailwind classes vs uso semántico

Verdad: `modo-landing/tailwind.config.js:105–397`.

## Headings legacy (Red Hat heredada)

Estas clases NO declaran fontFamily — heredan de `html { font-family: 'Red Hat Display' }`. Para display Quicksand hay que combinar con `font-quicksand` o agregar inline.

| Tw class | Web | Mobile | Uso |
|---|---|---|---|
| `text-h1-web` / `text-h1-mobile` | 56/56 | 40/53 | H1 raw |
| `text-h2-web` / `text-h2-mobile` | 48/56 | 32/30 | H2 raw |
| `text-h3-web` / `text-h3-mobile` | 40/74 | 24/30 | H3 raw |
| `text-h4-web` / `text-h4-mobile` | 32/42 | 22/30 | H4 raw |
| `text-h5-web` / `text-h5-mobile` | 24/56 | 20/28 | H5 raw |
| `text-h6-web` / `text-h6-mobile` | 24/30 | 18/25 | H6 raw |

## Body / paragraph

| Tw class | Web | Mobile | Uso |
|---|---|---|---|
| `text-p1-web` / `text-p1-mobile` | 24/34 | 16/22 | Subtitle hero / lede |
| `text-p2-web` / `text-p2-mobile` | 20/22 | 15/22 | Body medium |
| `text-p3-web` / `text-p3-mobile` | 16/22 | 14/22 | Body regular |

## SDK (con `--sdk-font-family` aplicada)

Estas SÍ declaran `fontFamily: var(--sdk-font-family)` — respetan theme switching. Pesos integrados.

| Tw class | Size | LH | Weight |
|---|---|---|---|
| `text-d1-medium` | 40 | 56 | 500 |
| `text-d2-medium` | 32 | 44 | 500 |
| `text-h1-bold` / `text-h1-medium` | 32 | 28 | 700 / 500 |
| `text-h2-bold` / `text-h2-medium` / `text-h2-regular` | 20 | 28 | 700 / 500 / 400 |
| `text-h3-medium` / `text-h3-regular` | 18 | 24 | 500 / 400 |
| `text-h4-bold` | 16 | 22 | 700 |
| `text-callout-medium` / `text-callout-regular` | 16 | 22 | 500 / 400 |
| `text-body-medium` / `text-body-regular` | 15 | 22 | 500 / 400 |
| `text-caption-bold/medium/regular` | 14 | 20 | 700 / 500 / 400 |
| `text-caption-link` | 13 | 20 | — |
| `text-title-medium/regular/capital` | 13 | 28-29 | 500 / 400 / 500+UC |
| `text-overline-l-*` | 12 | 16 | 500 / 400 |
| `text-overline-m-*` | 11 | 14 | 500 / 400 |
| `text-overline-s-*` | 10 | 14 | 500 / 400 |
| `text-overline-xs-*` | 8 | 8 | 500 / 400 |

## Rewards (Quicksand hardcoded)

| Tw class | Size | LH | Weight |
|---|---|---|---|
| `text-rewards-xl-bold` | 20 | 28 | 700 |
| `text-rewards-l-bold` | 14 | 16 | 700 |
| `text-rewards-m-bold` | 12 | 14 | 700 |
| `text-rewards-s-bold` | 10 | 14 | 700 |
| `text-rewards-xs-bold` | 8 | 8 | 700 |

## Helpers globales

Definidos en `globals.css:202–228`:

| Class | Equivalente |
|---|---|
| `title-h2-center` | `m-auto md:mt-0 leading-[42px] md:leading-[3rem] md:px-0 mb-14` |
| `subtitle` | `font-medium text-p1-mobile md:text-p1-web` |
| `bodyMedium` | `font-medium text-p2-mobile md:text-p2-web` |
| `bodyRegular` | `font-normal text-p3-mobile md:text-p3-web` |
| `buttonPrimary` | `text-tertiary-Collect10 bg-primary-PaymentDark py-3 px-9 rounded-full bodyRegular font-bold` |
| `buttonSecondary` | `bg-transparent border border-solid rounded-full py-3 px-9 bodyRegular font-bold text-tertiary-Collect10` |
| `layout-wrapper` | `h-full md:m-auto md:max-w-[92%] xxl:max-w-[80%]` |

## Patrón canónico (uso real)

```tsx
// Hero H1
<h1
  className="mb-3 max-w-[16ch] font-quicksand text-[32px] font-bold leading-[1.08] lg:text-[56px]"
  style={{ letterSpacing: '-0.025em' }}
>
  {title}
</h1>

// Section H2
<h2
  className="font-quicksand text-[19px] font-bold leading-tight text-primary-black"
  style={{ letterSpacing: '-0.018em' }}
>
  {section}
</h2>

// Card title H2
<div
  className="font-quicksand text-[22px] font-bold leading-[1.1] lg:text-[26px]"
  style={{ letterSpacing: '-0.022em' }}
>
  {card.title}
</div>

// Body lead
<p className="mb-6 max-w-[540px] text-base text-white/90 lg:text-[17px]">
  {subtitle}
</p>

// Caption
<span className="text-[13px] text-tertiary-darkGray">{caption}</span>

// Eyebrow chip
<div className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-white/30 bg-white/15 px-3 py-1 text-xs font-medium text-white">
  <span className="block h-1.5 w-1.5 rounded-full bg-promotions-PrimaryRewards" />
  {eyebrow}
</div>
```
