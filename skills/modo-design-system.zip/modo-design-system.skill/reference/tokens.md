# MODO Design Tokens — canonical

> Verdad extraída de `modo-landing/tailwind.config.js`, `modo-landing/src/styles/globals.css`, `modo-ui-lib-web/src/theme/*.scss`. Última extracción: 2026-05-20.

## Fuentes (Google Fonts CDN)

Cargadas en `modo-landing/src/pages/_document.js:51`:

```html
<link
  href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&family=Red+Hat+Display:wght@400;500;600;700;900&display=swap"
  rel="stylesheet"
/>
```

| Family | Pesos | Tw class | CSS var | Uso semántico |
|---|---|---|---|---|
| **Quicksand** | 400, 500, 700 | `font-quicksand` | — | Display: H1, H2, H3, H4, stat values, featured card titles, rewards labels |
| **Red Hat Display** | 400, 500, 600, 700, 900 | `font-red-hat` (inherit) | `--sdk-font-family` | Body, callout, caption, app-*, links, forms, navbar |
| **Rubik** | — | — | `--sdk-font-family` (theme=Patagonia) | Sólo theme bancario alt |

Default html: `font-family: 'Red Hat Display', sans-serif` (`globals.css:195`).

## Colores brand (verdad)

### Verde MODO (payment / brand primary)
```
#008859  primary-PaymentDefault / sdk-colors-default / brand-green-default
#00471B  primary-PaymentDark / brand-green-green-dark
#3CAB6D  payment-light / system-success-light
#58CA8A  brand-green-green-80
#7DE3AA  brand-green-green-60
#A0E7BF  brand-green-green-40
#C8F0DA  brand-green-green-20
#DCF5E7  brand-green-green-10 / Promotions.ModoGreen10
```

### Azul send (brand secondary / accent)
```
#0049C4  primary-SendDefault / sdk-colors-accent / brand-blue-default
#0D3F92  primary-SendDark / brand-blue-dark
#2375FF  brand-blue-light
#336DD0  brand-blue-80
#6692DC  brand-blue-60
#99B6E7  brand-blue-40
#CCDBF3  brand-blue-20
#E5EDF9  brand-blue-10
```

### Amarillo rewards
```
#FFC738  promotions-PrimaryRewards / sdk-promos-yellow-default
#FFF8E5  sdk-promos-yellow-light / primary-rewards-light
#E7A600  sdk-promos-yellow-dark / primary-rewards-dark
```

### Texto (neutrals)
```
#FFFFFF  primary-white / greys-white
#121212  primary-black / greys-black / opacity-black-* base
#414141  greys-gray-80 / secondary-gray-80
#717171  greys-gray-60 / secondary-gray-60 / tertiary-darkGray / tertiary-Gray60
#929292  greys-gray-40 / secondary-gray-40
#D0D0D0  greys-gray-20 / secondary-gray-20 / tertiary-Gray20
#ECECEC  greys-gray-8 / secondary-gray-08 / tertiary-Gray8
#F8F8F8  greys-gray-3 / secondary-gray-03 / Promotions.Gray3
#F5F5F5  tertiary-gray (legacy)
#333333  tertiary-Gray80
```

### Surfaces
```
#F3F4F9  surface-primary / sdk-surface-primary
#D0D0D0  surface-secondary
```

### System (semantic)
```
#3CAB6D  system-success-light  (legacy: #44C200 dark)
#DA1948  system-error-dark
#FFECF2  system-error-light
#EF9919  system-warning-dark
#FFECD0  system-warning-light
#0669FD  system-links / sdk-system-links / blue-techie-dark
```

### Brand alt (theme switching)
```
#263144  primary-BlueCrossDark (Banco Patagonia legacy)
#0783D3  primary-CollectDark
#005EA9  Patagonia theme primary (con Rubik font)
#192042  primary-blue-cross-dark (ui-lib)
#FF5524  primary-orange-dark
#FFA985  primary-orange-light
```

### Secondary palette (categorías / accents)
```
#4EB62A  secondary.GreenDark / tertiary-green-dark
#EBAE10  secondary.YellowDark / tertiary-mandarin-dark
#FE5E5E  secondary.RedDark / tertiary-red-dark / merchant.Category2Dark
#F7924A  secondary.OrangeDark / tertiary-carrot-dark
#A376FF  secondary.PurpleDark / tertiary-purple-dark
#6D6B6B  secondary.BrownDark / tertiary-brown-dark
#3395FF  secondary.BlueDark / tertiary-blue-dark
#29C6E2  secondary.CyanDark / tertiary-cyan-dark
#ED72DA  secondary.PinkDark / tertiary-pink-dark
#425573  secondary.PlatinumDark / tertiary-platinium-dark
#193D92  partner.playstation
```

## Spacing (Tailwind tokens)

Definidos como CSS vars en `globals.css:80–87`, mapeados a Tailwind en `tw.config.js:410–422`:

| Token Tw | CSS var | Px |
|---|---|---|
| `none` | `--spacing-none` | 0 |
| `xxxsm` | `--spacing-xxxsm` | 4 |
| `xxsm` | `--spacing-xxsm` | 8 |
| `xsm` | `--spacing-xsm` | 12 |
| `sm` | `--spacing-sm` | 16 |
| `regular` | `--spacing-regular` | 20 |
| `md` | `--spacing-md` | 24 |
| `lg` | `--spacing-lg` | 32 |
| `xlg` | `--spacing-xlg` | 40 |
| `xxlg` | `--spacing-xxlg` | 44 |
| `xxxlg` | `--spacing-xxxlg` | 48 |

SCSS extended scale (solo lib `modo-ui-lib-web/theme/spacing.scss`): hasta `huge = 88px`. NO usar en modo-landing — Tailwind tokens son la verdad.

## Breakpoints (modo-landing Tailwind)

| Tw key | Px | Uso |
|---|---|---|
| `sm` | 480 | Móviles grandes |
| `md` | 768 | Tablets |
| `lg` | 976 | Laptops |
| `xl` | 1440 | Desktops |
| `xxl` | 1900 | Pantallas wide |

SCSS lib (no usar en modo-landing): small-mobile=412, mobile=620, tablet=768, small-desktop=1280, desktop=1440.

## Radii

```
--spacing-border-radius-s:  8px   → rounded-s
--spacing-border-radius-m:  12px  → rounded-m
--spacing-border-radius-l:  16px  → rounded-l
--spacing-border-radius-xl: 24px  → rounded-xl
```

Patrones observados (allowlist):

- `rounded-[10px]` — inputs hero, botones secundarios
- `rounded-[12px]` — mosaic tiles, secondary cards
- `rounded-[14px]` — featured cards, app banners (default card)
- `rounded-full` — chips, badges, pill buttons, avatars

## Shadows

Lib default: `0 4px 4px 0 #12121214` (`shadow.scss`).

Patrón cards en landing:
```
box-shadow: 0 1px 2px rgba(18,18,18,0.04), 0 8px 24px rgba(18,18,18,0.05)
```

## Motion

```
ease_smooth:    cubic-bezier(0.25, 1, 0.5, 1)   default para hovers, transforms, opacity
ease_sharp:     cubic-bezier(0.4, 0, 0.4, 1)    botones, inputs, micro-interactions
duration_micro: 120ms                            hover scale, color
duration_norm:  200ms                            transform, position
duration_image: 300ms                            image hover scale
```

Aplicación canónica:
```html
class="transition-transform duration-[120ms] [transition-timing-function:cubic-bezier(0.25,1,0.5,1)] hover:scale-[1.02]"
```

## Container

```
mx-auto max-w-[1260px] px-4 lg:px-6
```

Excepción: layout wrapper helper `@apply h-full md:m-auto md:max-w-[92%] xxl:max-w-[80%]` (`globals.css:225`) — sólo para CMS-driven pages.

## Letter-spacing display (críticos)

| Contexto | Valor | Aplicación |
|---|---|---|
| H1 hero | `-0.025em` | `style={{ letterSpacing: '-0.025em' }}` |
| H2 card title | `-0.022em` | id. |
| H2 section | `-0.018em` | id. |
| H3 inline | `-0.02em` | id. |
| Stat value | `-0.025em` | id. |
| Wordmark MODO | `-0.06em` | Solo logo text |
| Wordmark sm | `-0.05em` | Logo en navbar |

## Theme switching

Tema default = MODO verde. Override via `<html data-theme="Patagonia">` (`globals.css:96–129`):
- Cambia `--sdk-colors-*` a paleta Patagonia (#005EA9 base)
- Cambia `--sdk-font-family` a Rubik

Para soportar más bancos: replicar bloque `:root[data-theme='<Bank>']` con sus tokens.

## Allowlist hex literal

Estos hex SÍ están permitidos en código fuera de tokens (gradient masks, inline letter-spacing N/A here):

```
rgba(255,255,255,0)   gradient transparente
rgba(255,255,255,0.X) overlay blanco
rgba(0,0,0,0.X)       overlay negro
rgba(18,18,18,0.X)    overlay ink
rgba(255,199,56,X)    gradient yellow → transparent (card fades)
rgba(0,73,196,X)      gradient blue → transparent
rgba(0,106,69,X)      gradient green (#006A45) → transparent
```

Cualquier otro hex literal → falla validate-tokens.sh.
