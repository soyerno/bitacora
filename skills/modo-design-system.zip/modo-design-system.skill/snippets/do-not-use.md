# Do NOT use · antipatterns concretos

> Lista de cosas que el skill bloquea explícitamente. Cada una con su alternativa MODO-correcta.

## Fonts

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `font-family: Inter` | `font-family: 'Red Hat Display', sans-serif` |
| `font-family: Roboto` | id. |
| `font-family: Arial` | id. |
| `font-family: 'Space Grotesk'` | display: `font-quicksand` |
| `font-family: system-ui` | body: `font-red-hat` |
| `font-family: -apple-system` | id. |
| `font-sans` (Tailwind default) | `font-red-hat` o `font-quicksand` |

## Colores

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `bg-green-500` | `bg-primary-PaymentDefault` |
| `bg-green-600` | `bg-primary-PaymentDefault` |
| `bg-green-700` | `bg-primary-PaymentDark` |
| `bg-blue-500` | `bg-primary-SendDefault` |
| `bg-blue-700` | `bg-primary-SendDark` |
| `bg-yellow-400` | `bg-promotions-PrimaryRewards` |
| `bg-yellow-500` | `bg-sdk-promos-yellow-dark` |
| `text-gray-500` | `text-tertiary-darkGray` |
| `text-gray-600` | `text-greys-gray-60` |
| `text-gray-700` | `text-greys-gray-80` |
| `text-gray-900` | `text-primary-black` |
| `bg-gray-50` | `bg-sdk-surface-primary` |
| `bg-gray-100` | `bg-greys-gray-3` |
| `bg-white` | `bg-primary-white` (sí, hasta blanco es token) |
| `text-white` | `text-primary-white` |
| `#FF0000`, `#00FF00` literal | tokens correspondientes |
| `bg-red-500` (error) | `bg-sdk-system-error-light` + `text-sdk-system-error-dark` |
| `bg-purple-XXX` | `bg-secondary-PurpleDark` (si categoría) |

## Spacing

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `p-[15px]` (excepto cases específicos) | `p-sm` (=16) o `p-xsm` (=12) |
| `m-[20px]` | `m-regular` (=20) |
| `gap-[24px]` | `gap-md` (=24) |
| `max-w-[1200px]` | `max-w-[1260px]` (canónico) o `max-w-screen-xl` |
| `max-w-[1440px]` | `max-w-[1260px]` (cap container) |

Excepción: hardcode permitido para `rounded-[10px]`, `rounded-[12px]`, `rounded-[14px]`, line-heights finos, letter-spacing display.

## Layout

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| Page sin `NavFooterLayout` | wrap content en `<NavFooterLayout>` |
| Page sin `<PageSeo>` | siempre incluir |
| Page sin `MODO_ORGANIZATION_JSONLD` | en `seoData.jsonLd` array |
| Page sin Breadcrumb JSON-LD | build con helper |
| Container `> 1260px` | usar `max-w-[1260px]` |
| Container `< 1024px max` | mismo, hace responsive |

## Componentes

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `<button class="bg-green-...">` rolled own | `<Button>` de `@playsistemico/modo-ui-lib-web` |
| `<input class="border ...">` rolled own | usar componente de la lib si existe |
| Icon SVG inline arbitrario | usar `<Icon name="..." />` de la lib |
| Modal custom | `<Modal>` de la lib |
| Navbar custom | `<Navbar>` de la lib |
| Footer custom | `<Footer>` de la lib |

## Motion

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `transition-all ease-linear` | `[transition-timing-function:cubic-bezier(0.25,1,0.5,1)]` |
| `duration-500` para micro | `duration-[120ms]` |
| `transition-colors` solo | `transition-transform` o `transition-[background-color,transform]` |
| Hover scale `>1.05` | `hover:scale-[1.02]` (sutil) o `hover:-translate-y-0.5` |

## SEO

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `<meta name="robots" content="noindex">` en prod | solo en non-prod (ya manejado en `_document.js`) |
| Title sin "MODO" | siempre incluir "MODO" en title de page principal |
| Description `< 50 chars` o `> 160 chars` | 120-155 chars sweet spot |
| OG image sin definir | siempre `og.image` (default si no hay editorial) |
| JSON-LD malformado | usar siempre helpers `buildXxxJsonLd` |

## Accesibilidad

| ❌ Banned | ✅ MODO equivalent |
|---|---|
| `<img>` sin `alt` | `alt="descripción"` o `alt="" aria-hidden="true"` (decorativa) |
| Botón icon-only sin `aria-label` | `aria-label="acción"` |
| `<a>` con solo emoji/icono | `aria-label="..."` + visible text o sr-only |
| Color contrast `< 4.5:1` | usar `text-primary-black` sobre `bg-primary-white` o similar |
| Form sin `<label>` | siempre asociar |

## Copy

Ver `reference/brand-voice.md`. Resumen:

| ❌ | ✅ |
|---|---|
| "Click aquí" | "Ver detalles" |
| "Estimado usuario" | "Hola" |
| "Próximamente" | (fecha concreta o no mencionar) |
| "Solución integral" | (acción concreta) |
| Emoji en producción | (no) |
| `—` em dash | `·` interpunto |
| "Mon-Fri" | "lunes a viernes" |
| `ARS 3000` | `$3.000` |
