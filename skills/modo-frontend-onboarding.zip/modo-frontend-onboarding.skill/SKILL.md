---
name: modo-frontend-onboarding
description: Playbook end-to-end para llevar un frontend (SPA Vite/Lovable o app Next) a producción en la infra MODO (EKS + Istio) bajo el org playsistemico. Cubre migración a Next 16 server-rendered, subida limpia del código (squash sin secretos en history), apertura del ticket JSM a devops (preguntando el aprobador y los grupos), y el armado de PRs individuales por paso de infra (catalog→helm→parameters→ci→cd→docker) clonando promos-hub. Auto-invocable cuando el user diga "subir <front> a playsistemico", "llevar la SPA a prod MODO", "onboarding de un frontend nuevo", "levantar la infra de un repo MODO", "deploy de <front> en EKS", "/modo-frontend-onboarding". Caso canónico: aprendeatumodo (COENXT-308, 7 PRs). NO inventa ownership ni valores de devops — pregunta y deja TODO(devops).
---

# MODO Frontend Onboarding (→ playsistemico + EKS)

Llevar un frontend a producción MODO de punta a punta: **migrar → subir limpio → ticket devops → PRs de infra**. Caso canónico: **aprendeatumodo** (Vite 5 SPA → Next 16 App Router server-rendered → `playsistemico/aprendeatumodo`, 7 PRs).

> Este skill ORQUESTA otros skills, no los duplica. Cada fase delega al skill especializado.

## Cuándo usar

- Subir un frontend (SPA Vite/Lovable, o app Next ya hecha) al org `playsistemico` y desplegarlo en EKS.
- Bootstrap de infra de un repo MODO frontend nuevo (helm/catalog/parameters/workflows).
- Cuando hay que abrir el ticket a devops para provisioning + armar los PRs de infra.

## Cuándo NO usar

- Bump de Next manteniendo Pages Router → `nextjs-pages-router-migration`.
- Solo la migración de código sin deploy → `vite-to-nextjs-app-router`.
- Backend/microservicio (este playbook es frontend EKS+Istio; el patrón de catalog/helm difiere).

## Prerrequisitos (chequear ANTES de arrancar)

- El repo destino en `playsistemico` existe (o pedir crearlo en el ticket). Verificar: `gh repo view playsistemico/<repo>`.
- Acceso `gh` al org playsistemico (`gh auth status`).
- `~/.npmrc` con token GH Packages para `@playsistemico` (auth local de build). Inyección: `export NODE_AUTH_TOKEN="$(grep -m1 'npm.pkg.github.com/:_authToken=' ~/.npmrc | sed 's/.*_authToken=//')"`.
- Repo de referencia clonado local: `promos-hub-site` (fuente canónica de infra).

## Fases

### Fase 0 · Discovery + gate de ownership (NO inventar)

Antes de tocar nada, recopilar — **preguntando al user, no asumiendo** (ver `modo-stakeholder-gate`):

| Dato | Para qué | Default seguro |
|------|----------|----------------|
| **Squad dueño** (técnico) | `catalog/global.yaml`, canales Slack/Datadog | preguntar — NO inventar |
| **Aprobador del ticket JSM** | quién aprueba el provisioning en devops | preguntar — campo obligatorio del ticket |
| **Grupos / teams** | GitHub team que owns el repo, grupo IAM, grupo de acceso | preguntar |
| **basePath / host** | subpath (`modo.com.ar/<x>`) vs subdominio (`<x>.modo.com.ar`) | preguntar. Subpath → `basePath: /<x>` + probes a `/<x>` + rewrite en modo-landing. Subdominio → basePath puede ser `/` + probes a `/` + `exposeName`/gateway propio. Define `NEXT_PUBLIC_SITE_URL` por env. |
| **Vars de runtime** | qué `NEXT_PUBLIC_*` necesita (Storyblok, Amplitude, DD) | derivar del código + confirmar |

Regla: si un dato es load-bearing (ownership, aprobador, grupo, host) y no lo sabés → **preguntar explícito**. Nunca un default silencioso. Lo que provisiona devops (KMS ARNs, ECR, EKS, DNS) → `TODO(devops)`, no inventar.

### Fase 1 · Migración a Next 16 server-rendered (si aplica)

Si el front es Vite/SPA → migrar con el skill **`vite-to-nextjs-app-router`** (App Router server-rendered, basePath, runtime env). Si ya es Next server-rendered → saltear.

El target SIEMPRE es server-rendered (`next start`), NO `output:'export'` — la infra EKS necesita un proceso node.

**Resolver el PM primero** (trap conocido del workspace): un solo lockfile, pin con campo `packageManager`, borrar los otros (aprendeatumodo arrancó con bun+npm+pnpm simultáneos). El `exec <pm> start` del `entrypoint.sh` (Fase 4) DEBE matchear ese PM.

Verificar el contrato antes de seguir (esperar a que `next start` bindee :3000 antes de curlear):
```bash
curl -fsS -o /dev/null -w '%{http_code}\n' http://localhost:3000/<basePath>   # 200
curl -s  -o /dev/null -w '%{http_code}\n' http://localhost:3000/              # 404 si hay basePath
```
`pnpm build` verde + esos dos códigos = contrato OK. El `:3000` es el mismo puerto que sondean los probes del helm.

### Fase 2 · Subida limpia del código a playsistemico

🔴 **Repo exportado de Lovable = `.git` MUERTO.** El `.git` es un **archivo** (no dir): `gitdir: /nix/store/<hash>-template-pool/git/repo.git/worktrees/dev-server` → path nix inexistente. `git status`/`git init` fallan con `fatal: not a git repository: /nix/store/...`. No hay history usable. Camino: `rm .git` (el classifier lo bloquea por borrado fuera-de-git → nombrá el target explícito en la `description` del Bash para que el user apruebe) → `git init -b main` fresh. **Init fresh = no hay history que scrubear** (limpio por construcción), pero el `.gitignore` de Lovable **NO ignora `.env`** → endurecer ANTES del primer commit y verificar el stage:
```bash
rm .git && git init -b main -q                                   # .git era un FILE pointer muerto
printf '\n# Secrets\n.env\n.env.*\n!.env.example\n*.tsbuildinfo\n' >> .gitignore
git add -A
git ls-files --cached --error-unmatch .env 2>/dev/null && echo "❌ .env trackeado" || echo "✅ .env fuera"
git ls-files --cached | grep -E 'node_modules/|^dist/' && echo "❌ basura staged" || echo "✅ sin node_modules/dist"
git grep -I --cached -lE 'eyJ[A-Za-z0-9_-]{20,}|_authToken=[A-Za-z0-9]|sk_live_|AKIA[0-9A-Z]{16}' -- . ':!.env.example' ':!*-lock.json' && echo "❌ secreto" || echo "✅ limpio"
```
Crear `.env.example` con las keys vacías (las `VITE_*` se inyectan en runtime). Caso canónico: modo-govern → SoyErnoModo/modo-govern (privado, 2026-05-27). Para repos CON history (no Lovable) y secreto en ancestro, seguir el squash-a-base de abajo.

🔴 **Nunca pushear una branch cuyo history contenga un secreto** (ej. PAT en `.npmrc` de un commit ancestro). Scan obligatorio antes de pushear (`git grep` sobre el tree — no `ls-files | xargs`, que con 0 archivos lee STDIN y da falso "limpio"):
```bash
git grep -nE 'ghp_[A-Za-z0-9]{20}|github_pat_[A-Za-z0-9_]{20,}|gh[ous]_[A-Za-z0-9]{20,}|_authToken=[A-Za-z0-9]|sk_live_[A-Za-z0-9]|AKIA[0-9A-Z]{16}' -- . && echo "❌ SECRETO — NO pushear" || echo "✅ limpio"
```
(El regex cubre PATs clásicos `ghp_`, fine-grained `github_pat_`, OAuth/app `gho_/ghs_/ghu_`, `_authToken=`, Stripe, AWS keys. Es un control de seguridad: ante la duda, sumar arms, nunca achicar.)
Si el secreto está en el history (no solo el tree) → **squash a un commit limpio sobre la base del repo destino**:
```bash
git remote add playsistemico https://github.com/playsistemico/<repo>.git
git fetch playsistemico
git checkout -b import-clean playsistemico/main          # base = Initial commit del repo destino
git checkout <migration-branch> -- .                     # overlay del árbol migrado (tree limpio)
git add -A && git commit -m "feat(<TICKET>): import <repo> · migración ..."
git merge-base --is-ancestor playsistemico/main HEAD && echo "✅ ancestro común (PR limpio)"
git push playsistemico import-clean:feat/<migration-branch>
gh pr create --repo playsistemico/<repo> --base main --head feat/<migration-branch> --title ... --body ...
```
Esto da **PR #1** (migración → main) con ancestro común (diff limpio) y SIN el secreto en el history nuevo. La branch remota pusheada (`feat/<migration-branch>`) es la que las fases siguientes llaman **`<MIGBR>`** (base de los PRs de infra); la branch local con el tree migrado es `import-clean` (= `<MIGBR-local>`). Detalle + por qué en `reference/clean-import-recipe.md`.

### Fase 3 · Ticket JSM a devops (preguntando el aprobador)

🔴 **OJO**: no hay un form JSM único para provisioning cloud (verificado en el catálogo). Se parte en dos: el **repo+team** va por el form **"ABM de Repositorios de GitHub"** (vía `modo-jsm-ticket`); los **recursos cloud** (KMS/ECR/EKS/DNS/Istio) se piden a **CloudOps por su canal** (Slack #cloudops o el que indiquen — confirmar con el squad, no inventar form). Detalle en `reference/jsm-provisioning-ticket.md`.

El pedido (form repo/team + checklist a CloudOps) cubre:
- Org GH Actions secrets para el repo: `DIMO_DEVOPS_PAT`, `MODO_PKG_TOKEN`, `MODO_SONARCLOUD_TOKEN`, `WF_SLACK_TOKEN`, `CODE_REVIEW_API_KEY`.
- KMS keys por env (para SOPS).
- ECR repo + EKS namespace + IAM role (los aplica `catalog.yaml@v1` desde `catalog/`, pero confirmar).
- DNS `<host>[.{env}].modo.com.ar` + entrada del gateway Istio.

🔴 **Preguntar el aprobador ANTES de crear el ticket** — es campo obligatorio y NO se inventa. Frase: *"¿Quién es el aprobador del ticket de provisioning (TL / lead de devops / manager)?"*. Igual con los grupos (GitHub team, grupo IAM). Ver `reference/jsm-provisioning-ticket.md` para el template de campos.

### Fase 4 · PRs de infra individuales por paso (clon promos-hub)

**Requiere que Fase 2 ya haya pusheado `<MIGBR>` al remoto** — si no, las PRs de infra no tienen base.

#### Fase 4a · Scaffold de los archivos de infra (PRIMERO — produce el `<INFRA_SHA>`)

Antes del loop de PRs hay que **crear los archivos**. Clonar promos-hub → aplicar valores per-project (ver `promos-hub-clone-map.md`) → commitear en una branch local **throwaway** (no se pushea; solo sirve de fuente para las slices):
```bash
# <MIGBR-local> = la branch LOCAL con el tree migrado (ej. import-clean de Fase 2)
git checkout -b feat/deploy-eks-<repo> import-clean       # branch sobre el código migrado
# crear: Dockerfile entrypoint.sh .dockerignore helm/ catalog/ .sops.yaml
#        parameters/<env>/ .github/workflows/ sonar-project.properties
#        (clonando promos-hub, valores per-project)
git add -A && git commit -m "feat(<TICKET>): infra deploy EKS (clon promos-hub)"
INFRA_SHA=$(git rev-parse HEAD)    # ← este es el <INFRA_SHA> del loop de abajo
```
🔴 El `<INFRA_SHA>` debe ser **alcanzable localmente desde el mismo worktree/repo** (mismo object store). Un clon aparte NO sirve. Este commit NO se pushea — las slices se extraen de él con `git checkout $INFRA_SHA -- <paths>` sobre el push limpio. (Si un agente scaffoldea en un worktree aislado, traer su commit al worktree de deploy con `git checkout <sha> -- <paths>` — el objeto es compartido en el mismo repo.)

#### Fase 4b · Loop de PRs (slices sin overlap)

Patrón de split tomado del bootstrap de modo-landing: **un PR por concern de config**, sin overlap de archivos. Cada branch sale del **push LIMPIO** de Fase 2 (no de la branch local con secreto en ancestro), targeting la branch de migración:

> Paths de workflows = `.github/workflows/<x>.yaml` (la tabla los abrevia).

| PR | Branch | Archivos | Gating |
|----|--------|----------|--------|
| catalog | `feat/infra-catalog` | `catalog/` + `.github/workflows/catalog.yaml` | provisiona primero |
| helm | `feat/infra-helm` | `helm/values.yaml` (🔴 probes a `/<basePath>`) + `helm/namespace.yaml` | — |
| parameters | `feat/infra-parameters` | `.sops.yaml` + `parameters/<env>/` + `.github/workflows/ssm.yaml` | 🔴 KMS ARNs devops |
| ci | `feat/infra-ci` | `.github/workflows/{ci,ci-alpha,pr}.yaml` + `sonar-project.properties` | org GH secrets |
| cd | `feat/infra-cd` | `.github/workflows/{cd,production}.yaml` | — |
| docker | `feat/infra-docker` | `Dockerfile` + `entrypoint.sh` + `.dockerignore` | — |

Receta de creación (slices sin overlap → PRs independientes) en `reference/infra-prs-recipe.md`. Valores per-project + el clon promos-hub en `reference/promos-hub-clone-map.md`.

### Fase 5 · Orden de merge + handoff

Orden sugerido: **#1 migración → catalog → helm → parameters → ci → cd → docker**. Los PRs gated en devops (parameters, ci) esperan al ticket. Dejar el orden + gating explícito en cada cuerpo de PR.

🔴 **Trap de retarget al mergear #1** (mismo bug que el stacked-PR de modo-landing): los 6 PRs de infra targetean `<MIGBR>`. Cuando #1 mergea a `main`, GitHub con *delete-branch-on-merge* (default en muchos repos MODO) **borra `<MIGBR>`** → los PRs de infra pierden la base (auto-close o retarget silencioso a `main` con diff inflado). Manejarlo, no esperar que sobreviva. Opción (elegir una):
- **(a) Retarget**: `for n in 2 3 4 5 6 7; do gh pr edit $n --repo <repo> --base main; done`. ⚠️ OJO: `gh pr edit --base` NO rebasa, solo cambia el ref. Como #1 mergea **squash** (commit nuevo en main, NO ancestro de las branches de infra), el diff del PR retargeteado queda **inflado** (muestra toda la migración) aunque mergee sin conflicto (contenido idéntico). Sirve pero el diff NO es limpio.
- **(b) Desactivar delete-on-merge** para #1 (mantiene `<MIGBR>` vivo como base). Diff de infra queda limpio mientras `<MIGBR>` exista.
- **(c) Serializar** (único diff realmente limpio): mergear #1 primero, rebasar las branches de infra sobre `main` (`git rebase --onto main <MIGBR> <infra-branch>`), recién ahí abrir/retargetear los 6 PRs. Más lento, diff perfecto.

**Rollback**: como las slices no comparten archivos, revertir un PR de infra es aislado (`gh pr revert` / revert del merge commit) y NO toca los otros concerns. Un workflow que rompe CI en main → revert del slice de CI solo.

## Gotchas load-bearing (de aprendeatumodo)

1. 🔴 **Probes al basePath**: con `basePath: /x`, `GET /` da 404 → liveness/readiness DEBEN pegar a `/x` o el pod nunca queda Ready. (Difiere de promos-hub que sondea `/`.)
2. 🔴 **Secreto en ancestro**: el squash a base del repo destino evita arrastrar un PAT del history viejo. Scan SIEMPRE antes de push.
3. **Puerto 3000** (`next start`), output `dist/`, `extra-content: "dist/"` en CI.
4. **Runtime env one-image-N-envs**: `next-runtime-env` + SSM, no bakear `NEXT_PUBLIC_*` en build.
5. **`entrypoint.sh` con `exec`** (`exec pnpm start`) para propagar SIGTERM.
6. **Slices sin overlap de archivos** → 6 PRs de infra independientes (no stacked), reviewables en paralelo.
7. 🔴 **Lovable `.git` muerto**: pointer file a path nix inexistente → `rm .git` + `git init` fresh. Init fresh no tiene history que scrubear, PERO el `.gitignore` de Lovable no excluye `.env` → endurecer + verificar stage antes del commit (ver Fase 2).

## Reglas operativas

- NO inventar: ownership, aprobador, grupos, KMS ARNs, distro IDs, account secrets → preguntar o `TODO(devops)`.
- NO claims sin verify: tras cada fase, correr el check correspondiente (build/grep/scan) y reportar el output real.
- Worktree dedicado para todo el trabajo de código.
- Commits MODO: `type(TICKET): subject`. Voz rioplatense en cuerpos de PR.

## Cross-link

- `vite-to-nextjs-app-router` — Fase 1 (migración SPA → Next 16).
- `modo-jsm-ticket` — Fase 3 (ticket de provisioning).
- `modo-stakeholder-gate` — Fase 0 (gate de ownership, no inventar).
- `sops-parameters-manager` — Fase 4 (encriptar secrets cuando haya KMS).
- `github-packages-auth` — auth `@playsistemico` (build local + CI).
- `helm-k8s-best-practices` / `frontend-security-checklist` (Layer 3 CSP post-deploy).
- Spec canónica del caso: `openspec/changes/deploy-eks-playsistemico` en aprendeatumodo (si está presente en la branch que mires — vive en `feat/migrate-to-next16`).
