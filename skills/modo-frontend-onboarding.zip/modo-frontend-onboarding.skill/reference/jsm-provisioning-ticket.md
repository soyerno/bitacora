# Ticket JSM de provisioning a devops

Se crea con el skill `modo-jsm-ticket` (29 service desks · 318 request types). Este doc define QUÉ pedir y los campos que NO se inventan.

## 🔴 Campos que se PREGUNTAN al user (no se inventan)

- **Aprobador**: quién aprueba el provisioning. Frase: *"¿Quién es el aprobador del ticket (TL / lead devops / manager)? Es campo obligatorio."* Sin aprobador → no se crea el ticket.
- **Grupos / teams**: GitHub team que owns el repo en playsistemico, grupo IAM, grupo de acceso a EKS/secrets. Frase: *"¿Qué GitHub team owns el repo y qué grupo de acceso aplica?"*
- **Squad**: el squad técnico dueño (va en `catalog/global.yaml` + canales).

## Qué pide el ticket a devops (provisioning)

1. **Repo + teams**: confirmar repo `playsistemico/<repo>` + asignar el GitHub team owner + permisos.
2. **Org GH Actions secrets** resueltos para el repo: `DIMO_DEVOPS_PAT`, `MODO_PKG_TOKEN`, `MODO_SONARCLOUD_TOKEN`, `WF_SLACK_TOKEN`, `CODE_REVIEW_API_KEY`.
3. **KMS keys por env** (develop/qa comparten account `151605301785`, preprod `262134918714`, prod `821600326346`) → para SOPS. Pedir los ARNs.
4. **ECR repo + EKS namespace + IAM role `<repo>`** — los aplica `catalog.yaml@v1` desde `catalog/`, pero confirmar que el squad/role están habilitados.
5. **DNS** `<host>[.{env}].modo.com.ar` + entrada del gateway Istio externo.
6. **Decisión de host**: subpath (`modo.com.ar/<x>`, requiere rewrite en modo-landing) vs subdominio (`<x>.modo.com.ar`).

## 🔴 No hay un form JSM único para provisioning cloud

Verificado contra el catálogo de `modo-jsm-ticket` (29 desks · 318 request types): **NO existe** un request type que capture "provisionar EKS + ECR + KMS + namespace + DNS + Istio" de una. Lo que SÍ hay:
- **"ABM de Repositorios de GitHub"** (desk repos) → para crear/configurar el repo + asignar el GitHub team owner + permisos. Esta parte SÍ va por form.
- **Accesos IAM/JumpCloud** → forms de acceso, si hace falta grupo nuevo.

Los **recursos cloud** (KMS keys, ECR, EKS namespace, IAM role, DNS, gateway Istio) NO tienen form — en MODO se piden a **CloudOps por su canal** (Slack #cloudops o el que el equipo indique) o por el desk que CloudOps designe. **Confirmar el canal real con el user / el squad** antes de asumir — NO inventar un form que no existe.

Regla honesta: el ticket cubre repo+team (form ABM Repos); el provisioning cloud se gestiona aparte con CloudOps. Documentar ambos caminos en el handoff, no implicar que un solo form alcanza. Para el caso real (aprendeatumodo COENXT-308), confirmar con qué se hizo antes de canonizar un desk.

Usar `modo-jsm-ticket` para el form de repo/team (descubre el request type, arma el payload, POST con confirmación). Para CloudOps, dejar el mensaje/checklist listo para Slack.

## Output esperado

Un ticket con: título claro (`Provisioning <repo> · EKS frontend`), descripción con la lista de arriba, aprobador seteado, squad/team referenciados, y link a la spec `deploy-eks-playsistemico` del repo para contexto.
