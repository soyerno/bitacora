# Capa 2 · ALB ingress + ticket PE CloudOps de routing

Cómo abrir el host de un frontend nuevo en el ALB de MODO y por dónde va el cambio. Complementa `jsm-provisioning-ticket.md` (provisioning general) con la mecánica concreta del routing.

## Las 3 capas del routing (recordatorio)

1. **App** — `exposeName` en `helm/values.yaml` + `basePath/assetPrefix` en el front. (Va en el repo del front, ver `promos-hub-clone-map.md`.)
2. **ALB ingress** — `playsistemico/payment-k8s-services`. Abre el host `<slug>.<env>.modo.com.ar` hacia el istio-gateway. ⬇️ este doc.
3. **VirtualService Istio** — `playsistemico/workflows` / `playsistemico/helm-charts` (templated por chart parent). Hace el takeover del path en `www.modo.com.ar` → svc. Lo aplica CloudOps/DSO.

## Capa 2 · mecánica exacta de `payment-k8s-services`

Patrón canónico = la regla `promoshub` (verificado 2026-05-27). Para un frontend nuevo, **espejar el bloque promoshub**:

- 🔴 Vive en **`misc-alb.yml` ÚNICAMENTE** — NO en `alb.yml`, NO en `internal-alb.yml`. Grepear `promoshub` para confirmar en qué file está antes de copiar (otros servicios pueden vivir en `alb.yml`).
- 🔴 Un file por env bajo `load-balancer/<env>/`. **Subdomains difieren por env**:

| File | `subdomains:` |
|------|---------------|
| `load-balancer/develop/misc-alb.yml` | `.develop.` + `.qa.` (develop sirve ambos) |
| `load-balancer/preprod/misc-alb.yml` | `.preprod.` |
| `load-balancer/production/misc-alb.yml` | `.` (apex/prod) |
| `load-balancer/sandbox/misc-alb.yml` | 🔴 **NO tocar** — sandbox tiene solo `redirect-to-modo` + `www`, no sirve frontends de app. promoshub tampoco está ahí. |

- Shape del bloque (insertar después del bloque `promoshub` de cada file):
```yaml
  - name: <slug>          # = exposeName del helm (label del subdominio, sin guiones raros)
    path: /*
    port: 80
    subdomains:
      - .develop.         # ajustar por env según tabla
      - .qa.
```

- `name` = el `exposeName` del chart (host label), NO el nombre del repo. Cuidado con la "r": si el subpath es `/aprende-a-tu-modo` (con r) el subdominio igual es `aprendeatumodo` (sin r).

## 🔴 No hay write access → el diff va en el ticket

`payment-k8s-services` es Platform-owned. `git push` devuelve **403 "Write access to repository not granted"**. No se abre PR uno mismo. El cambio se entrega como **diff en el ticket PE CloudOps** y lo aplica CloudOps. Generar el patch local (`git format-patch`/`git diff`) y pegarlo como comentario.

## Ticket de routing = PE CloudOps (no JSM, no COENXT)

El repo usa scope `PE-XXXX` (proyecto **PE = "Platform Enginnering"**, category DEVOPS, id `10204`). El cambio de routing/ALB se trackea con un issue **tipo CloudOps** en PE — no es un form de JSM ni va al board del front (COENXT).

Crear vía `createJiraIssue` (`mcp__claude_ai_Atlassian__createJiraIssue`):
- `projectKey: "PE"`, `issueTypeName: "CloudOps"` (id `10730`, "CloudOps User Story").
- 🔴 **Campo obligatorio ADF**: `customfield_10337` ("Criterios de aceptación") — el validador lo rechaza vacío Y exige formato **ADF** (no string plano). Pasar un doc ADF:
```json
{"customfield_10337": {"type":"doc","version":1,"content":[
  {"type":"orderedList","content":[
    {"type":"listItem","content":[{"type":"paragraph","content":[{"type":"text","text":"<criterio 1>"}]}]}
  ]}
]}}
```
- Recomendado: `customfield_12690` ("Type of work", cascading select) → `{"value": "Business as Usual"}` (otras: Business Value, Keep the Lights On, Developer Experience, Tech Debt).
- `description` sí acepta markdown con `contentFormat: "markdown"`. Solo los textarea custom (10337, etc.) exigen ADF.

**Gotcha**: si `createJiraIssue` falla con `"Los criterios de aceptación no deben de estar vacíos"` → falta `customfield_10337`. Si falla con `"no es un contenido válido del formato ADF"` → lo mandaste como string, convertilo a doc ADF.

## Checklist del ticket de routing

1. Diff de Capa 2 (ALB) pegado como comentario, espejando promoshub, sandbox excluido.
2. Pedido de Capa 3 (VirtualService) descrito: `host=(www.)?modo.com.ar` + `uri.prefix=/<path>` → `destination: <slug>.svc.cluster.local`.
3. DNS CNAME del subdominio al ALB (`tg-modo-cloudflare`) si va subdominio.
4. **Decisión de host flageada como "a confirmar"**: subdominio `<slug>.modo.com.ar`, subpath `www.modo.com.ar/<path>`, o ambos (promoshub tiene ambos).
5. Refs: epic del front (COENXT-XXX) + ticket de alta repo (HD-XXXXX).

Caso canónico: **PE-3192** (aprendeatumodo, 2026-05-27).
