# PRs de infra individuales por paso (sin overlap)

Patrón del bootstrap de modo-landing: un PR por concern de config. Las slices NO comparten archivos → PRs independientes (no stacked), reviewables en paralelo, cada diff = solo su slice.

## Precondición

- **Scaffold hecho (Fase 4a)**: los archivos de infra existen en un commit local `<INFRA_SHA>` (branch throwaway `feat/deploy-eks-<repo>`), creados clonando promos-hub + valores per-project (ver `promos-hub-clone-map.md`). Ese commit NO se pushea; solo es fuente de las slices.
- `<INFRA_SHA>` **alcanzable desde este worktree** (mismo repo/object store — un clon aparte no sirve).
- El push limpio de la migración ya está en `playsistemico/<MIGBR>` (Fase 2). Las branches de infra salen de AHÍ (limpio), no de la branch local con secreto en ancestro.
- Worktree limpio (`git status --porcelain` vacío).

## Receta (loop)

```bash
cd <worktree>
git fetch playsistemico
BASE=playsistemico/<MIGBR>          # push limpio de la migración
SRC=<INFRA_SHA>                     # commit con los archivos de infra scaffoldeados
REPO=playsistemico/<repo>

# precondición: worktree limpio (git status --porcelain vacío) para que `git add` no
# arrastre cambios ajenos. Si está sucio: stashear o limpiar antes.
run() {  # run <branch> "<commit-msg>" <files...>
  local br="$1" msg="$2"; shift 2
  git checkout -q -b "$br" "$BASE" || { echo "❌ no pude crear $br desde $BASE (¿fetch? ¿base existe?)"; return 1; }
  git checkout "$SRC" -- "$@"   || { echo "❌ path ausente en $SRC para $br (¿scaffold incompleto?)"; return 1; }
  git add -- "$@"                    # stage SOLO esos paths (no -A → no arrastra worktree sucio)
  git diff --cached | grep -qE 'ghp_[A-Za-z0-9]{20}|github_pat_[A-Za-z0-9_]{20,}|gh[ous]_[A-Za-z0-9]{20,}|_authToken=[A-Za-z0-9]|sk_live_[A-Za-z0-9]|AKIA[0-9A-Z]{16}' && { echo "❌ SECRETO en $br — abortar"; return 1; }
  git commit -q -m "$msg

Parte de la infra (<TICKET>) · clon promos-hub. Gated en devops donde aplique.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>" || { echo "❌ commit vacío/fallido en $br"; return 1; }
  git push -q playsistemico "$br":"$br" || { echo "❌ push falló en $br"; return 1; }
  echo "✅ $br ($(git diff --stat $BASE..$br --name-only | wc -l | tr -d ' ') files)"
}
```
Las slices (`run` devuelve ≠0 si una falla — no seguir a ciegas):
```bash
run feat/infra-catalog    "chore(<T>): catalog · IAM/ECR/EKS (squad <squad>)"            catalog .github/workflows/catalog.yaml
run feat/infra-helm       "chore(<T>): helm values + namespace (probes a /<basePath>)"   helm
run feat/infra-parameters "chore(<T>): parameters + .sops (NEXT_PUBLIC_*, ARNs TODO)"    .sops.yaml parameters .github/workflows/ssm.yaml
run feat/infra-ci         "ci(<T>): workflows CI (ci/ci-alpha/pr) + sonar"               .github/workflows/ci.yaml .github/workflows/ci-alpha.yaml .github/workflows/pr.yaml sonar-project.properties
run feat/infra-cd         "ci(<T>): workflows CD (cd/production)"                        .github/workflows/cd.yaml .github/workflows/production.yaml
run feat/infra-docker     "build(<T>): Dockerfile + entrypoint (modo-base node22, :3000)" Dockerfile entrypoint.sh .dockerignore
```

Luego un `gh pr create --repo $REPO --base <MIGBR> --head <br>` por branch — armar cada cuerpo con el skill **`modo-pr-author`** (voz rioplatense + template MODO), con el gating `TODO(devops)` que corresponda.

**Re-run**: si una branch ya existe (local/remota), `git checkout -b` falla (lo agarra el guard). Borrar antes: `git branch -D <br> 2>/dev/null; git push playsistemico :<br> 2>/dev/null`.

## Por qué base = MIGBR (no main)

main del repo destino no tiene el código Next todavía (la migración es PR #1, abierto). Si las branches de infra targetean main, su diff incluiría TODA la migración + su slice (ruidoso). Targeting `<MIGBR>` → diff = solo la slice. Cuando merge la migración, la infra ya está sobre ella. (Alternativa: mergear la migración primero y luego basar la infra en main — más limpio pero serializa.)

## Orden de merge

#1 migración → catalog (provisiona) → helm → parameters (gated KMS) → ci (gated secrets) → cd → docker.

## Verificación por PR

`gh pr list --repo $REPO --json number,title,headRefName,baseRefName` → confirmar base/head correctos y que cada slice tiene los archivos esperados.
