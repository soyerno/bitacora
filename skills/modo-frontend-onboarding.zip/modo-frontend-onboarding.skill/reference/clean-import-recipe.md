# Subida limpia a playsistemico (squash sin secreto en history)

## Problema

La branch de migración puede tener un secreto en un commit ANCESTRO (ej. el repo original tenía `.npmrc` con un PAT committeado; la branch salió de ahí y el commit base lo contiene aunque el tree actual esté limpio). Pushear la branch con history arrastra el secreto al repo nuevo.

Detectar:
```bash
# ¿el secreto está en el commit base de la branch?
git show <base-commit>:.npmrc 2>/dev/null | grep -c "ghp_"   # >0 = peligro
# scan del tree ACTUAL (debe ser 0 para poder subir el tree).
# git grep (NO ls-files|xargs: con 0 archivos lee STDIN → falso "limpio").
git grep -nE 'ghp_[A-Za-z0-9]{20}|github_pat_[A-Za-z0-9_]{20,}|gh[ous]_[A-Za-z0-9]{20,}|_authToken=[A-Za-z0-9]|sk_live_[A-Za-z0-9]|AKIA[0-9A-Z]{16}' -- . && echo "❌ SECRETO" || echo "✅ limpio"
```

## Receta (overlay sobre la base del repo destino)

```bash
REPO=playsistemico/<repo>
MIGBR=feat/<migration-branch>     # branch local con el tree migrado (limpio en HEAD)
git remote add playsistemico https://github.com/$REPO.git 2>/dev/null || true
git fetch playsistemico

# base = el Initial commit del repo destino (ancestro común → PR con diff limpio)
git checkout -b import-clean playsistemico/main
git checkout "$MIGBR" -- .         # overlay del tree migrado (NO trae .git history del MIGBR)
git add -A

# sanity ANTES de commitear
git diff --cached --name-only | grep -x ".npmrc" && echo "revisar .npmrc"
git diff --cached | grep -c "ghp_[A-Za-z0-9]"      # debe ser 0

git commit -m "feat(<TICKET>): import <repo> · migración Vite→Next 16 App Router server-rendered"
git merge-base --is-ancestor playsistemico/main HEAD && echo "✅ ancestro común" || echo "❌ historias no relacionadas"
git push playsistemico import-clean:"$MIGBR"
gh pr create --repo $REPO --base main --head "$MIGBR" --title "..." --body "..."
```

## Por qué `git checkout <migbr> -- .` y no merge/rebase

`git checkout <branch> -- .` copia el TREE (archivos) de esa branch al índice actual, SIN traer su history. El commit resultante tiene como único parent el `Initial commit` del repo destino → 1 commit limpio, ancestro común, sin el secreto del ancestro de la migración. Es el squash limpio.

## Gotcha

- `git checkout <migbr> -- .` NO borra archivos presentes en la base y ausentes en migbr. Si la base tiene archivos stale (raro en repo nuevo con solo README), borrarlos a mano. En repo recién creado (solo README) no aplica — el README de la migración pisa el del repo.
- Verificar el conteo de archivos staged tiene sentido (`git diff --cached --name-only | wc -l`).
