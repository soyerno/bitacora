# Clon promos-hub → nuevo frontend · mapa de valores per-project

`promos-hub-site` es la fuente canónica de infra (EKS + Istio, `next start`, next-runtime-env, sin CloudFront). Thin wrapper de `playsistemico/workflows@v1` + chart Istio externo. Clonar cada archivo y cambiar SOLO los valores per-project.

## Valores que cambian (fork promos-hub → `<repo>`)

| Archivo | Cambio |
|---------|--------|
| `helm/values.yaml` | `exposeName: "<slug>"` (🔴 NO el repo — es el slug del host/route Istio, corto y sin guiones; promos-hub usa `exposeName: "promoshub"` con `app.name: "promos-hub-site"`. Para aprendeatumodo ambos coinciden = `aprendeatumodo`, pero NO asumir que `exposeName == repo`). `app.name: "<repo>"` (nombre completo del repo). `containerPort: 3000`. 🔴 `livenessProbe`/`readinessProbe` `httpGet.path: /<basePath>` (si hay basePath; promos-hub usa `/`). Resto (istio, autoscaling, resources, observability) igual. |
| `helm/namespace.yaml` | templated `${PROJECT_NAME}-${ENVIRONMENT}` — igual. |
| `catalog/global.yaml` | `squad: <squad>`, `ecr: true`, `eks: true`. |
| `catalog/{develop,qa,preprod,production}.yaml` | `iam.role_name: <repo>`. |
| `.sops.yaml` | KMS ARNs por env → `TODO(devops)`. Account IDs en comments (dev/qa 151605301785, preprod 262134918714, prod 821600326346). NO inventar ARNs. |
| `parameters/<env>/configurations.yaml` | `NEXT_PUBLIC_*` del front (STORYBLOK_VERSION draft/published, SITE_URL por env, DD_SERVICE=`<repo>`, DD_ENV, ENV, APP_VERSION, Amplitude). Plaintext. |
| `parameters/<env>/secrets.yaml` | SOPS-encrypted cuando haya KMS (Storyblok token si es sensible, Amplitude experiment). Placeholder hasta entonces. (promos-hub tiene `secrets.yaml` en los 4 envs — verificado.) |
| `Dockerfile` | `FROM ${REGISTRY}modo-base:${BASE_VERSION}-node22`, `EXPOSE 3000`. (promos-hub EXPOSE 8080 es un mismatch interno; usar 3000 que matchea el app.) |
| `entrypoint.sh` | SSM `get-parameters-by-path --with-decryption` → export → `exec pnpm start` (`next start` :3000). `exec` para SIGTERM. |
| `.github/workflows/*` | delegan `@v1`, `node-version: 22`. `extra-content: "dist/"` (drop loaderNextImage si el front no tiene custom loader). Canales Slack del squad. |
| `sonar-project.properties` | `projectKey=playsistemico_<repo>`. `sonar.sources` = los source roots REALES del repo migrado (promos-hub usa `src`; aprendeatumodo usa `app,src` por el App Router top-level). Project-dependent — no copiar ciego. |
| `.dockerignore` | promos-hub excluye solo `.github/ parameters/ helm/`. Agregar `catalog/` es opcional/recomendado (infra-only, no va en la imagen). NO excluir `dist/` ni `node_modules` (la imagen los necesita — `extra-content: "dist/"`; promos-hub no los excluye). |

## Lo que NO cambia (estático)

`domainName: modo.com.ar`, `internalDomain`, estructura istio/serviceAccount/strategy/volumes/observability, refs `@v1`, account IDs por env, el mecanismo SSM→PublicEnvScript→envManager.

## Contrato runtime env (tabla NEXT_PUBLIC_* a SSM)

Lo que `entrypoint.sh` lee de SSM y `<PublicEnvScript/>` expone. Derivar del `envManager.ts` del front migrado. Para aprendeatumodo: `NEXT_PUBLIC_STORYBLOK_TOKEN/VERSION`, `NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_AMPLITUDE_API_KEY`, `NEXT_PUBLIC_DD_*`, `NEXT_PUBLIC_APP_VERSION`, `NEXT_PUBLIC_ENV`.

## 🔴 Diferencias clave vs promos-hub (NO copiar ciego)

1. **Probes al basePath** (promos-hub sondea `/`; si tu front tiene basePath, `/` da 404).
2. **`exec pnpm start`** (promos-hub usa `npm run start`; ajustar al PM del repo).
3. **EXPOSE 3000** (no el 8080 del Dockerfile de promos-hub).
