# modo-frontend-onboarding

Playbook end-to-end para llevar un frontend (SPA Vite/Lovable o app Next) a producción en la infra MODO (EKS + Istio) bajo el org `playsistemico`. Caso canónico: **aprendeatumodo** (COENXT-308 · 7 PRs).

## Quick start

- **Trigger**: `/modo-frontend-onboarding` o frases ("subir <front> a playsistemico", "llevar la SPA a prod MODO", "onboarding de un frontend nuevo").
- **Output**: PR de migración (→ main) + ticket JSM de provisioning (con aprobador) + PRs de infra individuales por paso (catalog/helm/parameters/ci/cd/docker).
- **Orquesta** otros skills, no los duplica.

## Fases

0. Discovery + gate de ownership (squad, **aprobador**, grupos, host — preguntar, no inventar).
1. Migración a Next 16 server-rendered (`vite-to-nextjs-app-router`).
2. Subida limpia a playsistemico (squash sin secreto en history).
3. Ticket JSM a devops (`modo-jsm-ticket`) — preguntando el aprobador y los grupos.
4. PRs de infra individuales por paso (clon promos-hub, slices sin overlap).
5. Orden de merge + handoff.

## Files

- `SKILL.md` — workflow completo + gotchas + reglas.
- `reference/clean-import-recipe.md` — squash limpio a playsistemico (sin PAT en history).
- `reference/jsm-provisioning-ticket.md` — qué pide el ticket + campos que se preguntan (aprobador/grupos).
- `reference/infra-prs-recipe.md` — loop de 6 PRs individuales por slice.
- `reference/promos-hub-clone-map.md` — valores per-project del clon promos-hub.

## Skills que orquesta

`vite-to-nextjs-app-router` · `modo-jsm-ticket` · `modo-stakeholder-gate` · `sops-parameters-manager` · `github-packages-auth` · `helm-k8s-best-practices` · `frontend-security-checklist`.

## Changelog

- **2026-05-27** — creado. Destilado del onboarding de aprendeatumodo (Vite 5 SPA → Next 16 → playsistemico, 7 PRs). Endurecido con rondas de audit independiente. (Detalle en `SKILL.md`.)
- **2026-05-27** — +gotcha Lovable `.git` muerto (pointer a path nix inexistente → `git init` fresh) + verify de stage limpio (`.env` fuera, sin node_modules/dist, sin secretos) para subida de repo sin history. Caso modo-govern → SoyErnoModo. (Detalle en Fase 2 + gotcha #7.)
