#!/usr/bin/env bash
# modo-landing smoke test — HTTP-level validation of key routes.
# Usage: ./smoke.sh [base_host]   (default: www.preprod.modo.com.ar)
# Compares status, title, byte size, and scans for error markers.
# Exit 0 if no FAIL; exit 1 if any route hard-fails (5xx / error page / unexpected 404).
set -uo pipefail

HOST="${1:-www.preprod.modo.com.ar}"
BASE="https://${HOST}"
UA="Mozilla/5.0 (modo-landing-smoke)"
TIMEOUT=30

# Routes: "path|expect"  where expect = ok2xx | redirect-shell | 404ok
# redirect-shell = deeplink pages that return 200 with a minimal shell + empty <title>
ROUTES=(
  "/|ok2xx"
  "/comercios|ok2xx"
  "/blog|ok2xx"
  "/tiendas-online|ok2xx"
  "/promos|ok2xx"
  "/qr|redirect-shell"
  "/account_linking|redirect-shell"
  "/account_linking_error|redirect-shell"
  "/personal_qr_error|redirect-shell"
  "/pagar|redirect-shell"
  "/recargas|redirect-shell"
)

fails=0
printf "%-26s %-5s %-7s %-7s %-14s %s\n" "ROUTE" "HTTP" "TIME" "BYTES" "VERDICT" "TITLE"
for entry in "${ROUTES[@]}"; do
  r="${entry%%|*}"; expect="${entry##*|}"
  body=$(curl -sL -A "$UA" --max-time "$TIMEOUT" "$BASE$r")
  code=$(curl -sL -o /dev/null -w "%{http_code}" -A "$UA" --max-time "$TIMEOUT" "$BASE$r")
  t=$(curl -sL -o /dev/null -w "%{time_total}" -A "$UA" --max-time "$TIMEOUT" "$BASE$r")
  bytes=$(printf "%s" "$body" | wc -c | tr -d ' ')
  title=$(printf "%s" "$body" | grep -oiE "<title[^>]*>[^<]*</title>" | head -1 | sed -E 's/<[^>]+>//g' | cut -c1-40)
  # error markers that mean a real broken page (not a normal /error route render)
  err=$(printf "%s" "$body" | grep -ciE "Application error: a client-side exception|Internal Server Error|>500<|This page could not be found.*static")

  verdict="PASS"
  case "$expect" in
    ok2xx)        [ "$code" = "200" ] || verdict="FAIL($code)";;
    redirect-shell) [ "$code" = "200" ] || verdict="FAIL($code)";;  # shell must still be 200
    404ok)        [ "$code" = "404" ] || verdict="WARN($code)";;
  esac
  [ "${err:-0}" -gt 0 ] && verdict="FAIL(errpage)"
  [[ "$verdict" == FAIL* ]] && fails=$((fails+1))

  printf "%-26s %-5s %-7s %-7s %-14s %s\n" "$r" "$code" "$t" "$bytes" "$verdict" "${title:-—}"
done

echo
echo "FAILS: $fails"
[ "$fails" -eq 0 ] || exit 1
