# modo-landing-smoke-test

Smoke test HTTP-level de modo-landing (modo.com.ar) por ambiente. Valida que las features levanten contra el edge live, compara prod vs preprod para cazar regresiones, y sabe qué versión está desplegada por env.

## Quick start

- Trigger: `/smoke-modo-landing`, "smoke test de modo-landing", "probá preprod", "se rompió X en prod"
- Comando: `~/.claude/skills/modo-landing-smoke-test/scripts/smoke.sh www.preprod.modo.com.ar`
- Output: tabla `ROUTE · HTTP · TIME · BYTES · VERDICT · TITLE` + exit code (1 si hay FAIL)

## Features

- Script `smoke.sh` parametrizable por host (prod/preprod/qa/develop)
- Maneja el redirect apex→www (gotcha #1)
- Distingue deeplink shells (200 + title vacío = OK) de pages de contenido (gotcha #2)
- Patrón de comparación prod vs preprod para separar regresión de código vs CMS content (gotcha #3)
- Snippet `gh api deployments` para saber qué versión corre cada env antes de testear
- Catálogo de pages high-risk sin tests (deeplink/qr/linking) en `reference/`

## Files

- `SKILL.md` — proceso, gotchas, interpretación de resultados, anti-patterns
- `README.md` — esta doc
- `scripts/smoke.sh` — smoke test ejecutable (editá el array `ROUTES`)
- `reference/high-risk-pages.md` — pages sin tests que las migraciones Next ponen en peligro

## Changelog

- **2026-05-27** — Skill creado durante el review del PR #1482 (migración Next 12→16). Smoke test de preprod baseline: home/comercios/blog/tiendas-online OK, deeplink pages (qr/account_linking*/personal_qr_error/pagar) 200 con shell esperado, `/promos` 404 en preprod vs 200 en prod (regresión de entorno, probable CMS). Documentado: 3 gotchas (apex→www 301, deeplink shells, prod-vs-preprod), `gh deployments` para versión live, y el gap de las 4 pages deeplink/qr/linking sin tests (usan next/router + SSR → frágiles en migración Next).
- **2026-05-27** — Cerrado el gap: agregados 17 tests jest+RTL para qr/account_linking/account_linking_error/personal_qr_error (commit `test(EXA)` en PR #1482, 219 suites / 1263 passed). `reference/high-risk-pages.md` actualizado con los patrones validados: tests en `src/pages-tests/` (no `src/pages/`, Next rutea), TDZ en factory de `jest.mock` (usar `var`+getter), router controllable mutado en beforeEach, stubs de deps pesadas (useBanksDeeplinks/AppList/error), profundidad relativa según subdir.
