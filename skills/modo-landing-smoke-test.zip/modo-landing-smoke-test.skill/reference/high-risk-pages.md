# Pages high-risk · deeplink/redirect · modo-landing

Pages que las migraciones de Next (12→16) ponen en peligro porque usan `next/router` + `getServerSideProps` + redirects client-side. **Estado 2026-05-27: ya tienen tests** (`src/pages-tests/`, 17 tests, commit `test(EXA)` en PR #1482). Antes tenían cero — el smoke HTTP las ve 200 pero no ejecuta el redirect JS, así que sin estos tests una regresión del router pasaba silenciosa.

| Page | Usa | Por qué es frágil en migración Next |
|---|---|---|
| `src/pages/qr/index.js` | `Router` (next/router), `react-device-detect` (`isAndroid`) | Redirect por device. Next 13+ cambió comportamiento de router; `react-device-detect` SSR puede divergir. |
| `src/pages/account_linking.jsx` | `getServerSideProps`, `useBanksDeeplinks`, `AppList` | SSR + deeplink bancario. Image en AppList tocado por la migración. |
| `src/pages/account_linking_error.jsx` | `useRouter`, `Error` component, `useBanksDeeplinks` | Lee query params del router para el deeplink de reintento. |
| `src/pages/personal_qr_error.jsx` | `useRouter`, `Error` component, `useBanksDeeplinks` | Idéntico patrón al anterior. |
| `src/components/linking.js` | — | Componente compartido de linking. |

## Por qué importan

Son los pasos finales del flujo de **vinculación de cuenta bancaria** y **QR interoperable** — entrada de usuarios desde la app/banco al sitio. Si la migración rompe el redirect (router API, query parsing, SSR hydration) estas pages fallan **silenciosamente** y no hay test que lo cace. El smoke HTTP las ve 200 (el shell levanta) pero NO ejecuta el redirect JS → no detecta el bug real.

## Cómo se testean (patrones validados, jest + RTL)

Tests viven en `src/pages-tests/<route>/` — **NUNCA en `src/pages/`**: Next rutearía el `.test.*` como una page. (El repo ya tiene `src/pages-tests/blog/`, `ayuda/`, etc.)

Gotchas jest al mockear estas pages:

1. **TDZ en el factory de `jest.mock`**: el factory corre al importar el módulo (hoisted arriba de todo). Si referenciás un `const`/`let` adentro (ej. `push: mockPush`), explota con `Cannot access 'mockPush' before initialization`. Fix: declarar el holder con `var` + acceder vía getter / wrapper lazy:
   ```js
   var mockState = { pathname: '/qr', isAndroid: false, push: jest.fn(() => Promise.resolve(true)) };
   jest.mock('next/router', () => ({
     __esModule: true,
     default: { get pathname() { return mockState.pathname; }, push: (...a) => mockState.push(...a) },
   }));
   jest.mock('react-device-detect', () => ({ get isAndroid() { return mockState.isAndroid; } }));
   ```
   (`mockState` con prefijo `mock` es lo único que jest permite referenciar en el factory.)

2. **Router controllable por test** (query/asPath): objeto `mock`-prefijado mutado en `beforeEach`:
   ```js
   const mockRouter = { query: {}, asPath: '/account_linking_error' };
   jest.mock('next/router', () => ({ __esModule: true, useRouter: () => mockRouter }));
   // en el test: mockRouter.query = { bank: 'modo' };  mockRouter.asPath = '...?bank=x';
   ```

3. **Mockear deps pesadas** a stubs que exponen props vía `data-testid` + `data-*`: `useBanksDeeplinks` (`jest.mock('../services/banks')`), `components/AppList`, `components/error`. Así asserteás "pasó el app correcto / isModo correcto" sin renderizar styled-components + DownloadButton + idToStoreLink.

4. **Profundidad relativa**: tests en `src/pages-tests/X.test.jsx` (raíz de pages-tests) usan `../pages/...` / `../services/...`; los que están en subdir (`src/pages-tests/qr/index.test.jsx`) usan `../../`.

Qué cubrir por page: redirect correcto según device/query (push con la URL esperada), guard (no redirige fuera de la ruta), `null` sin data / sin match de deeplink, `isModo` por `query.bank`, y `getServerSideProps` devolviendo el `baseUrl`.

Patrón de mock de router post-Next-16 también en `nextjs-pages-router-migration/reference/downstream-rebase-recipe.md`.

## Cómo se descubrió

Durante el review del PR #1482 (migración 12→16), el user pidió validar que estas pages tuvieran tests "para ver que no se rompa nada". Inventario:
```bash
REF=origin/feat/EXA-nextjs-12-to-16-migration
git ls-tree -r --name-only "$REF" | grep -iE "(qr|linking|personal|deeplink).*(test|spec)"   # → vacío
```
Resultado: 0 tests. Las pages usan exactamente las APIs que la migración cambia. Gap real, no cubierto por el quality gate (SonarCloud mide coverage de código nuevo, pero estas pages no son código nuevo del PR).
