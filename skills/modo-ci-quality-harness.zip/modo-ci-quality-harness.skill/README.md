# modo-ci-quality-harness

Skill MODO para instalar y validar el harness de calidad CI en cualquier frontend
del workspace: **audit hard-fail · bundle-size · visual regression · a11y**.

Codifica el rollout validado el 2026-05-26 (origen: review de `modo-landing-web-ui-lib#41`).

## Por qué existe

Cada repo MODO tiene un build distinto (rollup preserveModules, vite single-bundle,
Next con distDir custom, Vite+Bun). **No hay una config genérica que sirva.** Este
skill encapsula el árbol de decisión build→config + los gotchas cazados, para no
re-derivarlos a mano cada vez.

## Uso

```
/ci-quality-harness            # o frase natural: "validá la calidad de CI en <repo>"
```

1. Corre `scripts/detect-repo-type.sh <repo>` → tipo de build + gates aplicables.
2. Por cada gate: worktree → install/build → medir baseline real → drop-in → validar exit 0 → PR.
3. Thresholds: libs +15%, apps +10%. Gate A blocking día 1; B/C/D escalation 2 sprints.

## Estructura

```
SKILL.md                          # decision tree + flujo + gotchas resumidos
scripts/detect-repo-type.sh       # auto-detect build/PM/storybook/gates
reference/
├── decision-tree.md              # config size-limit + workflow por TYPE
├── gotchas.md                    # 12 trampas con fix
└── rollout-state.md              # PRs abiertos + backlog + hallazgos
reference/drop-ins/               # plantillas validadas
├── pr-audit.yml
├── bundle-size.pnpm.yml · bundle-size.bun.yml
├── size-limit.{lib-rollup-preserve,lib-vite,next,vite}.json
├── a11y.yml · a11y-storybook.mjs · axe-rules.json
└── loki.yml · loki.config.js
```

## No confundir con

- **guardia / pr-quality-review**: revisan PRs existentes. Este **instala gates nuevos**.
- **frontend-security-checklist**: CSP/headers (layer 3). Complementario.

## Estado

10+ PRs abiertos al 2026-05-26 (ver `reference/rollout-state.md`). Memoria persistente:
`ci-quality-harness-rollout-2026-05-26` (namespace obsidian-vault).
