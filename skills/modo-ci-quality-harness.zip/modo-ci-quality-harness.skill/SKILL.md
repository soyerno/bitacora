---
name: modo-ci-quality-harness
description: >-
  Instala y valida el harness de calidad CI en cualquier frontend MODO: audit
  hard-fail, bundle-size guard, visual regression (Loki) y a11y (axe WCAG 2.2 AA).
  Auto-invocable cuando el usuario dice (ES/EN) "validá la calidad de CI",
  "agregá bundle-size", "agregá el guard de tamaño", "check de accesibilidad en CI",
  "visual regression", "audit hard-fail", "harness de calidad", "lo mismo en modo-landing",
  "/ci-quality-harness". También al detectar que un repo MODO no tiene gate de
  bundle-size/a11y/visual o tiene pr-audit con continue-on-error. NO es un review
  de PR (eso es guardia/pr-quality-review) — este INSTALA gates nuevos.
---

# MODO CI Quality Harness

Instala 4 clases de gate de calidad en frontends MODO, con la config correcta
por **tipo de build** (no hay config genérica que sirva para todos).

Origen: review de `modo-landing-web-ui-lib#41` detectó 4 gaps (audit no-gate,
sin bundle-size, sin visual regression, sin a11y). Este skill codifica el rollout
validado el 2026-05-26 (10+ PRs across 5 repos).

## Los 4 gates

| Gate | Qué hace | Tool | Arranca |
|------|----------|------|---------|
| **A · audit** | Bloquea vulns critical en deps | `pnpm audit --audit-level=critical` | blocking día 1 |
| **B · bundle-size** | Budget de tamaño por bundle | `size-limit` | non-blocking → blocking 2 sprints |
| **C · visual regression** | Screenshot diff de Storybook | Loki (free) / Chromatic (paid) | blocking con baseline |
| **D · a11y** | axe WCAG 2.2 AA serious+critical | Playwright + `@axe-core/playwright` | report-only → blocking tras backlog |

## Regla de oro: la config depende del tipo de build

**NO copies una config genérica.** Antes de escribir nada, detectá el tipo:

```bash
bash ~/.claude/skills/modo-ci-quality-harness/scripts/detect-repo-type.sh <repo-path>
```

Mapeo build → config bundle-size (ver `reference/decision-tree.md` para el detalle):

| Tipo de repo | Detección | Config size-limit |
|--------------|-----------|-------------------|
| **lib rollup preserveModules** | `rollup.config.*` + `preserveModules: true` | `import: "{ X }"` + `ignore: [peerDeps]`, preset-small-lib (esbuild, tree-shaken) |
| **lib vite single-bundle** | `vite.config.*` + `build.lib` | `path: dist/index.es.js` directo + `ignore: [peerDeps]` |
| **app Next** | `next` dep + `distDir` | `@size-limit/file`, glob `<distDir>/static/chunks/**` |
| **app Vite** | `vite` + no `build.lib` | `@size-limit/file`, glob `dist/assets/*` |

Package manager: detectar `pnpm-lock.yaml` (pnpm), `bun.lock`/`bun.lockb` (Bun),
`package-lock.json` (npm). El workflow usa el PM correcto.

## Flujo de instalación (por repo, por gate)

**Siempre validar local antes de pushear** (regla MODO `smoke-test-before-distill`).
Cada gate B/C/D necesita medir/correr real, no asumir.

1. **Worktree dedicado** desde main (regla MODO worktrees-siempre).
2. **Detectar tipo de build** con el script.
3. **Install + build** con el PM correcto + token GitHub Packages
   (`NODE_AUTH_TOKEN` para pnpm/npm, `.npmrc` scoped para Bun).
4. **Medir baseline real** (size-limit) o **correr el gate** (axe/Loki).
5. **Setear thresholds**: libs +15%, apps +10% sobre baseline medido.
6. **Copiar drop-in** de `reference/drop-ins/` ajustado al tipo.
7. **Verificar exit 0 local**.
8. **Commit + push + PR** con `pr-body` que cite baselines reales.

## Drop-ins validados

En `reference/drop-ins/`:
- `pr-audit.yml` — gate A (critical sin continue-on-error)
- `bundle-size.pnpm.yml` / `bundle-size.bun.yml` — gate B (workflow propio, NO andresz1 action)
- `size-limit.{lib-rollup,lib-vite,next,vite}.json` — gate B configs por tipo
- `a11y.yml` + `a11y-storybook.mjs` + `axe-rules.json` — gate D (Playwright, version-agnostic)
- `loki.yml` + `loki.config.js` — gate C

## Gotchas (cazados en el rollout — leer `reference/gotchas.md`)

1. **No uses `@storybook/test-runner`** para a11y — acopla a la major de Storybook;
   repos con SB mezclado (7.2 + 7.6 + transitive 8.x) rompen con
   `Cannot find module 'storybook/internal/common'`. Usá el script Playwright+axe.
2. **No uses `andresz1/size-limit-action`** — no maneja el registry privado
   `@playsistemico`. Workflow propio con `.npmrc` token explícito.
3. **pnpm store v10 vs v11**: corepack pnpm ≠ system pnpm → `ERR_PNPM_UNEXPECTED_STORE`.
   Usar un solo pnpm consistente, reinstalar si cambia.
4. **`[[...slug]]` rompe el glob de size-limit** (brackets = glob class). Excluir esa
   page como budget individual; igual cuenta en el total.
5. **Chunks de Next tienen timestamp/hash inyectado** → usar globs (`framework-*.js`),
   nunca nombres fijos.
6. **`npx size-limit` baja v12 de la red** en vez del local → usar `node_modules/.bin/size-limit`.
7. **Cross-org**: repos en `SoyErnoModo` necesitan secret `MODO_PKG_TOKEN` para deps
   `@playsistemico` (el `github.token` no accede a packages de otra org).
8. **a11y script: `networkidle` cuelga** en iframes Storybook → usar `domcontentloaded`
   + `waitForSelector('#storybook-root')` + 150ms.
9. **axe-core/playwright exige `browser.newContext().newPage()`**, no `browser.newPage()`.
10. **promos-hub tiene `@storybook/react` como dep pero NO Storybook configurado**
    (0 stories) → gates C/D no aplican. Verificar `.storybook/` + stories reales antes.

## Escalation de thresholds (gates B/C/D)

`2 sprints non-blocking → 1 review → blocking`. Excepción: gate A (audit critical)
es blocking día 1. Gate D arranca report-only si hay backlog de violaciones
(caso modo-ui-lib-web: image-alt/button-name/aria en stories CMS).

## Estado del rollout (2026-05-26)

Ver memoria `ci-quality-harness-rollout-2026-05-26` (namespace obsidian-vault) y
`reference/rollout-state.md`. Plan canónico: `modo-landing#1493`.

## Relacionados

[[modo-pr-author]] (autora el PR) · [[frontend-security-checklist]] (CSP layer 3) ·
guardia/pr-quality-review (review, no install).
