#!/usr/bin/env bash
# check-pr-format.sh — Valida que un PR cumpla el formato MODO canónico.
#
# Usage:
#   ./check-pr-format.sh <PR_NUMBER> [<owner>/<repo>]
#
# Default repo: playsistemico/modo-landing
# Requires: gh CLI authenticated, jq

set -euo pipefail

PR="${1:-}"
REPO="${2:-playsistemico/modo-landing}"

if [ -z "$PR" ]; then
  echo "usage: $0 <PR_NUMBER> [<owner>/<repo>]" >&2
  exit 2
fi

if ! command -v gh >/dev/null; then
  echo "gh CLI no instalado" >&2
  exit 2
fi
if ! command -v jq >/dev/null; then
  echo "jq no instalado" >&2
  exit 2
fi

DATA=$(gh pr view "$PR" --repo "$REPO" --json title,body,state,headRefName,baseRefName)
TITLE=$(echo "$DATA" | jq -r '.title')
BODY=$(echo "$DATA" | jq -r '.body')
STATE=$(echo "$DATA" | jq -r '.state')
HEAD=$(echo "$DATA" | jq -r '.headRefName')
BASE=$(echo "$DATA" | jq -r '.baseRefName')

echo "=== PR #$PR · $REPO"
echo "Branch: $HEAD → $BASE · State: $STATE"
echo ""

PASS=0
FAIL=0

check() {
  local label="$1"; local condition="$2"
  if eval "$condition"; then
    echo "  ✓ $label"
    PASS=$((PASS+1))
  else
    echo "  ✗ $label"
    FAIL=$((FAIL+1))
  fi
}

echo "## Título"
TITLE_LEN=$(echo -n "$TITLE" | wc -c | tr -d ' ')
echo "  ($TITLE_LEN chars) $TITLE"
check "Largo ≤70 chars"                    "[ $TITLE_LEN -le 70 ]"
check "No termina con … (truncado)"        "[[ ! \"$TITLE\" =~ …\$ ]]"
check "Empieza con type(scope):"           "[[ \"$TITLE\" =~ ^(feat|fix|refactor|style|perf|docs|test|ci|build|chore|revert|merge)\\(.+\\): ]]"
check "Type en lowercase"                  "[[ ! \"$TITLE\" =~ ^[A-Z] ]]"
check "No termina con punto"               "[[ ! \"$TITLE\" =~ \\.\$ ]]"

echo ""
echo "## Body"
check "Tiene sección '## Descripción'"     "echo \"\$BODY\" | grep -q '^## Descripción'"
check "Tiene sección 'Evidencia'"          "echo \"\$BODY\" | grep -q '## Evidencia'"
check "Tiene sección 'JIRA'"               "echo \"\$BODY\" | grep -q '## JIRA'"
check "Tiene sección 'Checklist'"          "echo \"\$BODY\" | grep -q '## Checklist'"
check "Sin placeholders [Change!]"         "! echo \"\$BODY\" | grep -q '\\[Change!\\]'"
check "Sin <TBD>"                          "! echo \"\$BODY\" | grep -qi '<TBD>\\|<por completar>\\|lorem ipsum'"
check "Sin 'apetito' (banned)"             "! echo \"\$BODY\" | grep -qi 'apetito'"
check "Sin 'stakeholders' (banned)"        "! echo \"\$BODY\" | grep -qi 'stakeholders'"
check "Sin 'deliverables' (banned)"        "! echo \"\$BODY\" | grep -qi 'deliverables'"

echo ""
echo "## Checklist"
CHK_TOTAL=$(echo "$BODY" | grep -cE '^- \[[ x]\]' || true)
CHK_MARKED=$(echo "$BODY" | grep -cE '^- \[x\]' || true)
check "Tiene items de checklist"           "[ $CHK_TOTAL -ge 4 ]"
check "Al menos uno marcado (no 100% vacío)" "[ $CHK_MARKED -ge 1 ]"

echo ""
echo "## Evidencia"
# Si hay cambios visuales, debe haber screenshots o gif
HAS_VISUAL=$(echo "$BODY" | grep -cE '!\[|\.png|\.jpg|\.jpeg|\.gif|\.mp4|\.webm' || true)
HAS_NA=$(echo "$BODY" | grep -ciE 'N/A.*sin cambios visuales|sin cambios visuales|CI-only|backend' || true)
HAS_VISUAL=${HAS_VISUAL:-0}
HAS_NA=${HAS_NA:-0}
check "Evidencia tiene visuales o N/A explícito" "[ $HAS_VISUAL -ge 1 ] || [ $HAS_NA -ge 1 ]"

echo ""
echo "## Secciones opcionales (advisory)"

# Pull the diff to detect security-sensitive paths
DIFF_FILES=$(gh pr view "$PR" --repo "$REPO" --json files --jq '.files[].path' 2>/dev/null || echo "")

# Security review trigger detection
SEC_TRIGGER=$(echo "$DIFF_FILES" | grep -E '^src/pages/api/|^next\.config\.js$|^\.github/workflows/|^helm/|auth|token|session|jwt' | head -5)
if [ -n "$SEC_TRIGGER" ]; then
  echo "  ⚠ Security review TRIGGER detected — diff toca:"
  echo "$SEC_TRIGGER" | sed 's/^/      /'
  if echo "$BODY" | grep -qi '^## Security review'; then
    echo "  ✓ Sección 'Security review' presente"
  else
    echo "  ✗ Sección 'Security review' FALTA (obligatoria por scope del diff)"
    FAIL=$((FAIL+1))
  fi
fi

# Tests section advisory (skip for docs/chore titles)
if [[ ! "$TITLE" =~ ^(docs|chore) ]]; then
  if echo "$BODY" | grep -qi '^## Tests'; then
    echo "  ✓ Sección 'Tests' presente"
  else
    echo "  ⚠ Sección 'Tests' faltante (recomendada para este tipo de PR)"
  fi
fi

# Performance advisory if PR touches bundled client code
PERF_FILES=$(echo "$DIFF_FILES" | grep -E '^(src/components|src/pages|src/hooks|next\.config\.js|package\.json)' | head -1)
if [ -n "$PERF_FILES" ]; then
  if echo "$BODY" | grep -qi '^## Performance'; then
    echo "  ✓ Sección 'Performance' presente"
  else
    echo "  ⚠ Sección 'Performance' faltante (toca bundle del cliente)"
  fi
fi

# Rollback advisory for refactor/migration PRs
if [[ "$TITLE" =~ ^(refactor|chore.*migration) ]] || echo "$DIFF_FILES" | grep -qE '^(prisma/migrations|helm/|src/store)'; then
  if echo "$BODY" | grep -qi '^## Rollback'; then
    echo "  ✓ Sección 'Rollback' presente"
  else
    echo "  ⚠ Sección 'Rollback' faltante (refactor/migration sin plan B)"
  fi
fi

# Reviewers advisory if cross-team paths touched
CROSS_FILES=$(echo "$DIFF_FILES" | grep -E '^(helm/|\.github/|parameters/|server\.js)' | head -1)
if [ -n "$CROSS_FILES" ]; then
  if echo "$BODY" | grep -qi '^## Reviewers solicitados\|@[a-zA-Z]'; then
    echo "  ✓ Sección 'Reviewers' o @ menciones presente"
  else
    echo "  ⚠ Reviewers no asignados (toca infra/workflows — cross-team)"
  fi
fi

echo ""
echo "## Resultado"
echo "  PASS: $PASS · FAIL: $FAIL"
echo ""

if [ $FAIL -ne 0 ]; then
  exit 1
fi
