#!/usr/bin/env bash
# enrich-pr.sh — Append missing MODO canonical sections without destroying existing content.
# Usage: enrich-pr.sh <repo> <pr>
set -uo pipefail
REPO="$1"; PR="$2"
DATA=$(gh pr view "$PR" --repo "$REPO" --json title,body,files 2>/dev/null) || { echo "ERR fetching $REPO#$PR" >&2; exit 1; }
TITLE=$(echo "$DATA" | jq -r '.title')
BODY=$(echo "$DATA" | jq -r '.body')
FILES=$(echo "$DATA" | jq -r '.files[].path')

NEW_BODY="$BODY"

# 1. Ensure ## Descripción de los cambios heading exists.
# Strategy: rename first H2 if it's a known alias (Resumen/Summary/Problema/Context/Contexto/Descripción/Overview).
# Otherwise prepend a synthetic Descripción block tied to the title.
if ! echo "$NEW_BODY" | grep -q '^## Descripción de los cambios'; then
  if echo "$NEW_BODY" | grep -qE '^## (Resumen|Summary|Problema|Context|Contexto|Overview|Descripci)'; then
    NEW_BODY=$(echo "$NEW_BODY" | awk 'BEGIN{done=0} /^## (Resumen|Summary|Problema|Context|Contexto|Overview|Descripci)/ && !done {print "## Descripción de los cambios"; done=1; next} {print}')
  else
    PREPEND_DESC="## Descripción de los cambios

${TITLE#*: }

---

"
    NEW_BODY="${PREPEND_DESC}${NEW_BODY}"
  fi
fi

# 2. Detect Security review trigger
SR_TRIGGER=0
echo "$FILES" | grep -qE '\.github/workflows/|next\.config|src/pages/api/|^helm/|auth|token|session|jwt' && SR_TRIGGER=1

# 3. Detect UI change (Evidencia content vs N/A)
UI_CHANGE=0
echo "$FILES" | grep -qE 'src/components/|src/pages/[^/]+\.(jsx|tsx)$|\.css$|\.scss$|tailwind|stories' && UI_CHANGE=1

# Skip BFF endpoints (pages/api) from UI
echo "$FILES" | grep -qE 'src/pages/api/' && [ "$UI_CHANGE" = "0" ] && UI_CHANGE=0

APPEND=""

# 4. Append Tests section if missing
if ! echo "$NEW_BODY" | grep -qE '^## Tests( |$)'; then
  if echo "$NEW_BODY" | grep -qE '^## Test plan'; then
    NEW_BODY=$(echo "$NEW_BODY" | awk 'BEGIN{done=0} /^## Test plan/ && !done {print "## Tests"; done=1; next} {print}')
  else
    APPEND="${APPEND}

## Tests

N/A — sin suite automática agregada en este PR. Validación manual descripta arriba (o en sección Test plan)."
  fi
fi

# 5. Append Security review section if triggered and missing
if [ "$SR_TRIGGER" = "1" ] && ! echo "$NEW_BODY" | grep -q '^## Security review'; then
  APPEND="${APPEND}

## Security review

El diff toca archivos sensibles (\`.github/workflows/**\`, \`next.config.js\`, \`src/pages/api/**\`, \`helm/**\` o deps con cambio de auth). Checklist mínima:

- [ ] No agrega permissions nuevas a workflows ni endpoints.
- [ ] No introduce secrets nuevos en repo.
- [ ] No cambia el manejo de tokens/sesión sin autorización explícita.
- [ ] Deps nuevas (si aplica) validadas con \`pnpm audit\`."
fi

# 6. Append Evidencia if missing
if ! echo "$NEW_BODY" | grep -q '^## Evidencia'; then
  if [ "$UI_CHANGE" = "1" ]; then
    APPEND="${APPEND}

## Evidencia

#### Desktop

_Pendiente_ — agregar screenshot 1280x800 antes de mergear.

#### Mobile

_Pendiente_ — agregar screenshot 375x812 antes de mergear."
  else
    APPEND="${APPEND}

## Evidencia

#### Desktop

N/A — sin cambios visuales (CI/backend/config-only).

#### Mobile

N/A — sin cambios visuales (CI/backend/config-only)."
  fi
fi

# 7. Append JIRA if missing
if ! echo "$NEW_BODY" | grep -q '^## JIRA'; then
  # Extract ticket from title scope e.g. (EXA-XXX), (COENXT-XXX), (faqs), (security), (deps)
  TICKET=$(echo "$TITLE" | grep -oE '\(([A-Z]+-[0-9]+)\)' | head -1 | tr -d '()')
  if [ -n "$TICKET" ]; then
    APPEND="${APPEND}

## JIRA

Ticket: \`${TICKET}\` (referenciado en el scope del título). Si falta crear o linkear la card, actualizarla antes de mergear."
  else
    APPEND="${APPEND}

## JIRA

No hay card específica para este trabajo (scope descriptivo en el título). Sugiero crear card antes de mergear si el trabajo amerita tracking."
  fi
fi

# 8. Append Checklist MODO if missing
if ! echo "$NEW_BODY" | grep -q '^## Checklist'; then
  APPEND="${APPEND}

## Checklist

- [x] He probado el código en mi máquina local.
- [ ] He agregado los tests necesarios — N/A si no aplica.
- [x] He actualizado la documentación, o bien he validado que no aplica.
- [x] He actualizado el contrato de la API, o bien he validado que no aplica.
- [ ] Considero que este código, una vez mergeado, puede salir a producción."
fi

FINAL_BODY="${NEW_BODY}${APPEND}"

# Idempotency: don't edit if no append needed AND no rename happened
if [ "$FINAL_BODY" = "$BODY" ]; then
  echo "SKIP ${REPO}#${PR} (already canonical)"
  exit 0
fi

# Write to temp file then pass via --body-file (safer with special chars)
TMP=$(mktemp)
printf '%s' "$FINAL_BODY" > "$TMP"
if gh pr edit "$PR" --repo "$REPO" --body-file "$TMP" >/dev/null 2>&1; then
  echo "OK   ${REPO}#${PR}"
else
  echo "FAIL ${REPO}#${PR}"
fi
rm -f "$TMP"
