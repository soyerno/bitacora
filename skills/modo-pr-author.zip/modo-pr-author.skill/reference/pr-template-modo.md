# MODO PR Template (drop-in)

Template canónico para descripciones de PR en repos MODO. Copiar el bloque entre `---` y rellenar.

---

## 🎯 ¿Qué dolor soluciona?

<1-3 párrafos en voz rioplatense. Problema concreto y medible que dispara este PR — bug reportado, métrica que duele, costo operativo, deuda técnica con fecha de vencimiento. Si hay número, número (LCP +Xs, coverage bajó a Y%, build +Zmin, N tickets/semana). Sin esto el PR es vaporware.>

## 🛠️ ¿Qué tuvimos que hacer?

<Lista numerada de las decisiones técnicas tomadas. No es el diff — es el "qué hicimos en lenguaje humano" que un PM o un dev de otra área puede leer. Granularidad: archivo/módulo + decisión + por qué esa decisión y no otra.>

## 🎁 ¿Para qué?

<Outcome esperado en formato verificable. Métrica objetivo (LCP target, smells a 0, build -Xmin) o capacidad nueva habilitada (feature visible al user, unblock para el siguiente PR del stack). Si es estimado, marcarlo como "esperado post-deploy" y decir cuándo se mide.>

## Ticket

[**<TICKET-XXX> · <título descriptivo del ticket>**](<link Jira/Linear>)

<Una línea — Jira card específica del trabajo. Va ARRIBA del cuerpo (no solo al final) para que el reviewer y los crosslinks la encuentren en 2 segundos. Si no hay ticket todavía: justificar acá ("No hay card específica · es <razón>. Sugiero crear EXA-XXX antes de mergear.").>

## Milestone · <área/epic> [si aplica]

<2-4 líneas conectando este PR a la epic/milestone más amplia. Para PRs que aportan a un programa multi-PR (GEO, Next 16 migration, observability foundation, etc.). Incluir múltiples links contextuales a las cards padre:

- [<TICKET-XXX> · <título epic 1>](<link>) — <relación con este PR>
- [<TICKET-YYY> · <título epic 2>](<link>) — <relación con este PR>

Si el PR es one-off (no aporta a programa más amplio) → eliminar la sección entera.>

---

## Descripción de los cambios

<2-4 párrafos en español, voz rioplatense. Qué hace el PR, qué archivos/módulos toca, qué NO toca. Si es additive, decirlo. Si es breaking, decirlo en negrita.>

### Por qué ahora

- <Motivo 1: qué problema resuelve hoy>
- <Motivo 2: qué dependencia desbloquea>
- <Motivo 3: contexto de proyecto/incidente/decisión previa>

### <Sección técnica · ajustar título al cambio>

<Tabla, lista o prosa con el detalle técnico. Granularidad: alguien que no vio el código entiende qué pasa.>

Ejemplos de títulos según tipo de PR:
- Feature → `### Jobs / Componentes nuevos`
- Fix → `### Root cause y fix`
- Refactor → `### Cambios estructurales`
- CI → `### Jobs (paralelos)`
- Docs → `### Documentos tocados`

## Por qué no <alternativa técnica> [si aplica]

<Sección de descarte explícito. Cuando hay una alternativa "obvia" que NO elegiste, justificarla acá en 1-3 párrafos. Diferente a "Por qué ahora" (que es timing) — esta es justificación de DECISIÓN técnica.

Ejemplos de títulos:
- "Por qué no el paquete de core directo" — descarta usar lib existente.
- "Por qué no Server Components" — descarta usar feature framework.
- "Por qué no esperar a la migración" — descarta postergar.

Si no hay alternativa obvia que justificar → eliminar la sección.>

## Fuera de alcance (follow-up) [si aplica]

<Sección DEDICADA con prosa explicando QUÉ queda fuera y POR QUÉ. Distinta del `Follow-ups` final (que es bullet list corta de próximos PRs).

Usar acá cuando un trabajo relacionado merece su PROPIO ticket por razones de scope/riesgo/infra (ej. "el server core logger queda como ticket aparte porque arrastra dd-trace nativo al deploy image, decisión de infra que merece su propia revisión").

Granularidad: 1-3 párrafos por item out-of-scope. Si solo son bullets cortos → ir directo a `Follow-ups` al final.>

## Cómo se integra al flow [si aplica]

<Solo si el PR tiene impacto operativo: CI/CD, deploy, migraciones, breaking changes, feature flags, etc. Si no aplica, eliminar esta sección entera.>

## ⚠️ Heads-up antes de mergear [si aplica]

<Decisiones que el revisor tiene que tomar antes de aprobar. Listar opciones con recomendación clara.>

Formato:
- **A · <opción 1>** → <consecuencia>
- **B · <opción 2>** → <consecuencia>

Mi recomendación: **<letra>**, pero queda en manos del revisor.

## Verificación [variante compacta de Tests]

**Cuándo usar Verificación en lugar de Tests + Performance**: PRs chicos/medianos (<300 líneas) sin tablas before/after pesadas. Lista bullet con comandos + resultados literales. Caso canónico: PR #1497 (logger).

```
- `pnpm build` (lint + next build) — pasa
- `npx jest src/utils/logger` — 7/7 (TraceableError + obfuscación + forwarding Datadog), ModoLogger 98% cov
- lockfile sincronizado con la dep nueva
```

Si el PR amerita métricas detalladas (bundle, coverage delta, Web Vitals) → usar `Tests` + `Performance` secciones formales abajo.

## Tests [si aplica]

**Cuándo incluir**: PR con código de producción (no docs/chore/config-only). Sino, eliminar la sección.

```
Suite        Antes    Después   Δ
unit         1247     1252      +5
integration  89       91        +2
e2e          12       12        ±0
─────────────────────────────────
Coverage     78.4%    78.9%     +0.5pp
```

- Tests nuevos cubren: `<archivo o caso>`.
- Casos edge cubiertos: `<lista>`.
- Si bajó coverage, justificar acá.

## Performance [si aplica]

**Cuándo incluir**: tocaste rutas / componentes que entran en bundle del cliente, o cambiaste deps. Sino, eliminar.

```
Bundle             Antes      Después    Δ
First Load JS      215 KB     217 KB     +2 KB
Page-specific JS   45 KB      44 KB      -1 KB
─────────────────────────────────────────────
LCP (Lighthouse)   1.8s       1.7s       -0.1s
```

Notas:
- Si subió >5KB First Load → justificar.
- Si rompiste Web Vitals → blocker.

## Rollback [si aplica]

**Cuándo incluir**: cambio difícil de revertir (migrations, feature flag de gran scope, deploy con state, config infra). Sino, eliminar.

- **Plan A (rollback simple)**: `git revert <SHA>` + redeploy. Aplica si: <condición>.
- **Plan B (rollback complejo)**: <pasos concretos>. Aplica si: <condición>.
- **Datos a preservar**: <lista de tablas / keys / state que NO se debe perder>.
- **Tiempo estimado de rollback**: <X minutos>.

## Reviewers solicitados [si aplica]

**Cuándo incluir**: tocás áreas con dueños claros o el PR cruza equipos. Sino, eliminar.

- @<github-handle> — área <X>, razón <Y>.
- @<github-handle> — security review obligatoria (ver sección abajo).
- @<github-handle> — DevOps para coordinar wiring.

## Security review [obligatoria si toca BFF / auth / infra]

**Cuándo es obligatoria**:
- Tocaste `src/pages/api/*` (BFF endpoints).
- Tocaste código de auth/tokens/sesiones.
- Tocaste `next.config.js` headers / CSP / `next-safe`.
- Tocaste workflows de CI/CD.
- Tocaste env vars sensibles o `helm/` (SOPS).
- Agregaste dependencias nuevas (`package.json`).

**Qué pedirle al reviewer de seguridad** (checklist mínimo):

- [ ] No introduce XSS (verificó `dangerouslySetInnerHTML`, sanitización).
- [ ] No expone secrets en client bundle (`NEXT_PUBLIC_*` solo para datos públicos).
- [ ] Validación de input en endpoints BFF nuevos.
- [ ] No relaja CSP ni headers existentes sin justificar.
- [ ] Dependencias nuevas: licencia OK + no flaggeadas por `pnpm audit`.

Si no aplica ninguna de las condiciones de arriba → eliminar la sección.

## Evidencia

#### Desktop

<Screenshot 1280x800 via Playwright · O "N/A — sin cambios visuales" si es backend/CI>

#### Mobile

<Screenshot 375x812 via Playwright · O "N/A">

## JIRA

<Link directo a la card · O texto explícito: "No hay card específica para este trabajo (es <razón concreta>). Sugiero crear EXA-XXX antes de mergear.">

## Checklist

- [x|/ ] He probado el código en mi máquina local
- [x|/ ] He agregado los tests necesarios para validar mis pruebas de manera automatizada
- [x|/ ] He actualizado la documentación, o bien he validado que no aplica
- [x|/ ] He actualizado el contrato de la API, o bien he validado que no aplica
- [x|/ ] Considero que este código, una vez mergeado, puede salir a producción

**Reglas para el checklist**:
- Marcar honesto: `[x]` solo si lo hiciste. No marcar para inflar.
- Si no aplica, marcar `[x]` y poner al lado `— N/A, <razón>`.
- Si está bloqueado por una decisión (ej. heads-up arriba), dejar `[ ]` y referenciar.

## Follow-ups [si aplica]

- <Bullet 1: cosa que queda para próximo PR>
- <Bullet 2: tech-debt identificada>
- <Bullet 3: integraciones futuras>

---

## Variantes según tipo de PR

### PR de feature (con cambios visuales)
- **Por qué ahora** obligatorio.
- **Evidencia** obligatoria con screenshots reales (no placeholders).
- **Tests** obligatorio (no es opcional acá).
- **Performance** si toca rutas con tráfico (homepage, /comercios, /promos).

### PR de fix (bug)
- Estructura recomendada:
  - `### Root cause` — qué causó el bug.
  - `### Fix` — qué cambia este PR.
  - `### Regression test` — cómo se previene reaparición.
- **Heads-up**: si el bug afectó prod, mencionar incidente/usuarios afectados.
- **Tests** sección obligatoria con el regression test agregado.

### PR de CI / chore / build
- **Evidencia** = "N/A — sin cambios visuales" explícito.
- **JIRA** = si no hay, justificar (DevSecOps, plataforma, tech-debt).
- **Heads-up** crítico si rompe builds existentes.
- **Security review** obligatoria si toca `.github/workflows/` o secrets.

### PR de docs
- Cuerpo corto OK.
- Sin evidencia, sin tests.
- Linkear a fuentes si aplica (Confluence, ADR, RFC).
- Eliminar todas las secciones opcionales (Tests, Performance, Rollback).

### PR de refactor
- **Heads-up** obligatorio: ¿qué se rompe? ¿hay rollback fácil?
- **Rollback** sección obligatoria (refactors son notoriamente difíciles de revertir).
- **Tests** deben quedar marcados o con explicación.
- Mencionar SI se preserva el comportamiento (no debería cambiar nada visible).

### PR de security / BFF / infra
- **Security review** sección obligatoria con reviewer asignado.
- **Heads-up** obligatorio (impacto cross-team).
- **Rollback** obligatorio si toca `helm/` o config de prod.

## Matriz de obligatoriedad

| Sección                | feature visual | feature backend | fix bug | refactor | CI/chore | docs | security/BFF |
|---|---|---|---|---|---|---|---|
| 🎯 ¿Qué dolor?         | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| 🛠️ ¿Qué hacer?         | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| 🎁 ¿Para qué?          | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| **Ticket** (arriba)    | obligatorio    | obligatorio     | obligatorio | obligatorio | justificar si no | si aplica | obligatorio |
| **Milestone · epic**   | si epic activa | si epic activa  | no | si epic activa | si epic activa | no | si epic activa |
| Descripción            | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| Por qué ahora          | obligatorio    | obligatorio     | obligatorio | recomendado | recomendado | opcional | obligatorio |
| **Por qué no <alt>**   | si descarte    | si descarte     | no | si descarte | si descarte | no | si descarte |
| **Fuera de alcance (prosa)** | si scope grande | si scope grande | no | si scope grande | si scope grande | no | si scope grande |
| Heads-up               | si aplica      | si aplica       | si prod afectado | obligatorio | si rompe builds | no | obligatorio |
| **Verificación** (compacta) | si PR <300L | si PR <300L | si PR <300L | si PR <300L | si PR <300L | no | si PR <300L |
| **Tests** (tabla)      | si PR ≥300L    | si PR ≥300L     | si PR ≥300L | obligatorio | si aplica | no | si PR ≥300L |
| **Performance**        | si tráfico alto | opcional       | opcional | si toca hot path | no | no | opcional |
| **Rollback**           | si data migration | si data migration | opcional | obligatorio | si rompe | no | obligatorio |
| **Reviewers**          | si cross-team  | si cross-team   | si prod | obligatorio | si rompe | opcional | obligatorio |
| **Security review**    | si auth/tokens | si BFF/api      | si security bug | si infra | si workflows | no | obligatorio |
| Evidencia              | screenshots    | N/A explícito   | screenshots si UI | si UI | N/A | N/A | si UI |
| JIRA (final)           | si no Ticket arriba | si no Ticket arriba | si no Ticket arriba | si no Ticket arriba | si no Ticket arriba | si aplica | si no Ticket arriba |
| Checklist              | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| Follow-ups (bullets)   | si aplica      | si aplica       | si parche temporal | si quedan etapas | si aplica | no | si aplica |

**Regla `Ticket` vs `JIRA`**: si la card va arriba como `## Ticket`, omitir la sección `## JIRA` final (es duplicación). El template clásico tenía JIRA al final solamente — el patrón nuevo (PR #1497) lo sube arriba para que sea el primer link semántico del PR.

**Regla `Verificación` vs `Tests + Performance`**: usar `Verificación` compacta para PRs chicos sin métricas duras. PRs grandes (≥300L) o con bundle/Web Vitals impact deben usar `Tests` + `Performance` con tablas before/after.

**Cómo leer**: "obligatorio" = la sección DEBE estar; "si aplica" = incluir solo si pasa la condición de la sección; "opcional" = a criterio del autor; "no" = eliminar la sección.
