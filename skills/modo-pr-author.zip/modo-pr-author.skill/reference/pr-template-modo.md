# MODO PR Template (drop-in)

Template canónico para descripciones de PR en repos MODO. Copiar el bloque entre `---` y rellenar.

---

## 🎯 ¿Qué dolor soluciona?

<1-3 párrafos en voz rioplatense. Problema concreto y medible que dispara este PR — bug reportado, métrica que duele, costo operativo, deuda técnica con fecha de vencimiento. Si hay número, número (LCP +Xs, coverage bajó a Y%, build +Zmin, N tickets/semana). Sin esto el PR es vaporware.>

## 🛠️ ¿Qué tuvimos que hacer?

<Lista numerada de las decisiones técnicas tomadas. No es el diff — es el "qué hicimos en lenguaje humano" que un PM o un dev de otra área puede leer. Granularidad: archivo/módulo + decisión + por qué esa decisión y no otra.>

## 🎁 ¿Para qué?

<Outcome esperado en formato verificable. Métrica objetivo (LCP target, smells a 0, build -Xmin) o capacidad nueva habilitada (feature visible al user, unblock para el siguiente PR del stack). Si es estimado, marcarlo como "esperado post-deploy" y decir cuándo se mide.>

---

## Descripción de los cambios

<2-4 párrafos en español, voz rioplatense. Qué hace el PR, qué archivos/módulos toca, qué NO toca. Si es additive, decirlo. Si es breaking, decirlo en negrita.>

### Por qué ahora

- <Motivo 1: qué problema resuelve hoy>
- <Motivo 2: qué dependencia desbloquea>
- <Motivo 3: contexto de proyecto/incidente/decisión previa>

### <Sección técnica · ajustar título al cambio>

<Tabla, lista o prosa con el detalle técnico. Granularidad: alguien que no vio el código entiende qué pasa.>

Ejemplos de títulos según tipo de PR:
- Feature → `### Jobs / Componentes nuevos`
- Fix → `### Root cause y fix`
- Refactor → `### Cambios estructurales`
- CI → `### Jobs (paralelos)`
- Docs → `### Documentos tocados`

## Cómo se integra al flow [si aplica]

<Solo si el PR tiene impacto operativo: CI/CD, deploy, migraciones, breaking changes, feature flags, etc. Si no aplica, eliminar esta sección entera.>

## ⚠️ Heads-up antes de mergear [si aplica]

<Decisiones que el revisor tiene que tomar antes de aprobar. Listar opciones con recomendación clara.>

Formato:
- **A · <opción 1>** → <consecuencia>
- **B · <opción 2>** → <consecuencia>

Mi recomendación: **<letra>**, pero queda en manos del revisor.

## Tests [si aplica]

**Cuándo incluir**: PR con código de producción (no docs/chore/config-only). Sino, eliminar la sección.

```
Suite        Antes    Después   Δ
unit         1247     1252      +5
integration  89       91        +2
e2e          12       12        ±0
─────────────────────────────────
Coverage     78.4%    78.9%     +0.5pp
```

- Tests nuevos cubren: `<archivo o caso>`.
- Casos edge cubiertos: `<lista>`.
- Si bajó coverage, justificar acá.

## Performance [si aplica]

**Cuándo incluir**: tocaste rutas / componentes que entran en bundle del cliente, o cambiaste deps. Sino, eliminar.

```
Bundle             Antes      Después    Δ
First Load JS      215 KB     217 KB     +2 KB
Page-specific JS   45 KB      44 KB      -1 KB
─────────────────────────────────────────────
LCP (Lighthouse)   1.8s       1.7s       -0.1s
```

Notas:
- Si subió >5KB First Load → justificar.
- Si rompiste Web Vitals → blocker.

## Rollback [si aplica]

**Cuándo incluir**: cambio difícil de revertir (migrations, feature flag de gran scope, deploy con state, config infra). Sino, eliminar.

- **Plan A (rollback simple)**: `git revert <SHA>` + redeploy. Aplica si: <condición>.
- **Plan B (rollback complejo)**: <pasos concretos>. Aplica si: <condición>.
- **Datos a preservar**: <lista de tablas / keys / state que NO se debe perder>.
- **Tiempo estimado de rollback**: <X minutos>.

## Reviewers solicitados [si aplica]

**Cuándo incluir**: tocás áreas con dueños claros o el PR cruza equipos. Sino, eliminar.

- @<github-handle> — área <X>, razón <Y>.
- @<github-handle> — security review obligatoria (ver sección abajo).
- @<github-handle> — DevOps para coordinar wiring.

## Security review [obligatoria si toca BFF / auth / infra]

**Cuándo es obligatoria**:
- Tocaste `src/pages/api/*` (BFF endpoints).
- Tocaste código de auth/tokens/sesiones.
- Tocaste `next.config.js` headers / CSP / `next-safe`.
- Tocaste workflows de CI/CD.
- Tocaste env vars sensibles o `helm/` (SOPS).
- Agregaste dependencias nuevas (`package.json`).

**Qué pedirle al reviewer de seguridad** (checklist mínimo):

- [ ] No introduce XSS (verificó `dangerouslySetInnerHTML`, sanitización).
- [ ] No expone secrets en client bundle (`NEXT_PUBLIC_*` solo para datos públicos).
- [ ] Validación de input en endpoints BFF nuevos.
- [ ] No relaja CSP ni headers existentes sin justificar.
- [ ] Dependencias nuevas: licencia OK + no flaggeadas por `pnpm audit`.

Si no aplica ninguna de las condiciones de arriba → eliminar la sección.

## Evidencia

#### Desktop

<Screenshot 1280x800 via Playwright · O "N/A — sin cambios visuales" si es backend/CI>

#### Mobile

<Screenshot 375x812 via Playwright · O "N/A">

## JIRA

<Link directo a la card · O texto explícito: "No hay card específica para este trabajo (es <razón concreta>). Sugiero crear EXA-XXX antes de mergear.">

## Checklist

- [x|/ ] He probado el código en mi máquina local
- [x|/ ] He agregado los tests necesarios para validar mis pruebas de manera automatizada
- [x|/ ] He actualizado la documentación, o bien he validado que no aplica
- [x|/ ] He actualizado el contrato de la API, o bien he validado que no aplica
- [x|/ ] Considero que este código, una vez mergeado, puede salir a producción

**Reglas para el checklist**:
- Marcar honesto: `[x]` solo si lo hiciste. No marcar para inflar.
- Si no aplica, marcar `[x]` y poner al lado `— N/A, <razón>`.
- Si está bloqueado por una decisión (ej. heads-up arriba), dejar `[ ]` y referenciar.

## Follow-ups [si aplica]

- <Bullet 1: cosa que queda para próximo PR>
- <Bullet 2: tech-debt identificada>
- <Bullet 3: integraciones futuras>

---

## Variantes según tipo de PR

### PR de feature (con cambios visuales)
- **Por qué ahora** obligatorio.
- **Evidencia** obligatoria con screenshots reales (no placeholders).
- **Tests** obligatorio (no es opcional acá).
- **Performance** si toca rutas con tráfico (homepage, /comercios, /promos).

### PR de fix (bug)
- Estructura recomendada:
  - `### Root cause` — qué causó el bug.
  - `### Fix` — qué cambia este PR.
  - `### Regression test` — cómo se previene reaparición.
- **Heads-up**: si el bug afectó prod, mencionar incidente/usuarios afectados.
- **Tests** sección obligatoria con el regression test agregado.

### PR de CI / chore / build
- **Evidencia** = "N/A — sin cambios visuales" explícito.
- **JIRA** = si no hay, justificar (DevSecOps, plataforma, tech-debt).
- **Heads-up** crítico si rompe builds existentes.
- **Security review** obligatoria si toca `.github/workflows/` o secrets.

### PR de docs
- Cuerpo corto OK.
- Sin evidencia, sin tests.
- Linkear a fuentes si aplica (Confluence, ADR, RFC).
- Eliminar todas las secciones opcionales (Tests, Performance, Rollback).

### PR de refactor
- **Heads-up** obligatorio: ¿qué se rompe? ¿hay rollback fácil?
- **Rollback** sección obligatoria (refactors son notoriamente difíciles de revertir).
- **Tests** deben quedar marcados o con explicación.
- Mencionar SI se preserva el comportamiento (no debería cambiar nada visible).

### PR de security / BFF / infra
- **Security review** sección obligatoria con reviewer asignado.
- **Heads-up** obligatorio (impacto cross-team).
- **Rollback** obligatorio si toca `helm/` o config de prod.

## Matriz de obligatoriedad

| Sección                | feature visual | feature backend | fix bug | refactor | CI/chore | docs | security/BFF |
|---|---|---|---|---|---|---|---|
| Descripción            | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| Por qué ahora          | obligatorio    | obligatorio     | obligatorio | recomendado | recomendado | opcional | obligatorio |
| Heads-up               | si aplica      | si aplica       | si prod afectado | obligatorio | si rompe builds | no | obligatorio |
| **Tests**              | obligatorio    | obligatorio     | obligatorio | obligatorio | si aplica | no | obligatorio |
| **Performance**        | si tráfico alto | opcional       | opcional | si toca hot path | no | no | opcional |
| **Rollback**           | si data migration | si data migration | opcional | obligatorio | si rompe | no | obligatorio |
| **Reviewers**          | si cross-team  | si cross-team   | si prod | obligatorio | si rompe | opcional | obligatorio |
| **Security review**    | si auth/tokens | si BFF/api      | si security bug | si infra | si workflows | no | obligatorio |
| Evidencia              | screenshots    | N/A explícito   | screenshots si UI | si UI | N/A | N/A | si UI |
| JIRA                   | obligatorio    | obligatorio     | obligatorio | obligatorio | justificar si no | si aplica | obligatorio |
| Checklist              | obligatorio    | obligatorio     | obligatorio | obligatorio | obligatorio | obligatorio | obligatorio |
| Follow-ups             | si aplica      | si aplica       | si parche temporal | si quedan etapas | si aplica | no | si aplica |

**Cómo leer**: "obligatorio" = la sección DEBE estar; "si aplica" = incluir solo si pasa la condición de la sección; "opcional" = a criterio del autor; "no" = eliminar la sección.
