# Validator patterns (meta-transferibles)

Patrones aprendidos construyendo el validador de este skill. Transferibles a otros skills tipo validator (`pr-quality-review`, `guardia`, `modo-code-review-checklist`, etc.).

## Pattern 1 · Diff-aware validation

Los validadores estáticos (solo regex sobre el body del PR) detectan placeholders y palabras banned pero **no entienden el scope**. Un PR de docs y un PR que toca el BFF tienen reglas distintas.

**Solución**: enriquecer el validador con el diff del PR.

```bash
DIFF_FILES=$(gh pr view "$PR" --repo "$REPO" --json files --jq '.files[].path' 2>/dev/null || echo "")

# Trigger automático de Security review por scope sensible
SEC_TRIGGER=$(echo "$DIFF_FILES" | grep -E '^src/pages/api/|^next\.config\.js$|^\.github/workflows/|^helm/|auth|token|session|jwt' | head -5)
if [ -n "$SEC_TRIGGER" ]; then
  # Sección Security review pasa de opcional a obligatoria
  if echo "$BODY" | grep -qi '^## Security review'; then
    echo "  ✓ Sección 'Security review' presente"
  else
    echo "  ✗ Sección 'Security review' FALTA (obligatoria por scope del diff)"
    FAIL=$((FAIL+1))
  fi
fi
```

**Cuándo usar**: cualquier validator que tenga "secciones obligatorias según tipo de cambio". Resuelve el dilema de "no quiero inflar PRs simples con secciones que no aplican, pero quiero exigirlas cuando sí aplican".

**Cuándo NO usar**: validators sobre commit messages (no hay diff aún ahí) o sobre archivos sueltos sin PR context.

## Pattern 2 · Idempotent MD insertion con `awk`

Editar Markdown existente para insertar bloques sin romper formato. `sed` rompe con headers que tienen caracteres especiales (`⚠️`, `#`, `:`). `awk` con `getline` es robusto.

```bash
# Insertar /tmp/insert.md antes de la línea 56 de /tmp/body.md
awk 'NR==56 { while ((getline line < "/tmp/insert.md") > 0) print line; print ""; print $0; next } { print }' \
  /tmp/body.md > /tmp/newbody.md
```

**Cuándo usar**:
- Insertar secciones en MD que ya existen sin reescribir todo el body.
- Bodies con HEREDOCs interpolarían `$`/backticks; `awk` opera sobre archivo y los preserva textuales.
- Cuando necesitás detectar la línea pivot por número (resultado de un `grep -n` previo).

**Alternativa**: usar `Edit` tool (Read + Edit) si estás en flujo Claude Code. `awk` es para flujos bash externos.

## Pattern 3 · Dogfooding loop

Cuando un skill se evoluciona, **probarlo sobre el caso que lo originó**. El bucle es:

1. Caso real X dispara un dolor → skill nace para resolverlo.
2. Skill v1 cubre el dolor inicial.
3. Identificás nuevo dolor / refinamiento → skill v2.
4. **Antes de cerrar v2**: pasar el caso X original por el skill v2. Si v2 detecta algo que v1 no detectaba sobre X, eso valida la evolución.

Ejemplo en este skill:
- PR #1480 originó el skill (v1 lo armó con título corto, body limpio).
- v2 sumó detección de Security review automática.
- Al pasar v2 sobre PR #1480: detectó que faltaba sección Security review (porque toca `.github/workflows/`).
- Agregué la sección → validador pasa limpio → loop cerrado.

**Cuándo usar**: cualquier skill que produzca artifacts validables (PRs, decks, RFCs, configs). El dogfooding catchea regresiones del propio skill.

**Anti-pattern**: cerrar la evolución sin pasar el caso original. Después salen sorpresas en producción.

## Pattern 4 · `gh pr edit --body-file` vs HEREDOC

Para bodies largos con caracteres especiales (`$`, backticks, `<` `>`), HEREDOC necesita `'EOF'` quoteado. Si el body lo construís via inyección programática (awk/sed), es más limpio escribir a archivo y pasar `--body-file`:

```bash
# OK para bodies armados desde scratch
gh pr edit "$PR" --repo "$REPO" --body "$(cat <<'EOF'
...
EOF
)"

# MEJOR para bodies con inyección/edición
awk '...' input.md > /tmp/newbody.md
gh pr edit "$PR" --repo "$REPO" --body-file /tmp/newbody.md
```

**Cuándo usar `--body-file`**:
- Body armado vía pipeline (awk/sed/jq).
- Body con `$variables` que NO deben interpolarse.
- Body >100 líneas (HEREDOC se vuelve ilegible).
- Querés conservar el body intermedio para debug.

## Trap: BSD sed `0,/regex/s//.../` no es portable

Para reemplazar SOLO la primera ocurrencia de un patrón, el idiom GNU `sed '0,/^## Resumen$/s//.../'` **NO funciona en macOS** (BSD sed) — falla silencioso, no reemplaza. Como el host de Hernán es darwin, usar `awk` con flag:

```bash
# Portable first-occurrence replace (GNU + BSD)
awk 'BEGIN{done=0} /^## (Resumen|Summary)$/ && !done {print "## Descripción de los cambios"; done=1; next} {print}'
```

Aplica a cualquier script bash de este skill que corra en macOS. Síntoma: el rename "no pasó" pero no hubo error.

## Trap: `wc -c` cuenta bytes, no chars (títulos UTF-8)

GitHub trunca títulos por longitud, y `check-pr-format.sh` valida con `wc -c` — ambos cuentan **bytes**, no caracteres. Caracteres multi-byte UTF-8 comunes en títulos MODO:

| Char | Uso | Bytes |
|---|---|---|
| `—` (em-dash) | separador de scope | 3 |
| `→` (flecha) | "12 → 16", "motion() → CSS" | 3 |
| `·` (middle dot) | "Sub-PR #01 · codemod" | 2 |

Un título visualmente de 68 chars con dos `—` mide **72 bytes** → falla el límite de 70. Verificar siempre con `echo -n "título" | wc -c`, no contar a ojo. Si excede, reemplazar `—`→`·` (ahorra 1 byte c/u) o cortar palabras.

## Trap: validator y enricher deben compartir el trigger de Security review

Si el validador detecta el trigger de Security review por **texto del body** (`grep workflows/ en body`) pero el enricher lo decide por **archivos del diff** (`gh pr view --json files`), divergen: un PR cuyo body MENCIONA "workflows" pero no toca ninguno queda marcado como faltante de Security review aunque no aplique. Ambos deben leer la MISMA fuente — usar `files` (la realidad del diff), no `body` (lo que el autor escribió). Patrón canónico:

```bash
FILES=$(gh pr view "$PR" --repo "$REPO" --json files --jq '.files[].path')
echo "$FILES" | grep -qE '\.github/workflows/|next\.config|src/pages/api/|^helm/|auth|token|session|jwt' && SR_TRIGGER=1
```

## Cross-link

Estos patterns se documentan acá porque emergieron construyendo el validator de este skill, pero son transferibles. Si los aplicás a otro skill, dejá un comentario en este archivo con el caso (acumular fixtures).

| Pattern | Aplicado en | Fecha |
|---|---|---|
| Diff-aware validation | `modo-pr-author/scripts/check-pr-format.sh` | 2026-05-21 |
| Idempotent MD insertion | PR #1480 body edit (Security review section) | 2026-05-21 |
| Dogfooding loop | PR #1480 v1→v2 | 2026-05-21 |
| `--body-file` over HEREDOC | PR #1480 v2 update | 2026-05-21 |
| Bulk enrichment idempotente | `scripts/enrich-pr.sh` · 50 PRs cross-repo a 8/8 | 2026-05-26 |
| BSD sed → awk first-occ | `enrich-pr.sh` rename headings | 2026-05-26 |
| `wc -c` byte trap títulos | 16 retitulados, 2 outliers multi-byte | 2026-05-26 |
| Validator/enricher trigger sync | SR trigger por files no body | 2026-05-26 |
