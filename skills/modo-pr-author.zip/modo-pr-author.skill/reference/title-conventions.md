# PR Title Conventions (MODO)

## Formato canónico

```
type(SCOPE-XXX): subject en imperativo lowercase
```

- **type**: `feat` | `fix` | `refactor` | `style` | `perf` | `docs` | `test` | `ci` | `build` | `chore` | `revert` | `merge`
- **SCOPE**: Jira ticket (ej. `EXA-1234`, `COENXT-567`)
- **subject**: <70 chars total, imperativo, lowercase, sin punto final

## Reglas duras

| Regla | Por qué |
|---|---|
| **<70 chars** | GitHub trunca con `…` a ~72 chars. PRs con título cortado se ven mal en listas y notificaciones. |
| **Imperativo lowercase** | "agregá X" no "Agregó X" / "Adds X". Convención de commits del repo. |
| **Sin punto final** | El título no es una oración cerrada. |
| **Scope obligatorio** | Sin Jira ticket explícito, usar scope descriptivo (`ci(security)`, `chore(deps)`) y explicitar en body. |
| **Type minúscula** | `feat` no `Feat`. |
| **Sin emojis** | El repo MODO no usa emojis en commits/títulos. |

## Excepciones

- **`Merge branch` / `Revert` automáticos**: respetar formato git default.
- **Hotfix urgente**: agregar `[HOTFIX]` al final permitido (raro).

## Examples

### ✅ Buenos

- `feat(EXA-1234): agregá filtro por categoría a /comercios`
- `fix(EXA-5678): blog SSR body vacío por gate !loading`
- `ci(security): nuevo workflow Frontend Security (SAST + audit + headers)` (sin Jira, scope descriptivo)
- `refactor(EXA-9012): consolidá Cybermonday utils en un único módulo`
- `docs(EXA-comercios): MVP /comercios en docs principales`

### ❌ Malos

- `feat(EXA-1234): Adds new filter to /comercios for category filtering with multiple options and pagination support` (>70 chars, inglés, sustantivado)
- `Feat: bug fix` (sin scope, type mayúscula, vago)
- `fix: arregla el bug del search` (sin Jira)
- `feat(EXA-1234): Mejora la performance de /comercios.` (mayúscula + punto final + sustantivado en vez de imperativo)
- `ci(security): add Frontend Security workflow with SAST + audit + secrets + headers + checklist gates` (>70 chars, va a truncar — caso real del PR #1480 pre-fix)

## Cómo medir

```bash
echo -n "tu título acá" | wc -c
# resultado ≤ 70 → ok
# resultado > 70 → acortar antes de pushear
```

## Cuando hay múltiples cambios

Si el PR mezcla feature + fix + refactor → indicador de PR demasiado grande. Splitear. Si no se puede, usar el type del cambio principal y mencionar los otros en el body.

## Tip de scope

- `EXA` para casi todo en modo-landing.
- `COENXT` para trabajo del board Comercios ToFu.
- `SECURITY`, `DEVOPS`, `CI` como scopes descriptivos cuando no hay Jira (justificar en body).
