# Voz rioplatense · glosario para PRs MODO

Diccionario de reemplazo. Lado izquierdo = lo que NO usar (suena a consultora/marketing/inglés traducido). Lado derecho = lo que sí.

Base en memoria `feedback_rioplatense_voice` + `feedback_no_apetito`.

## Verbos y acciones

| ❌ Consultoría / inglés-trad | ✅ Rioplatense |
|---|---|
| Se implementó / implementamos | Sumé / agregué / metí |
| Se procedió a | Hice / arranqué |
| Se evaluó la posibilidad de | Probé / vi si |
| Se identificó que | Vi que / encontré que |
| Resolver / solucionar (formal) | Arreglar / corregir |
| Optimizar (cuando no es perf real) | Mejorar / refinar |
| Leverage | Usar / aprovechar |
| Refactorizar (cuando es solo mover) | Mover / reorganizar |
| Integrar | Conectar / sumar |
| Implementar (en docs) | Armar / hacer |

## Sustantivos y conceptos

| ❌ | ✅ |
|---|---|
| Stakeholders | Equipo / DevOps / Product / TL |
| Deliverables | Lo que sale / lo que mergea |
| Apetito ("si hay apetito") | Tiempo / feedback ("si hay tiempo", "con feedback", "sujeto a feedback") |
| Bandwidth | Tiempo / capacidad |
| Alignment | Acuerdo / charla previa |
| Initiative | Proyecto / iniciativa (ok en limitado) |
| Solución | Fix / cambio / PR |
| Implementación | Cambio / código / PR |
| Pain points | Problemas / fricciones |
| ROI / valor agregado | Beneficio concreto |

## Frases comunes

| ❌ | ✅ |
|---|---|
| Esto representa un riesgo de X | Esto puede romper X si… |
| Considero pertinente | Creo que conviene |
| Sería interesante explorar | Vale la pena ver |
| A la luz de los hallazgos | Con lo que vi |
| Se sugiere | Sugiero / propongo |
| En relación a | Sobre / acerca de |
| En el marco de | En el contexto de / dentro de |
| Es importante mencionar que | Ojo que / heads-up |
| Cabe destacar que | A tener en cuenta |

## Términos técnicos OK

Estos quedan en inglés y son válidos:
- Workflow, gate, deploy, build, lint, hook, runner, secret, token
- Branch, PR, merge, rebase, cherry-pick, stash, worktree
- Endpoint, payload, header, SSR, ISR, CSR
- Bundle, chunk, lazy load, SSR, CSR
- Cache, hit, miss, TTL
- Audit, scan, hardening, SAST, SBOM

## Banned absoluto

Estas palabras NO se usan en PRs MODO:
- `apetito` (ver `feedback_no_apetito`)
- `stakeholders` (ver `feedback_rioplatense_voice`)
- `deliverables`
- `leverage` (como verbo en español)
- `synergy` / `sinergia`
- `low-hanging fruit`
- `circle back`
- `at the end of the day` / `al final del día` (cuando no es literal)

## Test de oído

Antes de cerrar un PR description, leerlo en voz alta. Si suena a:
- Whitepaper de consultora → reescribir.
- Traducción literal del inglés → reescribir.
- Newsletter de LinkedIn → reescribir.
- Charla técnica entre dos ingenieros de MODO → ✅

## Ejemplos lado a lado

### ❌ Versión consultoría

> Se procedió a implementar una solución que apunta a optimizar el flujo de validación de seguridad pre-deploy. Esto representa un activo estratégico para la organización en términos de mitigación de riesgo y aumenta el ROI del trabajo de los stakeholders involucrados en el área de DevSecOps.

### ✅ Versión rioplatense

> Sumé un workflow de seguridad que corre antes de cada deploy. Cubre lo que hoy no tenemos: SAST, secret scan, audit de deps. Cualquier cosa que rompa estos checks bloquea el deploy a prod.
