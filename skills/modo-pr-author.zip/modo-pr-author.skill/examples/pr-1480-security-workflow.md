# Ejemplo canónico · PR #1480 Frontend Security Workflow

PR real: https://github.com/playsistemico/modo-landing/pull/1480

Caso de un PR CI-only (sin cambios visuales), additive sobre un workflow ya existente, con heads-up sobre decisión técnica pre-merge.

## Inputs disponibles

- Branch: `chore/security-workflow`
- Commit único: `ci(security): add Frontend Security workflow with SAST + audit + secrets + headers + checklist gates`
- Diff: `.github/workflows/security.yml` (+362 LOC, archivo nuevo)
- Sin Jira ticket dedicado
- Working tree previo: limpio

## Versión inicial (rota — `gh pr create` default)

### Título

```
ci(security): add Frontend Security workflow with SAST + audit + secr…
```

**Problemas:**
- 73 chars, truncado por GitHub con `…`
- En inglés (convención MODO es español para body, inglés para title aceptable, PERO el caso del título largo se podía evitar)

### Body

```markdown
…ets + headers + checklist gates

Adds .github/workflows/security.yml as a pre-deploy security gate aligned
with the frontend-security-checklist, csp-hardening, and github-actions-security
skills. Runs on PRs, push to main, and manual dispatch...

[continúa todo el cuerpo del commit pegado]

## Descripción de los cambios

[Change!] Describí tu feature, problemas que hayas tenido, notas, mejoras...

## Evidencia

#### Desktop

[Change!] Screenshots, gifs o videos de los cambios realizados.

#### Mobile

[Change!] Screenshots, gifs o videos de los cambios realizados.

## JIRA

[Change!] Link de la card de JIRA asociada.


## Checklist

- [ ] He probado el código en mi máquina local
- [ ] He agregado los tests necesarios para validar mis pruebas de manera automatizada
- [ ] He actualizado la documentación, o bien he validado que no aplica
- [ ] He actualizado el contrato de la API, o bien he validado que no aplica
- [ ] Considero que este código, una vez mergeado, puede salir a producción
```

**Problemas:**
- Cuerpo del commit pegado arriba sin formato
- 4 placeholders `[Change!]` sin completar
- Checklist 100% desmarcado
- JIRA sin contenido ni explicación
- Evidencia sin "N/A" explícito (es CI-only, no tiene visual)

## Versión corregida (canon)

### Título

```
ci(security): nuevo workflow Frontend Security (SAST + audit + headers)
```

**Mejoras:**
- 66 chars, no se trunca
- Mantiene scope `(security)` para indicar área
- Mantiene `ci(...)` que es el type correcto

### Body

```markdown
## Descripción de los cambios

Suma `.github/workflows/security.yml` como **gate de seguridad pre-deploy** para modo-landing (front + BFF de Next.js). Operacionaliza la checklist OWASP que ya teníamos como skill (`frontend-security-checklist`) y la ejecuta automáticamente en cada PR, push a `main` y antes de promote a preprod/prod.

Es **additive**: no toca `ci.yaml`, `pr.yaml` ni `cd.yaml`. La cadena existente de `playsistemico/workflows` sigue igual.

### Por qué ahora

- Hoy no tenemos SAST, secret scanning ni verificación automática de headers en CI. SonarCloud cubre code smells pero no OWASP ni secretos.
- Con el BFF de Next.js creciendo (`src/pages/api/*`) necesitamos un check sistemático antes de cada deploy.
- Alinea con las skills internas `frontend-security-checklist`, `csp-hardening` y `github-actions-security`.

### Jobs (paralelos)

| Job | Herramienta | Bloqueante |
|---|---|---|
| `deps-audit` | `pnpm audit --audit-level=high --prod` | siempre |
| ... [tabla completa] |

## Cómo se integra al flow de deploy

El workflow corre solo en PRs y push a main. Para usarlo como gate pre-deploy a preprod/prod, hay dos opciones (a definir con DevOps en un follow-up):

1. **Manual desde Actions** → antes de correr `Frontend CD`, disparar `Frontend Security` con el `environment` correspondiente. Si falla, no se promueve.
2. **Wire automático** → agregar `needs: ['security']` o un `workflow_call` desde `cd.yaml`. Más invasivo, requiere coordinar con DevOps.

Este PR mergea **sin** wiring automático para no bloquear deploys actuales. Wiring queda como follow-up.

## ⚠️ Heads-up antes de mergear

GitHub Dependabot reporta **111 vulnerabilidades** abiertas en `main` (3 critical, 37 high, 59 moderate, 12 low). El job `deps-audit` con `--audit-level=high` va a fallar inmediatamente contra el primer PR que se abra después de mergear esto.

Dos opciones (decidir antes de aprobar):

- **A · Mergear bloqueante desde día 1** → siguiente paso es trabajar la deuda de deps high+ en paralelo. PRs nuevos quedan bloqueados hasta limpieza.
- **B · Mergear con `continue-on-error: true` en `deps-audit`** → flipear a bloqueante una vez que se haya limpiado el backlog. Más conservador.

Mi recomendación: **B**, pero queda en manos del revisor.

## Evidencia

Cambio CI-only — no afecta UI ni endpoints. La evidencia visible será:

- Tab **Security → Code scanning alerts** se va a poblar con los hallazgos de Semgrep (SARIF upload).
- Tab **Actions → Frontend Security** mostrará la corrida del workflow en este mismo PR (ver checks abajo).
- Si gitleaks encuentra algo, comenta inline en el PR.

#### Desktop

N/A — sin cambios visuales.

#### Mobile

N/A — sin cambios visuales.

## JIRA

No hay card de JIRA específica para este workflow (es trabajo de DevSecOps cross-cutting). Si DevOps prefiere trackearlo, sugiero crear un ticket bajo `EXA` o el board de plataforma y linkearlo aquí antes de mergear.

## Checklist

- [x] He probado el código en mi máquina local (YAML validado con `python3 -c "import yaml; yaml.safe_load(...)"`)
- [ ] He agregado los tests necesarios para validar mis pruebas de manera automatizada — N/A, el workflow se valida ejecutándose en este mismo PR
- [x] He actualizado la documentación, o bien he validado que no aplica — skill `frontend-security-checklist` actualizado con sección "CI implementation" + reference template
- [x] He actualizado el contrato de la API, o bien he validado que no aplica — N/A
- [ ] Considero que este código, una vez mergeado, puede salir a producción — **bloqueado por decisión A vs B (ver heads-up)**

## Follow-ups

- Limpiar las 111 vulnerabilidades reportadas por Dependabot (depende de la decisión A/B).
- Wirear el workflow al CD (manual o `workflow_call`).
- Agregar ZAP baseline scan contra el preview deploy (futuro sprint).
- License scan con `pnpm licenses list`.
- `lockfile-lint` para evitar resolución a registries random.
```

## Lo que este caso enseña (reglas extraíbles)

| Aprendizaje | Aplicar cuando |
|---|---|
| Cuerpo del commit no es body del PR | Siempre — usar `--body` explícito en `gh pr create` |
| Título ≤70 chars | Siempre |
| Evidencia "N/A — sin cambios visuales" explícito | PR de CI / chore / docs / backend |
| Heads-up con decisión A/B | Cuando el merge tiene implicancias no obvias |
| Checklist marcado honesto + N/A | Siempre |
| JIRA explicitado si no hay card | Trabajo de plataforma / DevSecOps / tech-debt |
| Follow-ups al final | Si dejaste cosas para próximos PRs |
| Por qué ahora | Justifica el PR para el revisor que no tiene contexto |
| Sección "Cómo se integra al flow" | Si tiene impacto operativo (CI/CD, deploy) |

## Iteraciones posibles sobre este formato

Si en el futuro el formato necesita evolucionar:

1. **Sección Tests** → si el repo agrega cobertura mínima obligatoria, sumar bloque con coverage diff.
2. **Sección Performance** → si hay impacto en bundle size, agregar tabla before/after.
3. **Sección Rollback** → si el cambio es difícil de revertir, explicitar el plan B.
4. **Sección Reviewers solicitados** → agregar bullet list de @ @ menciones.
5. **Sección Security review** → si tocaste `src/pages/api/*` (BFF), pedir review explícita de un security-savvy.

Estas son opciones, no obligaciones. El template base cubre el 80% de casos.
