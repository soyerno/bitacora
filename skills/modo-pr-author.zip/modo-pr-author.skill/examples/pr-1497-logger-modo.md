# Caso canónico · PR #1497 — Logger MODO-core client (browser-safe) + Datadog Browser Logs

PR original: https://github.com/playsistemico/modo-landing/pull/1497
Tipo: `feat` backend (browser-side infra, no UI)
Tamaño: 8 archivos · +363/-0
Branch: `feat/modo-landing-logger`
Author: SoyErnoModo
Status al canonicalizar: OPEN

## Por qué es gold standard

5 cosas que hace bien y que el template canónico ahora codifica:

1. **`Ticket` arriba del body** — link Jira es el primer pointer semántico del PR, no enterrado al final. Reviewer lo encuentra en 2 segundos. Formato: `[**COENXT-321 · <título descriptivo>**](<link>)`.
2. **`Milestone · SEO/GEO`** — el PR no vive aislado; vincula a 3 cards padre de epics activas con relación específica de cada una con este PR.
3. **`Por qué no el paquete de core directo`** — descarte técnico explícito con razón concreta (`core` es server-only por `pino + async_hooks`, no bundlea client). Distinto a "por qué ahora".
4. **`Fuera de alcance (follow-up)` con prosa** — el server core logger merece su propio ticket porque arrastra `dd-trace` nativo al deploy image (decisión infra). 1 párrafo explicando POR QUÉ, no un bullet seco.
5. **`Verificación` compacta** — 3 bullets con comandos + resultados literales. Sin tablas before/after pesadas (overkill para PR <500 líneas).

## Body completo extraído

```markdown
## 🎯 ¿Qué dolor soluciona?

modo-landing no tiene logger estructurado client-side. Debuggear bugs reportados desde el browser hoy implica leer `console.*` ad-hoc esparcido por el código, sin obfuscación de datos sensibles ni forwarding a observability. Cuando un user reporta "se rompió", oncall no tiene trazas en Datadog del lado cliente — solo Datadog server (BFF) y Amplitude (analytics events, no errors).

Adicional: el logger de `@playsistemico/core` es **server-only** (`pino` + `async_hooks`) → no bundlea en el client. Necesitamos misma API portada a browser para que el equipo trabaje contra el mismo contrato.

La regla baseline MODO es: todo front debe tener logger + Amplitude + analytics. modo-landing ya tiene Amplitude; faltaba el logger client.

## 🛠️ ¿Qué tuvimos que hacer?

1. **`src/utils/logger/ModoLogger.ts`**: clase con la misma API que el server logger — `debug/info/warn/trace/error` + `TraceableError.from()` + obfuscación de keys sensibles (token, email, dni, etc.). Escribe a `console` y, con token configurado, forwardea a **Datadog Browser Logs**. `errorInfo` estructurado `{message, stack, type, details, cause}`.
2. **`src/utils/logger/datadog.ts`**: init lazy de `@datadog/browser-logs`. **No-op sin `NEXT_PUBLIC_DD_CLIENT_TOKEN`** (env-gated igual que el RUM de promos-hub; lee runtime via `window.__ENV`).
3. **`src/utils/logger/index.ts`**: instancia `logger` compartida + `createLogger` + `initLogger`.
4. Wire en `_app.js`: `initLogger()` corre en mount client. Env documentado en `.env.example` (`NEXT_PUBLIC_DD_*`).
5. Tests: 7/7 pass cubriendo TraceableError + obfuscación + forwarding Datadog. ModoLogger 98% cov.

## 🎁 ¿Para qué?

Llevar a modo-landing al baseline de observability MODO: logger client estructurado + Datadog Browser Logs para errors reportados desde browser. Habilita debugging real de incidents user-facing sin depender de `console.log` ad-hoc.

## Ticket

[**COENXT-321 · Logger MODO-core client (browser-safe) + Datadog Browser Logs en modo-landing**](https://play-sistemico.atlassian.net/browse/COENXT-321)

## Milestone · SEO/GEO

Observability foundation que habilita debugging de bugs reportados desde el browser en flujos SEO/GEO. Aplica como soporte transversal a las epics activas:

- [COENXT-176 · [GEO] Fundaciones (M0)](https://play-sistemico.atlassian.net/browse/COENXT-176) — infraestructura GEO operativa
- [COENXT-183 · [GEO] SEO Técnico (M3)](https://play-sistemico.atlassian.net/browse/COENXT-183) — verificar errors de JSON-LD/schema render en prod
- [COENXT-184 · [GEO] Estructura Web (M3)](https://play-sistemico.atlassian.net/browse/COENXT-184) — debug SSR/hidratación en pages indexables

## Por qué no el paquete de core directo

El logger de `@playsistemico/core` es **server-only** (`pino` + `async_hooks`) → no bundlea en el client. Se porta la **misma API** a browser.

## Fuera de alcance (follow-up)

El **server core logger** (`@playsistemico/core` en `server.js` + API routes) queda como ticket aparte: arrastra `dd-trace` nativo al deploy image, decisión de infra que merece su propia revisión.

## Verificación

- `pnpm build` (lint + next build) — pasa
- `npx jest src/utils/logger` — 7/7 (TraceableError + obfuscación + forwarding Datadog), ModoLogger 98% cov
- lockfile sincronizado con la dep nueva
```

## Mapping body → secciones del template canónico

| Sección del PR #1497 | Template (`pr-template-modo.md`) | Comentario |
|---|---|---|
| `## 🎯 ¿Qué dolor soluciona?` | `## 🎯 ¿Qué dolor soluciona?` | 3 párrafos con contexto + razón técnica + regla baseline |
| `## 🛠️ ¿Qué tuvimos que hacer?` | `## 🛠️ ¿Qué tuvimos que hacer?` | Lista numerada con paths + decisión por item |
| `## 🎁 ¿Para qué?` | `## 🎁 ¿Para qué?` | Outcome verificable + capacidad habilitada |
| `## Ticket` | `## Ticket` ✨ nuevo en template | Arriba del body, no al final |
| `## Milestone · SEO/GEO` | `## Milestone · <área/epic>` ✨ nuevo | 3 epic links con razón específica |
| `## Por qué no el paquete de core directo` | `## Por qué no <alternativa>` ✨ nuevo | Descarte técnico explícito |
| `## Fuera de alcance (follow-up)` | `## Fuera de alcance (follow-up)` ✨ nuevo | Prosa explicando POR QUÉ es out-of-scope |
| `## Verificación` | `## Verificación` ✨ nuevo (compacta) | 3 bullets sin tablas pesadas |

## Anti-pattern evitado

El template original (pre-update 2026-05-29) tenía:
- `JIRA` al final solamente → enterrado, reviewer scrolling.
- `Follow-ups` solo bullets cortos → no podía justificar prosa de scope.
- `Tests` con tabla obligatoria → overkill para PRs chicos.

PR #1497 destapó el gap. Update del template + revisor (commit del skill `modo-pr-author` + `pr-quality-review`, 2026-05-29) cierra el drift.

## Voz rioplatense

PR escribe en español, voseo implícito ("Necesitamos misma API portada", "no bundlea"), sin buzzwords. Cumple `feedback_rioplatense_voice` y `feedback_no_apetito`.

## Replicar el patrón

Cuando autorás un PR similar (feat backend infra, observability, libs MODO portadas), copiar la estructura completa. Cambiar:
- Ticket COENXT-321 → tu ticket
- 3 epic links → epics relevantes (o omitir Milestone)
- "Por qué no `@playsistemico/core` directo" → tu alternativa descartada
- Verificación bullets → tus comandos + resultados

NO copiar literal el body — el patrón es la **estructura semántica**, no el texto.
