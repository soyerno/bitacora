---
name: modo-pr-author
description: Author MODO-grade pull request descriptions following the repo template + commit conventions + voz rioplatense. Auto-invocable cuando el usuario pide "armá el PR", "creá el PR", "describí este PR", "iterá la descripción de este PR" o cuando se va a llamar `gh pr create`/`gh pr edit` en un repo MODO. Complementa los skills de REVIEW (pr-quality-review, guardia) que evalúan PRs ya creados — este AUTORA descripciones.
---

# MODO PR Author

Skill para autorar (y editar) descripciones de Pull Request en repos MODO siguiendo:

1. Template del repo (`.github/pull_request_template.md`)
2. Convenciones de commit del CLAUDE.md global (`type(SCOPE-XXX): Subject`)
3. Voz rioplatense (sin buzzwords, sin "apetito", sin "stakeholders")
4. Quality rules del CLAUDE.md (descripción completa, JIRA linked, evidencia visual para UI, checklist marcado)

## Cuándo se usa

### Auto-invocar
- Usuario pide "armá el PR", "creá el PR", "describí este PR", "iterá la descripción".
- Se va a ejecutar `gh pr create` o `gh pr edit --body` en un repo MODO.
- Detectás que un PR ya creado tiene placeholders `[Change!]` o cuerpo de commit pegado sin formatear.

### Manual
- Slash command `/modo-pr-author` (cuando se cree).
- Usuario pasa una branch y pide armar el PR desde cero.

## Cuándo NO se usa

- PR de un repo no-MODO (usar `engram-branch-pr` que es genérico).
- Solo querés REVIEW de un PR existente → usar `pr-quality-review` o `guardia`.

## Process

### Step 1 — Inputs requeridos

Antes de armar, recolectar:

```bash
# Branch + commits
git log --oneline origin/main..HEAD
git diff origin/main...HEAD --stat
git show HEAD --no-patch  # último commit completo

# PR existente (si edit)
gh pr view <PR> --repo <owner>/<repo> --json title,body,headRefName,additions,deletions,files

# Template del repo
cat .github/pull_request_template.md
```

Si falta alguno: leer del filesystem o pedir al user. Nunca asumir.

### Step 2 — Identificar componentes

Del diff y commits, sacar:

| Componente | De dónde | Cómo usarlo |
|---|---|---|
| **Tipo** | Commit type (`feat`/`fix`/`ci`/`chore`…) | Va en el título |
| **Scope** | Jira ticket de los commits | Va en el título `type(COENXT-NNN)`. Legacy `EXA-XXX` está muerto (project EXA borrado 2026) — reemplazar al editar |
| **Subject** | Primera línea del commit | Refinar a <70 chars |
| **Por qué** | Cuerpo del commit + contexto | Sección "Por qué ahora" |
| **Cambios** | `git diff --stat` + análisis | Tabla o bullet list |
| **Riesgos** | Files críticos tocados, deps, infra | Sección "Heads-up" o "Riesgos" |
| **Evidencia visual** | Si hay cambios en UI | Screenshots desktop+mobile (Playwright) |
| **JIRA** | Scope del commit | Link a card |

### Step 3 — Armar el title

Reglas:
- **<70 chars** (GitHub trunca a ~72 con `…`).
- Formato: `type(SCOPE-XXX): subject en imperativo lowercase`.
- Si no hay ticket Jira específico, usar scope descriptivo (`ci(security)`, `chore(deps)`) y explicitarlo en el body que falta linkear.
- NO usar mayúsculas tipo título.
- NO terminar con punto.

**Test rápido**: `echo "tu título" | wc -c` debe dar ≤70.

### Step 4 — Armar el body (formato canónico MODO)

Estructura obligatoria (ver `reference/pr-template-modo.md` para template drop-in):

```markdown
## 🎯 ¿Qué dolor soluciona?

<1-3 párrafos en voz rioplatense. Problema concreto y medible que dispara este PR — bug reportado, métrica que duele, costo operativo, deuda técnica con fecha de vencimiento. Si hay número, número (LCP +Xs, coverage bajó a Y%, build +Zmin). Sin esto el PR es vaporware.>

## 🛠️ ¿Qué tuvimos que hacer?

<Lista numerada de las decisiones técnicas tomadas. No es el diff — es el "qué hicimos en lenguaje humano" que un PM o un dev de otra área puede leer. Granularidad: archivo/módulo + decisión + por qué esa decisión y no otra.>

## 🎁 ¿Para qué?

<Outcome esperado en formato verificable. Métrica objetivo (LCP target, smells a 0, build -Xmin) o capacidad nueva habilitada (feature visible al user, unblock para el siguiente PR del stack). Si es estimado, marcarlo como "esperado post-deploy" y decir cuándo se mide.>

---

## Descripción de los cambios

<2-4 párrafos: qué hace, dónde toca, qué no toca. En español, voz rioplatense.>

### Por qué ahora

<Bullet list de motivación. Por qué este PR existe hoy, qué problema resuelve.>

### <Sección técnica específica · ej. "Jobs (paralelos)" o "Cambios">

<Tabla o lista con el detalle técnico. Granularidad: alguien que NO vio el código entiende qué pasa.>

## Cómo se integra al flow [si aplica]

<Si el cambio tiene impacto operativo · ej. CI/CD, deploy, migraciones, breaking changes.>

## ⚠️ Heads-up antes de mergear [si aplica]

<Decisiones que el revisor tiene que tomar antes de aprobar. Listar opciones con recomendación.>

## Tests [si aplica · ver matriz de obligatoriedad]

<Tabla suite/coverage antes-después. Casos nuevos cubiertos. Justificar bajas de coverage.>

## Performance [si aplica]

<Tabla bundle/Web Vitals antes-después. Solo si tocaste bundle del cliente o deps.>

## Rollback [si aplica]

<Plan A simple + Plan B complejo + datos a preservar + tiempo estimado.>

## Reviewers solicitados [si aplica]

<@ menciones con razón. Cross-team, áreas con dueño, security.>

## Security review [obligatoria si toca BFF/auth/infra/workflows/deps]

<Checklist de seguridad para el reviewer. Condiciones de obligatoriedad en `reference/pr-template-modo.md`.>

## Evidencia

#### Desktop

<Screenshot 1280x800 via Playwright · O "N/A — sin cambios visuales" si es backend/CI>

#### Mobile

<Screenshot 375x812 via Playwright · O "N/A">

## JIRA

<Link a la card · O "No hay card específica para este trabajo (es <razón>). Sugiero crear EXA-XXX antes de mergear.">

## Checklist

- [x] He probado el código en mi máquina local <- marcar honesto
- [ ] He agregado los tests necesarios <- marcar honesto (N/A si no aplica)
- [x] He actualizado la documentación, o bien he validado que no aplica
- [x] He actualizado el contrato de la API, o bien he validado que no aplica
- [ ] Considero que este código, una vez mergeado, puede salir a producción

## Follow-ups [si aplica]

<Bullet list de cosas que quedan para próximos PRs. Linkea memorias/decisiones si las hubo.>
```

**Matriz de obligatoriedad por tipo de PR**: ver `reference/pr-template-modo.md` sección "Matriz de obligatoriedad". Resumen:

| Sección | feature visual | feature backend | fix | refactor | CI/chore | docs | security/BFF |
|---|---|---|---|---|---|---|---|
| Tests | obligatorio | obligatorio | obligatorio | obligatorio | si aplica | no | obligatorio |
| Performance | si tráfico alto | opcional | opcional | si hot path | no | no | opcional |
| Rollback | si data migration | si data migration | opcional | **obligatorio** | si rompe | no | **obligatorio** |
| Reviewers | si cross-team | si cross-team | si prod | obligatorio | si rompe | opcional | obligatorio |
| Security review | si auth/tokens | **si BFF/api** | si security bug | si infra | si workflows | no | **obligatorio** |

**Triggers automáticos de Security review obligatoria** — si el diff toca alguno de estos, la sección es **mandatoria**:
- `src/pages/api/**` (BFF endpoints)
- `**/auth/**`, archivos con `token`, `session`, `jwt` en el nombre
- `next.config.js` (headers / CSP / next-safe)
- `.github/workflows/**`
- `helm/**` (SOPS, secrets)
- `package.json` con deps nuevas (no bumps)

Detecta automático con:
```bash
git diff --name-only origin/main...HEAD | grep -E '^src/pages/api/|next\.config\.js|^\.github/workflows/|^helm/|auth|token|session|jwt' && echo "SECURITY REVIEW REQUIRED"
```

### Step 5 — Ejecutar

```bash
# CREAR PR nuevo (HEREDOC para preservar formato)
gh pr create --base main --head <branch> \
  --title "<titulo>" \
  --body "$(cat <<'EOF'
<body completo, copiando de Step 4>
EOF
)"

# EDITAR PR existente (formato roto / placeholders)
gh pr edit <PR> --repo <owner>/<repo> \
  --title "<titulo>" \
  --body "$(cat <<'EOF'
<body completo>
EOF
)"
```

**Importante**: usar HEREDOC con `'EOF'` quoteado para evitar interpolación de `$`/backticks.

### Step 6 — Verificar

```bash
gh pr view <PR> --json title,body | jq -r '.title, .body' | head -50
```

Confirmar:
- Sin placeholders (`[Change!]`, `<por completar>`, `TBD`).
- Sin cuerpo de commit pegado arriba duplicando el body.
- Título no truncado (`…` al final = mal).
- Checklist con marcas reales (no todo desmarcado).
- JIRA presente o explícitamente justificado.

## Bulk enrichment de PRs existentes

Cuando hay que llevar MUCHOS PRs ya abiertos al estándar MODO (auditoría retroactiva), NO reescribir cada body a mano. Usar `scripts/enrich-pr.sh <repo> <pr>` — enriquece sin destruir contenido.

### Enrichment vs full rewrite

| Situación | Approach |
|---|---|
| PR nuevo desde cero | Full body con template (Step 4) |
| 1 PR con body decente pero secciones faltantes | `enrich-pr.sh` o edit manual |
| N≥5 PRs existentes a auditar | `enrich-pr.sh` en batch (`xargs -P 4`) |
| PR con body roto / placeholders | Full rewrite manual |

### Qué hace `enrich-pr.sh` (idempotente)

1. Rename primer H2 conocido (`Resumen`/`Summary`/`Problema`/`Context`/`Overview`) → `## Descripción de los cambios`. Si no hay H2 conocido, **prepend** bloque sintético con el subject del título + separador `---`.
2. Rename `## Test plan*` → `## Tests`.
3. Append `## Security review` (checklist mínima) si el diff toca `.github/workflows/`, `next.config`, `src/pages/api/`, `helm/`, o nombres con `auth|token|session|jwt`.
4. Append `## Evidencia` — N/A explícito si CI/backend; placeholder "pendiente" si toca `src/components/`, `src/pages/*.{jsx,tsx}`, CSS, stories.
5. Append `## JIRA` — extrae ticket de `(COENXT-NNN)` / `(PERSZ-NNN)` / `(IE-NNN)` del título. Si solo encuentra `EXA-XXX` o nada, marca el PR como orphan y sugiere create vía Step "Crear ticket faltante" abajo.
6. Append `## Checklist` MODO canónico.

**Idempotente**: si una sección ya existe, la saltea. Re-correr es seguro. Si nada cambia, imprime `SKIP`.

### Workflow batch + validación

```bash
# 1. Listar tus PRs abiertos
gh search prs --author <login> --state open --limit 50 --json url,number,repository \
  --jq '.[] | "\(.repository.nameWithOwner) \(.number)"' > /tmp/pr-list.txt

# 2. Enrich en paralelo (idempotente, seguro)
cat /tmp/pr-list.txt | xargs -P 4 -L 1 ~/.claude/skills/modo-pr-author/scripts/enrich-pr.sh

# 3. Validar (check-pr-format.sh emite TSV-friendly; correr en loop)
cat /tmp/pr-list.txt | while read repo pr; do
  ~/.claude/skills/modo-pr-author/scripts/check-pr-format.sh "$pr" "$repo"
done
```

### Lo que enrichment NO arregla — títulos

`enrich-pr.sh` NO toca títulos (truncar pierde semantic info sin tu juicio). Para títulos >70 chars, proponer cortes y aplicar `gh pr edit <pr> --repo <repo> --title "..."` manual. **Trap de bytes**: GitHub/`wc -c` cuentan BYTES, no chars. Em-dash `—`, flecha `→`, bullet `·` son multi-byte UTF-8 (3, 3, 2 bytes). Un título de 68 chars con dos `—` mide 72 bytes → falla el límite. Verificar con `echo -n "título" | wc -c`, no por longitud visual.

### Crear ticket faltante (orphan PR → COENXT)

Cuando el batch audit encuentra PRs orphan (sin `COENXT-NNN`/`PERSZ-NNN`/`IE-NNN` en title ni body, o con `EXA-XXX` muerto), wire el PR a un ticket nuevo en el project correcto.

**Project defaults frontend MODO** (verificar siempre [[reference-jira-coenxt]]):
- `COENXT` — default. Frontend MODO (modo-landing, satélites, comercios, observability, SEO/GEO).
- `PERSZ` — Personalización.
- `COE` (CoE GenAI) — NO usar para frontend. Es para trabajo del Centro de Excelencia GenAI.
- `EXA` — **DEAD**. Project borrado. Cualquier `EXA-XXX` en title/body es orphan.

**Flow (per PR)**:
```
1. createJiraIssue cloudId=17e75179-15ce-48f2-954d-ec6946aca61c
   projectKey=COENXT  issueTypeName=Tarea  contentFormat=markdown
   summary="<derivado del title, sin el type prefix>"
   description="<formato MODO 🎯 🛠️ 🎁 + sección Milestone SEO/GEO + PR url>"
2. Captura new key (e.g. COENXT-NNN).
3. gh pr edit <PR> --repo <repo> --title 'type(COENXT-NNN): subject'  # title only, NUNCA body
4. createIssueLink inwardIssue=COENXT-NNN outwardIssue=<epic> type=Relates
```

**Epic mapping milestones SEO/GEO activos** (ver [[reference-jira-coenxt]] tabla completa):
- `COENXT-176` [GEO] Fundaciones M0 → security, observability, CI hygiene, tech-debt
- `COENXT-181` [GEO] SEO Técnico M2 → perf imágenes, SSR, sitemap, CLS, server-side A/B
- `COENXT-182` [GEO] Social PR M2 → Trustpilot, social proof
- `COENXT-183` [GEO] SEO Técnico M3 → JSON-LD/schema scoped por página
- `COENXT-184` [GEO] Estructura Web M3 → /comercios canonical, semantic HTML

**Classifier gotchas** (auto mode): ver [[reference-jira-mcp-classifier-gotchas]]. Resumen:
- `editJiraIssue` sobre tickets que el agent NO creó en la sesión → bloqueado. Workaround: `addCommentToJiraIssue` + `createIssueLink`.
- `createJiraIssue` con narrative detallada que use keywords `OWASP`, `CGNAT`, `~N min`, `fabricates` → puede bloquearse inconsistentemente. Mismo description en hermano cookies puede pasar o fallar. Si falla, simplificar prosa y reintentar, o crear manual UI.

**Batch >40 PRs**: spawn `Agent` background con run_in_background=true. Agent puede pegar contra session limit Anthropic (5h+ wall). Si pasa, completar manual desde main thread.

## Anti-patterns

- **`gh pr create` sin `--body`** → GitHub pega el cuerpo del commit + template juntos sin formato. Siempre pasar `--body` explícito.
- **Placeholders sin completar** → `[Change!]`, `<TBD>`, `lorem ipsum` en producción.
- **Título truncado** → si termina en `…`, GitHub lo cortó. Acortar manual.
- **Buzzwords/consultoría** → "stakeholders", "deliverables", "leverage", "apetito" están BANNED. Voz rioplatense (ver memoria `feedback_rioplatense_voice`).
- **Evidencia faltante para UI** → cualquier cambio visual necesita screenshot desktop + mobile. Si es CI/backend, escribir "N/A — sin cambios visuales" explícito (no dejar la sección vacía).
- **Checklist todo desmarcado** → señal de PR apurado. Marcá lo que sí hiciste.
- **Cuerpo del commit duplicando body** → el commit dice "qué", el PR dice "qué + por qué + cómo + riesgos". Diferentes audiencias.
- **No mencionar follow-ups** → si dejaste cosas para después, listarlas. Sino el revisor las descubre tarde.

## Iteraciones canónicas

### Caso PR #1497 (logger MODO-core client) — gold standard estructura

**Aporta al template** (canonicalizado 2026-05-29):
1. `## Ticket` arriba del body (no enterrado al final como `JIRA`).
2. `## Milestone · <área/epic>` con 3 epic links contextuales.
3. `## Por qué no <alternativa técnica>` — descarte explícito (`@playsistemico/core` es server-only).
4. `## Fuera de alcance (follow-up)` con **prosa** explicando POR QUÉ (server core logger arrastra `dd-trace` nativo al deploy image).
5. `## Verificación` compacta — 3 bullets con comandos + resultados literales, sin tablas before/after.

Detalle completo + body extraído + mapping a template canónico en `examples/pr-1497-logger-modo.md`.

### Caso PR #1480 (security workflow)

**Problemas iniciales** del `gh pr create` default:
1. Título truncado: `ci(security): add Frontend Security workflow with SAST + audit + secr…`
2. Cuerpo del commit pegado arriba sin formato.
3. Template con `[Change!]` sin completar.
4. Checklist 100% desmarcado.

**Fix aplicado**:
1. Título a `ci(security): nuevo workflow Frontend Security (SAST + audit + headers)` (66 chars).
2. Body reescrito en español, con secciones canónicas.
3. Tabla de jobs para granularidad técnica.
4. Heads-up con decisión A/B explícita (bloqueante desde día 1 vs `continue-on-error`).
5. Evidencia: N/A explícito (es CI-only).
6. JIRA: explicitado que no hay card y sugerido crear EXA-XXX.
7. Checklist: marcas reales + N/A donde aplica.
8. Follow-ups listados (limpieza vulns, wiring CD, ZAP scan, license scan).

Detalle completo en `examples/pr-1480-security-workflow.md`.

## Voz rioplatense en PRs MODO

Aplica `feedback_rioplatense_voice` (memoria del proyecto). Frases canónicas:

| ❌ Mal (consultoría) | ✅ Bien (rioplatense) |
|---|---|
| "Se implementó una solución para…" | "Sumé/agregué/metí…" |
| "Esto representa un riesgo…" | "Esto puede romper X si…" |
| "Stakeholders involucrados" | "Equipo de X / DevOps / etc." |
| "Si hay apetito" | "Si hay tiempo / con feedback" |
| "Deliverables" | "Lo que sale" / "Lo que mergea" |
| "Leverage X to Y" | "Usar X para Y" |

Test: leerlo en voz alta. Si suena a McKinsey, reescribir.

## Crosslinks

- `pr-quality-review` — para auditar el PR DESPUÉS de armarlo.
- `guardia` — review parallel multi-agent.
- `commit` — para los commits que van en el PR (no para la descripción del PR).
- Memoria `feedback_pr_description_sync` — tras `git push` a rama con PR abierto, actualizar título+body también, no solo el código.
- Memoria `feedback_rioplatense_voice` — voz canónica.
- Memoria `feedback_no_apetito` — palabras banned.
- Memoria `feedback_estimates_assume_ai` — si el PR menciona estimates, hacer explícito "con IA".

## Files

- `SKILL.md` — proceso completo (este archivo)
- `README.md` — quick start + changelog
- `reference/pr-template-modo.md` — template drop-in con todas las secciones
- `reference/title-conventions.md` — reglas detalladas de title
- `reference/rioplatense-glossary.md` — diccionario buzzword→rioplatense
- `examples/pr-1497-logger-modo.md` — caso canónico feat backend (Ticket arriba + Milestone + Por qué no <alt> + Fuera de alcance prosa + Verificación compacta)
- `examples/pr-1480-security-workflow.md` — caso canónico CI-only
- `scripts/check-pr-format.sh` — valida un PR contra las reglas
