# MODO PR Author

Skill para autorar (y editar) descripciones de Pull Request en repos MODO siguiendo el template del repo, convenciones de commit, voz rioplatense y quality rules globales.

Complementa los skills de **review** (`pr-quality-review`, `guardia`, `engram-pr-review-deep`) que evalúan PRs ya creados. Este AUTORA descripciones.

## Quick start

- Trigger: "armá el PR", "creá el PR", "iterá la descripción", o detección automática de `gh pr create`/`gh pr edit` en repo MODO.
- Output: título ≤70 chars + body completo siguiendo template del repo, sin placeholders, voz rioplatense.
- Validar con: `~/.claude/skills/modo-pr-author/scripts/check-pr-format.sh <PR> [<owner>/<repo>]`

## Features

- Template canónico MODO con todas las secciones obligatorias (Descripción, Por qué, Cambios técnicos, Heads-up, Evidencia, JIRA, Checklist, Follow-ups).
- Title conventions con regla de ≤70 chars y validación automática.
- Glosario rioplatense (evita consultoría/inglés-traducido).
- Variantes según tipo de PR (feature, fix, refactor, CI, docs).
- Script bash de validación (17 checks) testeado contra PRs reales.
- Ejemplo canónico: PR #1480 antes/después.

## Files

- `SKILL.md` — proceso completo (process, anti-patterns, voz, crosslinks).
- `README.md` — esta doc.
- `reference/pr-template-modo.md` — template drop-in.
- `reference/title-conventions.md` — reglas detalladas de title.
- `reference/rioplatense-glossary.md` — diccionario buzzword → rioplatense.
- `examples/pr-1480-security-workflow.md` — caso canónico antes/después.
- `scripts/check-pr-format.sh` — validador (17 obligatorios + 4 advisories diff-aware).
- `scripts/enrich-pr.sh` — enriquecedor idempotente para PRs existentes (append secciones faltantes sin destruir contenido). Para auditoría retroactiva en batch.
- `reference/validator-patterns.md` — patterns meta-transferibles + traps (BSD sed → awk, `wc -c` bytes vs chars, validator/enricher trigger sync).

## Install / uso en repo MODO

No necesita instalación. El skill es global (`~/.claude/skills/`). Para usar el validador como pre-push hook:

```bash
# .husky/pre-push (opcional, si querés CI-side)
PR=$(gh pr view --json number --jq '.number' 2>/dev/null || true)
if [ -n "$PR" ]; then
  ~/.claude/skills/modo-pr-author/scripts/check-pr-format.sh "$PR" || {
    echo "PR format check failed. Run: gh pr edit $PR --body \"...\""
    exit 1
  }
fi
```

## Changelog

- **2026-05-26 (v3)** — bulk enrichment. `scripts/enrich-pr.sh` enriquece PRs existentes de forma idempotente (rename heading canónico + append Tests/Security review/Evidencia/JIRA/Checklist faltantes, preservando contenido). Workflow batch con `xargs -P`. 3 traps nuevos en `validator-patterns.md` (BSD sed → awk, `wc -c` cuenta bytes no chars en títulos UTF-8, validator/enricher trigger debe leer files no body). Caso canónico: 50 PRs cross-repo de Hernán llevados de 1→50 en 8/8. (Detalle: `SKILL.md` `## Bulk enrichment de PRs existentes`.)
- **2026-05-21 (v2)** — evolución del template: 5 secciones opcionales con criterios de obligatoriedad (Tests, Performance, Rollback, Reviewers, Security review). Matriz de obligatoriedad por tipo de PR. Validador detecta diff y exige Security review cuando toca `src/pages/api/`, `next.config.js`, `.github/workflows/`, `helm/` o deps. Advisory warnings para Tests/Performance/Rollback/Reviewers según scope. (Detalle: `SKILL.md` matriz + `reference/pr-template-modo.md` matriz de obligatoriedad.)
- **2026-05-21** — skill creado. Bootstrap desde el caso del PR #1480 (security workflow CI-only). Template + title conventions + rioplatense glossary + 17-check validator. (Detalle: `SKILL.md` y `examples/pr-1480-security-workflow.md`.)

## Crosslinks

- `pr-quality-review` — review post-creación.
- `guardia` — review parallel multi-agent.
- `commit` — commits del PR (Sentry convention).
- `frontend-security-checklist` — para PRs de seguridad como #1480.
- Memorias: `feedback_rioplatense_voice`, `feedback_no_apetito`, `feedback_pr_description_sync`, `feedback_estimates_assume_ai`.
