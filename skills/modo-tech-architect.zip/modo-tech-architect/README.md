# modo-tech-architect

PRD → specs OpenSpec + plan de implementación + sprint breakdown + tareas Jira. Consulta Swagger/OpenAPI, Confluence y repos MODO para detectar reuso antes de proponer cosas nuevas.

## Quick start

- **Trigger**: `analyze this PRD`, `create tech specs for X`, `implementation plan for Y`, `what MODO APIs/components exist for Z`.
- **Output**: documentación técnica consolidada con API mapping, gap matrix, sprint plan y (opcional) tareas Jira creadas.
- **Ejemplo**: pasarle un PRD de feature nueva → recibe OpenSpec change folder, TECHNICAL_IMPLEMENTATION_GUIDE.md y plan por sprints.

## Features

- Discovery automático contra Swagger, Confluence (vía MCP Atlassian) y repos `@playsistemico`.
- Gap matrix por requirement (✅ existe / 🟡 parcial / 🔴 falta).
- Genera artefactos OpenSpec (proposal, design, spec, plan) usando opsx.
- Sprint breakdown con estimates S/M/L/XL.
- Creación opcional de tareas Jira por sprint.
- Identifica reuso desde `@playsistemico/modo-sdk-web-ui-lib`, Remote Config, MCPs existentes.

## Files

- `SKILL.md` — proceso completo (8 fases: Input → Analysis → Specs → Docs → Sprints → Jira → Enhanced PRD → Iteration).
- `README.md` — esta doc.
- `references/`
  - `api-documentation-guide.md` — cómo documentar API integrations.
  - `modo-patterns.md` — patterns arquitectónicos comunes (UI lib wrappers, Remote Config, API service centralizado, MCP dual transport, etc.).
  - `tech-guide-structure.md` — template para TECHNICAL_IMPLEMENTATION_GUIDE.md.
  - `modo-merchants-api.md` — **cache canónica** de la superficie API documentada de Botón de Pago / MODO Checkout (5 endpoints, auth JWT HS256, webhooks JWS Flat). Última actualización: 2026-05-20.
- `scripts/`
  - `analyze_swagger.py` — parsea Swagger/OpenAPI y mapea a requirements.
  - `search_confluence.py` — busca patrones en Confluence spaces.
  - `generate_sprint_plan.py` — convierte specs a tasks.
  - `create_jira_tasks.py` — crea tickets desde el plan.
- `assets/`
  - `tech-guide-template.md`, `adr-template.md`, `sprint-plan-template.md`.

## Recursos MODO que consulta

| Resource | Cómo |
|---|---|
| Swagger/OpenAPI | `scripts/analyze_swagger.py --url <swagger-url>` |
| Confluence | Atlassian MCP (`mcp__claude_ai_Atlassian__*`). cloudId `play-sistemico`: `${MODO_ATLASSIAN_CLOUDID}` (ver Setup). |
| GitHub | gh CLI o skills de GitHub para grep repos `@playsistemico/*`. |
| UI lib | `@playsistemico/modo-ui-lib-web` (design system) y `@playsistemico/modo-sdk-web-ui-lib` (SDK). |

## Changelog

- **2026-05-20** — Agregada cache `references/modo-merchants-api.md` con la superficie API del producto Botón de Pago / MODO Checkout (auth, endpoints, webhooks, gaps de DX). Cubre el gap detectado en la sesión "developers portal mapping" cuando la skill no tenía Swagger cacheado para merchants/checkout y hubo que tirar de Confluence en vivo.
- **2026-01-29** — Creación inicial del skill con scripts, references y assets.

## Anti-patterns conocidos

- **Inventar endpoints** que no aparezcan en Swagger/Confluence/repos. Si falta, documentar como gap y bloquear hasta que backend confirme.
- **Saltar el discovery** asumiendo que ya conocés el stack. Cada feature tiene matices.
- **Tirar todos los gaps al mismo bucket**. Separar 🔴 críticos (blockers) de 🟡 importantes de ⚪ minor.

## Setup

El skill requiere la env var `MODO_ATLASSIAN_CLOUDID` con el cloudId del tenant Atlassian. Pedíselo al admin del workspace.

## Cross-links

- `modo-planner` — orquestador end-to-end (este skill es una fase de ese workflow).
- `sdd-explore` / `sdd-propose` / `sdd-design` / `sdd-tasks` — pipeline alternativo sin Jira.
- `mwdd-create-prd` / `mwdd-create-spec` — pipeline más formal con validación.
