# MODO Merchants API · cached reference

Cache canónica de la superficie API documentada del producto **Botón de Pago / MODO Checkout**, consumida por integradores externos (bancos socios + e-commerces). Fuente: espacio Confluence `Developers` en `play-sistemico.atlassian.net` (cloudId `${MODO_ATLASSIAN_CLOUDID}` — ver Setup en `README.md`).

> **Heads up**: el portal `developers.modo.com.ar` NO hostea API. Es un viewer auth-gated que renderea las mismas docs que `merchants.modo.com.ar/docs`. La API real vive en otro dominio.

## Base URLs

| Ambiente | URL |
|---|---|
| Preprod | `https://merchants.preprod.playdigital.com.ar` |
| Prod | `https://merchants.playdigital.com.ar` |

⚠️ Los ejemplos cURL del Confluence a veces usan `merchants-api.playdigital.com.ar` — inconsistencia de doc, no usar esa variante.

## Headers obligatorios (todos los requests)

```
Content-Type: application/json
User-Agent: <Merchant-Name>           # MANDATORIO. Si falta → request rechazada.
Authorization: Bearer <accessToken>    # Excepto /token y /.well-known/jwks.json
```

## Endpoints documentados (5)

| Verbo | Path | Propósito | Auth |
|---|---|---|---|
| `POST` | `/merchants/middleman/token` | Generar `accessToken` (JWT HS256, TTL 1 semana) | username/password en body |
| `POST` | `/merchants/ecommerce/payment-intention` | Crear intención de pago (QR + deeplink) | Bearer |
| `POST` | `/merchants/ecommerce/payment-intention` | Misma ruta + `subPayments[]` → **Split de pago** (solo DECIDIR 2.0/Tradicional) | Bearer |
| `GET` | `/merchants/ecommerce/payment-intention/{id}/data` | Obtener info de pago + `payment_data` + `sub_payments` | Bearer |
| `GET` | `/.well-known/jwks.json` | JSON Web Key Set para verificar firmas de webhooks | público |

## Auth model

**No es OAuth2 client_credentials. Es login con username/password que devuelve JWT propietario.**

```bash
curl -X POST 'https://merchants.playdigital.com.ar/merchants/middleman/token' \
  -H 'User-Agent: <Merchant-Name>' \
  -H 'Content-Type: application/json' \
  -d '{"username": "...", "password": "..."}'
```

Respuesta:
```json
{
  "accessToken": "<JWT HS256, exp en 7 días>",
  "user": {
    "id": "uuid",
    "name": "...",
    "callbackUrl": "https://.../callback/",
    "intentionReuseEnabled": true,
    "stores": [{
      "id": "uuid",
      "cuit": "...",
      "name": "...",
      "mcc": "551",
      "paymentMethods": [{"id": "uuid", "acquirer": "DECIDIR"}]
    }]
  }
}
```

**Reglas no-obvias del token:**
- JWT firmado HS256 (simétrico), `exp` en Unix timestamp dentro del payload.
- TTL de **1 semana**.
- La doc pide explícitamente **reutilizar el token entre requests**, no pedir uno nuevo cada vez.
- No hay scopes. El user trae `stores[]` con `acquirer` (DECIDIR, DECIDIR_PLUS, IPG).

**Onboarding de credenciales (preprod):** el integrador se da de alta como usuario en la app MODO; el código SMS de verificación se completa con `000000` (no llega SMS real en preprod). Es un hack documentado, no self-service.

## Crear intención de pago

```
POST /merchants/ecommerce/payment-intention
```

Campos:
| Campo | Tipo | Req | Notas |
|---|---|---|---|
| `productName` | string | ✅ | |
| `price` | float | ✅ | Max 13 chars |
| `quantity` | integer | ✅ | |
| `currency` | string | ✅ | `"ARS"` |
| `storeId` | string | ✅ | UUID provisto por MODO |
| `externalIntentionId` | string | ✅ | Único por transacción. Viaja al gateway/adquirente. Cumple rol de idempotency key parcial. |
| `expirationDate` | string | ❌ | ISO 8601. Default 10 min. Min 5 min, max 10 min. Se valida al escaneo (no al pago). |
| `message` | string | ❌ | Se transmite hasta el webhook |
| `subPayments` | array | ⚠️ | Solo para Split de pago. Suma debe igualar `price` total. |

Respuesta exitosa (201):
```json
{
  "id": "uuid",
  "status": "CREATED",
  "qr": "<EMV QR string>",
  "deeplink": "https://www.preprod.modo.com.ar/pagar/",
  "expirationAt": 600000,
  ...
}
```

## Máquina de estados

```
CREATED → SCANNED → PROCESSING → ACCEPTED
                                ↘ REJECTED
```

Estados notificados por webhook. Reintento del webhook para ACCEPTED y REJECTED: **4 veces a 30s, 60s, 90s, 120s**.

⚠️ La doc de Webhooks dice "reintentamos APPROVED y REJECTED" pero el estado real es `ACCEPTED`. Confunde al armar el handler.

## Webhooks

- El integrador expone una URL al onboardar la tienda.
- MODO postea ahí con un objeto que incluye `signature` en formato **JWS Flat (RFC-7515 §7.2.2)**.
- Verificación: descargar JWKS de `/.well-known/jwks.json` **una vez al iniciar la app**, NO en cada llamada al webhook.
- Política: responder `200 OK` instantáneo antes de procesar; procesar async.

Snippet de verificación (Node, `node-jose`):
```js
import { JWS, JWK } from 'node-jose';

let modoKeyStore;

async function initModoKeyStore() {
  const jwksUrl = 'https://merchants.playdigital.com.ar/.well-known/jwks.json';
  const response = await fetch(jwksUrl);
  const parsedResponse = await response.json();
  modoKeyStore = await JWK.asKeyStore(parsedResponse);
}

async function verifySignature(body) {
  const result = await JWS.createVerify(modoKeyStore).verify(body.signature);
  delete body.signature;
  return isEqual(body, JSON.parse(result.payload.toString()));
}
```

## Lo NO documentado / verificado

Páginas Confluence que existen pero NO están leídas en esta cache:
- Devoluciones (simples) — page 5446795363
- Devoluciones Split — page 5451153424
- Devoluciones y Cancelaciones — page 5451186186
- Integración Frontend — page 5446598669
- Integración Backend — page 5447024667 (al 2026-05-20 estaba **vacía**)
- Multi-Merchant — page TBD
- Plugins: Tiendanube (5446500440), VTEX (5446565945), Magento (5446893659), WooCommerce (5447483424), Tiendastic, Drubbit (5451153450), Tienda Negocio

Trampas de naming:
- **"V2 Modificación de cuotas"** (page 6015647892) NO es endpoint API. Es procedimiento manual en admin VTEX cambiando el sufijo `cc_code` del Provider STORE ID.

Gaps de DX (al 2026-05-20):
- Sin OpenAPI/Swagger descargable
- Sin self-service signup de credenciales
- Sin sandbox público sin login
- Sin SDKs versionados en npm/PyPI/Maven
- Sin changelog formal
- Sin Postman/Insomnia collection
- Sin status page
- Sin ratelimits documentados
- Sin idempotency keys explícitas (`externalIntentionId` cumple parcialmente)

## Confluence space ID + page map (para futuras consultas)

- cloudId: `${MODO_ATLASSIAN_CLOUDID}`
- space key: `Developers`
- Auth pages: 5446696973 (Autenticación token), 5447417900 (Credenciales logueo)
- API core: 5447548930 (Creación intención), 5446434849 (Obtener info), 5447417878 (Split), 5447221281 (Webhooks)
- Productos: 5446434817 (Qué es MODO), 5446598657 (Cómo funciona), 5446565897 (Plataformas y Gateways)

## Última verificación

- Fecha: **2026-05-20**
- Método: Atlassian MCP (`mcp__claude_ai_Atlassian__getConfluencePage`) con cloudId `${MODO_ATLASSIAN_CLOUDID}`.
- Sesión: Mapeo de developers portal → publicado como [RD01 en erno-modo](https://soyernomodo.github.io/erno-modo/rd/developers-portal-mapping.html).
