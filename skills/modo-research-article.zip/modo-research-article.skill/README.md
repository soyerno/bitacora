# modo-research-article

Skill canónico para escribir y publicar entradas en la colección **R&D** de la bitácora `erno-modo` (https://soyernomodo.github.io/erno-modo/rd/). Long-form HTML con diagramas SVG inline + Chart.js + tablas + matrices, usando los tokens MODO.

## Quick start

- **Trigger** (ES/EN): "armá un research", "research MODO de X", "RD nuevo", "investigación técnica", "mapeo de superficie", "investiguemos X y publicalo", `/modo-research-article`.
- **Output**: `<erno-modo>/rd/<slug>.html` + entry nuevo en `rd/rd.json`. Branch `feat/rd-<slug>` listo para PR.
- **Ejemplo**: "armá un research mapeando el API de promos" → outline → confirmás → genera HTML con TL;DR, TOC, diagramas, tabla de endpoints y disclaimer, commitea firmado y reporta el comando para abrir PR.

## Features

- Template HTML con todos los placeholders + slot para hasta 3 diagramas SVG + 1 Chart.js.
- Tokens MODO via CSS vars (Quicksand + Red Hat Display, verde `#008859` via `var(--accent)`). Cero hex hardcoded.
- Marker SVG `<defs>` único al body (no por diagrama).
- Status workflow `exploración → síntesis → decisión → archivado` mapeado a badge classes existentes del site.
- Numbering automático: `RD<NN>` siguiendo el máximo en `rd.json`.
- Worktree obligatorio: nunca toca `main` del repo.
- Commit firmado con `gpg` + PATH ajustado a `/opt/homebrew/bin`.
- NO abre PR automático — deja todo listo y reporta el comando.

## Files

- `SKILL.md` — proceso end-to-end + reglas duras + flow paso a paso.
- `README.md` — esta doc.
- `assets/`
  - `article-template.html` — skeleton HTML con placeholders `{{...}}` para llenar.
  - `rd-json-entry.template.json` — shape del item nuevo en `rd.json`.
- `references/`
  - `visual-recipes.md` — recetas drop-in: topology, state machine, endpoint table, callouts, matrix, gap columns, Chart.js.
  - `token-system.md` — mapeo de CSS vars (status, accent, surfaces, fonts) y cuándo crear uno nuevo.
  - `publish-workflow.md` — worktree → commit firmado → PR → sync → cleanup.
  - `hyperresearch-handoff.md` — Paso 0 opcional: motor de deep research (hyperresearch) → insumo del artículo. Install + comandos + costo.
  - `json-ld-schema-rules.md` — reglas schema.org para R&D que propone JSON-LD: campos obligatorios Rich Results, props mal-attribuidas, estrategia `@id` global, anti-hallucination invariant.
  - `a11y-checklist.md` — baseline WCAG 2.2 AA: head meta, table-scroll, SVG title+desc, Chart.js noscript fallback, code blocks aria-label+lang, heading order, verify-grep canónico.

## Reglas duras (resumen)

1. Worktree obligatorio en `/tmp/erno-modo-rd-<slug>` con branch `feat/rd-<slug>`.
2. CSS canónico en `rd/research-article.css` del repo — NO duplicar, NO inline.
3. Tokens via CSS vars — NO hex hardcoded en HTML/Chart.js.
4. Fonts MODO: Quicksand + Red Hat Display + JetBrains Mono. NO agregar otras.
5. Marker arrowhead único al body — NO por diagrama.
6. Chart.js lee CSS vars via helper `getCss(name, fallback)`.
7. Numbering `RD<NN>` (RD01, RD02, RD10).
8. Voz rioplatense — banned: `stakeholders`, `leverage`, `apetito`, `deliverables`.
9. No overclaim — features no-shipeadas con disclaimer.
10. Byline siempre "Hernán De Souza · Sr AI Engineer".
11. NO PR automático.

Ver `SKILL.md § Reglas duras (no negociables)` para el detalle completo.

## Cross-links

- **CSS canónico**: `rd/research-article.css` en repo `erno-modo` (source of truth, no duplicado en skill).
- **Ejemplos canónicos**:
  - `rd/developers-portal-mapping.html` (RD01) — mapping técnico con endpoint table, matrix productos×API, state machine SVG, Chart.js de gaps.
  - `rd/modo-govern-influencias.html` (RD02) — ensayo de genealogía, SVG radial de dimensiones + Chart.js horizontal bar. Buen referente para R&D de tipo ensayo (no mapping técnico).
- **Motor de research (Paso 0)**: `hyperresearch` — deep research agent-driven que precede al artículo. Ver `references/hyperresearch-handoff.md`.
- **Skill complementario**: `erno-modo-sync-all` — valida `rd.json` contra disco vía cron + `validate_rd()`.
- **Workflow promoción**: cuando una R&D sintetiza con propuesta concreta → promover a colección RFCs.

## Changelog

- **2026-05-28** — Wave 5 cierre: `reader-shell-pattern.md` validado en producción contra 19 lecciones + 5 R&D + 2 bitácora. Reverse converter `lección → slides PDF` documented en skill `modo-deck` (`scripts/leccion_to_slides.py`). Single source of truth = lección, slides son derivados on-demand. Pattern reusable para sitios MODO que mezclan reader scroll-read + presentación live: scroll para web/SEO/inclusión, slides para Zoom/PDF.
- **2026-05-28** — Nueva reference `reader-shell-pattern.md` canonizando el reader scroll-read unificado para sitios MODO. Pattern: 1 shell + JS parametrizado por `data-type="leccion|research|nota"`. Matriz de componentes por tipo (TL;DR, TOC sticky, prose 70ch, bionic toggle, reading progress, glossary `<abbr>` tooltips, skip-link WCAG, learn-objectives solo lección, next-lesson solo lección). Bionic excluye code/pre/table/headings (CSS canónico `assets/deck-bionic.css` en erno-modo). Caso canónico: SDD `bitacora-reader-experience` (commits 2c0?? y 5df9570) que unifica `research-article.css` actual al pattern. Leer antes de crear template HTML nuevo en R&D o lección.
- **2026-05-28** — Tercer R&D publicado: [RD04 `promos-hub-seo-geo-bridge`](https://soyernomodo.github.io/erno-modo/rd/promos-hub-seo-geo-bridge.html) (síntesis · landings temáticas evergreen + JSON-LD `SaleEvent` + cross-link a `/comercios/[slug]`, PR #50 squash-merged `85340aa`). Skill extendido con (a) **Paso 6.5 audit-iterate** obligatorio si R&D > 200 líneas: 2 critics paralelos Round 1 (SEO + Accessibility) + 1 critic fresh Round 2; RD04 cazó 4 CRIT + 11 WARN + 6 NIT que self-review missed. (b) **Verify subject term en repo** antes de escribir HTML — RD04 reescribió 700+ líneas porque "landings personalizadas" significaba landings temáticas por evento, no per-merchant per-month. (c) **Buffer effort estimate +40%** sobre estimate ingenuo. (d) Template HTML con a11y baseline (canonical + meta author + aria-live en nav-counts/theme-label). (e) Visual-recipes con nota anti-false-positive del marker SVG (CSS aplica marker-end automático). (f) Nuevas references `json-ld-schema-rules.md` + `a11y-checklist.md`.
- **2026-05-27** — Integrado **hyperresearch** (jordan-gibbs/hyperresearch, motor agent-driven de deep research) como **Paso 0 opcional** del flow. Nueva reference `hyperresearch-handoff.md`: el motor produce reporte sintetizado + sources con provenance en vault SQLite → alimenta Discovery/fill-template/`rd.json`. Reescribir su output neutro a voz rioplatense al pasar al HTML. Instalado en el host vía pipx pinned a python@3.13 (default 3.14 incompatible). Detalle en SKILL.md `## Paso 0`.
- **2026-05-21** — Segundo artículo publicado: RD02 `modo-govern-influencias.html` (ensayo de genealogía de un proyecto interno, con SVG radial de 6 dimensiones de influencia + Chart.js horizontal bar). Skill actualizado con reglas 14 y 15 (no rebasear si main avanzó; nav update completo en todos los index hermanos). Publish-workflow extendido con sección Troubleshooting (`gh api PUT` para mergear con worktrees múltiples, fix del nav slot collision con reset-and-reapply) + sección Bootstrap de categoría nueva con lista canónica de archivos a tocar. PR #28 mergeado (commit `ea52816`).
- **2026-05-21** — Skill creado. SKILL.md + 2 assets + 3 references + README. Disparado vía swarm de ruflo que se interrumpió y completado a mano. Primer ejemplo canónico vive en `rd/developers-portal-mapping.html` (RD01) del repo erno-modo.

## Anti-patterns

- **Crear CSS nuevo en el HTML del artículo.** Si necesitás un patrón visual nuevo, va a `rd/research-article.css` en un PR aparte al repo.
- **Hardcodear hex.** Verde MODO es `var(--accent)`, no `#008859`. Excepción: el favicon SVG inline en el `<head>` (irrelevante para tema).
- **Marker arrowhead por SVG.** Hay UNO al body — todas las flechas lo referencian con `marker-end: url(#arrowhead)`.
- **Pasar a `síntesis` sin propuesta concreta.** El estado `síntesis` implica que hay siguiente paso accionable. Si solo describís el problema, quedate en `exploración`.
- **Overclaim de features no-shipeadas.** Si mencionás algo en QA/POC/draft, va con disclaimer explícito de estado.
- **Saltarse worktree.** Tocar `main` directo rompe la disciplina de la bitácora.
