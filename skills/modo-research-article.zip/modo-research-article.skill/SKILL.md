---
name: modo-research-article
description: 'Generate long-form HTML R&D articles for the erno-modo bitácora (https://soyernomodo.github.io/erno-modo/rd/) using the canonical research-article.css pattern (SVG diagrams theme-aware, Chart.js with CSS vars, matrix grid, gap columns, callouts, endpoint tables). Auto-invoke when the user says (ES/EN) "armá un research", "research MODO", "long-form article", "RD nuevo", "investiguemos X y publicalo", "investigación técnica", "mapeo de superficie", "/modo-research-article". Output is `<erno-modo>/rd/<slug>.html` plus an entry in `rd/rd.json`. Estructura: TL;DR + TOC + prosa + diagramas SVG inline + Chart.js + matrix productos×API + gap-columns + endpoint table + footer con disclaimer. Enforces voz rioplatense, no overclaim, no inline styles, branding MODO (Quicksand + Red Hat Display, #008859 via vars), worktrees obligatorios.'
---

# MODO Research Article

Skill canónico para escribir y publicar entradas en la colección **R&D** de la bitácora `erno-modo` (https://soyernomodo.github.io/erno-modo/rd/).

Una R&D es una **investigación técnica long-form que precede a un RFC formal**: mapeos de superficie de API, descubrimientos, análisis de plataforma. Más corta que un RFC, más profunda que un comentario en Slack.

## Cuándo arrancar

Disparar el flujo cuando el usuario dice:

- "armá un research sobre X" / "research MODO de X"
- "long-form article" / "RD nuevo"
- "investiguemos X y publicalo"
- "investigación técnica" / "mapeo de superficie"
- "/modo-research-article"

Si el alcance es **chico** (1 página, sin diagramas, sin endpoints) → considerar si conviene un comentario en Slack/Confluence en vez de una R&D. La R&D pide al menos 1 diagrama o 1 visualización para justificarse.

## Reglas duras (no negociables)

1. **Worktree obligatorio.** Nunca tocar `main` del repo `erno-modo`. Crear worktree dedicado:
   ```bash
   cd /Users/hernan.desouza/Documents/Proyectos/modo/erno-modo
   git worktree add /tmp/erno-modo-rd-<slug> -b feat/rd-<slug> origin/main
   ```
2. **Estilos canónicos en `rd/research-article.css`.** NO duplicar el CSS, NO crear archivos css nuevos, NO inline styles excepto micro-tweaks (`<style>` chico en `<head>` para algo muy puntual). Si necesitás un patrón nuevo, primero proponer agregarlo a `research-article.css` en un PR aparte.
3. **Tokens vía CSS vars.** Verde MODO `#008859`, ink, muted, etc. salen siempre de `var(--accent)`, `var(--ink)`, `var(--muted)`, etc. **Prohibido** hardcodear hex en HTML o Chart.js. Ver `references/token-system.md`.
4. **Fuentes MODO.** Quicksand 600/700 (display) + Red Hat Display 400/500/600/700 (body) + JetBrains Mono (code). Vienen del `<head>` del template, no agregar otras.
5. **Marker SVG `<defs>` único** al body con `fill="currentColor"`. NO declarar marker por diagrama. Ver `references/visual-recipes.md`.
6. **Chart.js lee CSS vars.** Nunca colores hardcoded. Usar el helper `getCss(name, fallback)`. Ver `references/visual-recipes.md`.
7. **Numbering: `RD<NN>`** (RD01, RD02, RD03). Sumar 1 al máximo `number` que ya esté en `rd.json`.
8. **Status workflow:** `exploración → síntesis → decisión → archivado`. Mapea a badge classes `draft / rfc / completo / archived` (lo hace el index.html automático vía `rd.json`).
9. **Voz rioplatense.** Voseo, "tirar/meter/arrancar". Banned: `stakeholders`, `leverage`, `apetito`, `deliverables`. Test: leerlo en voz alta y que no suene a consultora.
10. **No overclaim.** Features en QA/POC/draft/RFC nunca van como justificación load-bearing. Mencionar con disclaimer de estado. Si la R&D habla de algo no shipeado, el footer-disclaimer lo aclara.
11. **Byline:** "Hernán De Souza · Sr AI Engineer". Nunca "Tech Lead" ni "MODO Team".
12. **MODO + bancos:** En JSON-LD/datos sí listar bancos. En prose decir "red MODO" o "ecosistema MODO" sin enumerar 37 nombres (ruido).
13. **No PR automático.** El skill termina dejando los archivos en el worktree + commit firmado. El usuario decide cuándo abrir el PR.
14. **Si main avanza durante el trabajo, NO rebasees.** Cuando main suma una categoría o link en el nav en paralelo (ej. Postmans entrando mientras escribías R&D), el rebase mete conflictos en 5 archivos (`index.html`, `decks/index.html`, `rfcs/index.html`, `herramientas/index.html`, `assets/nav-counts.js`) y mete ruido al diff. Más limpio: `git rebase --abort` → backup de `rd/*` → `git reset --hard origin/main` → restaurar `rd/*` → reaplicar parches del nav contra el state actual → un solo commit nuevo → `git push --force-with-lease`. Detalle en `references/publish-workflow.md § Troubleshooting`.
15. **Nav update completo.** Sumar el link de la categoría en TODOS los `<nav>` del repo: `index.html`, `decks/index.html`, `rfcs/index.html`, `postmans/index.html`, `herramientas/index.html`, `rd/index.html`, y cada artículo individual en `rd/*.html`. Más `assets/nav-counts.js`. Si bootstrappés una categoría, lista de archivos a tocar va en `references/publish-workflow.md § Bootstrap de categoría`.

## Flujo end-to-end

### Paso 0 · Research profundo con hyperresearch (opcional)

Si el tema necesita **profundidad real** (mapeo de superficie grande, muchas fuentes, análisis comparativo) y no traés ya el material crudo, correr **hyperresearch** ANTES de armar el HTML. Es el motor de research; este skill es el formateador de salida.

```bash
# /hyperresearch <tema>   (entry skill global, corre en cualquier sesión)
# o CLI directo:
hyperresearch research "<pregunta de investigación>" --tier light   # ~30-40 min, query acotada
hyperresearch research "<pregunta de investigación>" --tier full    # ~1.5-2.5 h, análisis profundo
```

hyperresearch produce un **reporte sintetizado + fuentes con provenance** en su vault SQLite (`research/`). Esa salida alimenta directo:

- **Paso 1 (Discovery)** → las `sources` ya vienen mapeadas, no hay que pedirlas a mano.
- **Paso 4 (fill template)** → el reporte sintetizado es la materia prima de la prosa + matrix + tablas.
- **Paso 5 (`rd.json`)** → el array `sources` se llena con las URLs del vault de hyperresearch.

**Cuándo NO usarlo:** research chico (1 fuente, sin comparativo) o cuando ya traés el material. hyperresearch consume API Anthropic (Opus/Sonnet/Haiku) — tier full tiene costo real. No dispararlo por reflejo.

> **Requisito:** hyperresearch instalado (pipx, python 3.13) + entry skill global en `~/.claude/`. Ver `references/hyperresearch-handoff.md`.

### Paso 1 · Discovery del research

Si el usuario no trae todo, preguntar (una sola vez, agrupado):

- **Tema y pregunta**: ¿qué estamos investigando y qué decisión destraba?
- **Fuentes**: links a Confluence, docs públicas, repos, paneles. Mínimo 1.
- **Visuales esperados**: ¿hace falta diagrama de topología? state machine? matrix productos × algo? chart de gaps?
- **Estado**: arranca en `exploración` por default. Si ya hay síntesis con recomendación → `síntesis`. Si ya hay decisión tomada → `completo`.

Si el usuario dijo "investigá X y publicalo" sin más, está autorizado a inventar la estructura razonable y mostrar el outline antes de escribir el HTML.

**Verify subject term en el repo ANTES de escribir el HTML.** Si el subject del R&D usa términos potencialmente ambiguos ("landings personalizadas", "promo pages", "checkout flow", "agent integration"), grepear el código real antes de asumir la interpretación. Reframes mid-flight cuestan caro: RD04 2026-05-28 reescribió 700+ líneas porque "landings personalizadas" significaba landings temáticas por evento, no per-merchant per-month. 2 minutos de `grep -rn "landing" src/` evitan 30 minutos de reescritura.

Verify-grep canónico para R&D que hablan de páginas/rutas/componentes:
```bash
cd <repo>
grep -rn "<term>" src/pages src/components src/CMS --include="*.tsx" --include="*.jsx" --include="*.ts" | head -20
find src -name "*<keyword>*" -type f | head -10
```

Si el subject no matchea con código real, **antes** de escribir, mostrar al user 2-3 interpretaciones candidatas con anchors al repo y pedir confirmación de cuál.

### Paso 2 · Outline del artículo

Antes de generar HTML, mostrar al usuario:

```
RD<NN> · <título>
Estado: <exploración|síntesis|completo>
~<N> min de lectura · <D> diagramas · <C> charts

TL;DR (3-4 bullets)

Secciones:
  1. <Encuadre>
  2. <Datos crudos / mapeo>
  3. <Análisis>
  ...
  N. Próximo paso

Visuales:
  - Diagrama topología (SVG inline)
  - Matrix productos × API
  - Chart.js bar: <X>
  - Tabla endpoints
  - Gap-columns críticos / importantes / OK
```

Confirmación rápida del usuario, después generar.

### Paso 3 · Crear worktree y copiar template

```bash
cd /Users/hernan.desouza/Documents/Proyectos/modo/erno-modo
git fetch origin
git worktree add /tmp/erno-modo-rd-<slug> -b feat/rd-<slug> origin/main
cp ~/.claude/skills/modo-research-article/assets/article-template.html \
   /tmp/erno-modo-rd-<slug>/rd/<slug>.html
```

Si el branch `feat/rd-category` aún no se mergeó a main (el que trae `rd/research-article.css`), basar el worktree en esa rama:

```bash
git worktree add /tmp/erno-modo-rd-<slug> -b feat/rd-<slug> origin/feat/rd-category
```

**TODO**: al momento de escribir este skill, `feat/rd-category` está en PR #28, no en main todavía. Una vez merged, basar siempre en `origin/main`.

### Paso 4 · Llenar el template

Reemplazar placeholders en el HTML. El template trae todos los marcadores explícitos `{{PLACEHOLDER}}`. Para cada bloque visual hay una receta en `references/visual-recipes.md`:

- **Diagrama topology / flow** → ver receta `dgm-node` + `dgm-arrow`.
- **State machine** → ver receta `dgm-state` con `dgm-state-init / -ok / -err`.
- **Matrix productos × API** → ver receta `matrix-card` + 5 columnas + leyenda.
- **Endpoint table** → ver receta `data-table` + `verb verb-post / verb-get`.
- **Gap columns** → 3 columnas: `gap-col-crit / gap-col-mid / gap-col-ok`.
- **Chart.js** → siempre leer CSS vars con `getCss()`.
- **Callouts** → `callout callout-info` (azul/rfc) o `callout callout-warn` (mostaza/draft).

Si la sección "Próximo paso" del artículo dice que hay que pasar a RFC formal, mencionarlo explícito: "el siguiente paso es promover esto a la colección RFCs como propuesta formal".

### Paso 5 · Actualizar `rd/rd.json`

Sumar un nuevo item al array `items` siguiendo el shape de `assets/rd-json-entry.template.json`. Campos obligatorios:

- `number` (próximo `RD<NN>`)
- `slug` (kebab-case, matches filename)
- `title`, `summary` (1 frase larga)
- `status`: `exploración | síntesis | completo | archivado`
- `tags` (array de 2-4 tags kebab-case)
- `area` (`platform | dx | seo | comercios | promos | analytics | infra`)
- `date` (`YYYY-MM-DD`)
- `href` (matches filename: `<slug>.html`)
- `reading_minutes`, `diagrams`, `charts` (counts)
- `sources` (array de URLs / referencias)

El `rd/index.html` lee `rd.json` por fetch y renderiza la grid automáticamente. **No hace falta editar `index.html`** salvo que cambie el copy fijo de la página (intro, workflow strip).

### Paso 6 · Validar localmente

Antes de commitear:

```bash
cd /tmp/erno-modo-rd-<slug>
# 1. validar JSON
node -e "JSON.parse(require('fs').readFileSync('rd/rd.json', 'utf8'))" && echo "rd.json OK"
# 2. validar HTML no tenga inline styles sospechosos
grep -nE 'style="(color|background|font-family):' rd/<slug>.html && echo "WARN inline styles" || echo "no inline color/bg/font"
# 3. validar tokens (no hex hardcoded en HTML)
grep -nE '#[0-9A-Fa-f]{6}' rd/<slug>.html | grep -v 'fill="#008859"' || echo "no extra hex"
# 4. servir y revisar
python3 -m http.server 8000 --directory /tmp/erno-modo-rd-<slug>
# abrir http://localhost:8000/rd/<slug>.html
```

### Paso 6.5 · Audit-iterate loop (obligatorio si R&D > 200 líneas)

Antes de commitear, si el HTML supera ~200 líneas y propone algo no-trivial (JSON-LD nuevo, plan SEO, propuesta arquitectónica), correr **audit-iterate** con sub-agents independientes. Self-review miente — esta regla viene de `feedback_audit_iterate_loop_for_new_agents` y RD04 lo confirmó (4 CRIT cazados que self-review missed).

**Round 1 · 2 critics paralelos** (lanzar en 1 mensaje con 2 `Agent` calls):

- `SEO Specialist` o `Code Reviewer` técnico — verifica JSON-LD válido, canonical strategy, claims load-bearing, métricas con baseline, contradicciones internas.
- `Accessibility Auditor` — WCAG 2.2 AA, table-scroll, aria-live, code-block aria-label, noscript fallback, heading order, breadcrumb. Ver checklist en `references/a11y-checklist.md`.

Prompt template para cada critic:
> Critic independiente line-by-line de R&D HTML. NO viste el diseño. Leelo fresh. Sé brutal. No praise. Cero hedging. [Archivo path] [Subject contexto] [Lista de checks específicos] Reportá findings en `path:line: SEVERITY: problema. fix sugerido.` con severities CRIT/WARN/NIT. Máx 250 palabras.

**Aplicar fixes Round 1** con verify-grep — antes de declarar fix, grepear el archivo para confirmar que el cambio existe. La prosa "lo arreglé" no cuenta sin grep que matchee.

**Round 2 · 1 critic fresh** sobre el archivo post-Round-1-fix:

- `Code Reviewer` o `Senior Developer` que NO vio el Round 1, leyendo el HTML post-fix.
- Prompt explícito: "verificá que los fixes claimed en commit message no sean solo prosa. Verify-grep canónico. Para CADA punto: `path:line: STATUS: detail` con STATUS = OK/MISS/REGRESSION."

Verdict aceptable para mergear: `PRODUCTION-READY` con 0 MISS o ≤1 MISS menor + fix inmediato.

**Buffer de effort estimate**: el primer estimate de effort sub-estima ~30-40% porque self-review no cuenta gaps de coordinación (validador Storyblok, audit redirect chains, CI gate Rich Results, plugins editorial). Inflar +40% sobre el estimate ingenuo antes de proponerlo en la R&D.

Caso canónico: [RD04 audit-iterate 2026-05-28](https://github.com/SoyErnoModo/erno-modo/pull/50) cazó 4 CRIT (JSON-LD inválido para Rich Results, duplicate content por query param, KPI vaporware, code block sin a11y) + 11 WARN + 6 NIT en Round 1, Round 2 verdict PRODUCTION-READY con 1 MISS menor. Estimate inicial ~7d → real ~10d.

### Paso 7 · Commit + (opcional) PR

```bash
cd /tmp/erno-modo-rd-<slug>
export PATH="/opt/homebrew/bin:$PATH"  # gpg para signed commits
git add rd/<slug>.html rd/rd.json
git commit -m "$(cat <<'EOF'
feat(rd): add RD<NN> · <title>

<one-line resumen del research>

Generated with modo-research-article skill.
EOF
)"
```

**NO** abrir PR automático. Reportar al usuario:
1. Path del HTML.
2. Diff de `rd.json`.
3. Comando para abrir PR cuando quiera: `gh pr create --fill --base main`.

### Paso 8 · Cross-link con `erno-modo-sync-all`

Cuando el PR se mergee, el cron `erno-modo-sync-all` valida que `rd.json` siga matcheando los archivos físicos. El skill **no toca `index.html` de la home** — eso es responsabilidad de `erno-modo-sync-all`.

## Cuando una R&D sintetiza → promover a RFC

El estado `síntesis` en una R&D es señal de que hay una propuesta concreta. En ese caso, el footer del artículo debe cerrar con:

> El siguiente paso es promover esto a la colección RFCs como propuesta formal (ver `rfcs/`).

Y el `Próximo paso` debe listar qué cambia al pasar a RFC: SDD `openspec/changes/`, sprint plan, Jira tasks.

## Estructura del skill

```
~/.claude/skills/modo-research-article/
├── SKILL.md                              # este archivo
├── README.md                             # quick start + features + changelog
├── assets/
│   ├── article-template.html             # skeleton HTML con placeholders
│   └── rd-json-entry.template.json       # shape de item en rd.json
└── references/
    ├── visual-recipes.md                 # recetas drop-in (SVG, Chart.js, matrix, gaps, tabla, callouts)
    ├── token-system.md                   # tokens CSS que usa research-article.css
    ├── publish-workflow.md               # detalle worktree → commit → PR → sync
    └── hyperresearch-handoff.md          # Paso 0: motor de research → insumo del artículo
```

- **Leer `references/visual-recipes.md`** cuando vayas a generar diagramas, charts, matrix, o tablas.
- **Leer `references/token-system.md`** si dudás qué CSS var usar para un color/state.
- **Leer `references/publish-workflow.md`** si dudás cómo cerrar el ciclo (worktree, commit firmado, PR, sync).

## Fuente de verdad

- CSS canónico: `rd/research-article.css` en el repo `erno-modo` (NO duplicar en el skill).
- Template HTML canónico: `rd/developers-portal-mapping.html` en el repo (RD01, fue el primer ejemplo).
- Catálogo: `rd/rd.json` en el repo, key `items`.
- Skill complementario: `erno-modo-sync-all` mantiene el cron de validación.

## TODOs conocidos

- PR #28 (`feat/rd-category`) ya mergeado a main el 2026-05-21 (commit `ea52816`). Worktrees nuevos basan en `origin/main` directo.
- Branch `fix/sync-validate-rd` quedó orfana del bootstrap — agregar `validate_rd()` al script `erno-modo-sync-all` antes de cerrar el ciclo.
- El template HTML asume que `../assets/styles.css`, `../assets/common.js`, `../assets/nav-counts.js`, `../assets/deck-bionic.css`, `../assets/deck-bionic.js` existen en el repo (vienen del skill `modo-deck`).
