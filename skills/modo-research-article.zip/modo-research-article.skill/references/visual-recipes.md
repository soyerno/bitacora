# Visual recipes · drop-in code

Recetas copy-paste para los bloques visuales canónicos de una R&D. Todas funcionan con `rd/research-article.css` ya cargado en el `<head>` del template.

## Diagrama de topología

Para mostrar cómo se conectan sistemas. Nodos rectangulares + flechas con marker. Usa `viewBox` para escalar.

```html
<figure class="article-figure">
  <svg viewBox="0 0 720 360" class="diagram" role="img" aria-labelledby="topology-title topology-desc">
    <title id="topology-title">Topología — qué muestra el diagrama</title>
    <desc id="topology-desc">Descripción larga accesible para screen readers.</desc>

    <!-- Nodo a la izquierda -->
    <g transform="translate(40,140)">
      <rect width="120" height="80" rx="10" class="dgm-node dgm-node-user"/>
      <text x="60" y="35" class="dgm-text dgm-text-strong" text-anchor="middle">Cliente</text>
      <text x="60" y="55" class="dgm-text dgm-text-muted" text-anchor="middle">(navegador)</text>
    </g>

    <!-- Nodo destacado -->
    <g transform="translate(220,40)">
      <rect width="170" height="76" rx="10" class="dgm-node"/>
      <text x="85" y="30" class="dgm-text dgm-text-strong" text-anchor="middle">Frontend</text>
      <text x="85" y="50" class="dgm-text dgm-text-muted" text-anchor="middle">SPA Next.js</text>
    </g>

    <!-- Nodo aside (accent) -->
    <g transform="translate(450,18)">
      <rect width="240" height="60" rx="10" class="dgm-node dgm-node-accent"/>
      <text x="120" y="24" class="dgm-text dgm-text-strong" text-anchor="middle">API real</text>
      <text x="120" y="42" class="dgm-text dgm-text-muted" text-anchor="middle">Otro dominio</text>
    </g>

    <!-- Flechas: usar marker-end via clase .dgm-arrow -->
    <path d="M 160 165 L 215 80" class="dgm-arrow"/>
    <path d="M 395 80 L 510 145" class="dgm-arrow dgm-arrow-dotted"/>
    <path d="M 160 155 C 320 90, 380 60, 450 50" class="dgm-arrow dgm-arrow-accent"/>
  </svg>
  <figcaption>Caption breve que cuenta qué leer del diagrama, no qué muestra el diagrama (eso ya lo ve).</figcaption>
</figure>
```

**Clases disponibles:**
- Nodos: `dgm-node` (default), `dgm-node-user` (fondo muted), `dgm-node-mid` (azul rfc), `dgm-node-accent` (verde MODO).
- Flechas: `dgm-arrow` (gris), `dgm-arrow-dotted` (dashed), `dgm-arrow-accent` (verde), `dgm-arrow-err` (rojo).
- Texto: `dgm-text` (default 12px), `dgm-text-strong` (13px bold), `dgm-text-muted` (11px gris), `dgm-text-accent` (verde 11px).

**Reglas:**
- Siempre `<title>` + `<desc>` con `aria-labelledby` para accesibilidad.
- Marker `<defs id="arrowhead">` ya está inyectado al body del template — NO declarar uno por SVG.
- Fill de la flecha hereda de `currentColor` definido en `.dgm-arrow*`, no setear fill en el path.
- **NO escribir `marker-end="url(#arrowhead)"` en cada path** — el CSS canónico `rd/research-article.css` aplica `marker-end: url(#arrowhead)` automático a `.dgm-arrow` via CSS prop. Si un audit reporta "marker definido pero nunca referenciado en paths" es false positive: el marker se referencia vía CSS, no vía atributo SVG.

## State machine

Estados como pills redondeados con transiciones. Para flujos finitos (4-6 estados).

```html
<figure class="article-figure">
  <svg viewBox="0 0 720 240" class="diagram" role="img" aria-labelledby="states-title states-desc">
    <title id="states-title">Ciclo de vida</title>
    <desc id="states-desc">CREATED → PROCESSING → ACCEPTED o REJECTED.</desc>

    <g transform="translate(20,100)">
      <rect width="110" height="50" rx="25" class="dgm-state dgm-state-init"/>
      <text x="55" y="30" class="dgm-text dgm-text-strong" text-anchor="middle">CREATED</text>
    </g>

    <g transform="translate(320,100)">
      <rect width="120" height="50" rx="25" class="dgm-state"/>
      <text x="60" y="30" class="dgm-text dgm-text-strong" text-anchor="middle">PROCESSING</text>
    </g>

    <g transform="translate(490,30)">
      <rect width="120" height="50" rx="25" class="dgm-state dgm-state-ok"/>
      <text x="60" y="30" class="dgm-text dgm-text-strong" text-anchor="middle">ACCEPTED</text>
    </g>

    <g transform="translate(490,170)">
      <rect width="120" height="50" rx="25" class="dgm-state dgm-state-err"/>
      <text x="60" y="30" class="dgm-text dgm-text-strong" text-anchor="middle">REJECTED</text>
    </g>

    <path d="M 130 125 L 318 125" class="dgm-arrow"/>
    <path d="M 440 122 L 488 60" class="dgm-arrow dgm-arrow-accent"/>
    <path d="M 440 130 L 488 195" class="dgm-arrow dgm-arrow-err"/>
  </svg>
  <figcaption>Anotaciones de retry/timeout van como `<text>` muted al lado del estado terminal.</figcaption>
</figure>
```

**Clases de estado:**
- `dgm-state` — neutral, fondo surface.
- `dgm-state-init` — fondo muted, para estados iniciales.
- `dgm-state-ok` — fondo verde, terminal exitoso.
- `dgm-state-err` — fondo rojo, terminal de error.

## Endpoint table

Tabla de endpoints HTTP con verbos coloreados.

```html
<div class="table-scroll">
  <table class="data-table">
    <caption>Endpoints documentados (N al YYYY-MM-DD)</caption>
    <thead>
      <tr>
        <th scope="col">Verbo</th>
        <th scope="col">Path</th>
        <th scope="col">Propósito</th>
        <th scope="col">Auth</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><code class="verb verb-post">POST</code></td>
        <td><code>/path/al/endpoint</code></td>
        <td>Qué hace en una frase</td>
        <td>Bearer token</td>
      </tr>
      <tr>
        <td><code class="verb verb-get">GET</code></td>
        <td><code>/path/{id}</code></td>
        <td>Otra cosa</td>
        <td>público</td>
      </tr>
    </tbody>
  </table>
</div>
```

**Verbo classes:** `verb-post` (verde), `verb-get` (azul). Para PUT/DELETE/PATCH, agregar la clase y el color tokenizado al CSS si hace falta.

## Callouts

Bloques de aviso. Dos variantes: `info` (azul/rfc) y `warn` (mostaza/draft).

```html
<p class="callout callout-info">
  <strong>Base URLs:</strong> Preprod <code>https://...</code> · Prod <code>https://...</code>.
</p>

<p class="callout callout-warn">
  <strong>Inconsistencia en la doc:</strong> la página dice X pero el estado real es Y.
</p>
```

Mantener cortos (2-3 líneas). Si es más, mover a prose normal o convertir en sección.

## Matrix grid (productos × API)

Heatmap visual para cruzar 2 dimensiones (productos en filas × features/endpoints en columnas).

```html
<div class="matrix-card">
  <div class="matrix">
    <div class="matrix-cell matrix-head"></div>
    <div class="matrix-cell matrix-head">Endpoint A</div>
    <div class="matrix-cell matrix-head">Endpoint B</div>
    <div class="matrix-cell matrix-head">Endpoint C</div>
    <div class="matrix-cell matrix-head">Endpoint D</div>
    <div class="matrix-cell matrix-head">Endpoint E</div>

    <div class="matrix-cell matrix-row-label">Producto 1</div>
    <div class="matrix-cell matrix-ok">✓</div>
    <div class="matrix-cell matrix-ok">✓</div>
    <div class="matrix-cell matrix-mid">parcial</div>
    <div class="matrix-cell matrix-na">—</div>
    <div class="matrix-cell matrix-gap">?</div>

    <div class="matrix-cell matrix-row-label">Producto 2</div>
    <div class="matrix-cell matrix-ok">✓</div>
    <div class="matrix-cell matrix-na">—</div>
    <div class="matrix-cell matrix-ok">✓</div>
    <div class="matrix-cell matrix-ok">✓</div>
    <div class="matrix-cell matrix-gap">?</div>
  </div>
  <div class="matrix-legend">
    <span><span class="lg-dot lg-ok"></span> Documentado</span>
    <span><span class="lg-dot lg-mid"></span> Parcial</span>
    <span><span class="lg-dot lg-gap"></span> No verificado</span>
    <span><span class="lg-dot lg-na"></span> N/A</span>
  </div>
</div>
```

**Grid columns:** primera columna fija 200px para labels, después N columnas equiespaciadas. Si tenés más de 6 columnas, considerar romper el diseño en dos matrices o pasar a tabla normal.

## Gap columns

3 columnas para clasificar issues por severidad. Patrón canónico de R&D que cierra con análisis.

```html
<div class="gap-columns">
  <div class="gap-col gap-col-crit">
    <h3>Críticos · N</h3>
    <ul>
      <li>Item crítico 1</li>
      <li>Item crítico 2</li>
    </ul>
  </div>
  <div class="gap-col gap-col-mid">
    <h3>Importantes · N</h3>
    <ul>
      <li>Item importante 1</li>
    </ul>
  </div>
  <div class="gap-col gap-col-ok">
    <h3>Lo que está bien · N</h3>
    <ul>
      <li>Item OK 1</li>
    </ul>
  </div>
</div>
```

**Regla**: siempre 3 columnas. Si solo tenés 2 categorías reales, dejá la tercera con un solo item ("Nada por ahora" no es válido — buscá algo positivo del estado actual).

## Chart con CSS vars

Chart.js que respeta el tema (claro/oscuro/auto). Nunca colores hardcoded.

```html
<figure class="article-figure">
  <div class="chart-wrap">
    <canvas id="my-chart" aria-label="Descripción del chart" role="img"></canvas>
  </div>
  <figcaption>Qué leer del chart, no qué muestra.</figcaption>
</figure>

<script>
(function () {
  if (typeof Chart === 'undefined') return;

  function getCss(name, fallback) {
    var v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  var ctx = document.getElementById('my-chart');
  if (!ctx) return;

  var urgent = getCss('--urgent-fg', '#B0001A');
  var draft = getCss('--draft-fg', '#8a5a00');
  var accent = getCss('--accent-ink', '#00471B');
  var muted = getCss('--muted', '#6B6B6B');
  var ink = getCss('--ink', '#1A1A1A');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Cat 1', 'Cat 2', 'Cat 3'],
      datasets: [{
        label: 'Cantidad',
        data: [9, 7, 5],
        backgroundColor: [urgent, draft, accent],
        borderRadius: 8,
        borderSkipped: false,
        maxBarThickness: 60
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function (c) { return c.parsed.y + ' items'; }
          }
        }
      },
      scales: {
        x: {
          ticks: { color: ink, font: { family: "'Red Hat Display', system-ui, sans-serif", size: 13, weight: '500' } },
          grid: { display: false }
        },
        y: {
          beginAtZero: true,
          ticks: { color: muted, stepSize: 1, font: { family: "'Red Hat Display', system-ui, sans-serif", size: 12 } },
          grid: { color: 'rgba(0,0,0,0.06)', drawBorder: false }
        }
      }
    }
  });
})();
</script>
```

**Reglas:**
- Helper `getCss(name, fallback)` siempre. El fallback es solo defensive — el tema real viene de CSS vars.
- Font family `'Red Hat Display'` para todos los ticks/labels.
- Chart container va con `.chart-wrap` (height 280px reservado en CSS).
- Si necesitás chart oscuro/claro diferente, no condicionalizar en JS — usar `getCss` y dejar que las vars cambien solas con el tema.

## Cuándo usar qué

| Visual | Cuándo |
|---|---|
| **Topology** | Hay ≥3 sistemas y querés mostrar quién habla con quién. |
| **State machine** | Hay un ciclo de vida con transiciones discretas y al menos 1 estado terminal. |
| **Endpoint table** | Mapeás una API. Mínimo 3 endpoints. |
| **Callout info** | Dato clave que no merece sección propia pero necesita destacarse. |
| **Callout warn** | Inconsistencia, gotcha, o bug abierto en la doc oficial. |
| **Matrix** | Cruzás 2 dimensiones discretas y querés mostrar coverage. |
| **Gap columns** | Clasificás issues por severidad (críticos / importantes / OK). |
| **Chart** | Hay un número cuantitativo que cuenta una historia mejor que prosa (counts, durations, ratios). Mínimo 3 datapoints. |

Si tu R&D no usa **ninguno** de estos visuales, considerá si conviene escribirla como comentario en Slack o entrada en Confluence en vez de R&D formal.
