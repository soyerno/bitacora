# Publish workflow · de worktree a sitio live

Cómo cerrar el ciclo end-to-end. Sigue el patrón de toda la bitácora `erno-modo`: worktree dedicado, commit firmado, PR contra `main`, sync diario que valida.

## Pre-condición

- Repo clonado en `/Users/hernan.desouza/Documents/Proyectos/modo/erno-modo` y al día con `origin/main`.
- El branch `feat/rd-category` (PR #28) ya mergeado a `main` — si no, basar en `origin/feat/rd-category`.
- `gh` autenticado y con permisos en el repo.
- `gpg` accesible en PATH (`/opt/homebrew/bin`) para commits firmados.

## Paso a paso

### 1 · Worktree

```bash
cd /Users/hernan.desouza/Documents/Proyectos/modo/erno-modo
git fetch origin
git worktree add /tmp/erno-modo-rd-<slug> -b feat/rd-<slug> origin/main
cd /tmp/erno-modo-rd-<slug>
```

Si el branch base aún no se mergeó:
```bash
git worktree add /tmp/erno-modo-rd-<slug> -b feat/rd-<slug> origin/feat/rd-category
```

### 2 · Generar el HTML

Copiar template y reemplazar placeholders:
```bash
cp ~/.claude/skills/modo-research-article/assets/article-template.html \
   /tmp/erno-modo-rd-<slug>/rd/<slug>.html
```

Editar el HTML siguiendo `references/visual-recipes.md` para cada bloque visual que necesites.

### 3 · Actualizar `rd/rd.json`

Sumar un item al array `items` siguiendo `assets/rd-json-entry.template.json`. El `number` es `RD<NN>` donde `NN = max(números existentes) + 1` (con padding a 2 dígitos: RD01, RD02, RD10, RD25).

```bash
# Validar JSON antes de seguir
python3 -m json.tool /tmp/erno-modo-rd-<slug>/rd/rd.json > /dev/null && echo "rd.json OK"
```

### 4 · Validación local

```bash
cd /tmp/erno-modo-rd-<slug>

# JSON parsea
python3 -m json.tool rd/rd.json > /dev/null

# Sin inline styles de color/bg/font (los acepta el linter solo si son micro-tweaks)
grep -nE 'style="(color|background|font-family):' rd/<slug>.html \
  && echo "WARN: inline color/bg/font detectado" \
  || echo "no inline color/bg/font"

# Sin hex hardcoded (excepto el favicon SVG inline en el head, que es #008859)
grep -nE '#[0-9A-Fa-f]{6}' rd/<slug>.html | grep -v '#008859' \
  && echo "WARN: hex hardcoded detectado" \
  || echo "no extra hex hardcoded"

# Servir local
python3 -m http.server 8000 --directory /tmp/erno-modo-rd-<slug> &
SERVER_PID=$!
echo "abrí http://localhost:8000/rd/<slug>.html"
# kill $SERVER_PID cuando termines
```

Checklist visual antes de cerrar:
- [ ] Theme toggle funciona (claro/oscuro/auto).
- [ ] Diagramas SVG no rompen en dark mode (los CSS vars resuelven solos).
- [ ] Chart.js respeta el tema (no hardcoded colors).
- [ ] TL;DR card visible arriba.
- [ ] TOC sticky en desktop, accordion en mobile.
- [ ] Footer con disclaimer.

### 5 · Commit firmado

```bash
cd /tmp/erno-modo-rd-<slug>
export PATH="/opt/homebrew/bin:$PATH"  # gpg

git add rd/<slug>.html rd/rd.json
git commit -m "$(cat <<'EOF'
feat(rd): add RD<NN> · <título corto>

<frase con el hallazgo central + qué decisión destraba>

Generated with modo-research-article skill.
EOF
)"
```

Si el commit falla por gpg: confirmar que `gpg --list-secret-keys` lista una key y que `git config --get user.signingkey` apunta a esa key.

### 6 · Push

```bash
git push -u origin feat/rd-<slug>
```

Si el classifier bloquea `git push` directo (raro en branches no-main), retry con `gh pr create` que también pushea.

### 7 · PR

```bash
gh pr create \
  --base main \
  --head feat/rd-<slug> \
  --title "feat(rd): add RD<NN> · <título>" \
  --body "$(cat <<'EOF'
## Resumen

Sumá una entrada nueva a la colección R&D (`rd/`) de la bitácora.

**Hallazgo principal:**
- <bullet>

**Visuales:**
- <diagrama / chart / matrix / tabla / etc.>

**Status:** exploración | síntesis | decisión

## Próximo paso

<qué destraba este research; si es síntesis, mencionar el RFC que sigue>

---

🤖 Generated with [Claude Code](https://claude.com/claude-code) via modo-research-article skill.
EOF
)"
```

**NO** automergeás. Esperás review (incluso de vos mismo en otro momento) y mergeás manual.

### 8 · Post-merge

Cuando el PR se mergea a `main`:

1. **GitHub Pages** redeploya solo en ~30s.
2. **`erno-modo-sync-all`** lo va a ver en el próximo cron (18:00 ART) o cuando corras manual. Su `validate_rd()` chequea que `href` exista y que el shape esté OK. Si hay drift, te lo reporta.
3. **Cleanup del worktree:**
   ```bash
   cd ~/Documents/Proyectos/modo/erno-modo
   git worktree remove /tmp/erno-modo-rd-<slug>
   git branch -D feat/rd-<slug>  # opcional, ya está mergeado
   ```

## Cuando una R&D pasa a síntesis o decisión

El status workflow es `exploración → síntesis → decisión → archivado`. Si ya pasó de "exploración":

- **Update simple**: editar `rd/rd.json`, cambiar `status` del item, commit + PR chico.
- **Si cambió contenido también**: editar el HTML también, mismo PR.
- **Si pasó a `síntesis` con propuesta concreta**: el siguiente paso real es promover a la colección RFCs (no se borra el R&D, queda como evidencia histórica).

## Cuándo NO publicar

- El research es solo para vos / un thread interno → comentario en Slack o nota en Obsidian, no R&D.
- Es info confidencial (credenciales, datos de cliente, internal-only) → la bitácora es pública.
- Es opinión pura sin datos / sin visuales → comentario, no R&D.
- Está incompleto y no querés que se vea así → branch local, no PR.

## Cross-link con `erno-modo-sync-all`

El skill `erno-modo-sync-all` valida `rd.json` contra el filesystem una vez por día:

- `validate_rd()` chequea `href` exista en `rd/`, `status` esté en el workflow oficial, `number` matchee `RD\d{2,}`.
- Read-only — reporta drift en el log, no auto-fixea.
- Si te avisa drift, abrí un PR de cleanup.

## Troubleshooting

### `gh pr merge --admin` falla con "main is already used by worktree"

**Síntoma:**
```
failed to run git: fatal: 'main' is already used by worktree at '/Users/.../erno-modo'
```

**Causa:** `gh pr merge` intenta hacer checkout local de `main` para confirmar, pero ya está checkouted en otro worktree del repo.

**Fix:** mergear vía GitHub REST API directo, sin tocar git local:
```bash
export PATH="/opt/homebrew/bin:$PATH"
gh api -X PUT repos/SoyErnoModo/erno-modo/pulls/<N>/merge -f merge_method=squash
```
Devuelve `{"sha":"...","merged":true,"message":"Pull Request successfully merged"}`. Después borrá la branch remota:
```bash
gh api -X DELETE repos/SoyErnoModo/erno-modo/git/refs/heads/feat/rd-<slug>
```

### Main avanzó durante el trabajo (conflictos en el nav)

**Síntoma:** después de pushear el branch, `gh pr view` reporta `"mergeable":"CONFLICTING"`. Al rebasear, conflictos en `index.html`, `decks/index.html`, `rfcs/index.html`, `herramientas/index.html`, `assets/nav-counts.js`.

**Causa:** main agregó una categoría/link al nav (ej. Postmans) en paralelo. Tu branch hizo los mismos cambios al nav contra una versión vieja.

**Fix (más limpio que pelear conflictos del rebase):**
```bash
cd /tmp/erno-modo-rd-<slug>
git rebase --abort  # si estabas en medio

# 1) Backup rd/* (es lo único 100% tuyo)
mkdir -p /tmp/rd-backup && cp -r rd /tmp/rd-backup/

# 2) Reset duro contra origin/main
git fetch origin main
git reset --hard origin/main

# 3) Restaurar rd/*
cp -r /tmp/rd-backup/rd ./rd

# 4) Re-aplicar nav patches contra el state actual de main
#    (sumar link al lado de la última categoría, no reemplazar nada)

# 5) Commit + force-push
git add -A && git commit -m "feat(rd): <slug> · <título>"
git push --force-with-lease origin feat/rd-<slug>
```

Esto evita 5 conflictos manuales y deja un commit limpio en el PR.

### Branch orfana del bootstrap (`fix/sync-validate-rd`)

Si bootstrappeás una categoría nueva, asegurate que el sync diario sepa validarla. Si no, queda branch huérfana esperando `validate_<cat>()` y el sync no te avisa de drift. Mergear ese fix junto con el bootstrap o anotarlo como TODO en SKILL.md.

## Bootstrap de categoría nueva (caso especial)

Cuando la R&D abre una categoría nueva (no es el caso típico — la categoría R&D ya existe desde 2026-05-21), seguir el patrón canónico:

**Archivos a crear:**
- `<cat>/index.html` (listing dinámico vía fetch a `<cat>.json`)
- `<cat>/<cat>.json` con shape `{_meta, items: [...]}` (key SIEMPRE `items`)
- `<cat>/<archivo-css>.css` si la categoría necesita estilos propios

**Archivos a modificar (TODOS, no se puede omitir ninguno):**
- `index.html` — sumar nav link + explore-card + counter + fetch a `<cat>.json` en el script
- `decks/index.html` — sumar nav link al lado de la última categoría
- `rfcs/index.html` — idem
- `postmans/index.html` — idem
- `herramientas/index.html` — idem
- `assets/nav-counts.js` — sumar entry al array `targets`
- Cada artículo de la categoría nueva — su nav debe listar TODAS las categorías hermanas

**Regla del slot:** SIEMPRE sumar el link al lado del último, NO reemplazar otro link. El bug clásico es asumir que un slot está libre cuando en realidad lo ocupa una categoría que se agregó hace dos commits.

**Validador del sync diario:** sumar `validate_<cat>()` al script `erno-modo-sync-all` (file `scripts/sync.sh` o similar). Si no, la categoría no se valida y puede driftear.
