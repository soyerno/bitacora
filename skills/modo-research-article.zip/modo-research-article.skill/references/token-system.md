# Token system · CSS vars para R&D articles

Mapping de los CSS custom properties que usa `rd/research-article.css` (y `assets/styles.css` del repo erno-modo). Sirve para saber qué `var(--xxx)` usar para cada color/estado en SVG diagrams, Chart.js, callouts custom, etc.

**Source of truth**: `assets/styles.css` en el repo erno-modo. Este doc es un mapa, no la definición.

## Layout / surfaces

| Token | Light | Dark | Uso |
|---|---|---|---|
| `--bg` | `#FAFAF7` (off-white) | `#0E1411` (verde casi negro) | Background del body. |
| `--surface` | `#FFFFFF` | `#131B17` | Cards, callouts, matrix cells. |
| `--border` | `#E2E2DC` | `#232C26` | Borders default. |
| `--border-soft` | `#EFEFE9` | `#1B231E` | Backgrounds sutiles (table caption, matrix grid gap). |
| `--shadow-card` | `0 6px 20px rgba(0,0,0,0.08)` | `... 0.35` | Sombra de cards/figures. |

## Tipografía / texto

| Token | Light | Dark | Uso |
|---|---|---|---|
| `--ink` | `#1A1A1A` (casi negro) | `#F2F4F1` | Texto principal, headings. |
| `--ink-soft` | `#2A2A2A` | `#DDE0DC` | Prose body. |
| `--muted` | `#6B6B6B` | `#92978F` | Captions, meta, ticks de charts. |

## Acento MODO

| Token | Light | Dark | Uso |
|---|---|---|---|
| `--accent` | `#008859` (verde MODO) | `#2DD68B` (verde brillante) | Links, badges, accent borders, arrows accent. |
| `--accent-ink` | `#00471B` (verde oscuro) | `#DCF5E7` | Texto sobre fondo accent, charts ok category. |
| `--accent-light` | `#E6F4EE` (verde claro) | `#14271E` | Background de cards destacadas, TL;DR. |
| `--focus` | `#008859` | igual al accent | Outline de focus. |

## Estados / status badges

Cada uno tiene par `bg`/`fg`. Mapean a status workflow del bitácora.

| Token bg | Token fg | Light fg | Dark fg | Uso (R&D workflow) |
|---|---|---|---|---|
| `--draft-bg` | `--draft-fg` | `#5C3F00` (mostaza oscuro) | `#F2D470` | **Exploración** · `status-badge draft` · gap-col-mid |
| `--rfc-bg` | `--rfc-fg` | `#0049C4` (azul) | `#93B4FF` | **Síntesis** · `status-badge rfc` · callout-info |
| `--done-bg` | `--done-fg` | `#00471B` (verde) | `#6FE3A8` | **Decisión/Completo** · `status-badge completo` · gap-col-ok · matrix-ok · verb-post · state-ok |
| `--archived-bg` | `--archived-fg` | `#6B5B3B` (beige oscuro) | `#B5A788` | **Archivado** · `status-badge archived` |
| `--urgent-bg` | `--urgent-fg` | `#B0001A` (rojo) | `#FF8B97` | **Crítico** · `status-badge urgent` · gap-col-crit · matrix-gap · state-err · arrow-err |

## Cómo mapea a R&D status workflow

```
exploración  → status-badge draft     → --draft-fg / --draft-bg     (mostaza)
síntesis     → status-badge rfc       → --rfc-fg / --rfc-bg         (azul)
decisión     → status-badge completo  → --done-fg / --done-bg       (verde)
archivado    → status-badge archived  → --archived-fg / --archived-bg (beige)
```

El `rd/index.html` traduce automático cuando lee `rd.json`. **No** mapear vos a mano.

## Uso en SVG diagrams

Las clases de `.dgm-*` ya tienen los CSS vars adentro. NO hardcodees hex en `fill`/`stroke`. Si necesitás un color nuevo, agregá clase nueva al CSS, no inline.

Ejemplo del marker arrowhead:
```css
.dgm-arrow {
  stroke: var(--muted);
  color: var(--muted);  /* el currentColor del marker hereda de acá */
}
.dgm-arrow-accent {
  stroke: var(--accent);
  color: var(--accent);
}
```

## Uso en Chart.js

```js
var urgent = getCss('--urgent-fg', '#B0001A');
var draft = getCss('--draft-fg', '#8a5a00');
var accent = getCss('--accent-ink', '#00471B');
var muted = getCss('--muted', '#6B6B6B');
var ink = getCss('--ink', '#1A1A1A');
```

Para mantener consistencia visual entre matrix grid y chart de gaps: usar el mismo set de 3 (urgent / draft / accent-ink) para "críticos / importantes / OK".

## Fonts

- `'Quicksand', sans-serif` — display (h1, h2, badges, eyebrows). Pesos 600 (semibold) y 700 (bold).
- `'Red Hat Display', system-ui, sans-serif` — body. Pesos 400/500/600/700.
- `'JetBrains Mono', 'Courier New', monospace` — código inline + bloques de código + verbo en endpoint table + TOC numbers.

Cargadas desde `<head>` del template. NO cambiar la combinación.

## Cuándo crear un token nuevo

Si necesitás un color que no está acá:

1. Primero **buscá si combinás existentes** con `color-mix()` (ya se usa en gap-col-crit/mid/ok).
2. Si no alcanza, **agregar al CSS canónico** `rd/research-article.css` (PR aparte al repo erno-modo).
3. **Documentar acá** después de mergeado.

NO definir vars dentro del HTML del artículo. NO duplicar en `<style>` inline.
