---
name: modo-storyblok
description: Orquestar contenido editorial en frontends MODO via Storyblok. Schemas + TS types + bloks renderer + dual-source con fallback al código + Management API push scripts + visual editor wiring. Reusable para cualquier content type MODO (cursos educativos, productos, promos, comercios, articles). Auto-invocable cuando el user pida "armá Storyblok para X", "convertí esto a CMS", "migrá hardcoded a Storyblok", "schema de Storyblok para Y", "/modo-storyblok".
---

# modo-storyblok

Skill canónico para orquestar contenido editorial en frontends MODO via Storyblok. Codifica el patrón end-to-end que migró las 7 páginas `/curso/<slug>` de aprendeatumodo de JSX hardcoded (1655 LOC) a Storyblok-driven con graceful fallback.

## When to use (auto-invoke triggers)

- "armá Storyblok para X", "convertí esto a CMS", "migrá hardcoded a Storyblok"
- "schema de Storyblok para Y", "blok para Z"
- "push schemas a Storyblok", "Management API"
- "visual editor de Storyblok"
- Sites MODO con contenido editorial: aprendeatumodo, modo.com.ar, promos-hub-site, comercios

## When NOT to use

- Contenido transaccional (promos, comercios) que viene de BFFs · usar el flow API, no CMS
- Contenido visual decorativo (assets, fonts, tokens) · usar `modo-design-system`
- Si el sitio ya tiene un CMS distinto (Sanity, Contentful) en pie · usar lo que esté

## Core principles

### P1 · Bloks nestables, no richtext puro

Para contenido editorial rico (cursos, articles, módulos) usar **bloks nestables**. Editor UX mejor que richtext con marks custom (cada bloque tiene su form propio). Pattern: 1 root story con campo `body: bloks` whitelisting N bloks atómicos.

### P2 · Dual-source con graceful fallback

Durante migración de hardcoded → CMS, **siempre** dual-source:

```tsx
const { story } = useStoryblok<MyStory>(slug);
const resolved = useMemo(() => {
  if (story) return { source: "storyblok", ...adapt(story) };
  return { source: "code", ...legacy };
}, [story, legacy]);
```

Permite migrar item por item sin romper el resto. Drop del fallback post-verificación.

### P3 · Adapter en boundary, no Component union types

NO modificar componentes downstream para aceptar `Legacy | Blok` unions. En su lugar, escribir un **adapter** que convierte el blok shape al shape downstream existente. Componentes no cambian.

```tsx
// adapter.ts
export function adaptStoryToFooShape(story: FooStory): FooShape {
  return {
    title: story.content.title,
    items: story.content.items.map(adaptItem),
    body: <BodyRenderer bloks={story.content.body} />,
  };
}
```

### P4 · Iconos por string-name + whitelist

Lucide icons en bloks: campo `icon_name: text` con whitelist en código. Dynamic import = bundle bloat ~600KB. Whitelist explícita + `resolveIcon()` con fallback + warn dev.

### P5 · Stories versionadas en git

`storyblok/stories/<full-slug>.json` por story · source-of-truth en git. Permite code review · rollback · diff editorial.

### P6 · Visual editor wireado por default

`useStoryblok` hook detecta `?_storyblok=*` y carga el StoryblokBridge automáticamente. Editor preview funciona sin config extra.

### P7 · Folders necesitan is_startpage child para servir contenido

Storyblok folders (`is_folder: true`) NO sirven contenido directamente desde el CDN. Para que `cdn/stories/<full-slug-folder>` devuelva content, crear child story con `is_startpage: true`. Storyblok renombra el slug del child al del parent automáticamente. Ver `reference/folder-routing.md` para los 5 gotchas (is_startpage, idempotency, story→folder conversion, parent_id, nested multilinks).

## Process · migrar contenido hardcoded a Storyblok

### Step 1 · Inventario del contenido legacy

```bash
# Cuántos archivos · qué LOC · qué patterns usan
ls src/components/<feature>/*.tsx
wc -l src/components/<feature>/*Content.tsx
grep -h "^import " src/components/<feature>/*Content.tsx | grep lucide | sort -u
```

Listar:
- Componentes branded usados (Callout, Step, Tile, etc.)
- Lucide icons (para iconMap whitelist)
- Patterns de contenido (prose, list, callout, step, sub-heading, etc.)

### Step 2 · Diseñar schemas

Para cada pattern → 1 schema Storyblok. Schemas son:
- **Root story** (`is_root: true`): el tipo principal · ej. `course`, `article`, `product_page`
- **Body bloks** (`is_nestable: true`): bloques atómicos · ej. `module_prose`, `module_callout`, `module_step`

Cada schema en `storyblok/components/<name>.json`. Ver `reference/schemas-canonical.md` para los 9 schemas del caso aprendeatumodo.

### Step 3 · TS types

Extender `src/CMS/types.ts` con tipos paralelos a cada schema · union para body. Ver `reference/schemas-canonical.md > TypeScript types`.

### Step 4 · Bloks renderer

`src/CMS/<Feature>BodyRenderer.tsx` con switch sobre `blok.component` → componente branded existente. Ver `reference/blok-renderer-pattern.md`.

3 helpers obligatorios:
- `iconMap.ts` · whitelist Lucide + `resolveIcon()`
- `richtextRenderer.tsx` · richtext SB → React (paragraph/heading/lists/marks bold/italic/link/code)
- `<Feature>BodyRenderer.tsx` · dispatch por blok type

### Step 5 · Adapter + page wiring

Adapter convierte `Story → Shape` consumido por el componente downstream. Page usa dual-source con fallback. Ver `reference/dual-source-pattern.md`.

### Step 6 · Stories versionadas

`storyblok/stories/<full-slug>.json` por story · versionar JSON canónico antes de push a Storyblok prod.

### Step 7 · Push scripts

`storyblok/scripts/push-components.mjs` + `push-stories.mjs` · sin deps · Management API · idempotente · dry-run default · region routing · retry. Ver `reference/mgmt-api-scripts.md`.

### Step 8 · Tests

Fixtures + tests RTL parametrizados con `describe.each`. Ver `reference/testing-pattern.md`.

### Step 9 · Editorial workflow

Después de push inicial:
- Editor edita en Storyblok UI
- Export script sincroniza JSON back a `storyblok/stories/*.json` (manual hasta ahora)
- Webhook Storyblok → CD trigger (cuando aterrice SSG)

## Canonical schemas (mínimos)

Para cualquier content type MODO, estos schemas son base:

| Schema | Rol |
|---|---|
| `<entity>` (root) | Story principal · title + description + metadata + SEO tabs |
| `<entity>_section` o `_module` | Sub-unidad si hay carousel/pagination |
| `module_prose` | Párrafo richtext |
| `module_callout` | Tone (info/warning/danger) + title + emoji + body |
| `module_tile_stack` + `module_tile` | Grilla de cards |
| `module_step` | Paso numerado |
| `module_check_item` | Item con tilde |
| `module_prose_list` | Lista bullet/numbered |
| `module_sub_heading` | h3 + icon opcional |

Detalle JSON-by-JSON en `reference/schemas-canonical.md`.

## Anti-patterns

- **Modificar componentes downstream** · No tipear `Legacy | Blok` unions. Adapter en boundary mantiene shape única.
- **Richtext puro para todo** · Editor UX se rompe sin form per blok. Usar bloks nestables.
- **Dynamic import de iconos** · `lucide-react/dist/esm/icons/${name}` mete 600KB+. Whitelist.
- **Schemas creados a mano en UI** · Sin versionado. Crear localmente, push via Management API.
- **Push sin dry-run** · El default debe ser `--apply` opcional. Default conservador.
- **CSR-only sin SSG** · React/Helmet emite invisible a crawlers. SEO trap. Ver skill `modo-seo-geo-audit`.
- **Token Management hardcoded en repo** · `.env.local` gitignored.

## Caso canónico

aprendeatumodo · PRs #11-#17 · 2026-05-23..2026-05-25:

| Wave | Scope | Output |
|---|---|---|
| W1 | SDD + 9 schemas + 14 TS types | #11 commit `8561298` |
| W2 | renderer + iconMap + richtextRenderer + 25 tests | #12 `6bf9e93` |
| W1b | Gap fixes A+B+C en schemas (callout title · subheading icon · intro/outro bloks) | #13 `a545986` |
| W3 | CoursePage + Carousel dual-source con adapter | #14 `f01c4ec` |
| W4 | piloto Seguridad story 634 LOC JSON | #15 `4ff8fac` |
| W5 | Mgmt API push scripts | #16 `db9c59b` |
| W6 | 6 cursos restantes (2318 LOC JSON · 30 modules · 148 bloks) | #17 `b6610ff` |
| W7 | split nested modules → standalone stories + folder routing fix (is_startpage children) | 2026-05-25 |
| W7b | course startpage child stories per folder con refs populados | 2026-05-25 |

Total: 42 stories organizadas en folder tree (1 `aprende` · 1 `curso` · 7 course folders · 7 `modulo` subfolders · 30 module stories · 7 course startpage children) · 176 body bloks nested · 126 tests RTL · 4ms-100ms render por blok.

## Files

- `SKILL.md` — este archivo · proceso end-to-end
- `README.md` — quick start + features + caso canónico
- `reference/schemas-canonical.md` — los 9 schemas con fields
- `reference/blok-renderer-pattern.md` — pattern del Renderer + iconMap + richtextRenderer
- `reference/dual-source-pattern.md` — adapter + page wiring + tests
- `reference/mgmt-api-scripts.md` — push-components + push-stories + retry + dry-run
- `reference/folder-routing.md` — folders + is_startpage children + parent_id + nested multilinks gotchas
- `reference/visual-editor-wiring.md` — wire del Visual Editor nativo (cmsEditable + firma _storyblok_tk + input→setState). NO editor custom
- `reference/testing-pattern.md` — fixtures + describe.each + adapter tests
- `assets/` — reservado para JSON templates copiables (vacío hoy · ejemplos vivos en `aprendeatumodo/storyblok/{components,stories}/*.json`)

## Cross-link

- [`modo-seo-geo-audit`](../modo-seo-geo-audit/) — CSR trap + SSG resolve
- [`modo-design-system`](../modo-design-system/) — tokens y componentes branded que el renderer mapea
- [`sdd-init`](../sdd-init/) — scaffold openspec/changes/<slug>/ para tracking
