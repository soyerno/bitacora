# Folder routing en Storyblok

Folders en Storyblok son stories con `is_folder: true`. Para que el CDN sirva contenido en el path del folder, hace falta un **child story con `is_startpage: true`**. Esta página codifica los gotchas descubiertos en aprendeatumodo W7 (2026-05-25).

## Gotcha 1 · folder sin startpage = 404

**Síntoma**: creás folder `aprende/curso/seguridad` con `content` populado. CDN devuelve "This record could not be found" en `cdn/stories/aprende/curso/seguridad`.

**Causa**: Storyblok no sirve `content` del folder directamente. El folder es solo un nodo del tree, no un story-with-content servible.

**Fix**: crear child story con:
- `slug: "home"` (Storyblok rewrites al slug del parent automáticamente)
- `parent_id: <folder.id>`
- `is_startpage: true`
- `content: <real content>`

CDN responde el path del folder con el content del startpage child.

```js
const payload = {
  story: {
    name: courseJson.name,
    slug: "home",
    parent_id: folderId,
    is_startpage: true,
    content: updatedContent,
  },
  publish: 1,
};
await mapi({ method: "POST", path: "stories", body: payload });
```

## Gotcha 2 · idempotency check NO por slug

**Síntoma**: re-correr el script crea un segundo child porque busca `slug: "home"` y Storyblok lo renombró al slug del parent.

**Causa**: Storyblok reescribe el slug del child startpage al match del parent slug post-create.

**Fix**: buscar por `is_startpage: true` + `!is_folder` filtrado al parent:

```js
const childrenResp = await mapiGet(`stories?with_parent=${folderId}&per_page=50`);
const existing = (childrenResp?.stories ?? []).find(
  (s) => s.is_startpage && !s.is_folder,
);
if (existing) {
  await mapi({ method: "PUT", path: `stories/${existing.id}`, body: payload });
} else {
  await mapi({ method: "POST", path: "stories", body: payload });
}
```

## Gotcha 3 · story existente NO se puede convertir a folder

**Síntoma**: tenés `aprende/curso/seguridad` como story (no folder) por un push anterior buggy. Intentás PUT con `is_folder: true` → 422 o queda como story igual.

**Causa**: Storyblok no permite flip `is_folder: false → true` en una story con content.

**Fix**: renombrar el slug del orphan para liberar el path, después crear folder fresh.

```js
if (orphan && !orphan.is_folder) {
  const newSlug = `${courseSlug}-orphan-w7`;
  await mapi({
    method: "PUT",
    path: `stories/${orphan.id}`,
    body: { story: { slug: newSlug, name: `[orphan] ${orphan.name}` } },
  });
}
await mapi({
  method: "POST",
  path: "stories",
  body: { story: { name, slug: courseSlug, is_folder: true, parent_id, content: {} } },
});
```

Después del éxito, borrar manualmente el orphan desde Storyblok UI.

## Gotcha 4 · parent_id OBLIGATORIO al crear

**Síntoma**: push de N stories con `full_slug: "aprende/curso/<x>"` los crea TODOS al ROOT (`parent_id: null`). full_slug es ignorado.

**Causa**: Storyblok deriva full_slug del `parent_id` tree + `slug`, no al revés.

**Fix**: orquestar el push en orden topológico:
1. Resolver `aprende` folder root (asumido existe).
2. Crear/PUT `aprende/curso` folder con `parent_id: <aprende.id>`.
3. Por cada curso: crear/PUT folder `aprende/curso/<slug>` con `parent_id: <curso.id>`.
4. Por cada curso: crear/PUT folder `aprende/curso/<slug>/modulo` con `parent_id: <course.id>`.
5. Por cada módulo: crear/PUT story con `parent_id: <modulo.id>` + `slug: <module_id>`.

## Gotcha 5 · CDN no resuelve nested multilinks en bloks

**Síntoma**: course story tiene `modules: [course_module_ref]` con `story.id: <real-id>`. CDN devuelve refs con `cached_url` pero sin `story` populado.

**Causa**: `resolve_links=story` resuelve refs top-level, no nested dentro de bloks de un blok root.

**Fix opciones**:
- **A · fetch separado por curso**: cliente hace `cdn/stories?starts_with=aprende/curso/<slug>/modulo/&version=published` y matchea por `cached_url`.
- **B · denormalizar al push**: script extrae módulos al push, los inlinea como content. Pierde edición independiente.
- **C · resolve_relations con custom resolver**: `?resolve_relations=course_module_ref.story`. Funciona si el blok es flat.

aprendeatumodo eligió A. Ver "Implementation · option A" abajo para el hook drop-in.

## Implementation · option A · `useCourseStory` hook

Drop-in hook que envuelve `useStoryblok` + segundo fetch para hidratar refs nested. Funciona para cualquier root story que tenga refs en bloks. Reusable cambiando el `prefix` y los types.

```ts
// src/CMS/useCourseStory.ts
import { useEffect, useState } from "react";
import { getStoryblokClient } from "./client";
import { useStoryblok } from "./useStoryblok";
import type { CourseStory, CourseModulePageBlok, StoryblokVersion } from "./types";

export function useCourseStory(courseSlug: string) {
  const { story: rootStory, loading: rootLoading, error: rootError } =
    useStoryblok<CourseStory>(courseSlug);

  const [hydrated, setHydrated] = useState<CourseStory | null>(null);
  const [hydrating, setHydrating] = useState(false);
  const [hydrateError, setHydrateError] = useState<Error | null>(null);

  useEffect(() => {
    if (!rootStory) { setHydrated(null); return; }

    const modules = rootStory.content.modules ?? [];
    const hasUnresolvedRefs = modules.some(
      (m) => m.component === "course_module_ref" && !m.story?.story?.content,
    );
    if (!hasUnresolvedRefs) { setHydrated(rootStory); return; }

    const client = getStoryblokClient();
    if (!client) { setHydrated(rootStory); return; }

    let cancelled = false;
    setHydrating(true);
    const version = (import.meta.env.VITE_STORYBLOK_VERSION ?? "published") as StoryblokVersion;
    const prefix = `${courseSlug}/modulo/`;

    client.get(`cdn/stories`, { version, starts_with: prefix, per_page: 50 })
      .then(({ data }) => {
        if (cancelled) return;
        const byFullSlug = new Map(
          (data?.stories ?? []).map((s: { full_slug: string }) => [s.full_slug, s]),
        );
        const patched: CourseStory = {
          ...rootStory,
          content: {
            ...rootStory.content,
            modules: modules.map((m) => {
              if (m.component !== "course_module_ref") return m;
              const cached = m.story?.cached_url || m.story?.full_slug;
              const target = cached ? byFullSlug.get(cached) : null;
              if (!target) return m;
              return {
                ...m,
                story: {
                  ...(m.story ?? {}),
                  story: {
                    name: target.name,
                    slug: target.slug,
                    full_slug: target.full_slug,
                    content: target.content as CourseModulePageBlok,
                  },
                },
              };
            }),
          },
        };
        setHydrated(patched);
      })
      .catch((e: Error) => { if (!cancelled) { setHydrateError(e); setHydrated(rootStory); } })
      .finally(() => { if (!cancelled) setHydrating(false); });

    return () => { cancelled = true; };
  }, [rootStory, courseSlug]);

  return { story: hydrated, loading: rootLoading || hydrating, error: rootError ?? hydrateError };
}
```

### Defensive en el page

Si la hidratación falla (network, refs no encontrados), el adapter retorna `modules: []`. Page debe **fallthrough al fallback legacy** en vez de renderear página vacía:

```tsx
const resolved = useMemo(() => {
  if (!course) return null;
  if (story) {
    const adapted = adaptStoryToCourseShape(story);
    if (adapted.modules.length > 0) {
      return { source: "storyblok" as const, ...adapted };
    }
    // fallthrough · evita "carga y desaparece"
  }
  return { source: "code" as const, ...legacyShape };
}, [course, story]);
```

### Caso canónico · aprendeatumodo PR #20

Implementación en `aprendeatumodo/src/CMS/useCourseStory.ts` + page wiring en `src/pages/CoursePage.tsx`. Commit `4ea9643` resuelve el bug "carga y desaparece" causado por refs unresolved en W7.

## Helpers reusables

### `findStoryByFullSlug(fullSlug)`

```js
async function findStoryByFullSlug(fullSlug) {
  const r = await mapiGet(`stories?with_slug=${encodeURIComponent(fullSlug)}`);
  return (r?.stories ?? []).find((s) => s.full_slug === fullSlug) ?? null;
}
```

### `findOrphanByLeafSlug(leafSlug)`

```js
async function findOrphanByLeafSlug(leafSlug) {
  const r = await mapiGet(`stories?with_slug=${encodeURIComponent(leafSlug)}`);
  return (r?.stories ?? []).find((s) => !s.parent_id && s.full_slug === leafSlug) ?? null;
}
```

### `ensureFolder({ fullSlug, name, parentId })`

Idempotente · GET → PUT update or POST create.

```js
async function ensureFolder({ fullSlug, name, parentId }) {
  const existing = await findStoryByFullSlug(fullSlug);
  const slug = fullSlug.split("/").pop();
  if (existing?.is_folder) {
    if (existing.name === name && existing.parent_id === parentId) return existing.id;
    await mapi({ method: "PUT", path: `stories/${existing.id}`, body: { story: { name, slug, is_folder: true, parent_id: parentId } } });
    return existing.id;
  }
  const r = await mapi({ method: "POST", path: "stories", body: { story: { name, slug, is_folder: true, parent_id: parentId, content: {} } } });
  return r.story.id;
}
```

### `buildChildIdMap(parentFullSlug)`

```js
async function buildChildIdMap(parentFullSlug) {
  const prefix = `${parentFullSlug}/`;
  const r = await mapiGet(`stories?starts_with=${encodeURIComponent(prefix)}&per_page=50`);
  const map = {};
  for (const s of (r?.stories ?? [])) {
    if (s.full_slug?.startsWith(prefix)) {
      map[s.full_slug] = { id: s.id, uuid: s.uuid };
    }
  }
  return map;
}
```

## Caso canónico · aprendeatumodo W7

Scripts en orden:

1. `push-w7-organized.mjs` · crea folder tree completo + módulos como stories con parent_id correcto.
2. `push-course-startpages.mjs` · per course folder: crea child story `home` con `is_startpage: true` populando refs con IDs reales.

Resultado: 42 stories organizadas (1 root `aprende` · 1 `curso` · 7 course folders · 7 `modulo` subfolders · 30 module stories · 7 course startpage children).

## Anti-patterns

- **Asumir que `full_slug` en POST manda el parent_id** · no manda. parent_id explícito siempre.
- **Search por `slug` después de crear startpage** · Storyblok renombra. Search por `is_startpage` flag.
- **PUT `is_folder: true` sobre story existente** · no flippea. Rename + recrear.
- **CDN call con `resolve_links` esperando refs nested resueltas** · no resuelve. Fetch separado o denormalizar.
- **Borrar orphans via script** · manual en UI siempre.
