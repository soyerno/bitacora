# Visual Editor wiring (Next Pages Router)

Cómo activar el **Visual Editor nativo de Storyblok** (WYSIWYG, drag-drop de
bloks, edición inline de texto, drafts, versiones, share links) en un front MODO.
**No se construye editor propio** — todo eso ya es nativo del producto; solo se
*wirea*. Caso canónico: modo-landing 2026-06-01 (`feat/storyblok-visual-editor`).

## Las 3 piezas que faltan en una integración read-only típica

Una integración que solo hace `StoryblokClient.get(..., {version:'published'})`
y renderiza bloks NO tiene editor. Faltan exactamente 3 cosas:

### 1. Atributos `data-blok-*` por blok (`storyblokEditable`)

Sin esto los bloks NO son clickeables en el canvas: no hay outline, ni
click-to-edit, ni edición inline de texto, ni drag-drop visual. Reimplementación
local de 6 líneas para **no sumar `@storyblok/react` al lockfile**:

```ts
// src/CMS/utils/cmsEditable.ts
import { IDefaultFields } from '../types';

export interface SbEditableAttrs {
  'data-blok-c'?: string;
  'data-blok-uid'?: string;
}

export function cmsEditable(
  blok?: Partial<Pick<IDefaultFields, '_editable' | '_uid'>>
): SbEditableAttrs {
  if (!blok?._editable) return {}; // published → sin _editable → cero markup en prod
  try {
    const json = blok._editable.replace(/^<!--#storyblok#/, '').replace(/-->$/, '');
    const options = JSON.parse(json) as { id: string; uid: string };
    if (!options?.id || !options?.uid) return {};
    return {
      'data-blok-c': JSON.stringify(options),
      'data-blok-uid': `${options.id}-${options.uid}`,
    };
  } catch {
    return {};
  }
}
```

Inyectar en el **wrapper que ya envuelve cada blok** del `body` (cero layout nuevo):

```jsx
{body?.map((element) => (
  <div key={element._uid} {...cmsEditable(element)}>
    <DynamicCMSComponent element={element} />
  </div>
))}
```

`_editable` solo viene en fetch `draft` → en prod `cmsEditable` devuelve `{}` →
cero cambio de markup. Clave: el componente debe recibir el blok COMPLETO (con
`_editable`/`_uid`), no solo sus campos.

**Nota de cobertura**: esto cubre bloks de **nivel raíz**. Bloks anidados (items
de grid/carousel) que las secciones renderizan directo desde `data.content` sin
pasar por el registry necesitan su propio spread → follow-up Wave 2.

### 2. Draft seguro en cualquier ambiente vía firma `_storyblok_tk`

Gatear el draft a `isLowEnv()` deja el editor inutilizable en preprod/prod.
La forma segura: validar el HMAC que el editor agrega al iframe. Solo una sesión
autenticada (que conoce el **Preview token** del space) puede firmar la query →
no se filtran borradores en URLs públicas.

```ts
// src/CMS/utils/validatePreview.ts
import crypto from 'crypto';

export function isValidStoryblokPreview(query?: Record<string, unknown>): boolean {
  const tk = query?.['_storyblok_tk'] as
    | { space_id?: string; timestamp?: string; token?: string }
    | undefined;
  const previewToken = process.env.STORYBLOK_PREVIEW_TOKEN; // ≠ API key pública
  if (!tk || !previewToken) return false;
  const { space_id: spaceId, timestamp, token } = tk;
  if (!spaceId || !timestamp || !token) return false;

  const expected = crypto
    .createHash('sha1')
    .update(`${spaceId}:${previewToken}:${timestamp}`)
    .digest('hex');
  if (expected !== token) return false;

  const now = Math.floor(Date.now() / 1000);
  return Number(timestamp) >= now - 3600; // ventana 1h (anti-replay)
}
```

```js
// getServerSideProps
const editorMode = isValidStoryblokPreview(query);
const preview = editorMode || (isLowEnv() && query.preview === 'true');
if (preview) { sbParams.version = 'draft'; sbParams.cv = Date.now(); }
if (!preview) setCmsCacheHeaders(res); // nunca cachear draft
```

### 3. Edición en vivo (`input` → setState, no reload)

El bridge ya se cargaba pero hacía `window.location.reload()` en cada tecla
(flashy). WYSIWYG real = actualizar el estado en el lugar. El bridge entrega la
story con relaciones resueltas si se las pasás en el constructor.

```js
const bridge = new StoryblokBridge({ resolveRelations: storyblokResolveRelations });
bridge.on('input', (payload) => { if (payload?.story) setStory(payload.story); });
bridge.on(['change', 'published'], () => window.location.reload()); // SSR fresco
```

Hook que devuelve la story viva:
```js
export function useStoryblok(preview, initialStory = false) {
  const [story, setStory] = useState(initialStory);
  useEffect(() => setStory(initialStory), [initialStory]);
  useEffect(() => { if (preview) addBridge(initEventListeners); }, [preview]);
  return story;
}
```

## Config externa (no es código)

1. `STORYBLOK_PREVIEW_TOKEN` (Settings → Access Tokens, tipo **Preview**) como secret SOPS por ambiente.
2. Space → Settings → Visual Editor → Location = URL de preview por env.
3. Drafts / versiones / historial / share = **nativo del producto**, no se construye nada.

## Por qué NO un editor custom

Construir un editor in-app (dnd-kit, contentEditable, persistir vía Management
API) reinventa el Visual Editor: superficie de bugs enorme, mantenimiento pesado.
Solo justifica si los editores no pueden tener seat de Storyblok. Default = wire
del nativo. Decisión load-bearing → preguntar al user antes de codear.
