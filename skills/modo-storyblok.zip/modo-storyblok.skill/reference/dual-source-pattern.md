# Dual-source pattern · Storyblok + fallback al código

Durante migración hardcoded → CMS, mantener ambos paths funcionando. Permite migrar item por item sin romper el resto. Drop del fallback se hace en PR final post-verificación.

## Hook `useStoryblok` con generic

```ts
// src/CMS/useStoryblok.ts
export type AnyStory = LandingStory | CourseStory; // o el union que aplique

interface UseStoryblokResult<T extends AnyStory = LandingStory> {
  story: T | null;
  loading: boolean;
  error: Error | null;
}

export function useStoryblok<T extends AnyStory = LandingStory>(slug: string): UseStoryblokResult<T> {
  const [story, setStory] = useState<T | null>(null);
  // ... fetch + bridge

  useEffect(() => {
    const client = getStoryblokClient();
    if (!client) { setLoading(false); return; }  // No token → fallback al código
    client.get(`cdn/stories/${slug}`, { version: "published" })
      .then(({ data }) => setStory(data.story as T))
      .catch((e) => setError(e))
      .finally(() => setLoading(false));
  }, [slug]);

  // Visual editor bridge auto-load cuando URL tiene ?_storyblok=*
  useEffect(() => {
    if (!window.location.search.includes("_storyblok")) return;
    const script = document.createElement("script");
    script.src = "//app.storyblok.com/f/storyblok-v2-latest.js";
    document.head.appendChild(script);
    script.onload = () => {
      new window.StoryblokBridge().on(["input", "published", "change"], (event) => {
        if (event.story?.full_slug === slug) setStory(event.story as T);
      });
    };
  }, [slug]);

  return { story, loading, error };
}
```

## Adapter (boundary)

NO modifica componentes downstream. Convierte `Story → Shape` que ya consumen.

```tsx
// src/CMS/storyToCourse.tsx
import { CourseBodyRenderer } from "./CourseBodyRenderer";
import { resolveIcon } from "./iconMap";

export interface AdaptedCourseShape {
  title: string;
  description: string;
  teaches: string;
  readingMinutes: number;
  seoTitle: string | null;
  seoDescription: string | null;
  ogImageUrl: string | null;
  intro: ReactNode;
  outro: ReactNode;
  modules: CourseModule[];  // ← shape EXISTENTE consumido por Carousel
}

export function adaptStoryToCourseShape(story: CourseStory): AdaptedCourseShape {
  const c = story.content;
  return {
    title: c.title,
    description: c.description,
    teaches: c.teaches,
    readingMinutes: c.reading_minutes,
    seoTitle: c.seo_title?.trim() || null,
    seoDescription: c.seo_description?.trim() || null,
    ogImageUrl: c.og_image?.filename || null,
    intro: c.intro?.length ? <CourseBodyRenderer bloks={c.intro} /> : null,
    outro: c.outro?.length ? <CourseBodyRenderer bloks={c.outro} /> : null,
    modules: c.modules.map(adaptModule),
  };
}

function adaptModule(blok: CourseModuleBlok): CourseModule {
  return {
    id: blok.module_id,
    number: blok.number,
    title: blok.title,
    subtitle: blok.subtitle?.trim() || undefined,
    icon: resolveIcon(blok.icon_name) ?? undefined,
    minutes: blok.minutes,
    content: <CourseBodyRenderer bloks={blok.body} />,
  };
}
```

## Page wiring

```tsx
// src/pages/CoursePage.tsx
const { story } = useStoryblok<CourseStory>(`aprende/curso/${slug}`);

const resolved = useMemo(() => {
  if (!course) return null;
  if (story) {
    const a = adaptStoryToCourseShape(story);
    return { source: "storyblok" as const, ...a };
  }
  return {
    source: "code" as const,
    title: course.title,
    description: course.description,
    teaches: course.teaches,
    readingMinutes: course.readingMinutes,
    seoTitle: `${course.title} — Aprendé con MODO`,
    seoDescription: course.description,
    ogImageUrl: null,
    modules: course.Content.modules,
    intro: course.Content.intro,
    outro: course.Content.outro,
  };
}, [course, story]);

if (!course || !resolved) return <Navigate to="/404" replace />;

// Downstream consume `resolved` indistintamente:
return (
  <>
    <Helmet>
      <title>{resolved.seoTitle}</title>
      <meta name="description" content={resolved.seoDescription} />
      {resolved.ogImageUrl && <meta property="og:image" content={resolved.ogImageUrl} />}
    </Helmet>
    <div data-source={resolved.source}>  {/* debug + tests */}
      <CourseModuleCarousel
        modules={resolved.modules}
        intro={resolved.intro}
        outro={resolved.outro}
        courseTitle={resolved.title}
        ...
      />
    </div>
  </>
);
```

## Tests · ambos paths

Path code (sin token):

```tsx
// src/pages/CoursePage.test.tsx
it("renders from code when no Storyblok story", () => {
  renderAt("/curso/seguridad");
  const region = screen.getByRole("region", { name: /encabezado/i });
  expect(region).toHaveAttribute("data-source", "code");
});
```

Path Storyblok (mock):

```tsx
// src/pages/CoursePage.storyblok.test.tsx
vi.mock("@/CMS", async () => {
  const actual = await vi.importActual("@/CMS");
  return {
    ...actual,
    useStoryblok: vi.fn(() => ({ story: STORY_MOCK, loading: false, error: null })),
  };
});

const { default: CoursePage } = await import("./CoursePage");

it("renders title from Storyblok story", () => {
  renderAt("/curso/seguridad");
  expect(screen.getByRole("heading", { name: /storyblok title/i })).toBeInTheDocument();
});

it("uses Storyblok reading_minutes (overrides code)", () => {
  renderAt("/curso/seguridad");
  expect(screen.getByText(/~9 min total/i)).toBeInTheDocument();
});
```

## Drop fallback post-migración (D6 pattern)

Cuando todas las stories están live y editorial confirma:

1. Borrar archivos legacy (`*CourseContent.tsx` × N)
2. Quitar prop `Content` de `CourseDefinition` type
3. Simplificar `resolved` en page: si no hay story → mostrar error/loading (no fallback)
4. Tests del path code → migrar a tests del loading state
5. Bundle reduction registrado (caso aprendeatumodo: -1655 LOC)

## Convenciones

- `source: "storyblok" | "code"` literal types para narrowing
- `data-source` attribute en page para debug + tests
- Adapter NUNCA modifica el story original (immutable in)
- Adapter retorna shape PURO downstream consume sin saber que vino de SB
- Empty fields normalizados (`"".trim() || null`, `undefined`, etc.)

## Anti-patterns

- **Tipear `Legacy | Blok` unions downstream** · multiplica complejidad. Adapter en boundary mantiene shape única.
- **Hooks condicionales** · `if (story) useFoo()` rompe React rules. Adapter en `useMemo` ok.
- **Fallback al código en prod cuando hay token** · si el editor publicó algo malo, el fallback oculta el bug. Mejor surfaceear error.
- **Sin `data-source` attribute** · pierdes debug visibility cuando algo va mal en prod.
