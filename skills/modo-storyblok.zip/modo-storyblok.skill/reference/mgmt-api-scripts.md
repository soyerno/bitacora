# Management API push scripts

Scripts node sin deps externas para sincronizar contenido versionado en git (`storyblok/components/*.json` + `storyblok/stories/*.json`) contra Storyblok space prod.

## Env vars

`.env.local` (en root del proyecto · gitignored):

```
STORYBLOK_MANAGEMENT_TOKEN=<oauth token con scope spaces:write>
STORYBLOK_SPACE_ID=244835
STORYBLOK_REGION=eu
```

Scripts auto-cargan `.env.local` si existe. Si vars ya están en env, ganan las del shell.

## Helper `_mapi.mjs`

Cliente Mgmt API lite. Sólo `fetch` (Node ≥18). Sin deps externas.

```js
// storyblok/scripts/_mapi.mjs
import { setTimeout as sleep } from "node:timers/promises";

const REGION_HOST = {
  eu: "api.storyblok.com",
  us: "api-us.storyblok.com",
  ap: "api-ap.storyblok.com",
  ca: "api-ca.storyblok.com",
  cn: "app.storyblokchina.cn",
};

export function getEnv() {
  const token = process.env.STORYBLOK_MANAGEMENT_TOKEN;
  const spaceId = process.env.STORYBLOK_SPACE_ID;
  const region = (process.env.STORYBLOK_REGION ?? "eu").toLowerCase();
  if (!token) throw new Error("Missing STORYBLOK_MANAGEMENT_TOKEN");
  if (!spaceId) throw new Error("Missing STORYBLOK_SPACE_ID");
  if (!REGION_HOST[region]) throw new Error(`Unknown region ${region}`);
  return { token, spaceId, region, host: REGION_HOST[region] };
}

export async function mapi({ method, path, body, dryRun, label }) {
  if (dryRun) {
    // En dry-run NO validamos env (objetivo: testear shape sin creds)
    console.log(`[dry-run] ${method} <region-host>/v1/spaces/<space-id>/${path}${label ? ` · ${label}` : ""}`);
    if (body) console.log(`[dry-run]   body: ${JSON.stringify(body).slice(0, 200)}…`);
    return { dryRun: true };
  }

  const { token, spaceId, host } = getEnv();
  const url = `https://${host}/v1/spaces/${spaceId}/${path}`;

  let lastErr = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const res = await fetch(url, {
      method,
      headers: { Authorization: token, "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (res.ok) {
      const text = await res.text();
      return text ? JSON.parse(text) : null;
    }

    // 422/401/403 = surface inmediato (no retry)
    if (res.status === 422 || res.status === 401 || res.status === 403) {
      throw new Error(`${method} ${path} → ${res.status}: ${await res.text()}`);
    }

    // 429 + 5xx → backoff retry
    lastErr = new Error(`${method} ${path} → ${res.status} ${res.statusText}`);
    if (attempt < 3) {
      const wait = 1000 * 2 ** (attempt - 1);
      console.warn(`  retry ${attempt}/3 in ${wait}ms (${lastErr.message})`);
      await sleep(wait);
    }
  }
  throw lastErr;
}

export async function mapiGet(path, { dryRun } = {}) {
  if (dryRun) return null;
  try {
    return await mapi({ method: "GET", path });
  } catch (e) {
    if (e.message.includes("→ 404")) return null;
    throw e;
  }
}
```

**Features**:
- Region routing (EU/US/AP/CA/CN)
- Retry exponencial 429/5xx (3 intentos, 1s/2s/4s)
- 422/401/403 surface inmediato (validation/auth)
- Dry-run no requiere env

## `push-components.mjs`

Sincroniza schemas. Idempotente: GET para detectar existentes → POST (create) o PUT (update).

```js
// storyblok/scripts/push-components.mjs
import { readFile, readdir } from "node:fs/promises";
import { mapi, mapiGet } from "./_mapi.mjs";

async function main() {
  await loadEnvLocal();
  const { apply, only, verbose } = parseArgs();
  const dryRun = !apply;

  const files = (await readdir(componentsDir)).filter(f => f.endsWith(".json")).sort();
  const components = await Promise.all(files.map(async f => JSON.parse(await readFile(join(componentsDir, f), "utf-8"))));
  const filtered = only ? components.filter(c => only.includes(c.name)) : components;

  // Index existing for diff
  const existing = dryRun ? { components: [] } : await mapiGet("components");
  const byName = new Map((existing?.components ?? []).map(c => [c.name, c]));

  for (const c of filtered) {
    const existingC = byName.get(c.name);
    if (existingC) {
      console.log(`  ↑ update ${c.name} (id=${existingC.id})`);
      await mapi({ method: "PUT", path: `components/${existingC.id}`, body: { component: { ...c, id: existingC.id } }, dryRun });
    } else {
      console.log(`  + create ${c.name}`);
      await mapi({ method: "POST", path: `components`, body: { component: c }, dryRun });
    }
  }
}
```

**Uso**:
```bash
node storyblok/scripts/push-components.mjs                           # dry-run all
node storyblok/scripts/push-components.mjs --apply                   # write all
node storyblok/scripts/push-components.mjs --apply --only course,course_module
node storyblok/scripts/push-components.mjs --apply --verbose
```

## `push-stories.mjs`

Sincroniza stories. Idempotente via `GET /stories?with_slug=<full_slug>`.

```js
// storyblok/scripts/push-stories.mjs
async function findExistingStoryId(fullSlug, dryRun) {
  if (dryRun) return null;
  const data = await mapiGet(`stories?with_slug=${encodeURIComponent(fullSlug)}`);
  return (data?.stories ?? []).find(s => s.full_slug === fullSlug)?.id ?? null;
}

async function main() {
  const { apply, publish, only } = parseArgs();
  const dryRun = !apply;
  // ... load stories from storyblok/stories/*.json

  for (const s of filtered) {
    const id = await findExistingStoryId(s.full_slug, dryRun);
    const { _filename, published_at, publish_at, ...rest } = s;
    const payload = {
      story: { ...rest, slug: s.slug || s.full_slug.split("/").pop() },
      ...(publish ? { publish: 1 } : {}),
    };

    if (id) await mapi({ method: "PUT", path: `stories/${id}`, body: payload, dryRun });
    else await mapi({ method: "POST", path: `stories`, body: payload, dryRun });
  }
}
```

**Uso**:
```bash
node storyblok/scripts/push-stories.mjs                                          # dry-run
node storyblok/scripts/push-stories.mjs --apply                                  # draft only
node storyblok/scripts/push-stories.mjs --apply --publish                        # write + publish
node storyblok/scripts/push-stories.mjs --apply --publish --only aprende/curso/seguridad
```

## Orden canónico (first run)

```bash
# 1. Schemas primero (sino stories fallan con 422 "component not found")
node storyblok/scripts/push-components.mjs --apply

# 2. Stories en draft
node storyblok/scripts/push-stories.mjs --apply

# 3. Publish cuando editorial valida
node storyblok/scripts/push-stories.mjs --apply --publish
```

## Errors comunes

| Status | Causa | Fix |
|---|---|---|
| 422 schema not valid | Field type inválido o required missing | Revisar JSON contra Storyblok docs |
| 422 component not found | Story usa blok que no existe en space | Correr push-components.mjs primero |
| 401/403 | Token sin scope o expirado | Regenerar en app.storyblok.com/me/account?tab=token |
| 429 rate limit | Burst de requests | Cliente reintenta con backoff (transparente) |
| 404 with_slug | First run normal | Script crea via POST |

## Anti-patterns

- **Default `--apply`** · destructive. Default debe ser dry-run.
- **No diff antes de PUT** · push-components hace GET para detectar existentes; sin diff podríamos sobreescribir cambios manuales del editor.
- **Borrar via script** · NO implementar delete por seguridad. Si hay que dropear component/story, hacer manual en UI con confirmación.
- **Hardcoded token en repo** · `.env.local` gitignored. Verificar `.gitignore` antes del primer commit.
- **Sin dry-run smoke** · siempre correr dry-run + revisar payload antes del primer `--apply`.

## Future · export script

Pendiente · script que pull de Storyblok y sincroniza JSON local. Permite editor edita en UI → export → PR con diff. Hasta entonces el flow es:
1. Editor edita en UI
2. Editor exporta JSON manual desde Storyblok UI
3. PR con el JSON actualizado
