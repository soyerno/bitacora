# Testing pattern · Storyblok stories + renderer

3 capas de tests:

1. **Unit · iconMap + richtextRenderer** · helpers
2. **Unit · CourseBodyRenderer** · cada blok type
3. **Smoke · piloto fixtures** · cada story JSON contra adapter+renderer (parametrizado con `describe.each`)

## 1. iconMap tests

```ts
// src/CMS/iconMap.test.ts
describe("resolveIcon", () => {
  it("returns null when name is empty", () => {
    expect(resolveIcon("")).toBeNull();
    expect(resolveIcon(undefined)).toBeNull();
    expect(resolveIcon(null)).toBeNull();
  });

  it("returns the icon when name is in whitelist", () => {
    expect(resolveIcon("Shield")).toBe(ICON_MAP.Shield);
  });

  describe("unknown name", () => {
    let warnSpy;
    beforeEach(() => { warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {}); });
    afterEach(() => { warnSpy.mockRestore(); });

    it("returns FALLBACK_ICON + warns in dev", () => {
      expect(resolveIcon("NoExiste")).toBe(FALLBACK_ICON);
      expect(warnSpy).toHaveBeenCalled();
    });
  });
});
```

## 2. richtextRenderer tests

```tsx
const para = (text, marks = []) => ({
  type: "doc",
  content: [{ type: "paragraph", content: [{ type: "text", text, marks: marks.length ? marks : undefined }] }],
});

describe("RichTextRenderer", () => {
  it("renders fallback when doc is null", () => {
    render(<RichTextRenderer doc={null} fallback={<span>nada</span>} />);
    expect(screen.getByText("nada")).toBeInTheDocument();
  });

  it("renders bullet_list and ordered_list", () => {
    const doc = { type: "doc", content: [
      { type: "bullet_list", content: [{ type: "list_item", content: [{ type: "paragraph", content: [{ type: "text", text: "Uno" }] }] }] },
      { type: "ordered_list", content: [{ type: "list_item", content: [{ type: "paragraph", content: [{ type: "text", text: "Dos" }] }] }] },
    ] };
    const { container } = render(<RichTextRenderer doc={doc} />);
    expect(container.querySelector("ul")).toBeInTheDocument();
    expect(container.querySelector("ol")).toBeInTheDocument();
  });

  it("applies multiple marks (bold + italic)", () => {
    const doc = para("fuerte", [{ type: "bold" }, { type: "italic" }]);
    const { container } = render(<RichTextRenderer doc={doc} />);
    expect(container.querySelector("strong")).not.toBeNull();
    expect(container.querySelector("em")).not.toBeNull();
  });

  it("handles unknown node type gracefully", () => {
    const doc = { type: "doc", content: [{ type: "unknown_block", content: [{ type: "text", text: "salvable" }] }] };
    const { container } = render(<RichTextRenderer doc={doc} />);
    expect(container.textContent).toContain("salvable");
  });
});
```

## 3. CourseBodyRenderer tests · 1 test por blok type + 1 tree completo

```tsx
describe("CourseBodyRenderer", () => {
  describe("module_callout", () => {
    it("renders title when provided + aria-label matches", () => {
      const blok = { _uid: "c1", component: "module_callout", tone: "info", title: "¿Sabías que…?", emoji: "💡", body: para("Las denuncias crecen.") };
      render(<CourseBodyRenderer bloks={[blok]} />);
      const note = screen.getByRole("note");
      expect(note).toHaveTextContent("¿Sabías que…?");
      expect(note).toHaveAttribute("aria-label", "¿Sabías que…?");
    });
  });

  describe("module_sub_heading", () => {
    it("applies danger tone class by default", () => {
      const blok = { _uid: "sh", component: "module_sub_heading", text: "QRishing", icon_name: "QrCode" };
      const { container } = render(<CourseBodyRenderer bloks={[blok]} />);
      const svg = container.querySelector("h3 svg");
      expect(svg?.getAttribute("class")).toContain("text-destructive");
    });
  });

  describe("full tree", () => {
    it("renders a realistic module body end-to-end", () => {
      const bloks = [
        { _uid: "head", component: "module_sub_heading", text: "Por qué importa" },
        { _uid: "intro", component: "module_prose", body: para("La seguridad digital es cosa de todos.") },
        { _uid: "callout", component: "module_callout", tone: "info", emoji: "💡", body: para("La mejor herramienta sos vos.") },
        { _uid: "tiles", component: "module_tile_stack", columns: "2", items: [/* 2 tiles */] },
        { _uid: "step", component: "module_step", number: 1, title: "Verificá", body: para("Antes de actuar.") },
      ];
      render(<CourseBodyRenderer bloks={bloks} />);
      expect(screen.getByRole("heading", { level: 3, name: "Por qué importa" })).toBeInTheDocument();
      expect(screen.getByRole("note")).toHaveTextContent("La mejor herramienta sos vos.");
    });
  });

  describe("unknown component", () => {
    let warnSpy;
    beforeEach(() => { warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {}); });
    afterEach(() => { warnSpy.mockRestore(); });

    it("skips unknown blok without crashing", () => {
      const blok = { _uid: "u", component: "module_nonexistent" };
      const result = render(<CourseBodyRenderer bloks={[blok]} />);
      expect(result.container).toBeInTheDocument();
    });
  });
});
```

## 4. Piloto fixture · adapter end-to-end

```tsx
// src/CMS/__fixtures__/aprende-curso-seguridad.ts
import storyJson from "../../../storyblok/stories/aprende-curso-seguridad.json";
import type { CourseStory } from "../types";
export const seguridadFixture = storyJson as unknown as CourseStory;
```

```tsx
// src/CMS/piloto-seguridad.test.tsx
describe("piloto seguridad · story shape", () => {
  it("matches canonical course_id + slug", () => {
    const s = adaptStorySnapshot(seguridadFixture);
    expect(s.title).toBe("Seguridad y Prevención de Fraude");
    expect(s.modulesCount).toBe(4);
    expect(s.moduleIds).toEqual(["por-que-importa", "medios-de-pago", "estafas-comunes", "como-protegerte"]);
  });

  it("intro renders welcoming Callout", () => {
    const adapted = adaptStoryToCourseShape(seguridadFixture);
    const { container } = render(<>{adapted.intro}</>);
    expect(container.textContent).toContain("reconocer las estafas más comunes");
  });
});

describe("piloto seguridad · module bodies render", () => {
  it("module 1 renders prose + callout '¿Sabías que…?'", () => {
    const adapted = adaptStoryToCourseShape(seguridadFixture);
    const { container } = render(<>{adapted.modules[0].content}</>);
    expect(container.textContent).toContain("Cada vez usamos más el celu");
    expect(container.textContent).toContain("¿Sabías que…?");
  });
});
```

## 5. Parametrizado con `describe.each` · N cursos

Cuando hay N stories, usar `describe.each` para no repetir test setup:

```tsx
// src/CMS/all-cursos.test.tsx
import { ALL_W6_FIXTURES } from "./__fixtures__/all-cursos";

describe.each(ALL_W6_FIXTURES)("piloto · $name", ({ name, story }) => {
  it("matches a CourseDefinition by course_id", () => {
    const def = getCourseByCourseId(story.content.course_id);
    expect(def, `${name} course_id no matchea registry`).toBeDefined();
  });

  it("adapter resolves all modules with Icon + content", () => {
    const adapted = adaptStoryToCourseShape(story);
    for (const m of adapted.modules) {
      expect(m.icon).toBeDefined();
      expect(m.content).toBeDefined();
    }
  });

  it("first module body renders something visible", () => {
    const adapted = adaptStoryToCourseShape(story);
    const { container } = render(<>{adapted.modules[0].content}</>);
    expect(container.textContent?.length ?? 0).toBeGreaterThan(0);
  });
});

describe("registry coverage", () => {
  it("all 7 cursos del registry tienen un story", () => {
    const fixtureIds = new Set(ALL_W6_FIXTURES.map(f => f.story.content.course_id));
    for (const c of COURSES) {
      expect(fixtureIds.has(c.courseId)).toBe(true);
    }
  });
});
```

## 6. Page tests · 2 paths (code fallback + Storyblok mock)

Path code:

```tsx
// CoursePage.test.tsx
it("marks data-source='code' when no Storyblok story", () => {
  renderAt("/curso/seguridad");
  const region = screen.getByRole("region", { name: /encabezado/i });
  expect(region).toHaveAttribute("data-source", "code");
});
```

Path Storyblok (mock):

```tsx
// CoursePage.storyblok.test.tsx
vi.mock("@/CMS", async () => {
  const actual = await vi.importActual("@/CMS");
  return { ...actual, useStoryblok: vi.fn(() => ({ story: STORY_MOCK, loading: false, error: null })) };
});
const { default: CoursePage } = await import("./CoursePage");

it("renders title from Storyblok story", () => {
  renderAt("/curso/seguridad");
  expect(screen.getByRole("heading", { name: /storyblok title/i })).toBeInTheDocument();
});

it("data-source='storyblok' on the course header", () => {
  renderAt("/curso/seguridad");
  expect(screen.getByRole("region", { name: /encabezado/i })).toHaveAttribute("data-source", "storyblok");
});

it("seo_title override in <title>", async () => {
  renderAt("/curso/seguridad");
  await waitFor(() => expect(document.title).toBe("Custom SEO title"));
});

it("emits JSON-LD with Storyblok-derived reading_minutes", async () => {
  renderAt("/curso/seguridad");
  await waitFor(() => {
    const lds = document.head.querySelectorAll('script[type="application/ld+json"]');
    const payload = Array.from(lds).map(s => s.textContent).join("\n");
    expect(payload).toMatch(/PT9M/);  // reading_minutes 9 → ISO duration
  });
});
```

## Convenciones

- **Helpers locales** · `para(text, marks)` y `multiPara(...)` reducen boilerplate de richtext docs
- **`describe.each` para N items** · explícito + cada test name parametrizado
- **Mock `@/CMS`** con `vi.importActual` para mantener exports reales · override sólo `useStoryblok`
- **`{ container }` cuando no hay role/text query** · permite assert sobre estructura DOM
- **`waitFor` para Helmet** · react-helmet-async flushea con rAF
- **`role="note"` para Callout** · semántica correcta + queryable
- **Cobertura registry** · test que matchea cada CourseDefinition con su story (no missing)

## Anti-patterns

- **Snapshot tests del render completo** · brittle · cualquier change rompe. Test por blok type en cambio.
- **Sin mock de `console.warn`** · tests verdes ensucian la consola con falsos positivos.
- **Test path Storyblok sin `vi.importActual`** · pierde todos los exports del módulo (LandingStory type etc).
- **Sin smoke E2E del fixture** · permite drift entre JSON y types.
