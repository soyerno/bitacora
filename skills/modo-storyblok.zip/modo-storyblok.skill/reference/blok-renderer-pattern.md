# Blok renderer pattern · Storyblok → React MODO

3 archivos forman el renderer end-to-end:

1. `iconMap.ts` · whitelist Lucide
2. `richtextRenderer.tsx` · richtext SB → React
3. `<Feature>BodyRenderer.tsx` · switch sobre bloks

## 1. `iconMap.ts`

Whitelist explícita. Dynamic import de `lucide-react/dist/esm/icons/${name}` mete ~600KB. Whitelist mantiene bundle controlado y previene typos editoriales.

```ts
// src/CMS/iconMap.ts
import {
  AlertTriangle, ArrowLeftRight, BadgeCheck, BarChart3, BookOpen,
  Briefcase, CreditCard, FileText, HandCoins, Heart, HelpCircle,
  Info, Landmark, Lightbulb, Lock, MessageSquare, Percent, Phone,
  PiggyBank, QrCode, Receipt, Scale, Shield, ShieldAlert,
  ShieldCheck, Smartphone, Store, Target, TrendingUp, Users,
  Wallet, Wifi,
  type LucideIcon,
} from "lucide-react";

export const ICON_MAP = {
  AlertTriangle, ArrowLeftRight, BadgeCheck, BarChart3, BookOpen,
  Briefcase, CreditCard, FileText, HandCoins, Heart, HelpCircle,
  Info, Landmark, Lightbulb, Lock, MessageSquare, Percent, Phone,
  PiggyBank, QrCode, Receipt, Scale, Shield, ShieldAlert,
  ShieldCheck, Smartphone, Store, Target, TrendingUp, Users,
  Wallet, Wifi,
} as const;

export const FALLBACK_ICON: LucideIcon = HelpCircle;

export function resolveIcon(name: string | undefined | null): LucideIcon | null {
  if (!name) return null;
  if (name in ICON_MAP) return ICON_MAP[name as keyof typeof ICON_MAP];
  if (import.meta.env.DEV) {
    console.warn(`[iconMap] Unknown icon_name "${name}". Falling back to HelpCircle.`);
  }
  return FALLBACK_ICON;
}
```

**Reglas**:
- Alphabetical order
- Agregar icon = PR explícito (no se agrega dinámico)
- Empty/undefined → `null` (skip render)
- Unknown name → fallback + dev warn (nunca crash)

## 2. `richtextRenderer.tsx`

Hand-rolled. ~175 LOC, ~3KB. Mapea richtext SB → primitivas MODO branded. NO usar `@storyblok/richtext` (sumaba ~30KB y no permite custom marks fácil).

Supported nodes: `doc`, `paragraph`, `heading`, `bullet_list`, `ordered_list`, `list_item`, `blockquote`, `hard_break`, `text`.

Supported marks: `bold`, `italic`, `link`, `code`.

Unknown nodes/marks: render children + dev warn (graceful degradation).

### Trap · `<p>`-en-`<p>` DOM nesting

`Step` y `CheckItem` envuelven children en `<p>` o `<span>`. Si el richtext también emite `<p>` adentro, browser warning + DOM corrupto.

**Fix**: opción `unwrapParagraphs`. Cuando true, top-level paragraphs renderean como Fragment + `<br/>` entre paragraphs (no como `<p>`).

```tsx
interface RichTextRendererProps {
  doc: SbRichText | null | undefined;
  paragraphClassName?: string;
  unwrapParagraphs?: boolean;
  fallback?: ReactNode;
}

export const RichTextRenderer = ({ doc, paragraphClassName, unwrapParagraphs, fallback }) => {
  if (!doc?.content?.length) return <>{fallback}</>;
  // ... dispatch
};

// case "paragraph":
if (ctx.unwrapParagraphs) return <>{children}</>;
return <p className={cn("font-red-hat ...", ctx.paragraphClassName)}>{children}</p>;
```

### Mark canónico · link

```tsx
case "link": {
  const href = (mark.attrs?.href as string) ?? "#";
  const target = (mark.attrs?.target as string) ?? undefined;
  const rel = target === "_blank" ? "noopener noreferrer" : undefined;
  return <a href={href} target={target} rel={rel} className="text-primary-PaymentDefault underline ...">{content}</a>;
}
```

## 3. `<Feature>BodyRenderer.tsx`

Switch sobre `blok.component` → componente branded. 1:1 con componentes existentes para visual parity con legacy.

```tsx
// src/CMS/CourseBodyRenderer.tsx
import { Fragment } from "react";
import Callout from "@/components/courses/Callout";
import {
  CheckItem, ProseList, Step, SubHeading, Tile, TileStack,
} from "@/components/courses/moduleStyles";
import { resolveIcon } from "./iconMap";
import { RichTextRenderer } from "./richtextRenderer";

export const CourseBodyRenderer = ({ bloks }) => {
  if (!bloks?.length) return null;
  return (
    <div className="space-y-4">
      {bloks.map((blok, i) => (
        <Fragment key={blok._uid ?? `blok-${i}`}>{renderBlok(blok)}</Fragment>
      ))}
    </div>
  );
};

function renderBlok(blok: CourseModuleBodyBlok) {
  switch (blok.component) {
    case "module_prose":          return <ProseBlok blok={blok} />;
    case "module_callout":        return <CalloutBlok blok={blok} />;
    case "module_tile_stack":     return <TileStackBlok blok={blok} />;
    case "module_step":           return <StepBlok blok={blok} />;
    case "module_check_item":     return <CheckItemBlok blok={blok} />;
    case "module_prose_list":     return <ProseListBlok blok={blok} />;
    case "module_sub_heading":    return <SubHeadingBlok blok={blok} />;
    default:
      if (import.meta.env.DEV) console.warn(`[Renderer] Unknown ${blok.component}`);
      return null;
  }
}

// Per-blok renderers:

const ProseBlok = ({ blok }) => <RichTextRenderer doc={blok.body} />;

const CalloutBlok = ({ blok }) => (
  <Callout tone={blok.tone} title={blok.title || undefined} emoji={blok.emoji}>
    <RichTextRenderer doc={blok.body} />
  </Callout>
);

const TileStackBlok = ({ blok }) => {
  const cols = blok.columns === "3" ? "md:grid-cols-3" : "md:grid-cols-2";
  if (blok.columns === "1") {
    return <TileStack>{blok.items.map((t, i) => <TileBlok key={t._uid ?? i} blok={t} />)}</TileStack>;
  }
  return (
    <div className={`grid grid-cols-1 ${cols} gap-3`}>
      {blok.items.map((t, i) => <TileBlok key={t._uid ?? i} blok={t} />)}
    </div>
  );
};

const TileBlok = ({ blok }) => {
  if (blok.emoji) return <Tile title={blok.title} emoji={blok.emoji}><RichTextRenderer doc={blok.body} /></Tile>;
  const Icon = resolveIcon(blok.icon_name);
  return (
    <Tile title={Icon ? <span className="inline-flex items-center gap-2"><Icon className="h-5 w-5 text-primary-PaymentDark" aria-hidden="true" />{blok.title}</span> : blok.title}>
      <RichTextRenderer doc={blok.body} />
    </Tile>
  );
};

const StepBlok = ({ blok }) => (
  <Step index={blok.number} title={blok.title}>
    <RichTextRenderer doc={blok.body} unwrapParagraphs />
  </Step>
);

const CheckItemBlok = ({ blok }) => (
  <ProseList variant="check">
    <CheckItem><RichTextRenderer doc={blok.text} unwrapParagraphs /></CheckItem>
  </ProseList>
);

const SubHeadingBlok = ({ blok }) => {
  const Icon = resolveIcon(blok.icon_name);
  if (!Icon) return <SubHeading>{blok.text}</SubHeading>;
  const toneClass = { danger: "text-destructive", default: "text-primary-PaymentDark", muted: "text-tertiary-Gray80" }[blok.icon_tone ?? "danger"];
  return (
    <SubHeading>
      <span aria-hidden="true" className="mr-2 inline-flex items-center">
        <Icon className={`inline h-5 w-5 ${toneClass}`} />
      </span>
      {blok.text}
    </SubHeading>
  );
};

const ProseListBlok = ({ blok }) => {
  // Extraer items del richtext flat (1 paragraph = 1 item)
  const items = extractListItems(blok.items);
  const ListTag = blok.style === "numbered" ? "ol" : "ul";
  const listClass = "font-red-hat ... list-disc pl-6 marker:text-primary-PaymentDefault space-y-2";
  return <ListTag className={listClass}>{items.map((it, i) => <li key={i}>{it}</li>)}</ListTag>;
};
```

## Convenciones

- **Emoji wins over icon_name** · Si ambos están seteados, emoji renderea, icon_name se ignora (convención Callout legacy).
- **`_uid` as key cuando hay; index fallback** · evita warnings React + permite reorden estable.
- **Always `aria-hidden="true"` en iconos decorativos** · el texto adyacente carrega la semántica.
- **`unwrapParagraphs` en Step/CheckItem/ProseList items** · evita DOM nesting warnings.

## Anti-patterns

- **Mapear blok → JSX inline en page** · explota el componente · usar dispatch en archivo dedicado.
- **`dangerouslySetInnerHTML` para richtext** · pierde tipos + XSS risk + no integra con primitivas branded.
- **No fallback para unknown blok** · crash en runtime cuando editor publica blok nuevo antes del code deploy.
- **Importar TODO Lucide** · bundle bloat. Whitelist.
