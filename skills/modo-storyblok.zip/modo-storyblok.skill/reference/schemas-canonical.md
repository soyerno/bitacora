# Schemas canónicos · Storyblok MODO

9 schemas que cubren ~80% de los content types MODO (cursos, articles, products con secciones, promos con descripción rica). Cada uno está en `storyblok/components/<name>.json` y se sube via `push-components.mjs --apply`.

## Convenciones

- `name` snake_case
- `display_name` con caps · prefijo `Module ·` o `Course ·` para agrupar visualmente en Storyblok UI
- `is_root: true` sólo para stories (course, article); `false` + `is_nestable: true` para bloks
- `real_name` mismo que `name`
- `restrict_components: true` + `component_whitelist` en todo field `bloks` para evitar drift
- Fields opcionales sin `required: true`

## 1. `course` (root)

Story raíz por curso. Adaptable a `article`, `product_page`, `landing_section`.

```json
{
  "name": "course",
  "display_name": "Course",
  "is_root": true,
  "is_nestable": false,
  "real_name": "course",
  "schema": {
    "tab-content": { "type": "tab", "pos": 0, "display_name": "Contenido", "keys": ["title", "description", "intro", "modules", "outro"] },
    "title": { "type": "text", "pos": 1, "required": true, "translatable": true, "max_length": 80 },
    "description": { "type": "textarea", "pos": 2, "required": true, "translatable": true, "max_length": 300 },
    "intro": {
      "type": "bloks", "pos": 3,
      "restrict_components": true,
      "component_whitelist": ["module_prose", "module_callout", "module_tile_stack", "module_step", "module_check_item", "module_prose_list", "module_sub_heading"]
    },
    "modules": {
      "type": "bloks", "pos": 4, "required": true,
      "restrict_components": true,
      "component_whitelist": ["course_module"]
    },
    "outro": {
      "type": "bloks", "pos": 5,
      "restrict_components": true,
      "component_whitelist": ["module_prose", "module_callout", "module_tile_stack", "module_step", "module_check_item", "module_prose_list", "module_sub_heading"]
    },
    "tab-meta": { "type": "tab", "pos": 6, "display_name": "Metadata", "keys": ["course_id", "reading_minutes", "teaches"] },
    "course_id": { "type": "option", "pos": 7, "required": true, "options": [{ "name": "...", "value": "..." }] },
    "reading_minutes": { "type": "number", "pos": 8, "required": true, "default_value": 8 },
    "teaches": { "type": "text", "pos": 9, "required": true, "max_length": 80 },
    "tab-seo": { "type": "tab", "pos": 10, "display_name": "SEO", "keys": ["seo_title", "seo_description", "og_image"] },
    "seo_title": { "type": "text", "pos": 11, "translatable": true },
    "seo_description": { "type": "textarea", "pos": 12, "translatable": true, "max_length": 200 },
    "og_image": { "type": "asset", "pos": 13, "filetypes": ["images"] }
  }
}
```

## 2. `course_module` (nestable)

Módulo dentro de un curso · contiene body de bloks.

```json
{
  "name": "course_module",
  "is_nestable": true,
  "schema": {
    "module_id": { "type": "text", "required": true, "description": "Stable id usado en URL ?modulo=X. Snake-kebab." },
    "number": { "type": "number", "required": true, "default_value": 1 },
    "title": { "type": "text", "required": true, "translatable": true, "max_length": 120 },
    "subtitle": { "type": "text", "translatable": true, "max_length": 200 },
    "icon_name": { "type": "text", "description": "Lucide icon name (whitelist en código)" },
    "minutes": { "type": "number", "required": true, "default_value": 2 },
    "body": {
      "type": "bloks", "required": true,
      "restrict_components": true,
      "component_whitelist": ["module_prose", "module_callout", "module_tile_stack", "module_step", "module_check_item", "module_prose_list", "module_sub_heading"]
    }
  }
}
```

## 3. `module_prose` (nestable)

Párrafo richtext. El bloque más usado.

```json
{
  "name": "module_prose",
  "is_nestable": true,
  "schema": {
    "body": { "type": "richtext", "required": true, "translatable": true }
  }
}
```

## 4. `module_callout` (nestable)

Callout branded con tone + emoji + title opcional + body richtext.

```json
{
  "name": "module_callout",
  "is_nestable": true,
  "schema": {
    "tone": {
      "type": "option", "required": true, "default_value": "info",
      "options": [
        { "name": "Info (verde)", "value": "info" },
        { "name": "Warning (amarillo)", "value": "warning" },
        { "name": "Danger (rojo)", "value": "danger" }
      ]
    },
    "title": { "type": "text", "translatable": true, "max_length": 80 },
    "emoji": { "type": "text", "max_length": 4 },
    "body": { "type": "richtext", "required": true, "translatable": true }
  }
}
```

## 5. `module_tile_stack` + `module_tile` (nestable)

Grilla de cards. `tile_stack` controla columnas; `tile` es el item.

```json
{
  "name": "module_tile_stack",
  "is_nestable": true,
  "schema": {
    "columns": {
      "type": "option", "required": true, "default_value": "2",
      "options": [
        { "name": "1 columna", "value": "1" },
        { "name": "2 columnas", "value": "2" },
        { "name": "3 columnas", "value": "3" }
      ]
    },
    "items": {
      "type": "bloks", "required": true,
      "restrict_components": true,
      "component_whitelist": ["module_tile"]
    }
  }
}
```

```json
{
  "name": "module_tile",
  "is_nestable": true,
  "schema": {
    "title": { "type": "text", "required": true, "translatable": true, "max_length": 80 },
    "body": { "type": "richtext", "required": true, "translatable": true },
    "icon_name": { "type": "text" },
    "emoji": { "type": "text", "max_length": 4 }
  }
}
```

## 6. `module_step` (nestable)

Paso numerado.

```json
{
  "name": "module_step",
  "is_nestable": true,
  "schema": {
    "number": { "type": "number", "required": true, "default_value": 1 },
    "title": { "type": "text", "required": true, "translatable": true, "max_length": 120 },
    "body": { "type": "richtext", "required": true, "translatable": true }
  }
}
```

## 7. `module_check_item` (nestable)

Item con tilde verde.

```json
{
  "name": "module_check_item",
  "is_nestable": true,
  "schema": {
    "text": { "type": "richtext", "required": true, "translatable": true }
  }
}
```

## 8. `module_prose_list` (nestable)

Lista flat bullet/numbered. Items separados por paragraphs en richtext.

```json
{
  "name": "module_prose_list",
  "is_nestable": true,
  "schema": {
    "style": {
      "type": "option", "required": true, "default_value": "bullet",
      "options": [
        { "name": "Bullet (•)", "value": "bullet" },
        { "name": "Numbered (1, 2, 3)", "value": "numbered" }
      ]
    },
    "items": { "type": "richtext", "required": true, "translatable": true }
  }
}
```

## 9. `module_sub_heading` (nestable)

h3 dentro del body · icon opcional con tone.

```json
{
  "name": "module_sub_heading",
  "is_nestable": true,
  "schema": {
    "text": { "type": "text", "required": true, "translatable": true, "max_length": 120 },
    "icon_name": { "type": "text" },
    "icon_tone": {
      "type": "option", "default_value": "danger",
      "options": [
        { "name": "Danger (rojo)", "value": "danger" },
        { "name": "Default (verde MODO)", "value": "default" },
        { "name": "Muted (gris)", "value": "muted" }
      ]
    }
  }
}
```

## TypeScript types

```ts
// src/CMS/types.ts (extracto)
export type SbRichText = { type: "doc"; content: unknown[] };

interface SbBlokBase { _uid?: string; component: string; _editable?: string }

export interface ModuleProseBlok extends SbBlokBase {
  component: "module_prose";
  body: SbRichText;
}

export interface ModuleCalloutBlok extends SbBlokBase {
  component: "module_callout";
  tone: "info" | "warning" | "danger";
  title?: string;
  emoji?: string;
  body: SbRichText;
}

// ... (módulo_tile, _step, _check_item, _prose_list, _sub_heading, _tile_stack)

export type CourseModuleBodyBlok =
  | ModuleProseBlok | ModuleCalloutBlok | ModuleTileStackBlok
  | ModuleStepBlok | ModuleCheckItemBlok | ModuleProseListBlok
  | ModuleSubHeadingBlok;

export interface CourseModuleBlok extends SbBlokBase {
  component: "course_module";
  module_id: string;
  number: number;
  title: string;
  subtitle?: string;
  icon_name?: string;
  minutes: number;
  body: CourseModuleBodyBlok[];
}

export interface CourseBlok extends SbBlokBase {
  component: "course";
  title: string;
  description: string;
  intro?: CourseModuleBodyBlok[];
  modules: CourseModuleBlok[];
  outro?: CourseModuleBodyBlok[];
  course_id: string;
  reading_minutes: number;
  teaches: string;
  seo_title?: string;
  seo_description?: string;
  og_image?: { filename?: string; alt?: string };
}

export interface CourseStory {
  name: string;
  slug: string;
  full_slug: string;
  content: CourseBlok;
  published_at?: string;
}
```

## Renaming para otros content types

Pattern aplica a cualquier feature reemplazando `course` → tu entity:

| course/module → | article/section | product/feature | promo/offer |
|---|---|---|---|
| `course` (root) | `article` | `product_page` | `promo_landing` |
| `course_module` | `article_section` | `product_feature` | `promo_section` |
| `module_*` body bloks | iguales · prefijo `section_*` opcional | iguales · prefijo `feature_*` | iguales |

Los body bloks (prose, callout, tile, step, check_item, list, sub_heading) son content-type-agnostic. Reusables.
