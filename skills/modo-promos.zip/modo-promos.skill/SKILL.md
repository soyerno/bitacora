---
name: modo-promos
description: Consultar promociones, bancos y comercios adheridos de MODO via el MCP `modo-promos-mcp`. Auto-invocar cuando el usuario pregunte por promos vigentes, slots, slugs, detalle de una promo, bancos asociados, o comercios adheridos en cualquier ambiente (develop/qa/preprod/prod). Tools disponibles bajo el prefijo `mcp__modo-promos__modo_*`.
---

# modo-promos — Skill para promociones y comercios de MODO

## Cuándo invocar

Usar este skill cuando el usuario pida:

- "qué promos hay en…", "promociones del slot…", "cards del carrousel"
- "detalle de la promo X", "qué bancos tiene la promo Y"
- "lista de bancos en MODO", "ID del banco Galicia"
- "slugs de todas las promos", "para sitemap"
- "qué comercios tienen…", "stores online…", "supermercados adheridos"
- Validar paridad entre ambientes (develop vs prod)
- Reproducir un bug que depende de data de un slot real

## MCP requerido

Server: `modo-promos` (registrado en `~/.claude/.mcp.json`).
Repo: `~/Documents/Proyectos/modo/modo-landing-workspace/mcp-servers/modo-promos-mcp/`.

Si las tools `mcp__modo-promos__*` no aparecen, indicar al usuario:

```bash
# 1. instalar deps (única vez)
cd ~/Documents/Proyectos/modo/modo-landing-workspace/mcp-servers/modo-promos-mcp && npm install

# 2. agregar a ~/.claude/.mcp.json (o usar /mcp en Claude Code)
```

## Tools disponibles

| Tool | Cuándo usar |
|------|-------------|
| `mcp__modo-promos__modo_get_promotions_by_slot` | Promos de un slot (carrousel, grilla, bancos, etc.). Slot default a sugerir: `web-modo-hub-carrousel_principal` |
| `mcp__modo-promos__modo_get_promotion_detail` | Detalle por slug (ya conocido) |
| `mcp__modo-promos__modo_get_promotion_banks` | Bancos asociados a una promo específica |
| `mcp__modo-promos__modo_list_active_banks` | Lista completa de bancos en MODO con IDs (necesario antes de filtrar por banco) |
| `mcp__modo-promos__modo_list_promotion_slugs` | Todos los slugs (sitemap, auditoría SEO, batch lookup) |
| `mcp__modo-promos__modo_search_stores_online` | Buscador de comercios con compra online |
| `mcp__modo-promos__modo_get_stores_by_promotion` | Resumen stores/brands/groups adheridos a una promo |
| `mcp__modo-promos__modo_get_stores_by_type` | Stores adheridos a una promo filtrados por type |

## Resources

- `modo-promos://environments` → tabla de URLs por ambiente
- `modo-promos://slots` → slots conocidos
- `modo-promos://sources` → valores válidos para `source`

## Workflow recomendado

1. **Si el usuario no dice ambiente** → asumir `prod`. Mencionarlo en la respuesta.
2. **Si pide "todas las promos"** → primero `modo_list_promotion_slugs` (paginado). No bajar el detalle de cada una salvo que lo pida.
3. **Si pide promos de un banco** → primero `modo_list_active_banks` para resolver el ID, después `modo_get_promotions_by_slot` con `banks: [id]`.
4. **Si pide comercios adheridos a una promo** → necesitás el `applicationId`. Si solo tenés el slug, llamar `modo_get_promotion_detail` y leer `application_id` del payload.

## Ambientes

```
develop → develop.playdigital.com.ar
qa      → qa.playdigital.com.ar
preprod → preprod.playdigital.com.ar
prod    → playdigital.com.ar  (default)
```

Cada tool acepta el arg `env`. Para comparar paridad: llamar dos veces (develop + prod) y diffear.

## Convención de respuesta al usuario

- Devolver **solo lo que pidió** + el `url` real consultado (para que pueda reproducirlo con curl).
- Para listas > 5 items, mostrar los primeros y avisar el total.
- Citar nombres de bancos asociados (Galicia, Santander, BBVA, Macro, Nación, ICBC, Supervielle, Credicoop, etc.) cuando sea relevante, según convención MODO.
- Nunca inventar IDs, slugs, ni URLs — siempre que vengan de la respuesta del MCP.

## Ejemplos

**Usuario:** "qué promos hay esta semana"
1. `modo_get_promotions_by_slot { slot: "web-modo-hub-carrousel_principal", limit: 10 }`
2. Listar las primeras N cards con `title`, `cta_value`, `cta_type`, fecha de validez si está en el payload.

**Usuario:** "detalle de la promo coto-mayo"
1. `modo_get_promotion_detail { slug: "coto-mayo" }` (si falla, primero `modo_list_promotion_slugs` y matchear)
2. Devolver título, descripción, bancos, vigencia.

**Usuario:** "diff bancos develop vs prod"
1. `modo_list_active_banks { env: "develop" }` + `modo_list_active_banks { env: "prod" }` en paralelo.
2. Diff por nombre + ID.

**Usuario:** "comercios adheridos a galicia eminent"
1. `modo_list_promotion_slugs` → matchear slug con "galicia eminent"
2. `modo_get_promotion_detail { slug: <match> }` → extraer `application_id`
3. `modo_get_stores_by_promotion { applicationId: <id> }`

## No hacer

- **No** mutar estado — el MCP es read-only.
- **No** asumir endpoints distintos a los expuestos por el server — si falta algo, pedir agregar la tool al MCP (`mcp-servers/modo-promos-mcp/src/`).
- **No** mezclar este MCP con el de modo-checkout o stores-maps-lib — este wrappea SOLO `rewards-handler-bff` + `map-handler-bff`.
