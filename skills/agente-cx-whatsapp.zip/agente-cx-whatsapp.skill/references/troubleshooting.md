# Troubleshooting — agente-cx-whatsapp

## HMAC inválido (logs: `hmac signature inválido`, 401 al webhook)

**Causa**: el `secret` con el que se registró el webhook en OpenWA no matchea `OPENWA_WEBHOOK_SECRET` del `.env`.

**Fix**:
1. Confirmar: `grep OPENWA_WEBHOOK_SECRET .env`
2. Listar webhooks registrados:
   ```bash
   curl "$OPENWA_BASE_URL/sessions/$OPENWA_SESSION_ID/webhooks" -H "X-API-Key: $OPENWA_API_KEY"
   ```
3. Si difiere, des-registrar el viejo y registrar de nuevo con el secret correcto.
4. Verificar que `express.json({ verify })` esté preservando `req.rawBody` (ver [src/index.mjs](../../../Documents/Proyectos/modo/modo-landing-workspace/agente-cx-whatsapp/src/index.mjs)) — el HMAC se calcula sobre el body raw, no parseado.

## `ANTHROPIC_API_KEY missing` (agente responde fallback)

Cuando falta la key, `claude.mjs` devuelve `"Servicio temporalmente no disponible"`. Verificar `.env` y reiniciar `npm run dev`. Modelo default es `claude-sonnet-4-6` — si querés Opus 4.7, setear `CLAUDE_MODEL=claude-opus-4-7`.

## modo-promos devuelve 4xx/5xx

El cliente de tools/modo-promos hace fetch directo a `rewards-handler-bff`. Si responde 4xx:

- 404 en slug → el slug pasado al tool no existe; pedirle al usuario que reformule.
- 5xx → caída del backend; el agente responderá "no tengo esa info confirmada" (lo que dice el system prompt).
- Verificar manualmente: `curl https://rewards-handler.playdigital.com.ar/slots/web-modo-hub-carrousel_principal?source=web_modo&limit=2`.

Para cambiar de ambiente sin redeploy: `MODO_ENV=develop npm run dev`.

## Confluence devuelve 401/403

- 401 → `CONFLUENCE_API_TOKEN` inválido o expirado. Regenerar en https://id.atlassian.com/manage-profile/security/api-tokens.
- 403 → el usuario `CONFLUENCE_EMAIL` no tiene acceso al space. Chequear `CONFLUENCE_ALLOWED_SPACES` vs permisos reales.

Para test rápido:
```bash
curl -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" \
  "$CONFLUENCE_BASE_URL/rest/api/search?cql=type%3Dpage&limit=1"
```

## Webhook no llega al agente

Causas comunes:

1. **OpenWA corre en Docker, agente fuera** → la URL del webhook debe ser `http://host.docker.internal:3737/openwa/webhook` (no `localhost`).
2. **Webhook registrado para otra sesión** → confirmar `sessionId` en el GET de webhooks.
3. **OpenWA reintenta 3 veces y abandona** → revisar logs del container: `docker logs openwa-api`. Si veo timeouts, el agente está tardando demasiado en responder con `202`. El agente devuelve 202 antes de procesar (ver `index.mjs:24`), así que esto no debería pasar; si pasa, revisar middleware de express.

## SQLite locked

`better-sqlite3` con WAL mode permite lecturas concurrentes pero solo un writer. Si veo `SQLITE_BUSY`, casi seguro hay otra instancia del agente corriendo:

```bash
lsof | grep sessions.sqlite
```

Matar el proceso huérfano y reiniciar.

## Anti-bot bloquea números legítimos

Si el thresholds están demasiado agresivos:

1. Ver score real: subir `LOG_LEVEL=debug` en `.env`, mirar `antibot-score` en stdout.
2. Ajustar variables sin tocar código:
   - `ANTIBOT_SCORE_THRESHOLD=0.85` (más permisivo)
   - `RATE_LIMIT_MAX_MSGS=20` (más mensajes/ventana)
   - `SPAM_REPEAT_LIMIT=5`
3. Para desbloquear un número específico ver SKILL.md → "Operaciones comunes".

**Nunca desactivar el filtro completo** — el agente es público y el endpoint del webhook está expuesto. Sin filtro, un atacante puede abusar de la API de Claude generando costos.

## Mensaje no-texto (imagen, audio, sticker)

`src/index.mjs` filtra `msg.type !== 'chat'` y responde "Por ahora solo respondo mensajes de texto". Si querés soportar audio (transcripción con Whisper):

1. Agregar tool `transcribe_audio` en `src/tools/`
2. Endpoint de OpenWA para descargar media: `GET /sessions/:id/messages/:msgId/media`
3. Trasncribir con Anthropic via files API o un Whisper externo

Out-of-scope del MVP actual.

## Agente responde lento (> 5s)

- Tool rounds máximo: 5 (ver `MAX_TOOL_ROUNDS` en `claude.mjs`). Si Claude llama tools en cadena, suma latencia. Bajar a 3 si querés UX más snappy a costa de calidad.
- Confluence puede tardar 1-2s por búsqueda. Considerar agregar cache en `tools/confluence.mjs` con TTL 5min.
- Modelo Haiku es 3x más rápido que Sonnet — para preguntas frecuentes/cortas: `CLAUDE_MODEL=claude-haiku-4-5-20251001`.
