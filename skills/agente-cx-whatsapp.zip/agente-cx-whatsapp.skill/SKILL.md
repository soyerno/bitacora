---
name: agente-cx-whatsapp
description: Operar el agente CX/Promos de MODO por WhatsApp (OpenWA + Anthropic + Confluence + modo-promos + anti-bot). Auto-invocar cuando el usuario pida levantar, configurar, debuggear, registrar webhook, ver logs, desbloquear números, o entender la arquitectura del agente. Triggers (ES/EN) "agente whatsapp", "agente cx", "openwa", "levantar el agente", "debuggear webhook", "anti-bot whatsapp", "desbloquear número whatsapp", "registrar webhook openwa", "test del agente cx". Proyecto en /Users/hernan.desouza/Documents/Proyectos/modo/modo-landing-workspace/agente-cx-whatsapp/.
---

# agente-cx-whatsapp

Operar el agente CX/Promos por WhatsApp de MODO. Stack: Node 22 + Express + `@anthropic-ai/sdk` + `better-sqlite3` + OpenWA (Docker).

## Mapa de archivos del proyecto

```
agente-cx-whatsapp/
├── src/index.mjs                # Express webhook server (port 3737)
├── src/openwa.mjs               # HMAC verify + send-text REST client
├── src/anti-bot.mjs             # rate-limit + heurística + challenge humano
├── src/store.mjs                # SQLite (mensajes, sesiones, bloqueos)
├── src/claude.mjs               # Anthropic tool_use loop + system prompt CX
├── src/tools/modo-promos.mjs    # fetch directo a rewards-handler-bff (público)
├── src/tools/confluence.mjs     # Atlassian REST con auth Basic
├── .env.example                 # plantilla de configuración
└── .data/sessions.sqlite        # estado runtime (auto-creada)
```

## Workflow: levantar end-to-end

Ejecutar en este orden:

1. **OpenWA (Docker)** — terminal separada:
   ```bash
   cd ~/Documents/Proyectos/modo/openwa
   docker compose -f docker-compose.dev.yml up -d
   # escanear QR en http://localhost:2886
   ```

2. **Agente** — primera vez `npm install`:
   ```bash
   cd ~/Documents/Proyectos/modo/modo-landing-workspace/agente-cx-whatsapp
   nvm use 22.22.2
   [ -f .env ] || cp .env.example .env   # editar las claves
   npm install
   npm run dev
   ```

3. **Registrar el webhook en OpenWA** (una sola vez por sesión OpenWA):
   ```bash
   source .env && curl -X POST "$OPENWA_BASE_URL/sessions/$OPENWA_SESSION_ID/webhooks" \
     -H "Content-Type: application/json" \
     -H "X-API-Key: $OPENWA_API_KEY" \
     -d "{\"url\":\"http://host.docker.internal:$PORT/openwa/webhook\",\"events\":[\"message.received\"],\"secret\":\"$OPENWA_WEBHOOK_SECRET\",\"retryCount\":3}"
   ```

4. **Health**: `curl http://localhost:3737/health` → `{ok: true}`.

5. **Test end-to-end**: mandar mensaje al número de WhatsApp conectado a OpenWA. Primer mensaje → challenge anti-bot. Responder challenge → conversación normal.

## Variables obligatorias en `.env`

| Var | Para qué |
|-----|----------|
| `ANTHROPIC_API_KEY` | Claude SDK |
| `CLAUDE_MODEL` | Default `claude-sonnet-4-6` |
| `OPENWA_BASE_URL` | Default `http://localhost:2785/api` |
| `OPENWA_SESSION_ID` | ID de la sesión OpenWA |
| `OPENWA_WEBHOOK_SECRET` | Mismo valor que se pasa al registrar el webhook |
| `OPENWA_API_KEY` | Si OpenWA tiene `API_MASTER_KEY` |
| `CONFLUENCE_BASE_URL`, `CONFLUENCE_EMAIL`, `CONFLUENCE_API_TOKEN` | Para que el agente lea CX |
| `CONFLUENCE_ALLOWED_SPACES` | Lista CSV de spaces permitidos (ej. `CX,PROMOS`) |
| `MODO_ENV` | `develop`/`qa`/`preprod`/`prod` para `rewards-handler-bff` |

## Operaciones comunes

| Acción | Comando |
|--------|---------|
| Logs vivos | `npm run dev` (JSON en stdout) |
| Inspect mensajes | `sqlite3 .data/sessions.sqlite "SELECT phone, direction, substr(body,1,60), datetime(created_at/1000,'unixepoch','localtime') FROM messages ORDER BY id DESC LIMIT 20;"` |
| Estado de un número | `sqlite3 .data/sessions.sqlite "SELECT * FROM sessions WHERE phone='5491122334455';"` |
| Desbloquear número | `sqlite3 .data/sessions.sqlite "UPDATE sessions SET blocked_until=NULL, state='human', human_verified_at=cast(strftime('%s','now') AS INTEGER)*1000 WHERE phone='5491122334455';"` |
| Reset total | `rm -rf .data/` (re-arranca el server y se recrea) |
| Probar tool de promos solo | `curl https://rewards-handler.playdigital.com.ar/banks?source=web_modo` |

## Troubleshooting

Cargar [references/troubleshooting.md](references/troubleshooting.md) cuando aparezca alguno de estos síntomas:
- HMAC inválido (`x-openwa-signature` no matchea)
- `ANTHROPIC_API_KEY missing` o 401
- modo-promos devuelve 4xx/5xx
- Confluence devuelve 401/403
- Webhook no llega al agente
- SQLite locked / corrupto
- Anti-bot bloquea legítimos
- Agente responde lento (> 5s)

## No hacer

- **No** modificar `src/anti-bot.mjs` para bajar todos los thresholds sin medir falsos positivos — está calibrado para el caso de uso CX.
- **No** exponer `/openwa/webhook` a internet sin HMAC válido (`OPENWA_WEBHOOK_SECRET` set + `verifyWebhookSignature` en el flow).
- **No** loggear `body` completo de mensajes en producción si contienen datos sensibles — el system prompt ya pide al usuario que NO comparta DNI/CBU/OTP, pero igualmente filtrar antes de Sentry/logs externos.
- **No** mezclar credenciales de Confluence con OpenWA — son secretos distintos.
- **No** correr `docker compose down -v` en `~/Documents/Proyectos/modo/openwa` sin avisar — perdés la sesión de WhatsApp y hay que escanear QR de nuevo.

## Referencia cruzada

- Promos: skill `modo-promos` (mismo workspace) — el agente NO usa ese MCP directamente; usa fetch a `rewards-handler-bff` desde `tools/modo-promos.mjs`. El MCP es para Claude Code; el agente WhatsApp es un servicio independiente.
- Confluence: el agente usa REST Atlassian directa con `CONFLUENCE_API_TOKEN` (no es el MCP de Atlassian).
