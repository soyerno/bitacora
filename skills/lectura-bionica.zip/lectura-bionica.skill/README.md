# lectura-bionica

Lectura biónica + lectura asistida para TDAH/dislexia. Bold de las primeras `ceil(N/2)` letras de cada palabra ≥3 letras, idempotente, en Markdown o HTML.

## Quick start

- **Trigger en sesión Claude**: `/lectura-bionica`, "modo TDAH", "pasalo a bionic", "lectura biónica".
- **CLI**: `python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py archivo.md` → emite Markdown a stdout.
- **Output**: prose con prefijos en `**bold**` (o `<b>…</b>` con `--html`), respetando código, números, URLs, paths, env vars, IDs y acrónimos.

Ejemplo:

```
echo "La lectura biónica reduce las regresiones oculares." | python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py
# → La **lect**ura **bión**ica **red**uce las **regres**iones **ocul**ares.
```

## Features

- Markdown (`**…**`) y HTML (`<b>…</b>`) con `--html`.
- Idempotente: pasarlo dos veces no double-bold ni rompe el output.
- Exclusiones: stopwords cortas (ES + EN), acrónimos all-uppercase ≤4 chars (RFC, SEO, URL, API), código inline + fenced, números, montos, URLs, paths (`~/`, `./`, `../`, `/`), env vars (`API_BASE_URL`), hex (`#008859`), IDs Jira (`EXA-1234`).
- Modos: stdin / archivo / `--check` (diff dry-run) / `--write` (sobrescribe).
- Cumple WCAG 2.2 AA (SC 1.4.8 + 1.4.12). Fundamento: deck draft `accesibilidad-lectura-asistida-tdah` en la bitácora.

## Files

- `SKILL.md` — proceso completo, reglas duras, algoritmo, notas de implementación (pitfalls que ya resolví).
- `README.md` — esta doc.
- `examples.md` — casos ES/EN + bordes (CamelCase, código, HTML, idempotencia).
- `scripts/bionic.py` — transformador. Stdin/archivo → markdown o HTML.

## Publicación en la bitácora

ZIP descargable: https://soyernomodo.github.io/erno-modo/skills/lectura-bionica.zip
Card visible: https://soyernomodo.github.io/erno-modo/herramientas/ (categoría "MODO · skills y MCPs propios").
Mantiene `~/.claude/skills/erno-modo-sync-all/` (incluida en `CUSTOM_SKILLS`).

## Changelog

- **2026-05-20** — Creación inicial. SKILL.md + examples.md + scripts/bionic.py. Publicada en bitácora erno-modo (PR #26 fixeó el deploy roto por worktree pointers). Sección `## Notas de implementación` documenta 6 pitfalls aprendidos (placeholders PUA, RE_PATH, `"" in "/_-."`, orden de `protect()`, idempotencia con sufijo, acrónimos).
