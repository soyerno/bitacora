---
name: lectura-bionica
description: 'Lectura biónica + lectura asistida para TDAH/dislexia aplicada a la salida de Claude y a archivos arbitrarios. Bold de la primera mitad de cada palabra ≥3 letras para crear un ancla visual que reduce regresiones oculares. Auto-invocar cuando el usuario diga "lectura biónica", "modo TDAH", "bionic reading", "leí mejor con bionic", "transformá esto a bionic", "ponelo en bionic", "/lectura-bionica", o cuando pida adaptar texto largo para accesibilidad lectora. Fundamento: deck https://soyernomodo.github.io/erno-modo/decks/draft/accesibilidad-lectura-asistida-tdah.html (WCAG 2.2 AA, SC 1.4.8 + 1.4.12).'
---

# lectura-bionica

Skill MODO para asistir lectura — voz neuronal: el cerebro completa la palabra desde el ancla del prefijo. Reduce regresiones oculares, fatiga visual y carga cognitiva en bloques largos. Pensado para TDAH, dislexia, screens chicas y lectura técnica densa.

Fundamento canónico: [decks/draft/accesibilidad-lectura-asistida-tdah.html](https://soyernomodo.github.io/erno-modo/decks/draft/accesibilidad-lectura-asistida-tdah.html).

## Cuándo se invoca

- Manual: `/lectura-bionica`, "pasalo a lectura biónica", "modo TDAH", "bionic mode", "bold half".
- Implícito: el usuario pide adaptar un texto largo (>150 palabras), pide accesibilidad lectora, dice que le cuesta leer, o referencia el deck de accesibilidad.
- En decks/RFCs MODO con bloques largos de prose, si el usuario lo activa para esa sesión.

## Reglas duras (del deck)

1. **Ancla = primera mitad** de cada palabra `≥ 3 letras`. Usar `Math.ceil(N/2)` letras en `**bold**` (markdown) o `<b>` (HTML).
2. **Palabras < 3 letras** quedan crudas (en, es, de, la, el, mi, tu, su, un, ya, no, etc.).
3. **Cobertura**: solo prose. **Nunca** aplicar a:
   - Bloques de código (` ``` `) ni inline code (`` ` ``).
   - Números, montos, fechas, IDs (`123`, `$4.500`, `2026-05-20`, `EXA-1234`).
   - URLs, paths, env vars, hex/rgb, tokens (`#008859`, `API_BASE_URL`, `~/.claude/`).
   - Inputs, formularios, placeholders, valores transaccionales, mandates AP2/ACP.
   - Identificadores de UI (selectores CSS, nombres de componentes, `data-*`).
4. **Una sola fuente de verdad** por palabra: si la palabra contiene un dígito o símbolo no-letra adyacente al prefijo, **no boldeás**.
5. **No re-procesar** texto ya boldeado: si la palabra ya tiene `**` o `<b>`, se respeta tal cual.
6. **Idioma-agnóstico**: aplica a ES, EN y mezclas. Acentos y ñ cuentan como letras.

## Tipografía + accesibilidad extendida (opt-in)

Aplican cuando el host (HTML/deck/web) lo soporta vía CSS custom properties:

| Control            | Valores                | Default | WCAG                |
| ------------------ | ---------------------- | ------- | ------------------- |
| Tamaño fuente      | 100% · 115% · 130%     | 100%    | SC 1.4.4            |
| Interlineado       | 1.5× · 1.7× · 1.9×     | 1.5×    | SC 1.4.12           |
| Tracking (letra)   | 0 · +2% · +4%          | 0       | SC 1.4.12           |
| Espacio palabra    | 0 · +8% · +12%         | 0       | SC 1.4.12           |

Sin JS adicional. Default = no modifica nada hasta opt-in del usuario.

**Objetivo cumplido**: WCAG 2.2 AA (SC 1.4.8 Visual Presentation, SC 1.4.12 Text Spacing). AAA queda fuera del MVP. OpenDyslexic font = fase 2.

## Algoritmo (referencia)

```
para cada palabra W en el texto:
    si W toca código / número / URL / id / hex / env var:
        emitir W tal cual
        continuar

    letras_alfa = contar letras en W (incluyendo acentos y ñ)
    si letras_alfa < 3:
        emitir W tal cual
        continuar

    k = ceil(letras_alfa / 2)
    prefijo = primeras k letras de W
    sufijo  = resto de W
    emitir "**" + prefijo + "**" + sufijo
```

Implementación de referencia en [scripts/bionic.py](scripts/bionic.py). Markdown por default (`**bold**`); flag `--html` emite `<b>`.

## Uso

### Transformar texto inline (Claude)

Cuando el skill está activo en una sesión, **Claude aplica bionic a su prose de salida** (no a code blocks, no a tablas con datos, no a IDs). Ejemplo:

> **Lect**ura **bión**ica **env**uelve la **prim**era **mit**ad de **ca**da **pal**abra **lar**ga en **bo**ld para **gen**erar un **anc**la **vis**ual.

### Transformar un archivo / texto largo

```bash
# Markdown (default)
python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py docs/RFC-SEO-2026-05-01.md > docs/RFC-SEO-2026-05-01.bionic.md

# HTML inline (para decks)
python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py --html input.html > output.bionic.html

# Desde stdin
echo "Hola mundo este es un test de lectura bionica" | python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py

# Modo dry-run (muestra el diff sin escribir)
python3 ~/.claude/skills/lectura-bionica/scripts/bionic.py --check input.md
```

### Toggle de la skill en sesión

- "activá bionic" / "modo TDAH on" → aplicar a todas las respuestas siguientes.
- "salí de bionic" / "modo TDAH off" → volver a prose normal.

## Qué NO hace (scope explícito)

- No reescribe inputs, formularios, montos, IDs ni datos transaccionales.
- No cambia fuente del sistema ni instala OpenDyslexic (fase 2).
- No aplica a apps nativas (iOS/Android MODO) en esta versión.
- No traduce, no corrige ortografía, no resume — solo asiste lectura.
- No procesa más de una vez el mismo texto (idempotente).

## Ejemplos

Ver [examples.md](examples.md) para ES, EN, técnico, y casos límite (números, código, URLs).

## Notas de implementación (pitfalls que ya doblegué)

Si alguien (o yo) refactorea `bionic.py`, evitar estas trampas que rompen idempotencia y/o corrompen output:

1. **Placeholders de protección NO pueden contener letras ni `[A-Z][A-Z0-9_]{2,}`**. La primera versión usaba `\0PROT{i}\0` y `RE_ENV_VAR` re-capturaba `PROT0` como env var, perdiendo la URL original. Usar caracteres del Unicode Private Use Area: `<idx>`. PUA no aparece en ningún `\w`, `[A-Z]`, ni símbolo común.

2. **`RE_PATH` debe requerir prefijo `/`**. Un simple `[~./]` matchea `.txt` y oculta el punto que `repl_word` usa como contexto para no boldear `llms`. Pattern correcto: `(?:~/|\./|\.\./|/)[\w./\-]+`.

3. **En Python, `"" in "/_-."` evalúa True** (substring vacío). En `repl_word`, chequear truthy primero: `if (prev and prev in "/_-.") or (nxt and nxt in "/_-."):`. Sin este guard, palabras al inicio/fin del texto nunca se boldean.

4. **Orden de `protect()` importa**:
   - `RE_INLINE_CODE` → primero (bloques opacos).
   - `RE_ALREADY_BOLD` → ANTES que `RE_HTML_TAG` para que capture el `<b>...</b>` entero (con letras-sufijo) y mantenga idempotencia en `--html`.
   - `RE_HTML_TAG` → ANTES que `RE_PATH`. Si no, `/p` adentro de `</p>` matchea path y rompe el tag → output con `<...>` corrupto.

5. **Idempotencia**: `RE_ALREADY_BOLD` extiende el match a las letras del sufijo (`\*\*…\*\*[a-záéíóú…]*` y `<b>…</b>[a-záéíóú…]*`). Sin esa extensión, segunda pasada re-procesa la cola (`**bold**eado` → `**bold****ea**do`).

6. **Acrónimos all-uppercase ≤4 chars no se boldean** (RFC, SEO, URL, API, MODO, JSON). Si se boldean queda ruidoso. Stopwords cortas tampoco.

## Estructura

```
~/.claude/skills/lectura-bionica/
├── SKILL.md          # Este archivo
├── README.md         # Quick start + changelog
├── examples.md       # Casos ES/EN + bordes
└── scripts/
    └── bionic.py     # Transformador stdin/archivo → markdown/HTML
```

## Origen

Deck draft: `decks/draft/accesibilidad-lectura-asistida-tdah.html` (Hernán De Souza · Sr AI Engineer · MODO). Esta skill es la implementación operativa de los principios del deck, lista para correr en cualquier contexto Claude Code.
