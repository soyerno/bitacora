# Ejemplos de lectura biónica

## ES — prose técnico

**Input**

> La lectura biónica envuelve la primera mitad de cada palabra de tres o más letras en bold para crear un ancla visual que el cerebro completa por inferencia. Reduce regresiones oculares y fatiga.

**Output**

> La **lect**ura **bión**ica **env**uelve la **prim**era **mit**ad de **ca**da **pal**abra de **tr**es o **má**s **let**ras en **bo**ld **pa**ra **cre**ar un **anc**la **vis**ual que el **cer**ebro **com**pleta por **infe**rencia. **Red**uce **regr**esiones **ocul**ares y **fat**iga.

## EN — short paragraph

**Input**

> Bionic reading bolds the first half of each word longer than two letters. The brain completes the rest from context.

**Output**

> **Bio**nic **read**ing **bol**ds the **fir**st **ha**lf of **ea**ch **wo**rd **lon**ger **th**an **t**wo **let**ters. The **bra**in **com**pletes the **re**st **fro**m **cont**ext.

## Mixto + casos límite

**Input**

```
El RFC SEO 2026-05-01 introduce llms.txt + WebSite SearchAction + 17 BankOrCreditUnion. El owner es Hernán De Souza y el costo dev estimado es 28 horas a $5.000/hora.
URL: https://soyernomodo.github.io/erno-modo/decks/draft/accesibilidad-lectura-asistida-tdah.html
Env: API_BASE_URL=https://api.modo.com.ar
Color: #008859 + EXA-1234
```

**Output**

```
El RFC SEO 2026-05-01 **intr**oduce llms.txt + WebSite SearchAction + 17 BankOrCreditUnion. El **own**er es **Her**nán De **Sou**za y el **cos**to dev **estim**ado es 28 **ho**ras a $5.000/hora.
URL: https://soyernomodo.github.io/erno-modo/decks/draft/accesibilidad-lectura-asistida-tdah.html
Env: API_BASE_URL=https://api.modo.com.ar
Color: #008859 + EXA-1234
```

Notar:
- `RFC`, `SEO`, `EN`, `ES` → siglas cortas, no se boldean.
- `2026-05-01`, `28`, `$5.000`, `17` → números, intactos.
- `llms.txt`, `WebSite`, `BankOrCreditUnion`, `SearchAction` → nombres compuestos con dígitos/símbolos cercanos, se pasan crudos.
- `https://…` → URL, intacta.
- `API_BASE_URL`, `EXA-1234`, `#008859` → env / id / hex, intactos.
- `Hernán`, `De`, `Souza` → nombres propios sí se boldean (es prose).

## Markdown con código

**Input**

````
La función `transform_prose` recibe el texto crudo y devuelve el texto procesado.

```python
def bold_word(word: str) -> str:
    k = math.ceil(len(word) / 2)
    return f"**{word[:k]}**{word[k:]}"
```

La salida es idempotente.
````

**Output**

````
La **func**ión `transform_prose` **rec**ibe el **tex**to **cru**do y **dev**uelve el **tex**to **proc**esado.

```python
def bold_word(word: str) -> str:
    k = math.ceil(len(word) / 2)
    return f"**{word[:k]}**{word[k:]}"
```

La **sal**ida es **idemp**otente.
````

El bloque de código queda intocado. El inline `` `transform_prose` `` también.

## HTML (--html)

**Input**

```html
<p>La lectura biónica reduce la fatiga visual.</p>
```

**Output**

```html
<p>La <b>lect</b>ura <b>bión</b>ica <b>red</b>uce la <b>fat</b>iga <b>vis</b>ual.</p>
```

## Stopwords cortas

Estas NO se boldean aunque tengan 3+ letras (suenan ruidosas si se bold):

`los · las · les · del · por · con · sin · más · que · qué · fue · ser · son · the · and · but · for · are · was · you · our`

El resto sí.
