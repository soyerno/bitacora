#!/usr/bin/env python3
"""
lectura-bionica: transformador de texto a formato de lectura biónica.

Bold de las primeras ceil(N/2) letras de cada palabra de N >= 3 letras alfabéticas.
Salta código (```...```, `inline`), HTML tags (excepto inline en --html), URLs, paths,
env vars, hex, IDs, números, montos y palabras ya boldeadas.

Uso:
    python3 bionic.py archivo.md                    # markdown bold (**...**)
    python3 bionic.py --html archivo.html           # HTML <b>...</b>
    cat texto.txt | python3 bionic.py               # stdin
    python3 bionic.py --check archivo.md            # imprime diff sin tocar el archivo

Idempotente: ejecutar dos veces produce el mismo output. Respeta acentos, ñ y mayúsculas.
"""
from __future__ import annotations

import argparse
import difflib
import math
import re
import sys
from pathlib import Path

# Palabras que NUNCA boldeamos aunque tengan ≥3 letras (stopwords cortas / siglas comunes).
# Conservador: mejor pasar de largo que ruido visual en conectores.
STOPWORDS_ES = {
    "los", "las", "les", "del", "por", "con", "sin", "más", "mas", "ese",
    "esa", "eso", "una", "uno", "que", "qué", "fue", "ser", "soy", "son",
    "muy", "yo", "tú", "el", "la",
}
STOPWORDS_EN = {
    "the", "and", "but", "for", "nor", "yet", "are", "was", "you", "our",
}
STOPWORDS = STOPWORDS_ES | STOPWORDS_EN

# Letras válidas para contar "palabra alfabética" (incluye acentos castellanos y ñ).
LETTER_CHARS = r"a-zA-ZáéíóúÁÉÍÓÚñÑüÜ"

# Patrones de exclusión: si una "palabra" matchea uno de estos, NO la procesamos.
RE_URL = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
RE_PATH = re.compile(r"(?:~/|\./|\.\./|/)[\w./\-]+")
RE_HEX = re.compile(r"#[0-9a-fA-F]{3,8}")
RE_ENV_VAR = re.compile(r"[A-Z][A-Z0-9_]{2,}")  # API_BASE_URL, EXA_TOKEN
RE_ID_TICKET = re.compile(r"[A-Z]{2,}-\d+")  # EXA-123, COENXT-456
RE_HAS_DIGIT = re.compile(r"\d")

# Token alfabético "puro" — sin dígitos ni símbolos internos.
RE_WORD = re.compile(rf"[{LETTER_CHARS}]+")

# Fence detection.
RE_CODE_FENCE_OPEN = re.compile(r"^\s{0,3}(```|~~~)")
RE_INLINE_CODE = re.compile(r"`[^`\n]+`")

# Markdown bold ya presente: respetar. Captura también letras-sufijo (idempotencia).
RE_ALREADY_BOLD = re.compile(
    rf"\*\*[^*\n]+\*\*[{LETTER_CHARS}]*|<b>[^<\n]+</b>[{LETTER_CHARS}]*",
    re.IGNORECASE,
)

# HTML tags (para --html: saltar el contenido de atributos, conservar tags).
RE_HTML_TAG = re.compile(r"<[^>]+>")


def is_excludable(token: str) -> bool:
    if RE_HAS_DIGIT.search(token):
        return True
    if RE_URL.fullmatch(token) or RE_PATH.fullmatch(token):
        return True
    if RE_HEX.fullmatch(token) or RE_ID_TICKET.fullmatch(token):
        return True
    if RE_ENV_VAR.fullmatch(token):
        return True
    return False


def bold_word(word: str, use_html: bool) -> str:
    """Bold ceil(N/2) letras del prefijo si N >= 3, no es stopword ni acrónimo."""
    if len(word) < 3:
        return word
    if word.lower() in STOPWORDS:
        return word
    # Acrónimos cortos all-uppercase (RFC, SEO, URL, API, MODO, JSON) — no boldear.
    if len(word) <= 4 and word.isupper():
        return word
    k = math.ceil(len(word) / 2)
    prefix, suffix = word[:k], word[k:]
    if use_html:
        return f"<b>{prefix}</b>{suffix}"
    return f"**{prefix}**{suffix}"


def transform_prose(text: str, use_html: bool) -> str:
    """Aplica bionic a 'prose': respeta tokens excluibles, palabras ya boldeadas,
    inline code, y exclusiones por regex sobre el token completo."""

    # Paso 1: proteger zonas que NO tocamos (inline code + ya-bold + html tags si HTML).
    # Placeholder con caracteres Unicode Private Use Area: no matchea ninguna regex
    # (no es letra, ni dígito, ni símbolo común) y no se vuelve a protegerse a sí mismo.
    protected: list[tuple[str, str]] = []
    placeholder = lambda i: f"{i}"

    def protect(pat: re.Pattern) -> None:
        nonlocal text
        def repl(m):
            idx = len(protected)
            protected.append((placeholder(idx), m.group(0)))
            return placeholder(idx)
        text = pat.sub(repl, text)

    # Orden: code/bold primero (capturan bloques completos), luego HTML tags
    # restantes (para que </p> no sea canibalizado por RE_PATH), luego el resto.
    protect(RE_INLINE_CODE)
    protect(RE_ALREADY_BOLD)
    if use_html:
        protect(RE_HTML_TAG)
    protect(RE_URL)
    protect(RE_PATH)
    protect(RE_HEX)
    protect(RE_ID_TICKET)
    protect(RE_ENV_VAR)

    # Paso 2: procesar token-por-token. Un "token raw" = secuencia alfabética
    # con posible prefijo/sufijo no-alfabético dentro de una "palabra wider".
    def repl_word(m: re.Match) -> str:
        word = m.group(0)
        # mirar entorno cercano: si el contexto sugiere que es parte de un token con dígito/símbolo,
        # bail. Esto cubre p.ej. "v1.2.3" donde "v" matchea solo pero el contexto descalifica.
        start, end = m.span()
        prev = text[start - 1] if start > 0 else ""
        nxt = text[end] if end < len(text) else ""
        if prev.isdigit() or nxt.isdigit():
            return word
        if (prev and prev in "/_-.") or (nxt and nxt in "/_-."):
            return word
        return bold_word(word, use_html)

    text = RE_WORD.sub(repl_word, text)

    # Paso 3: restaurar protected.
    for ph, original in protected:
        text = text.replace(ph, original)

    return text


def transform_text(text: str, use_html: bool) -> str:
    """Procesa línea por línea, salteando bloques de código fenced."""
    out: list[str] = []
    in_fence = False
    fence_marker = ""
    for line in text.splitlines(keepends=True):
        stripped = line.rstrip("\n")
        m = RE_CODE_FENCE_OPEN.match(stripped)
        if m:
            marker = m.group(1)
            if not in_fence:
                in_fence = True
                fence_marker = marker
            elif marker == fence_marker:
                in_fence = False
                fence_marker = ""
            out.append(line)
            continue
        if in_fence:
            out.append(line)
            continue
        # línea de prose
        nl = "\n" if line.endswith("\n") else ""
        out.append(transform_prose(stripped, use_html) + nl)
    return "".join(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("file", nargs="?", help="Archivo a transformar. Si se omite, lee de stdin.")
    parser.add_argument("--html", action="store_true", help="Salida HTML (<b>…</b>) en vez de markdown (**…**).")
    parser.add_argument("--check", action="store_true", help="Muestra diff y no escribe.")
    parser.add_argument("--write", action="store_true", help="Sobrescribe el archivo de entrada (no usar con stdin).")
    args = parser.parse_args()

    if args.file:
        src = Path(args.file)
        if not src.exists():
            print(f"ERROR: no existe {src}", file=sys.stderr)
            return 1
        original = src.read_text(encoding="utf-8")
    else:
        if args.write:
            print("ERROR: --write requiere archivo, no stdin.", file=sys.stderr)
            return 1
        original = sys.stdin.read()

    transformed = transform_text(original, use_html=args.html)

    if args.check:
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            transformed.splitlines(keepends=True),
            fromfile="original",
            tofile="bionic",
            n=2,
        )
        sys.stdout.writelines(diff)
        return 0

    if args.write:
        src.write_text(transformed, encoding="utf-8")
        print(f"escrito: {src}", file=sys.stderr)
        return 0

    sys.stdout.write(transformed)
    return 0


if __name__ == "__main__":
    sys.exit(main())
