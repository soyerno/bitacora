#!/usr/bin/env python3
"""modo-nocturno · orquestador del loop overnight read-only.

Lo invoca el LaunchAgent de noche. Corre cada source habilitado (READ-ONLY),
escribe findings, dispara la síntesis encajonada (claude -p), arma el reporte
matutino y notifica. SIEMPRE exit 0 (no rompe el cron por un fallo parcial).

Implementado en Python — NO bash — por el TCC trap de macOS: un LaunchAgent que
toca ~/Documents/ con /bin/bash devuelve 0 resultados en silencio. Python tiene
el grant TCC heredado. Ver memoria reference_bitacora_deck_audit_cron.

Modos:
  (default)        run completo: gather + synth + report + notif
  --no-synth       gather + report, sin LLM (dry-run barato para testear)
  --list-sources   lista sources descubiertos y su estado enabled
  --review         imprime el path del último reporte + cola pendiente
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR / "scripts"))

from sources import discover_sources  # noqa: E402
from report import build_report  # noqa: E402
from synthesize import run_synthesis  # noqa: E402

CONFIG_PATH = SKILL_DIR / "config.json"
# runs/ vive FUERA de ~/.claude/skills a propósito (audit 2026-05-26): contiene
# transcripts/mensajes en texto plano y no debe entrar al árbol de skills (que
# se empaqueta y publica vía erno-modo-sync-all).
DATA_DIR = Path.home() / ".nocturno-data"
RUNS_DIR = DATA_DIR / "runs"


def load_config() -> dict:
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    return {}


def notify(title: str, msg: str) -> None:
    # escapar comillas/backslashes — msg puede incluir repr(e) con caracteres raros
    def esc(s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"')
    try:
        subprocess.run(
            ["/usr/bin/osascript", "-e",
             f'display notification "{esc(msg)}" with title "{esc(title)}"'],
            capture_output=True, timeout=10,
        )
    except Exception:  # noqa: BLE001
        pass


def cmd_list_sources(cfg: dict) -> int:
    enabled = cfg.get("sources", {})
    for name, src in sorted(discover_sources().items()):
        on = enabled.get(name, src.default_enabled)
        send = "CAN_SEND" if src.can_send else "read-only"
        print(f"{'[x]' if on else '[ ]'} {name:14} {send}")
    return 0


def cmd_review(cfg: dict) -> int:
    report_dir = Path(cfg.get("report_dir", str(Path.home() / "Documents" / "Reports")))
    reports = sorted(report_dir.glob("overnight-*/index.md"), reverse=True)
    if not reports:
        print("Sin reportes nocturnos todavía.")
        return 0
    latest = reports[0]
    print(f"Último reporte: {latest}")
    pending = list((latest.parent / "pending").glob("*.md"))
    print(f"Propuestas en cola: {len(pending)}")
    for p in pending:
        print(f"  - {p.name}")
    return 0


def run(cfg: dict, do_synth: bool) -> int:
    enabled = cfg.get("sources", {})
    mem_dir = cfg.get("mem_dir", "")
    report_dir = Path(cfg.get("report_dir", str(Path.home() / "Documents" / "Reports")))

    stamp = time.strftime("%Y%m%d-%H%M%S")
    run_dir = RUNS_DIR / stamp
    findings_dir = run_dir / "findings"
    findings_dir.mkdir(parents=True, exist_ok=True)

    ctx = {
        "workdir": str(SKILL_DIR),
        "run_dir": str(run_dir),
        "mem_dir": mem_dir,
        "config": cfg,
    }

    written: list = []
    sources = discover_sources()
    for name, src in sorted(sources.items()):
        if not enabled.get(name, src.default_enabled):
            continue
        try:
            result = src.gather(ctx)
        except Exception as e:  # noqa: BLE001 — un source no puede tumbar el run
            from sources import SourceResult
            result = SourceResult(name, ok=False, errors=[f"crash: {e!r}"])
        fname = f"{name}.json"
        (findings_dir / fname).write_text(
            json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        written.append(fname)

    (findings_dir / "index.json").write_text(
        json.dumps(written, ensure_ascii=False), encoding="utf-8",
    )

    # Síntesis (encajonada). --no-synth la saltea.
    synth = {"skipped": True, "reason": "--no-synth"}
    if do_synth:
        synth_cfg = cfg.get("synthesis", {})
        if synth_cfg.get("enabled", True):
            synth = run_synthesis(
                run_dir,
                float(synth_cfg.get("max_budget_usd", 2.0)),
                synth_cfg.get("model", ""),
            )

    report_path = build_report(run_dir, report_dir, synth)

    n_props = synth.get("proposals", 0) if not synth.get("skipped") else 0
    # status file = alerting robusto (la notif osascript puede no aparecer a las 3am)
    (DATA_DIR / "LAST_RUN_STATUS.json").write_text(json.dumps({
        "ts": stamp, "sources": len(written), "proposals": n_props,
        "report": str(report_path),
        "synth": {k: synth.get(k) for k in ("ok", "skipped", "reason", "cost_usd", "permission_denials")},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    notify("MODO · Nocturno",
           f"{len(written)} fuentes · {n_props} propuestas en cola — revisá el reporte")
    print(str(report_path))
    return 0


def main(argv: list) -> int:
    cfg = load_config()
    if "--list-sources" in argv:
        return cmd_list_sources(cfg)
    if "--review" in argv:
        return cmd_review(cfg)
    do_synth = "--no-synth" not in argv
    try:
        return run(cfg, do_synth)
    except Exception as e:  # noqa: BLE001
        notify("MODO · Nocturno", f"Run falló: {e!r}")
        print(f"ERROR: {e!r}", file=sys.stderr)
        return 0  # exit 0 igual — no romper el cron


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
