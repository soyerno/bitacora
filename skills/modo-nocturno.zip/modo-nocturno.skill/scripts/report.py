"""Arma el reporte matutino que el humano revisa al despertar.

Cruza findings/*.json + pending/*.md → un index.md con:
  - resumen por source (ok/errores/duración)
  - findings agrupados por risk
  - cola de propuestas (drafts) con checklist de aprobación
Todo READ-ONLY sobre el run; el reporte vive en ~/Documents/Reports/overnight-<fecha>/.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

RISK_ICON = {"high": "🔴", "med": "🟡", "low": "⚪"}


def build_report(run_dir: Path, report_dir: Path, synth: dict) -> Path:
    findings_dir = run_dir / "findings"
    pending_dir = run_dir / "pending"
    date = time.strftime("%Y-%m-%d")
    out_dir = report_dir / f"overnight-{date}"
    out_dir.mkdir(parents=True, exist_ok=True)

    sources: list = []
    all_findings: list = []
    index = findings_dir / "index.json"
    if index.exists():
        for entry in json.loads(index.read_text()):
            fp = findings_dir / entry
            if not fp.exists():
                continue
            data = json.loads(fp.read_text())
            sources.append(data)
            for f in data.get("findings", []):
                all_findings.append(f)

    proposals = sorted(pending_dir.glob("*.md")) if pending_dir.exists() else []

    lines: list = []
    lines.append(f"# Nocturno · {date}")
    lines.append("")
    lines.append("Loop overnight read-only. **Nada fue aplicado ni enviado** — esto es una cola para tu review.")
    lines.append("")

    # Síntesis
    if synth.get("skipped"):
        lines.append(f"> Síntesis LLM: omitida ({synth.get('reason', '?')}).")
    else:
        cost = synth.get("cost_usd")
        lines.append(f"> Síntesis LLM: {'ok' if synth.get('ok') else 'con errores'} · "
                     f"propuestas: {synth.get('proposals', 0)} · "
                     f"costo: {f'${cost:.4f}' if isinstance(cost, (int, float)) else '?'}")
    lines.append("")

    # Resumen por source
    lines.append("## Fuentes")
    lines.append("")
    lines.append("| Source | OK | Findings | Errores | Duración |")
    lines.append("|---|---|---|---|---|")
    for s in sources:
        lines.append(f"| {s['source']} | {'✅' if s['ok'] else '❌'} | "
                     f"{len(s['findings'])} | {len(s['errors'])} | {s['duration_s']}s |")
    lines.append("")

    # Errores (si hay)
    errs = [(s["source"], e) for s in sources for e in s.get("errors", [])]
    if errs:
        lines.append("### Errores de fuentes")
        lines.append("")
        for src, e in errs:
            lines.append(f"- `{src}`: {e}")
        lines.append("")

    # Findings por risk
    by_risk = {"high": [], "med": [], "low": []}
    for f in all_findings:
        by_risk.get(f.get("risk", "low"), by_risk["low"]).append(f)
    lines.append("## Findings")
    lines.append("")
    for risk in ("high", "med", "low"):
        items = by_risk[risk]
        if not items:
            continue
        lines.append(f"### {RISK_ICON[risk]} {risk} ({len(items)})")
        lines.append("")
        for f in items:
            ev = f.get("evidence", "")
            ev_str = f" · `{ev}`" if ev else ""
            lines.append(f"- **{f['title']}** ({f['source']}){ev_str}")
            if f.get("suggested_action"):
                lines.append(f"  - → {f['suggested_action']}")
        lines.append("")

    # Cola de propuestas
    lines.append("## Cola de propuestas (requieren tu aprobación)")
    lines.append("")
    if not proposals:
        lines.append("_Sin propuestas drafteadas este run._")
    else:
        # copiar pending al report dir para tenerlo junto
        prop_out = out_dir / "pending"
        prop_out.mkdir(exist_ok=True)
        for p in proposals:
            shutil.copy2(p, prop_out / p.name)
            lines.append(f"- [ ] `{p.name}` — ver `pending/{p.name}`")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append(f"_Generado por `modo-nocturno` · run `{run_dir.name}` · "
                 f"aplicar con `/nocturno-review` (o revisión manual)._")

    report_path = out_dir / "index.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path
