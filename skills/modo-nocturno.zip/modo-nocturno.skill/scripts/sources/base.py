"""Source ABC + tipos compartidos para modo-nocturno.

Contrato de cada source:
  - READ-ONLY. Junta señales del día y devuelve un SourceResult.
  - NUNCA escribe fuera de su findings.json.
  - NUNCA manda nada outward (mail, WhatsApp, push, PR). `can_send` queda False
    en v1 por diseño — el send lo hace el humano despierto, post-review.
  - Tolerante a fallo parcial: si revienta, devuelve ok=False + errors[] y el
    orquestador sigue con los demás (lección gh-graphql-bulk: exit≠0 ≠ no data).
"""
from __future__ import annotations

import hashlib
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field


@dataclass
class Finding:
    source: str
    kind: str
    title: str
    detail: str = ""
    evidence: str = ""          # path o quote que respalda el finding
    suggested_action: str = ""
    risk: str = "low"           # low | med | high

    @property
    def id(self) -> str:
        h = hashlib.sha1(f"{self.source}:{self.kind}:{self.title}".encode()).hexdigest()[:10]
        return f"{self.source}.{self.kind}.{h}"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["id"] = self.id
        return d


@dataclass
class SourceResult:
    source: str
    ok: bool = True
    findings: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    duration_s: float = 0.0

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "ok": self.ok,
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "duration_s": round(self.duration_s, 2),
            "errors": self.errors,
            "findings": [f.to_dict() for f in self.findings],
        }


class Source(ABC):
    name: str = "base"
    default_enabled: bool = True
    can_send: bool = False   # invariante v1: ningún source envía outward

    @abstractmethod
    def gather(self, ctx: dict) -> SourceResult:
        """ctx: {workdir, run_dir, mem_dir, config}. Devuelve SourceResult."""
        ...
