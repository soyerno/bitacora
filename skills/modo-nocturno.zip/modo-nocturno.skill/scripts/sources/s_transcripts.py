"""Source: transcripts. Mina las sesiones de Claude Code del día.

Lee los *.jsonl de ~/.claude/projects/*/ modificados en las últimas 24h, extrae
los turnos del HUMANO (señal concisa de intención) + nombres de tools usadas, y
arma un digest compacto por sesión. La síntesis (LLM) decide qué de esto merece
destilarse a SKILL.md/memoria — acá solo juntamos material acotado por budget.

NO lee el contenido completo (puede ser enorme). Cap de sesiones + chars por
config para no inflar el costo del paso de síntesis.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .base import Finding, Source, SourceResult

PROJECTS = Path.home() / ".claude" / "projects"


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text" and block.get("text"):
                    out.append(block["text"])
                elif block.get("type") == "tool_use" and block.get("name"):
                    out.append(f"[tool:{block['name']}]")
        return " ".join(out)
    return ""


def _digest_session(path: Path, max_chars: int) -> str:
    user_turns: list = []
    tools: dict = {}
    try:
        with path.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = ev.get("message") or {}
                role = msg.get("role") or ev.get("type")
                content = msg.get("content")
                if role == "user" and content is not None:
                    txt = _extract_text(content).strip()
                    if txt and not txt.startswith("[tool:") and "tool_result" not in str(content)[:40]:
                        user_turns.append(txt)
                elif role == "assistant" and isinstance(content, list):
                    for b in content:
                        if isinstance(b, dict) and b.get("type") == "tool_use":
                            n = b.get("name", "?")
                            tools[n] = tools.get(n, 0) + 1
    except Exception:  # noqa: BLE001
        return ""
    if not user_turns:
        return ""
    tool_summary = ", ".join(f"{k}×{v}" for k, v in sorted(tools.items(), key=lambda x: -x[1])[:8])
    body = "\n".join(f"- {t[:300]}" for t in user_turns[:20])
    digest = f"Tools: {tool_summary or '—'}\nTurnos del humano:\n{body}"
    return digest[:max_chars]


class TranscriptsSource(Source):
    name = "transcripts"

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        cfg = (ctx.get("config") or {}).get("transcripts", {})
        max_sessions = int(cfg.get("max_sessions", 15))
        max_chars = int(cfg.get("max_chars_per_session", 3000))
        cutoff = time.time() - 24 * 3600
        if not PROJECTS.exists():
            r.ok = False
            r.errors.append(f"no existe {PROJECTS}")
            r.duration_s = time.time() - t0
            return r
        try:
            recent = [
                p for p in PROJECTS.glob("*/*.jsonl")
                if p.stat().st_mtime >= cutoff
            ]
            recent.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            for p in recent[:max_sessions]:
                digest = _digest_session(p, max_chars)
                if not digest:
                    continue
                proj = p.parent.name
                r.findings.append(Finding(
                    source=self.name, kind="session",
                    title=f"Sesión {p.stem[:8]} · {proj[-40:]}",
                    detail=digest, evidence=str(p), risk="low",
                    suggested_action="Si hay aprendizaje genérico/decisión técnica reusable → draftear destilado a skill/memoria.",
                ))
            if not recent:
                r.findings.append(Finding(
                    source=self.name, kind="none",
                    title="Sin sesiones en 24h", detail="", risk="low",
                ))
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
