"""Registry de sources — descubre automáticamente todo módulo `s_*.py`.

Agregar una fuente nueva ("mails, slacks y creciendo") = soltar un archivo
`s_<algo>.py` con una subclase de Source acá. Cero cambios en el orquestador.
"""
from __future__ import annotations

import importlib
import pkgutil

from .base import Finding, Source, SourceResult  # noqa: F401  (re-export)


def discover_sources() -> dict:
    """Instancia toda subclase de Source en módulos s_*.py de este paquete."""
    found: dict = {}
    for mod in pkgutil.iter_modules(__path__):
        if not mod.name.startswith("s_"):
            continue
        m = importlib.import_module(f"{__name__}.{mod.name}")
        for attr in dir(m):
            obj = getattr(m, attr)
            if isinstance(obj, type) and issubclass(obj, Source) and obj is not Source:
                inst = obj()
                found[inst.name] = inst
    return found
