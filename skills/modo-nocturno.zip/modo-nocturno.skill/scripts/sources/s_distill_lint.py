"""Source: distill-lint. Audita el knowledge base destilado (memorias + skills).

Reusa el script existente `~/.claude/skills/distill-lint/scripts/lint.sh`
(read-only, emite REPORT.md). Parsea la tabla resumen → un Finding por check
con hallazgos > 0, y adjunta el path del reporte completo.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path

from .base import Finding, Source, SourceResult

LINT = Path.home() / ".claude" / "skills" / "distill-lint" / "scripts" / "lint.sh"
ROW = re.compile(r"^\|\s*(.+?)\s*\|\s*(\d+)\s*\|$")


class DistillLintSource(Source):
    name = "distill_lint"

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        if not LINT.exists():
            r.ok = False
            r.errors.append(f"lint.sh ausente: {LINT}")
            r.duration_s = time.time() - t0
            return r

        env = dict(os.environ)
        if ctx.get("mem_dir"):
            env["MEM_DIR"] = ctx["mem_dir"]
        env["OUT"] = str(Path(ctx["run_dir"]) / "distill-lint-out")
        try:
            p = subprocess.run(
                ["bash", str(LINT)],
                capture_output=True, text=True, env=env, timeout=120,
            )
            report_path = ""
            if p.stdout.strip():
                report_path = p.stdout.strip().splitlines()[-1]
            if not (report_path and Path(report_path).exists()):
                r.ok = False
                r.errors.append("lint.sh no devolvió path de reporte válido")
                r.duration_s = time.time() - t0
                return r

            txt = Path(report_path).read_text(encoding="utf-8", errors="replace")
            for line in txt.splitlines():
                m = ROW.match(line.strip())
                if not m:
                    continue
                label, count = m.group(1), int(m.group(2))
                if label.lower().startswith("check") or count == 0:
                    continue
                risk = "med" if any(k in label.lower() for k in ("dead", "orphan entr", "contrad")) else "low"
                r.findings.append(Finding(
                    source=self.name, kind="kb_hygiene",
                    title=f"{label}: {count}",
                    detail=f"{count} hallazgo(s) de tipo '{label}' en el knowledge base.",
                    evidence=report_path, risk=risk,
                    suggested_action="Revisar REPORT.md; draftear fix de orphans/dead-refs/cross-refs para aprobación.",
                ))
            if not r.findings:
                r.findings.append(Finding(
                    source=self.name, kind="kb_clean",
                    title="Knowledge base limpio",
                    detail="Sin orphans/stale/dead-refs/contradicciones.",
                    evidence=report_path, risk="low",
                    suggested_action="Nada que hacer.",
                ))
        except subprocess.TimeoutExpired:
            r.ok = False
            r.errors.append("lint.sh timeout (>120s)")
        except Exception as e:  # noqa: BLE001 — tolerancia a fallo parcial
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
