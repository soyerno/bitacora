"""Source: skill_forge. Detecta FALLAS RECURRENTES en los transcripts.

Inspirado en el skill-forge de Hermes Agent (NousResearch): "observa fallas,
detecta patrones, y genera skills para cubrir casos futuros". Acá la versión
honesta y read-only:

  1. Escanea los *.jsonl de ~/.claude/projects/ de los últimos N días.
  2. Junta los `tool_result` marcados `is_error` (señal limpia de falla).
  3. Normaliza cada error a una FIRMA (saca paths, hashes, números, strings) y
     lo clusterea por clase (command-not-found, module-not-found, lint, test,
     auth, timeout, etc.).
  4. Cuando una firma aparece en ≥ `min_recurrence` SESIONES DISTINTAS, emite un
     Finding: "esto te falla seguido — draftear skill/regla que lo prevenga".

Diferencia con `s_transcripts`: ese digiere sesiones (trigger = aprendizaje/
éxito, lo decide la síntesis). Este dispara por FALLA REPETIDA — el trigger que
`distill-learnings` (human-gated, success-driven) no tiene. La síntesis convierte
el Finding en un skill-candidate a `pending/`; el humano lo aprueba despierto.

READ-ONLY. `can_send = False`. No escribe nada: devuelve SourceResult y el
orquestador serializa. Cap de sesiones + chars por config (budget del synth).
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

from .base import Finding, Source, SourceResult

PROJECTS = Path.home() / ".claude" / "projects"

# clase legible por regex sobre el texto del error (primer match gana)
CLASSES = [
    (r"command not found|not recognized", "command-not-found"),
    (r"no such file or directory|enoent", "file-not-found"),
    (r"permission denied|eacces|eperm", "permission-denied"),
    (r"modulenotfounderror|cannot find module|module not found", "module-not-found"),
    (r"typeerror", "type-error"),                      # antes que el heurístico TS
    (r"referenceerror|is not defined", "reference-error"),
    (r"ts\d{3,4}\b|is not assignable|type '.*?' is not", "ts-error"),
    (r"eslint|lint(ing)? (error|fail)", "lint-error"),
    (r"\b\d+ (failed|failing)\b|test.*fail|fail.*test|✕|✗|assertionerror", "test-failure"),
    (r"timeout|timed out|etimedout", "timeout"),
    (r"econnrefused|connection refused|enotfound|getaddrinfo", "network-error"),
    (r"\b401\b|\b403\b|unauthorized|forbidden|authentication failed|failed to authenticate", "auth-error"),
    (r"merge conflict|conflict in|both modified", "merge-conflict"),
    (r"syntaxerror|unexpected token|parse error", "syntax-error"),
]

# líneas de error "informativas" para elegir el seed de la firma
_INFORMATIVE = re.compile(
    r"error|traceback|exception|fail|not found|cannot|denied|refused|unexpected|assert",
    re.IGNORECASE,
)
# banners de test-runner (`==== 1 failed in 0.3s ====`): matchean "fail" pero no
# son la línea de error — se excluyen del seed para no firmar sobre el resumen.
_BANNER = re.compile(r"={4,}|-{4,}|\*{4,}")

# ruido harness/meta y transitorio: NO son fallas de dev sino mecánica del loop
# del agente (Edit antes de Read, etc.) o infra efímera. No ameritan skill.
_NOISE = re.compile(
    r"tool_use_error"
    r"|file has not been read"
    r"|file has been modified since read"
    r"|file does not exist"
    r"|string to replace not found|no changes to make"
    r"|temporarily unavailable|auto mode cannot determine"
    r"|rate.?limit|overloaded|please try again|try this action again"
    # decisiones del humano / safety, NO fallas: el user canceló o auto-mode negó
    r"|user doesn't want to proceed|tool use was rejected|user rejected"
    r"|permission for this action was denied|denied by the claude code"
    r"|agent type \S+ not found",
    re.IGNORECASE,
)

# firmas que tras normalizar quedan sin sustancia accionable
_GENERIC = {"", "error", "fail", "failed", "<n>", "exit code <n>", "exit status <n>"}

# fricción del humano: correcciones/frustración en turnos del humano. Lexicón
# CURADO y multi-palabra a propósito — un "no" suelto es ruido; "ya te dije" /
# "sigue sin andar" / "i told you" son señal de que el agente falló sin que haya
# is_error. NO se clusterea el texto libre (ruidoso): se cuenta densidad por
# sesión y se atribuye al contexto (qué hacía el agente antes).
_FRUSTRATION = re.compile(
    r"\bya te dije\b|\bte dije\b|no es eso|no era eso|eso est[áa] mal|\bestá mal\b"
    r"|no funciona|sigue (sin|igual|fallando|roto|mal)|no anda|no era as[íi]"
    r"|otra vez (lo )?mismo|de nuevo (lo )?mismo|no entendiste|no es as[íi]"
    r"|te equivocaste|no hagas eso|no quiero que|por qu[ée] (hiciste|borraste)"
    r"|te dije que no|eso no era|mal ah[íi]"
    r"|i told you|that'?s wrong|that'?s not (it|what)|still (broken|not work)"
    r"|does ?n'?t work|not working|you broke|stop doing that|wrong again",
    re.IGNORECASE,
)


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text" and block.get("text"):
                out.append(block["text"])
            elif isinstance(block, str):
                out.append(block)
        return "\n".join(out)
    return ""


def _seed_line(text: str) -> str:
    """Línea más informativa del error. En multi-línea elige la ÚLTIMA
    informativa: la excepción de un traceback y el resumen de stderr burbujean
    al final (`ModuleNotFoundError: ...`, `error: ...`), no el header
    (`Traceback (most recent call last):`). Fallback: primera línea no vacía."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return ""
    informative = [ln for ln in lines if _INFORMATIVE.search(ln) and not _BANNER.search(ln)]
    if informative:
        return informative[-1]
    return lines[0]


def _normalize(line: str) -> str:
    """Firma estable: borra todo lo volátil para que el mismo error en sesiones
    distintas colapse a la misma key."""
    t = line.lower()
    # colapsar el nombre del binario faltante → un solo cluster "command not
    # found: <cmd>" (node/gh/docker recurren como CLASE: binario fuera de PATH).
    t = re.sub(r"command not found:?\s*\S+", "command not found: <cmd>", t)
    t = re.sub(r"\S+: command not found", "<cmd>: command not found", t)
    t = re.sub(r"/[^\s:'\"]+", "<path>", t)            # paths absolutos
    t = re.sub(r"\b[0-9a-f]{7,40}\b", "<hash>", t)      # sha/hex
    t = re.sub(r"\b\d+(?:\.\d+)?", "<n>", t)            # enteros y floats (sin \b final: '0.3s')
    t = re.sub(r"[\"'][^\"']*[\"']", "<str>", t)        # literales entre comillas
    t = re.sub(r"\s+", " ", t).strip()
    return t[:160]


def _classify(text: str) -> str:
    low = text.lower()
    for pat, label in CLASSES:
        if re.search(pat, low):
            return label
    return "error"


def _scan_session(path: Path, max_err_chars: int) -> dict:
    """Escanea una sesión y devuelve:
      {"errors": {firma: {class,tool,sample}},   # is_error, 1× por firma/sesión
       "friction": int,                          # turnos del humano con corrección
       "pairs": [(frase_humano, contexto_agente)]}  # hasta 5, para el synth

    Errores → clustering cross-sesión. Fricción → densidad por-sesión + atribución
    al contexto (qué hacía el agente justo antes de la corrección)."""
    sigs: dict = {}
    tool_names: dict = {}  # tool_use_id -> nombre de la tool
    friction = 0
    pairs: list = []
    last_ctx = "—"         # contexto de la última acción del agente
    try:
        with path.open(encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    ev = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                msg = ev.get("message") or {}
                role = msg.get("role") or ev.get("type")
                content = msg.get("content")

                # turno de TEXTO del humano (no tool_result, no sintético) →
                # fricción. isMeta/isCompactSummary = inyecciones del harness
                # (cuerpo de un Skill, resumen de compactación), NO el humano.
                if role == "user" and not ev.get("isMeta") and not ev.get("isCompactSummary"):
                    has_tr = isinstance(content, list) and any(
                        isinstance(b, dict) and b.get("type") == "tool_result" for b in content
                    )
                    if not has_tr:
                        txt = _extract_text(content).strip()
                        if txt and not txt.startswith("[tool:") and _FRUSTRATION.search(txt):
                            friction += 1
                            if len(pairs) < 5:
                                pairs.append((txt[:120], last_ctx[:100]))

                if not isinstance(content, list):
                    continue
                # contexto del agente: última tool usada (o texto) antes de una corrección
                if role == "assistant":
                    tools_here = [
                        b.get("name") for b in content
                        if isinstance(b, dict) and b.get("type") == "tool_use" and b.get("name")
                    ]
                    if tools_here:
                        last_ctx = "tool:" + ",".join(tools_here[:3])
                    else:
                        atxt = _extract_text(content).strip()
                        if atxt:
                            last_ctx = atxt[:100]
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    btype = block.get("type")
                    if btype == "tool_use" and block.get("id"):
                        tool_names[block["id"]] = block.get("name", "?")
                    elif btype == "tool_result" and block.get("is_error"):
                        err = _extract_text(block.get("content"))[:max_err_chars].strip()
                        if not err or _NOISE.search(err):
                            continue
                        seed = _seed_line(err)
                        if not seed:
                            continue
                        sig = _normalize(seed)
                        if not sig or sig in _GENERIC or sig in sigs:
                            continue
                        sigs[sig] = {
                            "class": _classify(err),
                            "tool": tool_names.get(block.get("tool_use_id"), "?"),
                            "sample": seed[:200],
                        }
    except Exception:  # noqa: BLE001 — una sesión corrupta no tumba el scan
        return {"errors": {}, "friction": 0, "pairs": []}
    return {"errors": sigs, "friction": friction, "pairs": pairs}


class SkillForgeSource(Source):
    name = "skill_forge"

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        cfg = (ctx.get("config") or {}).get("skill_forge", {})
        lookback_days = int(cfg.get("lookback_days", 7))
        max_sessions = int(cfg.get("max_sessions", 150))
        min_recurrence = int(cfg.get("min_recurrence", 3))
        max_findings = int(cfg.get("max_findings", 8))
        max_err_chars = int(cfg.get("max_err_chars", 1200))
        cutoff = time.time() - lookback_days * 86400

        if not PROJECTS.exists():
            r.ok = False
            r.errors.append(f"no existe {PROJECTS}")
            r.duration_s = time.time() - t0
            return r

        # firma -> {sessions:set, class, tool, samples:[(stem,line)], paths:[]}
        clusters: dict = {}
        def _mtime(p: Path) -> float:
            try:  # un .jsonl rotado/borrado entre glob y stat no debe tumbar el scan
                return p.stat().st_mtime
            except OSError:
                return 0.0

        friction_sessions: list = []  # (count, stem, path, pairs)
        try:
            recent = [p for p in PROJECTS.glob("*/*.jsonl") if _mtime(p) >= cutoff]
            recent.sort(key=_mtime, reverse=True)
            for p in recent[:max_sessions]:
                res = _scan_session(p, max_err_chars)
                for sig, meta in res["errors"].items():
                    c = clusters.setdefault(sig, {
                        "sessions": set(), "class": meta["class"],
                        "tool": meta["tool"], "samples": [], "paths": [],
                    })
                    c["sessions"].add(p.stem)
                    if len(c["samples"]) < 3:
                        c["samples"].append(meta["sample"])
                        c["paths"].append(str(p))
                if res["friction"]:
                    friction_sessions.append((res["friction"], p.stem, str(p), res["pairs"]))
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
            r.duration_s = time.time() - t0
            return r

        recurring = sorted(
            ((sig, c) for sig, c in clusters.items() if len(c["sessions"]) >= min_recurrence),
            key=lambda kv: len(kv[1]["sessions"]), reverse=True,
        )[:max_findings]

        for sig, c in recurring:
            n = len(c["sessions"])
            samples = "\n".join(f"- {s}" for s in c["samples"])
            r.findings.append(Finding(
                source=self.name, kind="recurring_failure",
                title=f"Falla recurrente ×{n} sesiones · {c['class']}",
                detail=(
                    f"Firma normalizada: `{sig}`\n"
                    f"Clase: {c['class']} · Tool: {c['tool']} · Sesiones distintas: {n}\n"
                    f"Muestras:\n{samples}"
                ),
                evidence="; ".join(c["paths"]),
                risk="med",
                suggested_action=(
                    f"Esta falla ({c['class']}) se repitió en {n} sesiones distintas. "
                    "Draftear un skill-candidate / regla / memoria que la prevenga o la "
                    "resuelva de una: qué la dispara, cómo evitarla, fix canónico."
                ),
            ))

        # Fricción del humano: por-sesión (densidad), NO cross-sesión. El texto
        # libre no clusterea limpio → reporto las sesiones más ásperas con sus
        # pares «corrección ← qué hacía el agente» para que el synth infiera el
        # patrón evitable sin re-leer la sesión.
        friction_min = int(cfg.get("friction_min", 4))
        max_friction = int(cfg.get("max_friction_findings", 3))
        rough = sorted(
            (s for s in friction_sessions if s[0] >= friction_min), reverse=True,
        )[:max_friction]
        for count, stem, path, pairs in rough:
            samples = "\n".join(f"- «{ph}»  ← tras {ctx}" for ph, ctx in pairs)
            r.findings.append(Finding(
                source=self.name, kind="friction",
                title=f"Sesión con fricción alta ×{count} · {stem[:8]}",
                detail=(
                    f"El humano corrigió/objetó {count} veces en esta sesión.\n"
                    f"Pares corrección ← contexto del agente:\n{samples}"
                ),
                evidence=path,
                risk="med",
                suggested_action=(
                    f"{count} correcciones en una sola sesión. Mirá los pares: si hay un "
                    "patrón evitable (tool mal usada, asunción equivocada, regla ignorada), "
                    "destilá una regla/memoria que lo prevenga. Si fue one-off, descartá."
                ),
            ))

        if not recurring and not rough:
            r.findings.append(Finding(
                source=self.name, kind="none",
                title="Sin fallas recurrentes ni fricción alta en la ventana",
                detail=f"lookback={lookback_days}d · sesiones={len(recent[:max_sessions])} · umbral_err={min_recurrence} · umbral_fricción={friction_min}",
                risk="low",
            ))
        r.duration_s = time.time() - t0
        return r
