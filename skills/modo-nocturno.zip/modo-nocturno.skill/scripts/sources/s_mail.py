"""Source: Mail (stub, creciendo). NUNCA envía.

Mismo patrón que WhatsApp: read + draft, el humano manda. El MCP de Gmail vive
en la sesión Claude, no en el cron — para unattended hace falta un read
configurado (export local o API con OAuth token). Stub honesto hasta wirear.

Para activar: setear MAIL_EXPORT_PATH (JSON de últimos N mails) y completar
_read_mail(). default_enabled=False.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .base import Finding, Source, SourceResult


class MailSource(Source):
    name = "mail"
    default_enabled = False
    can_send = False

    def _read_mail(self) -> list:
        path = os.environ.get("MAIL_EXPORT_PATH")
        if path and Path(path).exists():
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
                return data if isinstance(data, list) else data.get("messages", [])
            except Exception:  # noqa: BLE001
                return []
        return []

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        if not os.environ.get("MAIL_EXPORT_PATH"):
            r.findings.append(Finding(
                source=self.name, kind="not_wired",
                title="Mail source no wireado (read-only)",
                detail="Falta MAIL_EXPORT_PATH. read+draft; nunca envía.",
                risk="low",
                suggested_action="Setear MAIL_EXPORT_PATH y completar _read_mail().",
            ))
            r.duration_s = time.time() - t0
            return r
        try:
            for m in self._read_mail():
                subj = str(m.get("subject", ""))[:120]
                frm = str(m.get("from", "?"))[:60]
                if not subj:
                    continue
                r.findings.append(Finding(
                    source=self.name, kind="inbound_mail",
                    title=f"Mail de {frm}: {subj}",
                    detail=str(m.get("snippet", ""))[:400], risk="low",
                    suggested_action="Si requiere respuesta → draftear al queue. NO enviar.",
                ))
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
