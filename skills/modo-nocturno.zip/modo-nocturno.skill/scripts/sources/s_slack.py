"""Source: Slack (stub, creciendo). NUNCA envía.

Read + draft. El MCP de Slack vive en la sesión Claude; para unattended hace
falta un read configurado. Stub honesto. default_enabled=False.

Para activar: setear SLACK_EXPORT_PATH (JSON de mentions/DMs recientes) y
completar _read_slack().
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .base import Finding, Source, SourceResult


class SlackSource(Source):
    name = "slack"
    default_enabled = False
    can_send = False

    def _read_slack(self) -> list:
        path = os.environ.get("SLACK_EXPORT_PATH")
        if path and Path(path).exists():
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
                return data if isinstance(data, list) else data.get("messages", [])
            except Exception:  # noqa: BLE001
                return []
        return []

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        if not os.environ.get("SLACK_EXPORT_PATH"):
            r.findings.append(Finding(
                source=self.name, kind="not_wired",
                title="Slack source no wireado (read-only)",
                detail="Falta SLACK_EXPORT_PATH. read+draft; nunca envía.",
                risk="low",
                suggested_action="Setear SLACK_EXPORT_PATH y completar _read_slack().",
            ))
            r.duration_s = time.time() - t0
            return r
        try:
            for m in self._read_slack():
                ch = str(m.get("channel", "?"))[:40]
                text = str(m.get("text", ""))[:400]
                if not text:
                    continue
                r.findings.append(Finding(
                    source=self.name, kind="mention",
                    title=f"Slack #{ch}",
                    detail=text, risk="low",
                    suggested_action="Si requiere respuesta → draftear al queue. NO enviar.",
                ))
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
