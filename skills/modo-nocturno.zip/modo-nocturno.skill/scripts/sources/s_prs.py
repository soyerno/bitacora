"""Source: PRs. Trabajo en vuelo en GitHub vía `gh search prs`.

Junta PRs abiertos autorados por el usuario + PRs donde le pidieron review.
Señala follow-ups olvidados (PRs viejos sin actividad). READ-ONLY: solo lee.
"""
from __future__ import annotations

import json
import subprocess
import time
from datetime import datetime, timezone

from .base import Finding, Source, SourceResult

FIELDS = "title,url,repository,updatedAt,isDraft,state"


def _gh_search(query_flag: str) -> list:
    p = subprocess.run(
        ["gh", "search", "prs", query_flag, "--state=open",
         "--limit=40", "--json", FIELDS],
        capture_output=True, text=True, timeout=60,
    )
    if p.returncode != 0:
        # tolerancia: gh puede salir ≠0 con data parcial o rate-limit
        if not p.stdout.strip():
            raise RuntimeError(p.stderr.strip()[:200] or "gh search prs falló")
    return json.loads(p.stdout) if p.stdout.strip() else []


def _stale_days(updated_at: str) -> int:
    try:
        dt = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - dt).days
    except Exception:  # noqa: BLE001
        return 0


class PRsSource(Source):
    name = "prs"

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        for label, flag in (("autorado", "--author=@me"),
                            ("review pedido", "--review-requested=@me")):
            try:
                for pr in _gh_search(flag):
                    repo = (pr.get("repository") or {}).get("nameWithOwner", "?")
                    sd = _stale_days(pr.get("updatedAt", ""))
                    risk = "med" if sd >= 7 else "low"
                    draft = " [draft]" if pr.get("isDraft") else ""
                    r.findings.append(Finding(
                        source=self.name, kind="open_pr",
                        title=f"[{label}] {repo}: {pr.get('title', '?')[:80]}{draft}",
                        detail=f"Sin actividad hace {sd} día(s).",
                        evidence=pr.get("url", ""), risk=risk,
                        suggested_action="Si está stale → draftear nudge/follow-up o nota para retomar.",
                    ))
            except Exception as e:  # noqa: BLE001
                r.errors.append(f"{label}: {e!r}")
        r.ok = not r.errors or bool(r.findings)
        r.duration_s = time.time() - t0
        return r
