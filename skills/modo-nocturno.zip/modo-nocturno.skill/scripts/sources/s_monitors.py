"""Source: monitors. Estado de servicios MODO + ecosistema.

Reusa `~/.claude/skills/modo-services-monitor/scripts/gather-all.sh` (capa
anon, sin auth). Emite un Finding con el resumen; si hay degradación, sube el
risk. READ-ONLY.
"""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

from .base import Finding, Source, SourceResult

GATHER = Path.home() / ".claude" / "skills" / "modo-services-monitor" / "scripts" / "gather-all.sh"
DEGRADE_MARKERS = ("🟡", "🟠", "🔴", "degrad", "incident", "outage", "down")


class MonitorsSource(Source):
    name = "monitors"

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        if not GATHER.exists():
            r.findings.append(Finding(
                source=self.name, kind="not_wired",
                title="modo-services-monitor no instalado",
                detail=f"Falta {GATHER}. Source inactivo hasta wirear.",
                risk="low",
                suggested_action="Instalar skill modo-services-monitor o desactivar este source en config.",
            ))
            r.duration_s = time.time() - t0
            return r
        try:
            p = subprocess.run(
                ["bash", str(GATHER)],
                capture_output=True, text=True, timeout=120,
            )
            out = (p.stdout or "") + (p.stderr or "")
            degraded = any(m in out for m in DEGRADE_MARKERS)
            r.findings.append(Finding(
                source=self.name, kind="service_status",
                title="Degradación detectada en servicios" if degraded else "Servicios OK",
                detail=out[:4000],
                risk="high" if degraded else "low",
                suggested_action="Si hay degradación con impacto MODO → draftear nota/alerta para revisar a la mañana." if degraded else "Nada que hacer.",
            ))
        except subprocess.TimeoutExpired:
            r.ok = False
            r.errors.append("gather-all.sh timeout (>120s)")
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
