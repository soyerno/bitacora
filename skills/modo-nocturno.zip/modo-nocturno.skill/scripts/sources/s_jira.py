"""Source: Jira (stub honesto). Issues asignados / en vuelo.

GAP CONOCIDO: el MCP de Atlassian solo vive dentro de una sesión Claude, no en
un cron Python. Para correr unattended necesita un API token (Basic auth
email:token contra la REST API). Mientras no esté wireado, este source emite
una nota de "not wired" en vez de fingir data.

Para activar: exportar JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN en el entorno
del LaunchAgent y reemplazar el cuerpo de _fetch() con la query JQL real.
"""
from __future__ import annotations

import os
import time

from .base import Finding, Source, SourceResult


class JiraSource(Source):
    name = "jira"
    default_enabled = False  # off hasta wirear el token

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        have_token = all(os.environ.get(k) for k in ("JIRA_BASE_URL", "JIRA_EMAIL", "JIRA_API_TOKEN"))
        if not have_token:
            r.findings.append(Finding(
                source=self.name, kind="not_wired",
                title="Jira source no wireado",
                detail="Falta JIRA_BASE_URL/JIRA_EMAIL/JIRA_API_TOKEN en el entorno del cron. "
                       "El MCP de Atlassian no corre en Python unattended.",
                risk="low",
                suggested_action="Exportar las 3 env vars en el plist y completar _fetch() con la JQL real.",
            ))
            r.duration_s = time.time() - t0
            return r
        # TODO: cuando haya token → GET /rest/api/3/search?jql=assignee=currentUser() AND statusCategory!=Done
        r.errors.append("token presente pero _fetch() no implementado todavía")
        r.duration_s = time.time() - t0
        return r
