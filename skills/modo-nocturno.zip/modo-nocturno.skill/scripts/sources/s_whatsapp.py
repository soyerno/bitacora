"""Source: WhatsApp (read + draft). NUNCA envía.

Límite acordado con el user (2026-05-26): el loop LEE mensajes para detectar
follow-ups/tareas y DRAFTEA respuestas al queue. El envío lo hace el humano
despierto, post-review. `can_send = False` es invariante — no negociable en el
cron unattended (acción outward + irreversible).

GAP CONOCIDO: leer WhatsApp requiere la sesión OpenWA del proyecto
`agente-cx-whatsapp` corriendo y exponiendo un endpoint/export de mensajes
recientes. Mientras no esté confirmado ese read endpoint, este source emite una
nota de "not wired" con el wiring exacto, en vez de fingir mensajes.

Para activar:
  1. Levantar el agente CX (skill `agente-cx-whatsapp`).
  2. Exponer GET de últimos N mensajes (o un export JSON a un path local).
  3. Setear WA_READ_ENDPOINT (url) o WA_EXPORT_PATH (archivo) en el entorno.
  4. Completar _read_messages() abajo.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .base import Finding, Source, SourceResult


class WhatsAppSource(Source):
    name = "whatsapp"
    can_send = False  # invariante: el cron jamás manda WhatsApp

    def _read_messages(self) -> list:
        """Devuelve [{from, text, ts}] de mensajes recientes. Read-only."""
        export = os.environ.get("WA_EXPORT_PATH")
        if export and Path(export).exists():
            try:
                data = json.loads(Path(export).read_text(encoding="utf-8"))
                return data if isinstance(data, list) else data.get("messages", [])
            except Exception:  # noqa: BLE001
                return []
        # TODO: si WA_READ_ENDPOINT → GET con timeout y parsear.
        return []

    def gather(self, ctx: dict) -> SourceResult:
        r = SourceResult(self.name)
        t0 = time.time()
        wired = bool(os.environ.get("WA_EXPORT_PATH") or os.environ.get("WA_READ_ENDPOINT"))
        if not wired:
            r.findings.append(Finding(
                source=self.name, kind="not_wired",
                title="WhatsApp source no wireado (read-only)",
                detail="Falta WA_EXPORT_PATH o WA_READ_ENDPOINT. El loop NUNCA envía; "
                       "solo leería para draftear respuestas al queue.",
                risk="low",
                suggested_action="Levantar agente-cx-whatsapp, exponer read endpoint, setear env var. Ver header del módulo.",
            ))
            r.duration_s = time.time() - t0
            return r
        try:
            for msg in self._read_messages():
                sender = str(msg.get("from", "?"))[:40]
                text = str(msg.get("text", ""))[:400]
                if not text:
                    continue
                r.findings.append(Finding(
                    source=self.name, kind="inbound_msg",
                    title=f"WhatsApp de {sender}",
                    detail=text, evidence=str(msg.get("ts", "")), risk="low",
                    suggested_action="Si requiere respuesta → DRAFTEAR texto al queue. NO enviar (lo manda el humano).",
                ))
        except Exception as e:  # noqa: BLE001
            r.ok = False
            r.errors.append(repr(e))
        r.duration_s = time.time() - t0
        return r
