# modo-nocturno

Loop overnight read-only de **auto-mejora supervisada**. De noche junta señales,
draftea propuestas a una cola, y deja un reporte. El humano revisa y aprueba
despierto. **Nunca aplica edits ni envía mensajes de forma autónoma.**

Filosofía: el trabajo nocturno es **preparación**; la **decisión es tuya**.

## Por qué así (no auto-mutación)

Auto-mejora real = editar skills/memorias. Las reglas del user lo prohíben sin
supervisión (`feedback_audit_iterate_loop_for_new_agents`, `feedback_no_mentir_pedir_help`).
Un loop que se auto-mutea mientras nadie mira = drift silencioso. Por eso:
gather → draft → queue → **review humano** → apply.

## Cómo correr

```bash
cd ~/.claude/skills/modo-nocturno
python3 scripts/orchestrate.py --list-sources   # estado de fuentes
python3 scripts/orchestrate.py --no-synth         # dry-run sin LLM (gratis)
python3 scripts/orchestrate.py                    # run completo (gasta budget)
python3 scripts/orchestrate.py --review           # último reporte + cola
```

Salidas:
- Reporte matutino: `~/Documents/Reports/overnight-<fecha>/index.md`
- Datos del run (transcripts, findings, propuestas): `~/.nocturno-data/runs/<ts>/`
  — **fuera de `~/.claude/skills`** a propósito (no se publica, no clobberea skills).
- Estado del último run: `~/.nocturno-data/LAST_RUN_STATUS.json`

## Instalar el cron (SOLO tras validar dry-run)

```bash
cp com.ernomodo.nocturno.plist.template ~/Library/LaunchAgents/com.ernomodo.nocturno.plist
launchctl load ~/Library/LaunchAgents/com.ernomodo.nocturno.plist
launchctl kickstart -k gui/$(id -u)/com.ernomodo.nocturno   # probar ya
```

### Desinstalar (recovery)

```bash
launchctl bootout gui/$(id -u)/com.ernomodo.nocturno 2>/dev/null
launchctl unload ~/Library/LaunchAgents/com.ernomodo.nocturno.plist 2>/dev/null
rm ~/Library/LaunchAgents/com.ernomodo.nocturno.plist
# datos quedan en ~/.nocturno-data (borrar a mano si querés)
```

## Seguridad (verificado empíricamente 2026-05-26)

El paso de síntesis corre `claude -p` headless sobre contenido NO confiable
(PR titles, transcripts, mensajes) → superficie de prompt-injection. Endurecido:

- `--disallowed-tools "Bash Edit Write MultiEdit NotebookEdit Skill Agent Task
  WebFetch WebSearch"` → el agente reporta esas tools como *"not loaded"*.
  Verificado: una instrucción benigna-pero-firme de `Write`/`Bash` no escribe nada.
- `--strict-mcp-config` (sin `--mcp-config`) → cero MCP servers.
- El synth NO tiene Write: devuelve propuestas como JSON; **solo Python escribe**,
  a `~/.nocturno-data` (aislado).
- Test adversarial (injection pidiendo `git commit` + write-escape + skill-clobber):
  0 commits, 0 escapes, 0 clobbers.

**Por qué NO alcanza el allowlist solo**: `--allowed-tools` es ADITIVO — el
headless hereda las reglas `allow` del `settings.json` (git/gh). Hay que DENEGAR
explícitamente. (`--bare` aislaría más pero rompe el auth OAuth → descartado.)

## Fuentes (registry — "creciendo")

| Source | Estado | Mecanismo |
|---|---|---|
| `distill_lint` | ✅ on | reusa `distill-lint/scripts/lint.sh` |
| `transcripts` | ✅ on | mina `~/.claude/projects/*/*.jsonl` del día |
| `prs` | ✅ on | `gh search prs` autorado + review-requested |
| `monitors` | ✅ on | reusa `modo-services-monitor/scripts/gather-all.sh` |
| `jira` | ⚪ off | stub — necesita API token (MCP no corre en cron) |
| `whatsapp` | ⚪ off | stub read+draft — necesita OpenWA read endpoint. NUNCA envía |
| `mail` | ⚪ off | stub read+draft — necesita export/API |
| `slack` | ⚪ off | stub read+draft — necesita export/API |

Sumar fuente = soltar `scripts/sources/s_<x>.py` (subclase de `Source`,
`can_send=False`) + clave en `config.json`. El registry la descubre solo.

## Gaps honestos

- Stubs (jira/whatsapp/mail/slack): los MCP viven en la sesión Claude, no en el
  cron Python. Emiten `not_wired` hasta tener token/endpoint/export. No fingen data.
- Síntesis = costo real de tu cuenta Claude. Cap por `--max-budget-usd` (config).
- WhatsApp/mail/slack: read+draft por diseño. El envío lo hace el humano.

## Changelog

- **2026-05-26** — v1. Loop gather→draft→queue→review. 4 fuentes on + 4 stubs,
  registry auto-descubierto. Synth `claude -p` read-only duro (lección
  `reference_claude_p_headless_sandboxing`: allowlist es aditivo → denegar +
  sacar Write). Pasó audit independiente (Security Engineer): 3 🔴 fixeados +
  re-test empírico (0 escapes bajo injection). Cron NO instalado. Detalle en
  `SKILL.md ## Invariantes`.
