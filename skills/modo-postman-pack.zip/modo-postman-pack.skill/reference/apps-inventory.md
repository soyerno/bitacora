# MODO Apps Inventory (canónico)

Las 9 apps MODO/playdigital que aparecen en workspace típico de un Sr AI Engineer MODO (modo-landing-workspace + integraciones). Cada una con base URL por tier y endpoints conocidos en producción.

Actualizar este archivo cuando aparezca una app nueva (vía historial Chrome o discovery).

## 00 · Members Auth (OAuth2 + Token Exchange)

| Tier | Base URL |
|------|----------|
| QA | `https://members.auth.qa.playdigital.com.ar` |
| PREPROD | `https://members.auth.preprod.playdigital.com.ar` |
| PROD | `https://members.auth.playdigital.com.ar` |

Endpoints:
- `POST /token` · grant_type=`client_credentials` → access_token M2M con scope `create:token_exchange`.
- `POST /token` · grant_type=`urn:ietf:params:oauth:grant-type:token-exchange` con `subject_token`, `subject_token_type=urn:ietf:params:oauth:token-type:access_token`, `requested_subject={user_id}` → exchange_access_token (se manda en `X-auth-application` a Rewards Handler).

Notas:
- Tenant Auth0 por banco (cada banco tiene su `client_id` / `client_secret`).
- Para llamadas a Partners/Benefits, pasar `audience={partners_auth_audience}` en CC.

## 01 · Members Auth SDK (con dev-exception)

Mismas URLs que 00. Diferencia: requests llevan header `dev-exception: <valor>` para bypass del anti-bot Cloudflare en QA/PREPROD. Valor del header NO va a archivo en git/skill — vive sólo en el env del user.

## 02 · Rewards Handler (BFF promos & landing)

| Tier | Base URL |
|------|----------|
| QA | `https://rewards-handler.qa.playdigital.com.ar` |
| PREPROD | `https://rewards-handler.preprod.playdigital.com.ar` |
| PROD | `https://rewards-handler.playdigital.com.ar` |

Endpoints conocidos (mix de observado en historial + Swagger en `/docs/#/`):
- `GET /banks/sdk` — devuelve bank hub id del cliente.
- `GET /banks` — lista de bancos disponibles.
- `GET /banks/{bank_hub_id}/promos` — promos del banco.
- `GET /landing/{slug}?source=web_modo|webview_sdk` — landing page completa de una promo (hero + bancos + comercios + T&C). Hit canónico: `/landing/navidadshoppings-dic25?source=web_modo`.
- `GET /promos` — listado filtrable.
- `GET /promos/{slug}` — detail.
- `GET /promos/{slug}/merchants` — comercios.
- `GET /promos/{slug}/banks` — bancos.
- `GET /promos/{slug}/payment-methods` — medios de pago.
- `GET /remote-config/rewardshandlersdk` — config dinámica del SDK.
- `GET /remote-config/promoshub` — config dinámica del hub frontend.
- `GET /health`
- `GET /docs/openapi-json` — OpenAPI source para regenerar collections.

Header obligatorio: `X-auth-application: {{exchange_access_token}}`.

Repo: `github.com/playsistemico/rewards-handler-bff`.

## 03 · Partners Benefits API

| Tier | Base URL |
|------|----------|
| QA | `https://qa.api.modo.com.ar/partners/benefits/v1` |
| PREPROD | `https://preprod.api.modo.com.ar/partners/benefits/v1` |
| PROD | `https://api.modo.com.ar/partners/benefits/v1` |

Endpoints:
- `POST /promotions` — crear promo (reward: installments/discount/cashback, rules, publication, payment_methods, payment_flow).
- `GET /promotions?page=&page_size=` — listar.
- `GET /promotions/{id}` — get by ID.
- `PATCH /promotions/{id}` — update parcial.
- `POST /promotions/{id}/disable` — apagar.
- `GET /categories` — lookup.
- `GET /acquirers` — lookup.
- `GET /payment-methods` — lookup.

Auth: `Authorization: Bearer {partners_bearer_token}` (Auth0 CC con `audience=partners_auth_audience`).

## 04 · Cashback Recovery

| Tier | Base URL |
|------|----------|
| QA | `https://qa.api.modo.com.ar/cashback-recovery/v1` |
| PREPROD | `https://preprod.api.modo.com.ar/cashback-recovery/v1` |
| PROD | `https://api.modo.com.ar/cashback-recovery/v1` |

Endpoints:
- `POST /recoveries` — solicitar recovery (promotion_id, user_id, transaction_id, amount, currency, reason).
- `GET /recoveries/{id}` — status.
- `GET /recoveries?status=&user_id=` — listar/filtrar.

Doc: `developers.modo.com.ar/tech-docs#tag/Cashback-recovery/operation/PostCashbackRecovery`.

Auth: igual que Partners Benefits (Bearer M2M con audience partners).

## 05 · Merchants Docs

Sólo PROD: `https://merchants.modo.com.ar`.

Endpoints:
- `GET /docs` — index.
- `GET /docs/{uuid}` — documentación de integración del partner (Botón de Pago / Checkout) por UUID.

Auth: público (no requiere token).

UUIDs vistos en historial (smoke test válido): `16c7547a-6a0d-4cd6-b48a-aadf75176287`, `1e2aa881-a70d-4a1d-a8c5-51d1fdbb8e08`, `07d487b8-9a6f-4f71-b6c2-b2c5a95a9e57`, `b827da1d-bab4-4a20-bf42-f3f2b460f8a6`, `79480912-a375-4c07-9bb1-07fdede82457`.

## 06 · Promoshub Webview (frontend público)

| Tier | Base URL |
|------|----------|
| QA | `https://promoshub.qa.modo.com.ar` |
| PREPROD | `https://promoshub.preprod.modo.com.ar` |
| PROD | `https://promoshub.modo.com.ar` |

NO es API REST — es Next/Astro SSR. Paths frecuentes:
- `/` — home.
- `/promos` — listado.
- `/promos/{slug}` — promo detail.
- `/promos/{slug}/comercios` — drill comercios.
- `/promos/{slug}/bancos` — drill bancos.
- `/promos/{slug}/medios-de-pago` — drill MPs.
- `/promos-app?webview=true&filter=true&userId={uuid}&currentBanks={csv}` — webview deep link desde SDK MODO.
- `/promos-app/{slug}` — webview promo detail.
- `/promos/mapa?merchant_id=&application_id=&webview=true` — mapa de comercios.

Mirror en `www.modo.com.ar/mapa?merchant_id=...` (mismo contrato).

## 07 · Agentic Checkout SDK Deeplink (POC MODO for Agents)

Sólo PROD: `https://assets.mobile.playdigital.com.ar/modo/modosdk/securepayment_agent`.

NO es servidor propio — sirve HTML estático que abre el SDK MODO en flujo ACP/AP2.

Query params requeridos: `intent_id`, `merchant_id`, `merchant_name`, `merchant_platform`, `merchant_is_marketplace`, `sellers_in_cart`, `currency`, `amount_cents`, `items_count`, `items_cents`, `shipping_cents`, `discounts_cents`, `items` (JSON array), `buyer_user_id`, `mandate_id`, `session_id`, `customer_document`, `callback_success`, `callback_failure`.

Ver skill `simular-compra-agentica` para el flujo completo end-to-end con server local.

## 08 · POC Tracker MCP

Sólo PREPROD: `https://modo-poc-tracker.preprod.modo.com.ar/mcp` (detrás de Cloudflare Access — Zero Trust).

MCP server JSON-RPC. Autenticación vía Cloudflare Access SSO (cookie `CF_Authorization` después del handshake `/cdn-cgi/access/oauth/authorization`).

Métodos MCP estándar: `initialize`, `tools/list`, `tools/call`.

## 09 · Developers portal (referencia)

Sólo PROD: `https://developers.modo.com.ar`. Auth0 portal con Confluence space.

NO modelar como API directa — es viewer auth-gated que renderea Confluence. Las APIs reales están en `merchants.playdigital.com.ar` (Botón de Pago / Checkout merchants).

Endpoints públicos del portal:
- `/tech-docs` — Confluence docs.
- `/api-docs/open-api` — OpenAPI source público.
- `/bitacoras` — release notes por banco.
- `/changelog` — releases.
- `/diagnostico` — health checker.
- `/product-map` — feature matrix por banco.

Ver memoria `project_modo_developers_portal_split.md` para split portal vs API real.
