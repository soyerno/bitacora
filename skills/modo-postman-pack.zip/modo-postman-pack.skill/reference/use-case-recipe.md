# Use case folder · Recipe

Cada collection MODO debe tener al menos un folder `Use case · <flow>` con el happy path encadenado. Es lo primero que el user va a correr.

## Estructura

```
<collection>.json
├── Use case · <flow principal>
│   ├── 1 · <paso 1>                     # con test event que setea env vars
│   ├── 2 · <paso 2 que usa output de 1>
│   └── 3 · <paso final>
├── <Recurso A>
│   ├── GET /...
│   ├── POST /...
│   └── PATCH /...
├── <Recurso B>
│   └── ...
├── Error cases
│   ├── 401 invalid_client
│   ├── 400 missing field
│   └── ...
├── Variants
│   └── <payloads alternativos del happy path>
└── Originals (preserved)         # sólo si la collection ya existía
    └── <copy literal del original parametrizado>
```

## Step encadenado · template

Cada step persiste su output con `pm.environment.set` para que el siguiente lo consuma con `{{...}}`.

```json
{
  "name": "1 · OAuth Client Credentials",
  "event": [
    {
      "listen": "test",
      "script": {
        "type": "text/javascript",
        "exec": [
          "pm.test('200', () => pm.response.to.have.status(200));",
          "const body = pm.response.json();",
          "pm.test('Has access_token', () => pm.expect(body.access_token).to.be.a('string'));",
          "pm.environment.set('members_access_token', body.access_token);"
        ]
      }
    }
  ],
  "request": {
    "method": "POST",
    "header": [],
    "body": {
      "mode": "urlencoded",
      "urlencoded": [
        { "key": "client_id", "value": "{{members_client_id}}", "type": "text" },
        { "key": "client_secret", "value": "{{members_client_secret}}", "type": "text" },
        { "key": "grant_type", "value": "client_credentials", "type": "text" }
      ]
    },
    "url": {
      "raw": "{{auth_api_base_url}}/token",
      "host": ["{{auth_api_base_url}}"],
      "path": ["token"]
    },
    "description": "Devuelve access_token M2M. Guardalo en members_access_token."
  }
}
```

## Test event · patrones canónicos

### Status check + env set

```javascript
pm.test('200', () => pm.response.to.have.status(200));
pm.environment.set('<var>', pm.response.json().<field>);
```

### Status range

```javascript
pm.test('2xx', () => pm.expect(pm.response.code).to.be.within(200, 299));
```

### Defensive env set (puede ser objeto o array)

```javascript
const body = pm.response.json();
const id = body && (body.id || (Array.isArray(body) && body[0] && body[0].id));
if (id) pm.environment.set('<id_var>', id);
```

### SSR HTML smoke

```javascript
pm.test('200', () => pm.response.to.have.status(200));
pm.test('SSR rendered title', () =>
  pm.expect(pm.response.text()).to.match(/<title>.*?<\/title>/i)
);
```

## Folder naming

- `Use case · <flow>` — usar `·` (middle dot, U+00B7) como separador, no `-` ni `:`.
- Steps `1 · `, `2 · `, `3 · ` con espacio alrededor del middle dot.
- `Originals (preserved)` literal si copiás del original.

## Anti-patterns

- **Sin test event**: si el step no setea env var, el siguiente step va a fallar con `{{undefined}}`. Cada step encadenado debe persistir su output.
- **Hardcoded URLs**: siempre `{{<var>_base_url}}/path`, jamás `https://qa.api.modo.com.ar/path` literal.
- **Hardcoded tokens**: Bearer en collection → parametrizar a `{{...}}` + agregar step 0 que lo obtiene.
- **Use case folder con 1 request**: si es un solo request, no es un flow. Va al folder de recurso directamente.
- **Use case sin happy path**: si el flow falla en step 3 de 5 normalmente, no es happy path — partilo en 2 use cases distintos.
