# MODO Postman Pack Skill

Producir packs Postman MODO-completos cruzando historial Chrome + Postman exports + inventario canónico.

## Quick start

- Trigger: `/modo-postman-pack`, "armá un pack de Postman MODO", "extendé las colecciones", "consolidá los envs", "mapeá las APIs MODO que uso".
- Output: `~/Documents/Config/Postman/_extended_<YYYY-MM-DD>/` con 9 collections + 3 master envs + README.
- Ejemplo: `/modo-postman-pack` → 12 archivos JSON listos para importar en Postman.

## Features

- Cruza Chrome history (sqlite) con exports Postman existentes para mapear qué APIs MODO realmente usás.
- Inventario canónico de 9 apps MODO/playdigital con URLs QA/PREPROD/PROD.
- Genera collections numeradas con carpetas `Use case · …` encadenadas (prereq/test scripts).
- Parametriza Bearer tokens hardcoded (anti-credential-leak).
- Master env por tier (QA/PREPROD/PROD) con variables canónicas consistentes cross-collection.
- Preserva originales del user — todo va a `_extended_<YYYY-MM-DD>/`.

## Files

- `SKILL.md` — proceso de 5 pasos + reglas obligatorias + anti-patterns
- `README.md` — esta doc
- `reference/apps-inventory.md` — 9 apps MODO con URLs por tier y endpoints conocidos
- `reference/use-case-recipe.md` — pattern del Use case folder
- `reference/master-env-template.json` — template de master env

## Apps cubiertas

| # | App | Tipo |
|---|-----|------|
| 00 | Auth Members (OAuth2 + Token Exchange) | M2M auth |
| 01 | Auth Members SDK (con dev-exception header) | M2M auth + SDK |
| 02 | Rewards Handler (BFF promos & landing) | BFF |
| 03 | Partners Benefits API (Create/Update/Disable promo) | API REST |
| 04 | Cashback Recovery | API REST |
| 05 | Merchants Docs | Portal docs |
| 06 | Promoshub Webview | Frontend público |
| 07 | Agentic Checkout SDK Deeplink | URL-builder |
| 08 | POC Tracker MCP (Cloudflare Access) | MCP server |

Ver `reference/apps-inventory.md` para URLs por tier.

## Changelog

- **2026-05-21** — skill creado. Primer pack generado en `~/Documents/Config/Postman/_extended_2026-05-21/` (9 collections + 3 master envs). Inventario inicial de 9 apps MODO. Detalle en `SKILL.md`.
