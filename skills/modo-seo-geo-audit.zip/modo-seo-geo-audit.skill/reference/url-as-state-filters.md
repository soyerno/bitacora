# URL-as-State para filtros públicos · code patterns

Todos los filtros públicos (chips, select, search, sort, paginación, tabs, geo) viven en la URL. Default state = URL limpia. Cada estado tiene canonical + JSON-LD scoped + sitemap entry si aplica SEO value.

Aplica a:
- **modo-landing** (Next 12, Pages router) — `/promos`, `/comercios`
- **promos-hub-site** (Next 15, App router) — root, `/categoria/[slug]`, `/banco/[slug]`

## 1 · Decision tree: segmento vs query

```
¿Es un eje taxonómico (1 valor a la vez, top-level)?
  ├── Sí → segmento dinámico: /promos/categoria/[slug]
  └── No → query: ?categoria=...
                      &banco=...

¿Combinable con otros filtros?
  ├── Sí → query siempre
  └── No → segmento OK

¿Tiene SEO value (volumen de search, intent)?
  ├── Sí → indexable + sitemap entry + canonical self
  └── No → noindex + canonical al padre
```

## 2 · Next 12 Pages router (modo-landing)

### 2.1 · `useUrlFilter` hook (drop-in en `src/hooks/useUrlFilter.ts`)

```ts
import { useRouter } from 'next/router';
import { useCallback, useMemo } from 'react';

type FilterShape = Record<string, string | string[] | undefined>;

export function useUrlFilter<T extends FilterShape>(defaults: T) {
  const router = useRouter();

  const value = useMemo(() => {
    const out = { ...defaults } as T;
    Object.keys(defaults).forEach((k) => {
      const q = router.query[k];
      if (q !== undefined) (out as Record<string, unknown>)[k] = q;
    });
    return out;
  }, [router.query, defaults]);

  const setValue = useCallback(
    (patch: Partial<T>, opts?: { push?: boolean }) => {
      const merged: Record<string, string | string[] | undefined> = {
        ...router.query,
        ...patch,
      };
      // Strip default/empty values → URL limpia en default state
      Object.keys(merged).forEach((k) => {
        const v = merged[k];
        const isDefault = v === (defaults as Record<string, unknown>)[k];
        const isEmpty = v === '' || v === undefined || (Array.isArray(v) && v.length === 0);
        if (isDefault || isEmpty) delete merged[k];
      });
      const method = opts?.push ? router.push : router.replace;
      method({ pathname: router.pathname, query: merged }, undefined, {
        shallow: true,
        scroll: false,
      });
    },
    [router, defaults]
  );

  return [value, setValue] as const;
}
```

Uso en `/promos`:

```tsx
const [filters, setFilters] = useUrlFilter({
  categoria: 'todas',
  banco: 'todos',
  dia: 'todos',
  q: '',
});

// Click chip → escribe URL
<Chip onClick={() => setFilters({ categoria: 'supermercados' })} />

// Search debounced → replace (no push)
const onSearch = useMemo(() => debounce((q) => setFilters({ q }), 300), [setFilters]);
```

### 2.2 · `getServerSideProps` consume la URL para SSR del subset filtrado

```ts
export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const { categoria = 'todas', banco = 'todos', dia = 'todos', q = '' } = ctx.query;
  const promos = await fetchPromos({ categoria, banco, dia, q });
  return {
    props: {
      promos,
      filters: { categoria, banco, dia, q },
      canonical: buildCanonical(ctx.resolvedUrl, { categoria, banco, dia, q }),
      jsonLd: buildItemListLD(promos, ctx.req?.headers.host ?? '', { categoria, banco, dia, q }),
    },
  };
};
```

### 2.3 · `buildCanonical` (default state = URL limpia)

```ts
// src/utils/seo/buildCanonical.ts
const SEO_VALUE_KEYS = new Set(['categoria', 'banco', 'ciudad']); // indexables
const DEFAULT_VALUES: Record<string, string> = {
  categoria: 'todas',
  banco: 'todos',
  ciudad: 'todas',
};

export function buildCanonical(pathname: string, query: Record<string, unknown>): string {
  const base = `https://www.modo.com.ar${pathname.split('?')[0]}`;
  const indexable: string[] = [];
  Object.entries(query).forEach(([k, v]) => {
    if (!SEO_VALUE_KEYS.has(k)) return; // sort, q, page → no canonical
    if (typeof v !== 'string') return;
    if (v === DEFAULT_VALUES[k]) return;
    indexable.push(`${k}=${encodeURIComponent(v)}`);
  });
  return indexable.length ? `${base}?${indexable.sort().join('&')}` : base;
}
```

Sort alfabético de keys → previene `?a=1&b=2` vs `?b=2&a=1` siendo URLs distintas para crawlers.

### 2.4 · `<Head>` per-filter-state

```tsx
<Head>
  <title>{titleForFilters(filters)}</title>
  <meta name="description" content={descriptionForFilters(filters)} />
  <link rel="canonical" href={canonical} />
  {shouldNoIndex(filters) && <meta name="robots" content="noindex,follow" />}
  <script
    type="application/ld+json"
    // eslint-disable-next-line react/no-danger
    dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
  />
</Head>
```

`shouldNoIndex` devuelve true si:
- ≥3 filtros combinados (long-tail)
- `sort` o `page` presentes
- Subset vacío (`promos.length === 0`)
- `q` (search box) presente — usuario context, no SEO

## 3 · Next 15 App router (promos-hub-site)

### 3.1 · Server component reads `searchParams`

```tsx
// app/page.tsx
import { Metadata } from 'next';

type SP = { categoria?: string; banco?: string; dia?: string; q?: string };

export async function generateMetadata({ searchParams }: { searchParams: Promise<SP> }): Promise<Metadata> {
  const sp = await searchParams;
  const canonical = buildCanonical('/', sp);
  return {
    title: titleForFilters(sp),
    description: descriptionForFilters(sp),
    alternates: { canonical },
    robots: shouldNoIndex(sp) ? 'noindex,follow' : 'index,follow',
  };
}

export default async function PromosPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const promos = await fetchPromos(sp);
  return (
    <>
      <JsonLd data={buildItemListLD(promos, 'https://promos.modo.com.ar', sp)} />
      <PromoGrid promos={promos} initialFilters={sp} />
    </>
  );
}
```

### 3.2 · Client component muta `searchParams`

```tsx
// app/_components/PromoFilterBar.tsx
'use client';
import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import { useCallback, useTransition } from 'react';

export function PromoFilterBar() {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [, startTransition] = useTransition();

  const setFilter = useCallback(
    (key: string, value: string | null) => {
      const next = new URLSearchParams(sp.toString());
      if (value && value !== 'todos' && value !== 'todas') {
        next.set(key, value);
      } else {
        next.delete(key);
      }
      const qs = next.toString();
      startTransition(() => {
        router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
      });
    },
    [router, pathname, sp]
  );

  // ...
}
```

`router.replace` (no `push`) para que el back button salte al estado pre-filtros, no recorra cada chip click. `useTransition` evita bloquear el thread y muestra `isPending` para skeleton.

### 3.3 · Sitemap dinámico per filter (`app/sitemap.ts`)

```ts
import type { MetadataRoute } from 'next';

const TOP_CATEGORIAS = ['supermercados', 'gastronomia', 'indumentaria', 'tecnologia'];
const TOP_BANCOS = ['galicia', 'santander', 'bbva', 'macro', 'icbc'];

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://promos.modo.com.ar';
  const root = { url: base, lastModified: new Date(), changeFrequency: 'daily' as const, priority: 1.0 };
  const categorias = TOP_CATEGORIAS.map((c) => ({
    url: `${base}/?categoria=${c}`,
    lastModified: new Date(),
    changeFrequency: 'daily' as const,
    priority: 0.8,
  }));
  const bancos = TOP_BANCOS.map((b) => ({
    url: `${base}/?banco=${b}`,
    lastModified: new Date(),
    changeFrequency: 'daily' as const,
    priority: 0.7,
  }));
  return [root, ...categorias, ...bancos];
}
```

Solo top categorías/bancos. Combinaciones quedan fuera → `noindex` por `shouldNoIndex`.

## 4 · Reglas comunes (ambos routers)

### 4.1 · Default state = URL limpia

Buen test: en mount, `JSON.stringify(filters) === JSON.stringify(defaults)` debe coexistir con `router.asPath === pathname` (sin query). Si no, hay default leakeado a la URL.

### 4.2 · Idempotencia URL ↔ state

```ts
// Esto siempre debe ser true:
const fromUrl = parseQuery(window.location.search);
const back = serializeFilters(fromUrl);
assert(window.location.search === back || (window.location.search === '' && back === ''));
```

### 4.3 · Pagination

- Pagina 1: sin `?page=` (URL limpia).
- Pagina 2+: `?page=2` con canonical self + `noindex,follow` salvo decisión explícita.
- `rel=next/prev` legacy: opcional, Google lo ignora desde 2019.

### 4.4 · Search box

- Debounce 300ms.
- `router.replace` (nunca push).
- `noindex,follow` siempre — search results no son canónicos.
- Sí emitir `SearchAction` LD en home (no en la página resultante).

### 4.5 · Filtros que ROMPEN si los pones en URL

Nunca a URL:
- Modal open/close
- Tooltip visible
- Accordion expanded
- Dropdown open
- Drawer mobile open
- Animation step
- Skeleton state
- Form draft (autosave a localStorage, no URL)
- Auth state (cookies/session)

Test: ¿el user esperaría compartir este estado en WhatsApp? Si la respuesta es no → no va en URL.

## 5 · Migración incremental (no big-bang)

Cuando un site MODO tiene 0 filtros URL-state hoy:

1. **Wave A · 1 filtro principal**. Tomar el filtro de máximo volumen (en `/promos` es categoría). Migrarlo a URL con el hook. Probar con Googlebot UA + share en WhatsApp.
2. **Wave B · resto de filtros combinables**. Agregar al query progresivamente. Por cada uno: ¿es indexable? ¿entra en canonical? ¿entra en sitemap?
3. **Wave C · per-state LD + sitemap entries**. Generar el `ItemList` reducido. Listar top combinaciones en sitemap.
4. **Wave D · noindex sweep**. `noindex,follow` a combinaciones long-tail + sort + search.

PR por wave. Cada wave es independientemente shippable y mejora SEO sin regresión.

## 6 · Smoke test pre-merge (cualquier PR de filtros)

```bash
# 1. URL refleja filtro
curl -s "$URL?categoria=supermercados" | grep "categoria=supermercados.*canonical" || echo "FAIL: canonical no incluye filtro"

# 2. Subset SSR-rendered
curl -s "$URL?categoria=supermercados" | grep -E "supermercados" | head -3 || echo "FAIL: no hay items SSR del filtro"

# 3. LD scoped al filtro
curl -s "$URL?categoria=supermercados" | python3 -c "
import sys, re, json
m = re.search(r'<script type=\"application/ld\+json\">(.+?)</script>', sys.stdin.read(), re.S)
ld = json.loads(m.group(1))
items = ld.get('mainEntity', {}).get('itemListElement', [])
print(f'LD items: {len(items)}')
assert len(items) < 100, 'LD no scoped (devuelve catálogo completo)'
"

# 4. Default state = URL limpia
curl -s -L "$URL?categoria=todas" -o /dev/null -w '%{url_effective}\n' | grep -q '?' && echo "FAIL: default leakea query"

# 5. Noindex en combinatoria
curl -s "$URL?categoria=X&banco=Y&dia=Z" | grep -E 'noindex' || echo "FAIL: long-tail combo es indexable"

# 6. Googlebot ve el subset
curl -s -A "Googlebot/2.1" "$URL?categoria=supermercados" | grep -E "supermercados" || echo "FAIL: Googlebot no ve subset"
```

## 7 · Cache SSR · URL-as-state como cache key

URL-state es prerequisito de cache SSR útil. Sin URL diferenciada por filtro, cache HTTP/CDN/ISR no tiene key estable → o sirve stale wrong-content (un user con filtro A ve cache de B), o el equipo desactiva cache entera y todo es uncached. Con URL-state, cada combo es cacheable independiente.

### 7.1 · Capas de cache por URL

| Capa | Qué cachea | TTL recomendado MODO | Header |
|---|---|---|---|
| Browser | HTML/JSON per URL | 60s + SWR 5min | `Cache-Control: public, max-age=60, stale-while-revalidate=300` |
| CDN edge (Cloudflare / ALB / Vercel) | HTML SSR per URL | s-maxage 5min + SWR 1h | `Cache-Control: public, s-maxage=300, stale-while-revalidate=3600` |
| Next 12 ISR `getStaticProps` | output per slug + query | `revalidate: 60` a `600` | `revalidate` en return |
| Next 15 `fetch` cache | data layer per request | `next: { revalidate: 60 }` | per fetch |
| `unstable_cache` / `cache()` Next 15 | server fn output | `revalidate: 60`, `tags: ['promos']` | tag-based invalidation |
| App-level memo (SWR/TanStack) | client subset | session | `staleTime`/`gcTime` |

### 7.2 · Header per filter type

```ts
// utils/seo/cacheHeaders.ts
type CacheClass = 'long' | 'medium' | 'short' | 'none';

const POLICY: Record<CacheClass, string> = {
  long:   'public, s-maxage=600, stale-while-revalidate=3600',   // top categorías/bancos curados
  medium: 'public, s-maxage=300, stale-while-revalidate=1800',   // single filter no top
  short:  'public, s-maxage=60,  stale-while-revalidate=300',    // combinatoria 2 filtros
  none:   'private, no-store',                                   // search, sort, long-tail
};

export function cacheClassFor(filters: Record<string, string | undefined>): CacheClass {
  if (filters.q) return 'none';                                  // search box
  if (filters.sort && filters.sort !== 'default') return 'none'; // sort no-canónico
  const active = Object.values(filters).filter((v) => v && v !== 'todos' && v !== 'todas');
  if (active.length === 0) return 'long';                        // home / default
  if (active.length === 1) return isTopFilter(filters) ? 'long' : 'medium';
  if (active.length === 2) return 'short';
  return 'none';                                                 // long-tail combinatoria
}
```

### 7.3 · Next 12 Pages router (modo-landing)

```ts
// pages/promos.tsx
export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const filters = parseFilters(ctx.query);
  const promos = await fetchPromos(filters);

  ctx.res.setHeader('Cache-Control', POLICY[cacheClassFor(filters)]);
  ctx.res.setHeader('Vary', 'Accept-Encoding');

  return { props: { promos, filters, canonical: buildCanonical('/promos', filters) } };
};
```

Si la combinación es indexable + estable (top categorías), preferir `getStaticProps` + `getStaticPaths` con `fallback: 'blocking'` + `revalidate: 60`. ISR cachea por path + query del slug, no por query del request → mover top filtros a path (`/promos/categoria/[slug]`) para ISR; mantener combinaciones secundarias en query con SSR + s-maxage.

### 7.4 · Next 15 App router (promos-hub-site)

```ts
// app/page.tsx
import { unstable_cache } from 'next/cache';

const getPromos = unstable_cache(
  async (filters: PromoFilters) => fetchPromos(filters),
  ['promos-by-filters'],
  { revalidate: 60, tags: ['promos'] }
);

export default async function PromosPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const filters = normalizeFilters(sp);  // strip defaults, sort keys
  const promos = await getPromos(filters);
  // ...
}

// Setear header del response via route segment config:
export const dynamic = 'force-dynamic';   // si dependés de searchParams
export const revalidate = 60;             // o force-static + ISR si filters viven en path
```

Cache header via `headers()` o middleware:

```ts
// middleware.ts
import { NextResponse } from 'next/server';
export function middleware(req: Request) {
  const res = NextResponse.next();
  const url = new URL(req.url);
  const filters = parseFiltersFromSP(url.searchParams);
  res.headers.set('Cache-Control', POLICY[cacheClassFor(filters)]);
  return res;
}
```

Tag-based invalidation (cuando promos cambian en CMS):

```ts
// app/api/revalidate-promos/route.ts
import { revalidateTag } from 'next/cache';
export async function POST() {
  revalidateTag('promos');
  return Response.json({ ok: true });
}
```

Webhook de Storyblok/CMS pega a este endpoint con `Authorization: Bearer $ISR_REVALIDATE_TOKEN` → invalida todas las entries con tag `promos` sin tener que enumerar URLs.

### 7.5 · Cardinality control (el trap real)

URL-state mal hecho explota cardinality → CDN cachea miles de combos thin → eviction agresiva → hit rate baja. Reglas:

- **Whitelist combos cacheables**. Top 5 categorías × top 5 bancos = 25 entries calientes, no NxMx7x24.
- **Default URL limpia** = max hit rate. `?categoria=todas` crea entry separada que nunca se reusa.
- **Query key sort alfabético** (ya en `buildCanonical`) → `?a=1&b=2` y `?b=2&a=1` son misma cache entry, no 2.
- **Long-tail combinatoria** → `Cache-Control: private, no-store` (delegar a fetch level cache, no a CDN).
- **Search/sort/page** → cache muy corto (30s) o `no-cache`.
- **`Vary` header explícito** → solo `Accept-Encoding`. NUNCA `Cookie` o `User-Agent` para HTML público (rompe cache).

### 7.6 · Trade-off vs client-side filtering actual

Estado actual `/promos` modo-landing: client filtering sobre payload completo. Implicancias:

| Aspecto | Client filtering (hoy) | URL-state + SSR per filter |
|---|---|---|
| SSR renders cacheables | 1 (catálogo completo) | N entries chicas + whitelist top combos |
| HTML inicial size | grande (todo el catálogo) | chico (subset) → LCP mejor |
| TTFB | 1 cache entry caliente | top combos calientes, fría en miss |
| Crawler ve filtro | NO | SÍ |
| Shareable URL | NO | SÍ |
| Origen load | bajo (1 fetch) | depende cardinality + tagged invalidation |

Para que el migración a URL-state mejore load real (no solo SEO), respetar:
1. Whitelist top combos.
2. `revalidate` o `s-maxage` ≥ 60s (no `no-cache` por accidente).
3. Tag-based invalidation (no enumerar URLs en revalidate).
4. Default URL limpia (1 sola entry caliente).

### 7.7 · Smoke test cache headers

```bash
# Cache class por filter
for url in \
  "$SITE/promos" \
  "$SITE/promos?categoria=supermercados" \
  "$SITE/promos?banco=galicia" \
  "$SITE/promos?categoria=supermercados&banco=galicia" \
  "$SITE/promos?q=cafe" \
  "$SITE/promos?sort=desc" \
  ; do
  echo "=== $url ==="
  curl -sI "$url" | grep -iE "cache-control|vary|age|x-cache|cf-cache-status"
done
```

Esperado:
- `/promos` → `s-maxage=600, swr=3600` (default = long)
- top single → `s-maxage=600` (long) o `s-maxage=300` (medium)
- 2-filter combo → `s-maxage=60` (short)
- `?q=` y `?sort=` → `no-store`

`x-cache: HIT` / `cf-cache-status: HIT` en repeat request → cache funcionando. Si siempre `MISS`, el header está mal o `Vary` es muy amplio.

## 8 · Cross-link

- `json-ld-per-filter-state.md` — LD recipes scoped a filtros
- `csr-spa-trap.md` — por qué SSR matters para indexar filtros
- `~/.claude/skills/sdd-track/` — track del progreso por wave en `openspec/changes/<slug>/tasks.md`
- `~/.claude/skills/frontend-security-checklist/` — Layer 3 valida headers post-deploy (incluye `Cache-Control` además de CSP)
