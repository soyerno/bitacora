# `llms.txt` canónico MODO

Formato propuesto por https://llmstxt.org/ — markdown legible por LLMs con heading + descripción + secciones link-list. Reemplaza el 404 default que rompe AI crawlers.

## Template

```markdown
# <Nombre del sitio>

> <One-line description, terminada en punto. Tiene que decir QUÉ es y PARA QUIÉN.>

<Prosa de 2-3 líneas con contexto adicional: vínculo con MODO, idioma, audiencia, ausencia de login/paywall si aplica.>

- Audiencia: <quiénes son los usuarios target>.
- Idioma: español rioplatense (es-AR).
- Sin login, sin datos personales, sin paywall. Todo accesible vía navegador.

## <Sección 1 · ej. Cursos / Productos / Servicios>

- [<Nombre del item>](<URL absoluta>): <descripción de 1-2 líneas>.
- ...

## <Sección 2 · ej. Glosario / FAQ>

<Prosa o lista de pointers a contenido secundario.>

- [<Pointer>](<URL>)

## Sobre MODO

- [Sitio principal MODO](https://www.modo.com.ar/): <descripción de MODO en 1 línea>.
- [<Producto/Sección relacionada>](<URL>): <descripción>.

## Optional

- [Sitemap](https://<site>/sitemap.xml)
- [Política robots](https://<site>/robots.txt)
```

## Reglas

- **Heading `# <Nombre>` único** en la primera línea. Es el "title" del LLM.
- **Blockquote `> ...`** debajo del heading con la descripción canónica. AI crawlers la levantan como `meta description` semántico.
- **Links absolutos siempre**. Nada de paths relativos.
- **Descripción por link**: una línea, terminada en punto. Es lo que el LLM cita.
- **Sección `## Optional`** al final con sitemap/robots (y opcionalmente `llms-full.txt` cuando exista).

## Anti-patterns

- Llms.txt como dump del sitemap. Es curado, no exhaustivo.
- Llms.txt como marketing copy. Es referencia, no pitch.
- Llms.txt en HTML. Es markdown plano, devuelto como `text/markdown` o `text/plain`.
- Llms.txt sin links. Los AI crawlers siguen los links para profundizar.

## Para sites grandes · `llms-full.txt`

Cuando el contenido amerite, agregar `/llms-full.txt` con el cuerpo completo de cada page concatenado en markdown. Generar en build-time:

```bash
# Pseudo · adaptar al stack:
for slug in <iterate over routes>; do
  echo "## <Title del slug>"
  echo "<Body markdown del slug>"
  echo ""
done > public/llms-full.txt
```

Sin `/llms-full.txt`, el AI crawler decide qué profundizar siguiendo los links del `/llms.txt`. Con `/llms-full.txt`, recibe todo de un golpe — costoso pero exhaustivo.
