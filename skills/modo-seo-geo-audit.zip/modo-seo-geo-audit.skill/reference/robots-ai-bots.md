# `robots.txt` canónico MODO con AI bots

Default permisivo. Declarar explícito permite revertir caso por caso (cambiar `Allow → Disallow`) sin tocar el wildcard final.

```txt
User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /

User-agent: Twitterbot
Allow: /

User-agent: facebookexternalhit
Allow: /

# Crawlers de IA generativa (GEO). Permitimos indexar este contenido
# educativo gratuito de MODO. Si en el futuro hay que blanquear alguno,
# cambiar Allow por Disallow en el bloque correspondiente.
User-agent: GPTBot
Allow: /

User-agent: ChatGPT-User
Allow: /

User-agent: OAI-SearchBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: Claude-Web
Allow: /

User-agent: anthropic-ai
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: Perplexity-User
Allow: /

User-agent: Google-Extended
Allow: /

User-agent: CCBot
Allow: /

User-agent: Applebot
Allow: /

User-agent: Applebot-Extended
Allow: /

User-agent: Bytespider
Allow: /

User-agent: Amazonbot
Allow: /

User-agent: DuckDuckBot
Allow: /

User-agent: meta-externalagent
Allow: /

User-agent: *
Allow: /

Sitemap: https://<site>/sitemap.xml
```

## Bot family reference

| Family | Agents | Quién |
|---|---|---|
| Google | `Googlebot`, `Google-Extended` | Google Search + Bard/Gemini training |
| OpenAI | `GPTBot`, `ChatGPT-User`, `OAI-SearchBot` | ChatGPT training + browse + SearchGPT |
| Anthropic | `ClaudeBot`, `Claude-Web`, `anthropic-ai` | Claude training + browse |
| Perplexity | `PerplexityBot`, `Perplexity-User` | Perplexity index + user-initiated fetch |
| Apple | `Applebot`, `Applebot-Extended` | Spotlight/Siri + Apple Intelligence training |
| Meta | `meta-externalagent` | Llama training + Meta AI |
| Common Crawl | `CCBot` | Open dataset usado por casi todos los LLMs |
| ByteDance | `Bytespider` | TikTok/Doubao training |
| Amazon | `Amazonbot` | Alexa + AWS AI |
| Bing/MSFT | `Bingbot` | Bing Search + Copilot grounding |
| DuckDuckGo | `DuckDuckBot` | DuckDuckGo Search + AI Answers |

## Casos para blanquear

Solo `Disallow: /` selectivamente si:

- El contenido es estrictamente operacional (login, admin, BFFs) → conviene `Disallow` global y permitir explícito solo `/` y `/public/*`.
- Hay licencia que prohíbe AI training (no es el caso de MODO en general).
- El sitio sirve documentación que no debe entrenar competidores directos.

Para contenido marketing/educativo de MODO: **default Allow para todos**.
