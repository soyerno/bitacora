# modo-seo-geo-audit

Audit + fix de SEO, GEO (Generative Engine Optimization) y JSON-LD para frontends MODO. Detecta qué ven los crawlers reales (Googlebot, Bingbot, GPTBot, ClaudeBot, PerplexityBot), no qué ves vos en DevTools.

## Quick start

- Triggers: `validá SEO de <sitio>`, `audit SEO/GEO`, `JSON-LD ok?`, `valida que el sitio cumpla SEO`, `el filtro X no cambia la URL`, `no puedo compartir el resultado filtrado`, `Google no indexa /promos?categoria=...`
- Output: matriz de findings por capa (robots, sitemap, llms.txt, OG, canonical, JSON-LD, CSR trap, URL-as-state, LD per filter state, sitemap entries per filter) + plan de fixes priorizados en waves
- Ejemplo: `validá SEO de aprendeatumodo` → audit completo + W0 P0 PRs listos para mergear
- Ejemplo: `/promos no indexa categorías` → audit URL-state + plan migración a hook `useUrlFilter` + LD scoped + sitemap top categorías

## Features

- **Detección del CSR trap** — el patrón canónico donde React/Helmet emite JSON-LD invisible para crawlers en SPAs.
- **URL-as-state para filtros públicos** — todo filtro (categoría, banco, día, ciudad, search, sort, paginación) vive en URL para ser crawlable, shareable, emitir LD scoped Y servir como **cache key SSR/CDN/ISR**. Mejora LCP/TTFB al cachear top combos individualmente. Code patterns para Next 12 Pages router (modo-landing) y Next 15 App router (promos-hub-site).
- **Cache headers per filter class** — política `long`/`medium`/`short`/`none` según cardinality + cacheability del estado. `s-maxage` + `stale-while-revalidate` + tag-based `revalidateTag` para invalidación desde CMS webhook.
- **Drop-ins canónicos**: 8 recipes JSON-LD para `index.html` (`EducationalOrganization`, `Organization`, `WebSite`, `BreadcrumbList`, `CollectionPage`, `Course`, `FAQPage`, `VideoObject`) + recipes scoped per filter state (`ItemList` reducido, `BreadcrumbList` con filtro como crumb, `SearchAction`, `Offer`, `Product`, `LocalBusiness`+`OfferCatalog`).
- **`robots.txt` template** con los 17 AI bots explícitos (GPTBot, ClaudeBot, PerplexityBot, Google-Extended, CCBot, etc.).
- **`llms.txt` template** canónico siguiendo https://llmstxt.org/.
- **Validador local Python** (`scripts/validate-jsonld.py`) sin dependencias externas — corre required-field check + Google Rich Results Course strict check.
- **Smoke test pre-merge** para PRs de filtros (6 checks: URL refleja filtro, subset SSR, LD scoped, default URL limpia, noindex combinatoria, Googlebot ve subset).
- **MODO canonical assets** ya verificados (logo Storyblok 200 OK).

## Files

- `SKILL.md` — proceso completo de audit (1 inventario → 2 parse + lint → 3 matriz → 4 wave 0 curitas → 5 wave 1+ SSG)
- `README.md` — esta doc
- `reference/json-ld-recipes.md` — 8 recipes drop-in
- `reference/json-ld-per-filter-state.md` — recipes LD scoped a filtros (ItemList reducido, BreadcrumbList con filter crumb, SearchAction, Offer, Product, LocalBusiness+OfferCatalog, FAQPage scoped)
- `reference/url-as-state-filters.md` — code patterns Next 12 Pages + Next 15 App router (`useUrlFilter` hook, `buildCanonical`, sitemap dinámico, smoke test pre-merge)
- `reference/robots-ai-bots.md` — bots IA canónicos
- `reference/llms-txt-template.md` — formato canónico llms.txt
- `reference/csr-spa-trap.md` — explicación + detección + mitigación
- `scripts/validate-jsonld.py` — validador local (file | url | stdin)

## Validador

```bash
# Contra una URL live
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py https://aprendeatumodo.modo.com.ar/

# Contra un archivo HTML
python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py /tmp/index.html

# Por stdin
curl -s https://<sitio>/ | python3 ~/.claude/skills/modo-seo-geo-audit/scripts/validate-jsonld.py -
```

Exit codes: 0 = todo OK · 1 = required-field gaps · 2 = parse errors.

## Cross-link

- [`frontend-security-checklist`](../frontend-security-checklist/) — Layer 3 (CSP post-deploy) complementa este audit
- [`modo-design-system`](../modo-design-system/) — tokens/branding
- [`modo-research-article`](../modo-research-article/) — output canónico para reports SEO largos en bitácora
- [`nextjs-pages-router-migration`](../nextjs-pages-router-migration/) — destino natural cuando se migra a SSG/SSR para resolver el CSR trap de raíz

## Caso canónico

aprendeatumodo · 2026-05-23 · PR [#3](https://github.com/SoyErnoModo/aprendeatumodo/pull/3) (`feat(COENXT-309): SEO/GEO P0`):

| Item | Antes | Después |
|---|---|---|
| LD blocks en index.html | 1 | 5 (rich) |
| Sitemap URLs | 5 (4 anchors) | 8 (home + 7 cursos reales) |
| AI bots en robots.txt | 0 | 17 explícitos |
| llms.txt | 404 | nuevo |
| Google Rich Results Course strict check | 0/7 | 7/7 ✅ |

## Changelog

- **2026-05-23** — Skill creado. SKILL.md + 4 references + 1 script + caso canónico aprendeatumodo PR #3.
- **2026-05-25** — URL-as-state para filtros públicos. Nueva sección core en SKILL.md + 2 references nuevos (`url-as-state-filters.md`, `json-ld-per-filter-state.md`). Aplica a modo-landing `/promos` + `/comercios` y promos-hub-site root. Code patterns Next 12 Pages + Next 15 App router. Smoke test pre-merge para PRs de filtros.
- **2026-05-25 (cache)** — `url-as-state-filters.md > §7 Cache SSR`. URL es la cache key. Capas (browser/CDN/ISR/RSC/in-app), header policy 4-clases (`long`/`medium`/`short`/`none`), `unstable_cache` + `revalidateTag` patterns Next 15, cardinality control (whitelist top combos), trade-off vs client-filtering actual, smoke test `cf-cache-status`. SKILL matriz Step 3 sumó 2 capas (cache headers + hit rate). 4 anti-patterns cache añadidos (Vary Cookie/UA, no-cache global, default no-vacío, cardinality explosiva).
