#!/usr/bin/env python3
"""
Validador de JSON-LD para el audit SEO/GEO MODO.

Toma un archivo HTML (o lo descarga con curl si recibe una URL), parsea todos
los bloques `<script type="application/ld+json">` y reporta:

  1. Cantidad de blocks + tipos.
  2. Required-field check por @type según Google Rich Results docs.
  3. Strict check específico para Course (offers + url + provider.url +
     provider.logo + CourseInstance con courseMode + workload/schedule).

Uso:

    python3 validate-jsonld.py <html-file>
    python3 validate-jsonld.py <url>           # baja con curl + UA Googlebot
    curl -s "$SITE/" | python3 validate-jsonld.py -

Salida pensada para grep / human-readable. Exit code != 0 si hay errores
críticos (parse fail o LD inválido por schema).
"""
import json
import re
import subprocess
import sys


CHECKS = {
    "EducationalOrganization": ["name", "url", "logo"],
    "Organization": ["name", "url", "logo"],
    "Course": ["name", "description", "provider", "hasCourseInstance"],
    "CourseInstance": ["courseMode"],
    "WebSite": ["name", "url"],
    "VideoObject": ["name", "description", "thumbnailUrl", "uploadDate"],
    "FAQPage": ["mainEntity"],
    "BreadcrumbList": ["itemListElement"],
    "CollectionPage": ["name", "url"],
    "Article": ["headline", "author", "datePublished"],
    "Product": ["name", "image", "description"],
    "LocalBusiness": ["name", "address"],
}


def fetch_html(arg: str) -> str:
    """Resolve `arg` to HTML content."""
    if arg == "-":
        return sys.stdin.read()
    if arg.startswith(("http://", "https://")):
        return subprocess.check_output(
            ["curl", "-sL", "-A", "Googlebot/2.1", arg]
        ).decode("utf-8", errors="replace")
    return open(arg, encoding="utf-8").read()


def extract_lds(html: str):
    """Return list of (block_index, parsed_or_error)."""
    out = []
    for i, m in enumerate(
        re.finditer(r'<script type="application/ld\+json">(.*?)</script>', html, re.S),
        start=1,
    ):
        raw = m.group(1).strip()
        try:
            out.append((i, json.loads(raw)))
        except Exception as e:
            out.append((i, {"_parse_error": str(e), "_raw_head": raw[:200]}))
    return out


def walk_required(obj, path="root", out=None):
    """Recursively walk and collect (path, @type, missing_fields)."""
    if out is None:
        out = []
    if isinstance(obj, dict):
        t = obj.get("@type")
        if t and t in CHECKS:
            missing = [f for f in CHECKS[t] if f not in obj]
            out.append((path, t, missing))
        for k, v in obj.items():
            walk_required(v, f"{path}.{k}", out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk_required(v, f"{path}[{i}]", out)
    return out


def strict_check_course(ld):
    """Google Rich Results · Course strict check.

    Yields one tuple (course_name, [issues]) per Course node.
    """
    def visit(obj):
        if isinstance(obj, dict):
            if obj.get("@type") == "Course":
                issues = []
                if not obj.get("provider"):
                    issues.append("no provider")
                else:
                    p = obj["provider"]
                    if isinstance(p, dict):
                        if not p.get("url"):
                            issues.append("provider no url")
                        if not p.get("logo"):
                            issues.append("provider no logo")
                ci = obj.get("hasCourseInstance")
                if not ci:
                    issues.append("no CourseInstance")
                elif isinstance(ci, dict):
                    if not ci.get("courseMode"):
                        issues.append("CI no courseMode")
                    if not (ci.get("courseSchedule") or ci.get("courseWorkload")):
                        issues.append("CI needs courseSchedule|courseWorkload")
                if not obj.get("offers"):
                    issues.append("no offers (req for Course rich result)")
                if not obj.get("url"):
                    issues.append("no url")
                yield (obj.get("name", "<unnamed>"), issues)
            for v in obj.values():
                yield from visit(v)
        elif isinstance(obj, list):
            for v in obj:
                yield from visit(v)
    yield from visit(ld)


def main(argv):
    if len(argv) != 2:
        print(__doc__)
        sys.exit(1)

    html = fetch_html(argv[1])
    print(f"HTML size: {len(html)} bytes\n")

    lds = extract_lds(html)
    print(f"JSON-LD blocks: {len(lds)}")
    for i, ld in lds:
        if "_parse_error" in ld:
            print(f"  Block {i}: ❌ parse error · {ld['_parse_error']}")
            continue
        t = ld.get("@type", "?")
        print(f"  Block {i}: @type={t}")
    print()

    print("=== Required-field check ===")
    any_missing = False
    for i, ld in lds:
        if "_parse_error" in ld:
            continue
        for path, t, missing in walk_required(ld, f"ld[{i}]"):
            status = "✅ OK" if not missing else f"❌ missing={missing}"
            if missing:
                any_missing = True
            print(f"  {t:30s} {path:60s} {status}")
    print()

    print("=== Google Rich Results · Course strict check ===")
    course_count = 0
    for i, ld in lds:
        if "_parse_error" in ld:
            continue
        for name, issues in strict_check_course(ld):
            course_count += 1
            status = "✅ OK" if not issues else f"❌ {issues}"
            print(f"  {name[:42]:42s}: {status}")
            if issues:
                any_missing = True
    if course_count == 0:
        print("  (no Course nodes found)")
    print()

    print("=== Summary ===")
    if any(("_parse_error" in ld) for _, ld in lds):
        print("Parse errors found · exit 2")
        sys.exit(2)
    if any_missing:
        print("Required-field gaps found · exit 1")
        sys.exit(1)
    print("✅ All LD blocks pass required-field + strict checks.")


if __name__ == "__main__":
    main(sys.argv)
