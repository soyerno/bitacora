#!/usr/bin/env bash
# modo-services-monitor — render combined snapshot as Markdown table + TLDR
# Reads:
#   - MOTD cache:   ~/.cache/motd-status/status.json    (preferred, free)
#   - External:     stdin or first arg (JSON from check-external.sh)
#   - MODO API:     $MSM_MODO_JSON   (path to check-modo.sh output, optional)
#
# Output: Markdown to stdout — grid + TLDR block (only if degradation).
#
# Usage:
#   ./render.sh                       # uses MOTD cache, no MODO API
#   ./render.sh /path/to/external.json
#   MSM_MODO_JSON=/path/to/modo.json ./render.sh /path/to/external.json

set -u

EXT_SRC="${1:-${HOME}/.cache/motd-status/status.json}"
MODO_SRC="${MSM_MODO_JSON:-}"

if [[ ! -s "$EXT_SRC" ]]; then
  echo "**no data** — ejecutá \`bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh ~/.cache/motd-status/status.json\` primero, o \`motd-refresh\` desde la terminal."
  exit 0
fi

emoji_for() {
  case "$1" in
    none|ok|operational)  printf "🟢" ;;
    minor)                printf "🟡" ;;
    major)                printf "🟠" ;;
    critical|down)        printf "🔴" ;;
    maintenance)          printf "🔵" ;;
    *)                    printf "⚪" ;;
  esac
}

# Emit Markdown table 3 cols × N rows
emit_grid() {
  local rows
  rows=$(jq -r '.services[] | "\(.indicator)\t\(.name)\t\(.label)"' "$EXT_SRC" 2>/dev/null)
  [[ -z "$rows" ]] && { echo "_(cache vacío)_"; return; }

  echo "**Servicios externos + MODO público**"
  echo
  echo "| Servicio | Servicio | Servicio |"
  echo "|---|---|---|"

  local cells=()
  while IFS=$'\t' read -r ind name lab; do
    local emoji
    emoji=$(emoji_for "$ind")
    cells+=("$emoji $name")
  done <<< "$rows"

  local n=${#cells[@]} i=0
  while [[ $i -lt $n ]]; do
    local a="${cells[$i]:-}" b="${cells[$((i+1))]:-}" c="${cells[$((i+2))]:-}"
    echo "| $a | $b | $c |"
    i=$((i+3))
  done
  echo
}

# TLDR — only emit if any degraded service
emit_tldr_external() {
  local bad
  bad=$(jq -r '.services[] | select(.indicator!="none" and .indicator!="ok" and .indicator!="operational") | "- \(.indicator | ascii_upcase): **\(.name)** — \(.label)"' "$EXT_SRC" 2>/dev/null)
  if [[ -n "$bad" ]]; then
    echo "**TLDR · externos**"
    echo
    echo "$bad"
    echo
  fi
}

emit_modo() {
  [[ -z "$MODO_SRC" || ! -s "$MODO_SRC" ]] && return

  local ok reason
  ok=$(jq -r '.ok // false' "$MODO_SRC" 2>/dev/null)
  reason=$(jq -r '.reason // "?"' "$MODO_SRC" 2>/dev/null)

  if [[ "$ok" != "true" ]]; then
    echo "**status.modo.com.ar** — _$reason_ (ver \`reference/auth-setup.md\` para wire-up auth)"
    echo
    return
  fi

  local inc_count svc_count
  inc_count=$(jq '.incidents | length' "$MODO_SRC" 2>/dev/null)
  svc_count=$(jq '.services  | length' "$MODO_SRC" 2>/dev/null)

  echo "**status.modo.com.ar** — $svc_count servicios catalogados · $inc_count incidents recientes"
  echo

  # Open incidents (no end date / not resolved)
  local open_inc
  open_inc=$(jq -r '.incidents[] | select((.endedAt // .resolvedAt // .closedAt) == null) | "- **\(.title // .name // "incident")** — \(.severity // .status // "?") · \(.startedAt // .createdAt // "?")"' "$MODO_SRC" 2>/dev/null)

  if [[ -n "$open_inc" ]]; then
    echo "**TLDR · MODO incidents abiertos**"
    echo
    echo "$open_inc"
    echo
  fi
}

ts=$(jq -r '.ts // 0' "$EXT_SRC" 2>/dev/null)
now=$(date +%s)
age=$((now - ts))
if   [[ $age -lt 60   ]]; then age_str="${age}s ago"
elif [[ $age -lt 3600 ]]; then age_str="$((age/60))m ago"
elif [[ $age -lt 86400 ]]; then age_str="$((age/3600))h ago"
else                           age_str="$((age/86400))d ago"
fi

echo "_snapshot cacheado · $age_str · refresh: \`motd-refresh\` o re-correr \`check-external.sh\`_"
echo
emit_grid
emit_tldr_external
emit_modo
