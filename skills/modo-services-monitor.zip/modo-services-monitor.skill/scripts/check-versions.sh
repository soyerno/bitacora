#!/usr/bin/env bash
# modo-services-monitor — fetch last deployment per env for MODO repos
# Walks the workspace (~/Documents/Proyectos/modo) discovering playsistemico/*
# repos via the origin remote, then queries gh API for latest deployment per env.
#
# Auth: relies on `gh auth status` — no extra config needed.
#
# Output: JSON to stdout (or $1).
#   {
#     "ts": <unix>,
#     "repos": [
#       {
#         "repo": "modo-landing",
#         "path": "/Users/.../modo-landing",
#         "envs": {
#           "production": {"sha": "34cdfab", "ref": "main", "created_at": "..."},
#           "preprod":    {...},
#           "qa":         {...},
#           "develop":    {...}
#         }
#       }
#     ]
#   }

set -u

WORKSPACE="${MSM_WORKSPACE:-${HOME}/Documents/Proyectos/modo}"
OUT="${1:-/dev/stdout}"
ENVS="${MSM_ENVS:-production preprod qa develop}"
MAX_REPOS="${MSM_MAX_REPOS:-30}"

if ! command -v gh >/dev/null 2>&1; then
  echo '{"ts":0,"repos":[],"error":"gh CLI not in PATH"}' > "$OUT"
  exit 0
fi

if ! gh auth status >/dev/null 2>&1; then
  echo '{"ts":0,"repos":[],"error":"gh not authenticated — run `gh auth login`"}' > "$OUT"
  exit 0
fi

# Discover playsistemico repos
declare -a REPO_PATHS=()
declare -a REPO_NAMES=()

while IFS= read -r gitdir; do
  repo_root="$(dirname "$gitdir")"
  remote="$(git -C "$repo_root" remote get-url origin 2>/dev/null)"
  [[ "$remote" == *playsistemico/* ]] || continue
  # Extract repo name: anything after 'playsistemico/' minus trailing .git
  name="${remote##*playsistemico/}"
  name="${name%.git}"
  REPO_PATHS+=("$repo_root")
  REPO_NAMES+=("$name")
  [[ ${#REPO_PATHS[@]} -ge $MAX_REPOS ]] && break
done < <(find "$WORKSPACE" -maxdepth 4 -name ".git" -type d 2>/dev/null)

# Dedupe (keep first occurrence) — bash 3.2 compat, no associative arrays
SEEN_LIST=""
U_PATHS=()
U_NAMES=()
for i in "${!REPO_NAMES[@]}"; do
  n="${REPO_NAMES[$i]}"
  case " $SEEN_LIST " in
    *" $n "*) continue ;;
  esac
  SEEN_LIST="$SEEN_LIST $n"
  U_NAMES+=("$n")
  U_PATHS+=("${REPO_PATHS[$i]}")
done

# Fetch latest deployment per env per repo (parallel)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

fetch_repo() {
  local name="$1" path="$2" outf="$3"
  local env_json=""
  local first_env=1

  for env in $ENVS; do
    # Pull latest 1 deployment for this env
    local resp
    resp=$(gh api "repos/playsistemico/${name}/deployments?environment=${env}&per_page=1" 2>/dev/null)
    local sha ref created
    sha=$(printf '%s' "$resp" | jq -r '.[0].sha // empty' 2>/dev/null)
    ref=$(printf '%s' "$resp" | jq -r '.[0].ref // empty' 2>/dev/null)
    created=$(printf '%s' "$resp" | jq -r '.[0].created_at // empty' 2>/dev/null)

    [[ $first_env -eq 1 ]] && first_env=0 || env_json+=","
    if [[ -n "$sha" ]]; then
      env_json+="\"${env}\":{\"sha\":\"${sha:0:7}\",\"ref\":\"${ref}\",\"created_at\":\"${created}\"}"
    else
      env_json+="\"${env}\":null"
    fi
  done

  printf '{"repo":"%s","path":"%s","envs":{%s}}\n' "$name" "$path" "$env_json" > "$outf"
}

for i in "${!U_NAMES[@]}"; do
  fetch_repo "${U_NAMES[$i]}" "${U_PATHS[$i]}" "$tmp/$i.json" &
done
wait

now=$(date +%s)
{
  printf '{"ts":%d,"repos":[' "$now"
  first=1
  for part in "$tmp"/*.json; do
    [[ -s "$part" ]] || continue
    [[ $first -eq 1 ]] && first=0 || printf ','
    cat "$part"
  done
  printf ']}\n'
} > "$OUT"
