---
name: modo-services-monitor
description: Service-status panel para MODO + ecosistema externo. Auto-invocable cuando el user pregunta "cómo están los servicios", "están todos los servicios up", "status de servicios", "service status", "qué versión está en prod", "qué hay desplegado en preprod", "/services-status", "/motd-status" o pide ver el panel del MOTD. Tres capas: (1) statuspages externos + MODO público vía MOTD cache; (2) `status.modo.com.ar/api/last-incidents` con JWT opt-in; (3) versiones desplegadas por env vía GitHub Deployments API cruzando con repos del workspace. Soporta modo compact (default) y verbose (detalle por servicio + impacto en MODO + tabla de versiones). Renderea Markdown grid 3×N + TLDR solo si hay degradación (🟡🟠🔴).
---

# modo-services-monitor

Skill MODO para responder rápido "¿cómo están los servicios?" desde cualquier proyecto sin abrir la terminal ni navegar a status.modo.com.ar.

## Cuándo se invoca

**Manual / explícito**:
- `/services-status`, `/motd-status`
- "como están los servicios"
- "está todo up"
- "hay algún incident"
- "service status"
- "muéstrame el estatus" / "muéstrame con detalle"
- "qué versión está en prod"
- "qué hay desplegado en preprod"
- "qué versión tiene `<repo>` en `<env>`"

**Implícito**:
- User reporta un bug raro y se sospecha incident externo (Cloudflare, GitHub, npm caído).
- User pregunta por uptime de modo.com.ar / promos / merchants / developers.
- User pide cruzar con incidents internos del status-page oficial MODO.
- User pregunta por estado de un repo MODO o el último deploy de un env.

**Detección de modo**:
- Verbose si el user dice "con detalle", "completo", "verbose", "todo", "qué impacto tiene", "y las versiones", "y qué está deployado".
- Compact otherwise.

## Tres capas de data

### Capa 1 · Externos + MODO público (always-on, anon)

Read `~/.cache/motd-status/status.json` (cache del MOTD del shell). Si no existe o tiene >5min, correr:

```bash
bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh ~/.cache/motd-status/status.json
```

Polea 13 endpoints:

| Categoría | Servicios |
|---|---|
| AI/dev infra | GitHub · Claude · OpenAI · Datadog · Cloudflare · GCP · npm · Vercel |
| MODO público | modo.com.ar · /promos · merchants.playdigital.com.ar · developers.modo.com.ar · status.modo.com.ar |

Sin auth. Pull paralelo, ~800ms.

### Capa 2 · status.modo.com.ar interno (opt-in, auth)

Fuente canónica MODO: `playsistemico/status-page` (Remix + Prisma + Auth0) servida en https://status.modo.com.ar. Modela Service · Bank · Flow · Incident · Squad · Subscription.

APIs relevantes (autenticadas con Cookie o JWT Auth0):
- `GET /api/last-incidents` → incidents recientes con severidad
- `GET /api/services` → catálogo de servicios MODO
- `GET /api/banks` → bancos asociados
- `GET /api/flows` → flujos críticos
- `GET /api/incidents.filter` → filter ad-hoc

**Auth setup** — ver `reference/auth-setup.md`. Resumen: setear `MODO_STATUS_JWT` o `MODO_STATUS_COOKIE` en env o en `~/.config/modo-services-monitor.env`.

Sin auth → la skill ignora capa 2 silenciosamente (no rompe la respuesta).

### Capa 3 · Versiones desplegadas (workspace + gh API)

Para cada repo `playsistemico/*` cloneado en `~/Documents/Proyectos/modo/` (recursivo, max 4 niveles), consulta `gh api repos/playsistemico/<repo>/deployments?environment=<env>&per_page=1` para los envs `develop · qa · preprod · production`. Devuelve `{sha, ref, created_at}` del último deployment registrado.

**Discovery**: walk `find $WORKSPACE -maxdepth 4 -name ".git" -type d`, extrae `origin` remote, filtra por `playsistemico/`. Dedupe por repo name (un repo cloneado en varios paths cuenta una vez).

**Auth**: usa `gh auth status` — no extra config.

**Cuando emitir**: solo en modo `verbose`. En modo `compact` no se ejecuta (latencia ~3-5s por workspace de 25 repos).

## Modos de render

| Modo | Trigger | Contenido |
|---|---|---|
| `compact` (default) | "cómo están los servicios", "/services-status" | Grid 3×N + TLDR si hay degradación |
| `verbose` | "muéstrame con detalle", "verbose", "completo", "qué versión hay en prod", "y las versiones" | Compact + per-service WHAT/IMPACT + tabla versiones × envs + catálogo repos |

`render.sh` acepta el modo como arg (`verbose|compact|detailed`) o env var `MSM_MODE`.

## Workflow estándar

### Compact mode

```bash
# Paso 1 — refresh externos (skip si cache < 5min)
bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh \
  ~/.cache/motd-status/status.json

# Paso 2 — fetch MODO interno (skip si no hay auth)
bash ~/.claude/skills/modo-services-monitor/scripts/check-modo.sh \
  > /tmp/msm-modo.json

# Paso 3 — render
MSM_MODO_JSON=/tmp/msm-modo.json \
  bash ~/.claude/skills/modo-services-monitor/scripts/render.sh
```

### Verbose mode (con versiones)

```bash
# Paralelizá las 3 capas
bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh ~/.cache/motd-status/status.json &
bash ~/.claude/skills/modo-services-monitor/scripts/check-modo.sh > /tmp/msm-modo.json &
MSM_MAX_REPOS=25 bash ~/.claude/skills/modo-services-monitor/scripts/check-versions.sh /tmp/msm-versions.json &
wait

# Render verbose
MSM_MODO_JSON=/tmp/msm-modo.json \
MSM_VERSIONS_JSON=/tmp/msm-versions.json \
  bash ~/.claude/skills/modo-services-monitor/scripts/render.sh verbose ~/.cache/motd-status/status.json
```

Output: grid + TLDR + per-service WHAT/IMPACT + tabla versiones × envs + catálogo repos.

## Reglas duras

1. **No spam de probes** — si `~/.cache/motd-status/status.json` tiene <5min de antigüedad (`MSM_TTL`), no re-correr `check-external.sh`. Read directo.
2. **TLDR solo si hay degradación** — todo verde → solo grid + age. Nunca explicar lo obvio.
3. **MODO Merchants HTTP 404 root es esperado** — no flaggearlo como down. El host responde, simplemente no hay `/`. Indicator queda `none`.
4. **Capa 2 nunca rompe la respuesta** — si auth falla, mostrar grid de capa 1 + nota "_status.modo.com.ar — auth no configurada_" y seguir.
5. **Capa 3 solo en verbose** — `check-versions.sh` toma 3-5s contra el workspace completo. No bloqueante en compact.
6. **No exponer JWT/cookie** — `MODO_STATUS_JWT` y `MODO_STATUS_COOKIE` nunca se loguean ni se imprimen. Si el user pide ver el JWT, decir "está en `~/.config/modo-services-monitor.env`" sin imprimirlo.
7. **Statuspages indicator vocabulary**: `none | minor | major | critical | maintenance`. Mapping a emoji en `render.sh`.
8. **Bash `set -u` + var interpolation ambigua** — usar `${var}` siempre que el char siguiente sea válido como identifier (`_`, letra, dígito). Bash 3.2 toma el char trailing como parte del nombre de la var → `unbound variable` o expansion incorrecta. Caso canónico cazado: `_$reason_` → bash leyó `$reason_`. Fix: `_${reason}_`.
9. **Bash 3.2 (macOS default) no soporta `declare -A`** — para dedupe de listas usar string flat + `case " $list " in *" $x "*) continue ;; esac`. No assumir bash 4+.
10. **Workspace discovery** — `find $WORKSPACE -maxdepth 4 -name ".git" -type d` + `git remote get-url origin` + grep `playsistemico/`. Dedupe por repo name, NO por path (un repo cloneado 2x cuenta una sola vez).

## Glosario de indicadores

| Emoji | Indicator | Significado |
|---|---|---|
| 🟢 | `none` / `ok` / `operational` | OK |
| 🟡 | `minor` | Minor outage / degraded |
| 🟠 | `major` | Major outage |
| 🔴 | `critical` / `down` | Down / critical |
| 🔵 | `maintenance` | Mantenimiento programado |
| ⚪ | `?` | Unknown / unreachable |

## Roadmap

- **V1.0** (ship) — Capa 1 (externos + MODO público) + Capa 2 opt-in via JWT/cookie.
- **V1.1** — Auth0 client_credentials flow (machine-to-machine) si Cyber aprueba CLIENT_ID + SECRET para CLI use.
- **V1.2** — Hook al MOTD del shell: el render del skill comparte el mismo formato que `motd_status_render` para consistencia visual.
- **V1.3** — Watch mode: `--watch 30s` para polling continuo (útil durante incident response).

## Comparación con status-page oficial

| | `playsistemico/status-page` | `modo-services-monitor` (esta skill) |
|---|---|---|
| Escala | Sistema MODO completo · 30+ services · banks · flows · SLA · newsletters | Snapshot rápido · 13 endpoints clave |
| Persistencia | Postgres + Prisma + Auth0 | Cache local JSON · ephemeral |
| Audiencia | SREs MODO · admin curated incidents | Desarrolladores individuales · self-service |
| Auth | Auth0 obligatorio · Cookie o JWT | Auth opcional (capa 2) |
| Acceso | https://status.modo.com.ar (login) | Claude Code en cualquier proyecto |

Esta skill **NO reemplaza** al status-page oficial. Es complemento dev-facing: cruza statuspages externos (no cubiertos por el portal) con la lista oficial de MODO via API.
