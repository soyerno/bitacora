# modo-services-monitor

Service-status panel para MODO desde Claude Code. Responde "¿cómo están los servicios?" sin abrir terminal ni navegar al status-page oficial.

## Qué hace

- **Capa 1 (anon)**: pull paralelo a 8 statuspages externos (GitHub · Claude · OpenAI · Datadog · Cloudflare · GCP · npm · Vercel) + 5 HTTP probes MODO (modo.com.ar · /promos · merchants · developers · status).
- **Capa 2 (opt-in, auth)**: fetch a `status.modo.com.ar/api/last-incidents` + `/api/services` cuando hay JWT/cookie. Cruza con la fuente canónica MODO.
- Renderea grid Markdown 3×N + TLDR solo si hay degradación (🟡🟠🔴) o incidents abiertos.

## Install

```bash
# Ya viene como skill local en ~/.claude/skills/modo-services-monitor/
# Auto-invocable. No requiere setup.

# Opcional — capa 2 MODO interna:
echo 'MODO_STATUS_JWT=eyJhbGc...' > ~/.config/modo-services-monitor.env
chmod 600 ~/.config/modo-services-monitor.env
```

Ver `reference/auth-setup.md` para cómo extraer el JWT/cookie desde el browser.

## Uso desde Claude Code

```
> como estan los servicios
> /services-status
> hay algún incident hoy
> está MODO up
```

Cualquiera de esos triggers invoca la skill. Output: grid + TLDR.

## Uso desde terminal

```bash
# Refresh externos
bash ~/.claude/skills/modo-services-monitor/scripts/check-external.sh \
  ~/.cache/motd-status/status.json

# Fetch MODO (necesita auth)
bash ~/.claude/skills/modo-services-monitor/scripts/check-modo.sh

# Render
bash ~/.claude/skills/modo-services-monitor/scripts/render.sh
```

## Comparación con `~/.config/motd-status.sh`

| | MOTD (`motd-status.sh`) | Skill `modo-services-monitor` |
|---|---|---|
| Triggered by | Cada terminal abierta | Comando del user en Claude Code |
| Output | Terminal ANSI (3×4 grid coloreado) | Markdown table 3×N + TLDR |
| Cache | `~/.cache/motd-status/status.json` | Mismo cache (reusa) |
| Capa 2 MODO interna | No | Sí (opt-in) |
| Refresh | `motd-refresh` desde shell | Auto al expirar cache (5min) |

Los dos comparten el cache, así que la skill se beneficia gratis del polling que ya hace el MOTD al abrir terminales.

## Archivos

```
~/.claude/skills/modo-services-monitor/
├── SKILL.md                      # Metadata + reglas
├── README.md                     # Este archivo
├── scripts/
│   ├── check-external.sh         # 13 endpoints públicos (capa 1)
│   ├── check-modo.sh             # status.modo.com.ar/api/* (capa 2, auth)
│   └── render.sh                 # Markdown grid + TLDR
└── reference/
    └── auth-setup.md             # Cómo conseguir JWT/cookie
```

## Changelog

- **2026-05-25** — **V1.1** ship. Agregado capa 3 (versiones desplegadas vía gh Deployments API), modo verbose con per-service WHAT/IMPACT (catálogo en `data/services-catalog.json`), bug fix bash `set -u` interpolation (`${reason}`), bash 3.2 compat para dedupe sin `declare -A`. Nuevos: `scripts/check-versions.sh`, `data/services-catalog.json`, `reference/bash-portability-rules.md`, `reference/github-deployments-api.md`.
- **2026-05-25** — **V1.0** ship inicial. Capa 1 (8 statuspages + 5 HTTP probes MODO) + capa 2 opt-in (`status.modo.com.ar/api`). PR #44 a erno-modo bitácora.

## Roadmap

- V1.2 — Auth0 m2m (si Cyber aprueba CLIENT_ID + SECRET vía JSM)
- V1.3 — Drift detection (prod ↔ preprod) automática en verbose
- V1.4 — Hook visual al MOTD del shell
- V1.5 — Watch mode `--watch 30s`

## Source-of-truth

- `playsistemico/status-page` — status page interna MODO, Remix + Prisma + Auth0
- `~/.config/motd-status.sh` — MOTD del shell que polea los mismos endpoints
- Memoria asociada: `reference_motd_status_monitor.md`, `reference_modo_services_monitor.md`
